# External comparison harness

This directory is intentionally separate from the GT-R paper source.

Run with the bundled Python environment:

```sh
<REDACTED_LOCAL_PATH>/
  run_external_comparison.py --repetitions 1000 --kem-samples 100
```

To retain the completed Windows reference measurements while recalibrating the
GT-R rows from the packaged 2026-09-30 WSL2 network rerun, run:

```sh
python3 refresh_with_20260930_network_results.py \
  --package-root .. \
  --paper-macros ../gtr-experiment-upgrade/sim/results/external_comparison_macros.tex
```

The refresh records both the original Windows measurement platform and the
platform used for the deterministic derivation in `results/manifest.json`.

`reference_protocols.py` contains independent, clean-room D2D-MAP and PAF-IoD
control-flow references.  They are not original-author implementations.  Read
`REPORT_KR.md` and `results/manifest.json` before using any result: the PUF and
AEGIS paths use disclosed surrogates, the KEMTLS structural sample uses current
ML-KEM-768 instead of the paper's NIST-round-2 suite, and the common network
results are controlled application-layer emulations rather than radio tests.
