#!/usr/bin/env python3
"""Refresh the external-comparison outputs with the 2026-09-30 network rerun.

The external D2D-MAP, PAF-IoD, and KEMTLS measurements were collected on
Windows and are retained verbatim.  This script recalibrates only the GT-R
common-model rows from the new RTT-10 raw trials, refreshes the direct GT-R and
mutual PQ-TLS rows, regenerates the LaTeX macros, and records both measurement
and refresh provenance in the manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

import run_external_comparison as comparison


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def replace_scheme_rows(
    existing: list[dict[str, object]],
    replacement: list[dict[str, object]],
    scheme: str,
) -> list[dict[str, object]]:
    replacement_iter = iter(row for row in replacement if row["scheme"] == scheme)
    refreshed: list[dict[str, object]] = []
    for row in existing:
        if row["scheme"] == scheme:
            refreshed.append(next(replacement_iter))
        else:
            refreshed.append(row)
    try:
        next(replacement_iter)
    except StopIteration:
        return refreshed
    raise RuntimeError(f"replacement row count mismatch for {scheme}")


def selected(
    rows: list[dict[str, object]], scheme: str, loss_percent: float
) -> dict[str, object]:
    for row in rows:
        if (
            row["scheme"] == scheme
            and float(row["rtt_ms"]) == 100.0
            and float(row["loss_percent"]) == loss_percent
        ):
            return row
    raise KeyError((scheme, loss_percent))


def macro_text(
    normal: list[dict[str, object]], loss: list[dict[str, object]]
) -> str:
    lines = ["% Generated from the 2026-09-30 network rerun; do not edit manually."]
    specs = (
        ("ExtDtwoD", "D2D-MAP reference"),
        ("ExtPaf", "PAF-IoD reference"),
        ("ExtKemtls", "KEMTLS structural reference"),
        ("ExtGtr", "GT-R calibrated profile"),
    )
    for prefix, scheme in specs:
        zero = selected(normal, scheme, 0.0)
        loss20 = selected(loss, scheme, 20.0)
        lines.extend(
            [
                rf"\newcommand{{\{prefix}Trials}}{{{int(zero['trials'])}}}",
                rf"\newcommand{{\{prefix}Messages}}{{{int(zero['messages'])}}}",
                rf"\newcommand{{\{prefix}Bytes}}{{{int(zero['protocol_bytes'])}}}",
                rf"\newcommand{{\{prefix}ZeroMedian}}{{{float(zero['median_completion_ms']):.3f}}}",
                rf"\newcommand{{\{prefix}ZeroPtf}}{{{float(zero['p95_completion_ms']):.3f}}}",
                rf"\newcommand{{\{prefix}TwentySuccess}}{{{float(loss20['success_rate_percent']):.1f}}}",
                rf"\newcommand{{\{prefix}TwentyMedian}}{{{float(loss20['median_completion_ms_successes']):.3f}}}",
                rf"\newcommand{{\{prefix}TwentyPtf}}{{{float(loss20['p95_completion_ms_successes']):.3f}}}",
            ]
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--package-root",
        type=Path,
        default=HERE.parent,
        help="root containing linux-rerun-20260930",
    )
    parser.add_argument(
        "--paper-macros",
        type=Path,
        default=None,
        help="optional second destination for the regenerated LaTeX macros",
    )
    args = parser.parse_args()
    package_root = args.package_root.resolve()

    gtr_summary = package_root / "linux-rerun-20260930/network/gtr-mutual-rtt-main-n100/summary.csv"
    pqtls_summary = package_root / "linux-rerun-20260930/network/pq-tls-mutual-rtt-n100/summary.csv"
    gtr_raw = package_root / "linux-rerun-20260930/network/gtr-mutual-rtt-main-n100/scratch"
    for required in (gtr_summary, pqtls_summary, gtr_raw):
        if not required.exists():
            raise FileNotFoundError(required)

    comparison.GTR_ACTUAL = gtr_summary
    comparison.PQTLS_ACTUAL = pqtls_summary
    comparison.GTR_RTT10_RAW = gtr_raw

    manifest_path = RESULTS / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    repetitions = int(manifest["common_model_trials_per_condition"])
    seed = int(manifest["seed"])

    cpu_rows: list[dict[str, object]] = comparison.load_csv(RESULTS / "cpu_reference.csv")
    sample_counts = {row["scheme"]: int(row["samples"]) for row in cpu_rows}
    gtr_local = comparison.load_gtr_local_samples()
    if len(gtr_local) != 100:
        raise RuntimeError(f"expected 100 RTT-10 GT-R samples, found {len(gtr_local)}")

    for row in cpu_rows:
        if row["scheme"] == "GT-R calibrated local component":
            row.update(
                {
                    "samples": len(gtr_local),
                    "median_ms": round(statistics.median(gtr_local), 6),
                    "p95_ms": round(comparison.percentile(gtr_local, 0.95), 6),
                    "min_ms": round(min(gtr_local), 6),
                    "max_ms": round(max(gtr_local), 6),
                    "measurement": "2026-09-30 RTT-10 rerun residual after subtracting 4 RTT",
                }
            )
            break
    else:
        raise RuntimeError("missing GT-R calibrated CPU row")

    profiles = [
        comparison.Profile(
            "D2D-MAP reference",
            (42, 58, 34, 42, 42),
            5,
            tuple(0.0 for _ in range(sample_counts["D2D-MAP reference"])),
            "independent executable; HMAC CRP-table PUF surrogate",
        ),
        comparison.Profile(
            "PAF-IoD reference",
            (100, 100, 100),
            3,
            tuple(0.0 for _ in range(sample_counts["PAF-IoD reference"])),
            "independent executable; AES-GCM/PUF surrogates",
        ),
        comparison.Profile(
            "KEMTLS structural reference",
            (1250, 6000, 1100, 1048),
            4,
            tuple(0.0 for _ in range(sample_counts["KEMTLS structure ML-KEM-768"])),
            "independent two-KEM structure with ML-KEM-768; 9398-B KKDD wire profile",
        ),
        comparison.Profile(
            "GT-R calibrated profile",
            (3200, 4400, 1600, 100, 365, 364),
            6,
            tuple(gtr_local),
            "2026-09-30 executable GT-R local overhead; common model begins at M1",
        ),
    ]

    regenerated_normal = comparison.normal_experiment(profiles, repetitions, seed)
    regenerated_loss = comparison.loss_experiment(profiles, repetitions, seed + 1)
    old_normal: list[dict[str, object]] = comparison.load_csv(RESULTS / "normal_same_model.csv")
    old_loss: list[dict[str, object]] = comparison.load_csv(RESULTS / "loss_same_model.csv")
    normal = replace_scheme_rows(old_normal, regenerated_normal, "GT-R calibrated profile")
    loss = replace_scheme_rows(old_loss, regenerated_loss, "GT-R calibrated profile")

    comparison.write_csv(RESULTS / "cpu_reference.csv", cpu_rows)
    comparison.write_csv(RESULTS / "normal_same_model.csv", normal)
    comparison.write_csv(RESULTS / "loss_same_model.csv", loss)
    comparison.write_csv(
        RESULTS / "existing_and_reported_measurements.csv",
        comparison.existing_and_reported(),
    )

    macros = macro_text(normal, loss)
    (RESULTS / "external_comparison_macros.tex").write_text(macros, encoding="utf-8")
    if args.paper_macros is not None:
        args.paper_macros.parent.mkdir(parents=True, exist_ok=True)
        args.paper_macros.write_text(macros, encoding="utf-8")

    refresh_time = datetime.now(timezone.utc).isoformat()
    boundaries = [
        item
        for item in manifest["important_boundaries"]
        if not item.startswith("GT-R common-model local cost is calibrated")
    ]
    boundaries.append(
        "GT-R common-model local cost is calibrated from the 2026-09-30 RTT-10 WSL2 netns rerun after removing its measured network component."
    )
    manifest["generated_utc"] = refresh_time
    manifest["important_boundaries"] = boundaries
    manifest["source_hashes"] = {
        "reference_protocols.py": sha256_file(HERE / "reference_protocols.py"),
        "run_external_comparison.py": sha256_file(HERE / "run_external_comparison.py"),
        "refresh_with_20260930_network_results.py": sha256_file(Path(__file__)),
        "rerun_gtr_summary.csv": sha256_file(gtr_summary),
        "rerun_pqtls_summary.csv": sha256_file(pqtls_summary),
    }
    manifest["refresh"] = {
        "generated_utc": refresh_time,
        "platform": platform.platform(),
        "python": sys.version,
        "method": "retained Windows external-reference measurements and recalibrated only GT-R-derived rows",
        "external_reference_platform": manifest["platform"],
        "gtr_network_environment": "Windows 11 host with WSL2 Linux netns/tc",
        "gtr_rtt10_samples": len(gtr_local),
    }
    if "refresh_report.json" not in manifest["outputs"]:
        manifest["outputs"].append("refresh_report.json")
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    gtr_zero = selected(normal, "GT-R calibrated profile", 0.0)
    gtr_loss20 = selected(loss, "GT-R calibrated profile", 20.0)
    report = {
        "schema": "gtr.external-comparison.network-refresh.v1",
        "generated_utc": refresh_time,
        "source_hashes": {
            "gtr_summary": sha256_file(gtr_summary),
            "pqtls_summary": sha256_file(pqtls_summary),
        },
        "gtr_common_model_100ms": {
            "median_ms": float(gtr_zero["median_completion_ms"]),
            "p95_ms": float(gtr_zero["p95_completion_ms"]),
        },
        "gtr_common_model_20pct_loss": {
            "success_percent": float(gtr_loss20["success_rate_percent"]),
            "median_ms": float(gtr_loss20["median_completion_ms_successes"]),
            "p95_ms": float(gtr_loss20["p95_completion_ms_successes"]),
        },
        "preserved_schemes": [
            "D2D-MAP reference",
            "PAF-IoD reference",
            "KEMTLS structural reference",
        ],
    }
    (RESULTS / "refresh_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
