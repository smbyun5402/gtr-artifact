#!/usr/bin/env python3
"""Run external GT-R comparison experiments without editing the paper.

Outputs:
  results/reference_validation.json
  results/cpu_reference.csv
  results/normal_same_model.csv
  results/loss_same_model.csv
  results/infrastructure_outage.csv
  results/existing_and_reported_measurements.csv
  results/feature_matrix.csv
  results/external_comparison_macros.tex
  results/manifest.json

The common network experiments are controlled application-layer emulations.
They execute D2D-MAP and PAF-IoD reference cryptography, benchmark a current
ML-KEM-768 implementation of the KEMTLS key-transport structure, and calibrate
GT-R local overhead from the 2026-09-30 executable RTT-10 rerun.  They are not
physical-radio experiments and must not be described as original-author code.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import hmac
import importlib.util
import json
import math
import os
import platform
import random
import shutil
import statistics
import sys
import tempfile
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from reference_protocols import D2DMAPReference, PAFIoDReference, h


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
RESULTS = HERE / "results"
PAPER_MACROS = WORKSPACE / "gtr-experiment-upgrade/sim/results/external_comparison_macros.tex"
OPENSSL = WORKSPACE / "tmp/zerotrust_fix/openssl-4.0.1/apps/openssl"
GTR_CORE = WORKSPACE / "gtr-experiment-upgrade/testbed/reauth_demo.py"
GTR_ACTUAL = (
    WORKSPACE
    / "linux-rerun-20260930/network/gtr-mutual-rtt-main-n100/summary.csv"
)
PQTLS_ACTUAL = (
    WORKSPACE
    / "linux-rerun-20260930/network/pq-tls-mutual-rtt-n100/summary.csv"
)
GTR_RTT10_RAW = (
    WORKSPACE
    / "linux-rerun-20260930/network/gtr-mutual-rtt-main-n100/scratch"
)


def percentile(values: list[float], q: float) -> float:
    if not values:
        return math.nan
    ordered = sorted(values)
    pos = (len(ordered) - 1) * q
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return ordered[lo]
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (pos - lo)


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"no rows for {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def benchmark_reference(name: str, protocol: object, repetitions: int) -> tuple[list[float], dict]:
    timings = []
    last = None
    for _ in range(repetitions):
        started = time.perf_counter_ns()
        last = protocol.run()
        timings.append((time.perf_counter_ns() - started) / 1_000_000.0)
        if not last.success or not last.agreed_key:
            raise RuntimeError(f"{name} reference execution failed")
    assert last is not None
    return timings, asdict(last)


def import_gtr_core():
    # The packaged executable is a macOS binary.  Use it only when runnable on
    # the current host; the Windows rerun falls back to the OpenSSL-backed
    # cryptography bindings exposed by the same GT-R primitive wrapper.
    if OPENSSL.exists() and os.name != "nt":
        os.environ["OPENSSL"] = str(OPENSSL)
    else:
        os.environ.pop("OPENSSL", None)
    spec = importlib.util.spec_from_file_location("gtr_comparison_core", GTR_CORE)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load GT-R primitive wrapper")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    ok, version = module.openssl_ok()
    if not ok or "OpenSSL 4." not in version:
        raise RuntimeError(f"OpenSSL 4 unavailable: {version}")
    return module, version


def benchmark_kemtls_structure(repetitions: int) -> tuple[list[float], dict, str]:
    """Benchmark the two-KEM core shown in KEMTLS Fig. 2.

    The paper used NIST-round-2 Kyber/Dilithium configurations.  This clean-room
    executable uses standardized ML-KEM-768 and verifies both encapsulation
    equalities plus the final confirmation MAC.  It is therefore a current-
    primitive structural reference, not a reproduction of KKDD timings.
    """
    core, openssl_version = import_gtr_core()
    timings: list[float] = []
    with tempfile.TemporaryDirectory(
        prefix="kemtls-ref-", dir=tempfile.gettempdir()
    ) as tmp:
        core.WORK = tmp
        server_sk, server_pk = core.mlkem_keygen("kemtls-server-static")
        verified = 0
        for index in range(repetitions):
            started = time.perf_counter_ns()
            client_sk, client_pk = core.mlkem_keygen(f"kemtls-client-{index}")
            try:
                ct_e, ss_e_server = core.mlkem_encap(client_pk)
                ss_e_client = core.mlkem_decap(client_sk, ct_e)
                ct_s, ss_s_client = core.mlkem_encap(server_pk)
                ss_s_server = core.mlkem_decap(server_sk, ct_s)
                client_key = h(ss_e_client, ss_s_client, b"KEMTLS-reference")
                server_key = h(ss_e_server, ss_s_server, b"KEMTLS-reference")
                confirm = hmac.new(server_key, b"server-finished", hashlib.sha256).digest()
                expected = hmac.new(client_key, b"server-finished", hashlib.sha256).digest()
                if not (
                    hmac.compare_digest(ss_e_server, ss_e_client)
                    and hmac.compare_digest(ss_s_server, ss_s_client)
                    and hmac.compare_digest(confirm, expected)
                ):
                    raise RuntimeError("KEMTLS structural reference key mismatch")
                verified += 1
            finally:
                for path in (client_sk, client_pk):
                    Path(path).unlink(missing_ok=True)
            timings.append((time.perf_counter_ns() - started) / 1_000_000.0)
        meta = {
            "sessions": repetitions,
            "verified": verified,
            "primitive": "ML-KEM-768",
            "kem_operations_per_session": "1 ephemeral keygen, 2 encapsulations, 2 decapsulations",
            "server_static_keygen_timed": False,
            "process_launch_included": core.CRYPTO_BACKEND == "openssl-cli",
            "crypto_backend": core.CRYPTO_BACKEND,
            "original_KKDD_reproduced": False,
        }
    return timings, meta, openssl_version


def load_gtr_local_samples() -> list[float]:
    samples: list[float] = []
    for path in sorted(GTR_RTT10_RAW.glob("rtt10-loss0-*.initiator.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        # Existing fit is approximately four RTTs from TCP connect through
        # protected ACK_R.  Subtract that network component for the common
        # application-layer comparison while retaining process/scheduler cost.
        samples.append(max(0.0, float(data["mutual_adoption_ttsc_ms"]) - 40.0))
    if not samples:
        raise FileNotFoundError("GT-R RTT-10 raw trials not found")
    return samples


@dataclass(frozen=True)
class Profile:
    name: str
    message_sizes: tuple[int, ...]
    one_way_delays: int
    cpu_samples_ms: tuple[float, ...]
    implementation: str

    @property
    def protocol_bytes(self) -> int:
        return sum(self.message_sizes)


def normal_experiment(profiles: list[Profile], repetitions: int, seed: int) -> list[dict[str, object]]:
    rng = random.Random(seed)
    rows: list[dict[str, object]] = []
    rate_bps = 10_000_000.0
    for profile in profiles:
        serialization_ms = profile.protocol_bytes * 8.0 / rate_bps * 1000.0
        for rtt_ms in (10.0, 50.0, 100.0, 200.0):
            values = []
            for _ in range(repetitions):
                cpu = rng.choice(profile.cpu_samples_ms)
                values.append(cpu + profile.one_way_delays * rtt_ms / 2.0 + serialization_ms)
            rows.append(
                {
                    "scheme": profile.name,
                    "rtt_ms": rtt_ms,
                    "loss_percent": 0.0,
                    "trials": repetitions,
                    "successes": repetitions,
                    "success_rate_percent": 100.0,
                    "median_completion_ms": round(statistics.median(values), 6),
                    "p95_completion_ms": round(percentile(values, 0.95), 6),
                    "messages": len(profile.message_sizes),
                    "protocol_bytes": profile.protocol_bytes,
                    "link_rate_mbps": 10.0,
                    "measurement_type": "common application-layer emulation",
                    "implementation": profile.implementation,
                }
            )
    return rows


def loss_experiment(profiles: list[Profile], repetitions: int, seed: int) -> list[dict[str, object]]:
    rng = random.Random(seed)
    rows: list[dict[str, object]] = []
    rtt_ms = 100.0
    rate_bps = 10_000_000.0
    max_retransmissions = 3
    for profile in profiles:
        for loss_percent in (0.0, 5.0, 10.0, 20.0):
            p = loss_percent / 100.0
            completion: list[float] = []
            successful_bytes: list[int] = []
            successes = retransmissions = total_bytes = 0
            for _ in range(repetitions):
                elapsed = rng.choice(profile.cpu_samples_ms)
                trial_bytes = 0
                trial_retx = 0
                trial_ok = True
                for size in profile.message_sizes:
                    delivered = False
                    for attempt in range(max_retransmissions + 1):
                        trial_bytes += size
                        elapsed += size * 8.0 / rate_bps * 1000.0
                        if rng.random() >= p:
                            elapsed += rtt_ms / 2.0
                            delivered = True
                            break
                        trial_retx += 1
                        elapsed += rtt_ms
                    if not delivered:
                        trial_ok = False
                        break
                retransmissions += trial_retx
                total_bytes += trial_bytes
                if trial_ok:
                    successes += 1
                    completion.append(elapsed)
                    successful_bytes.append(trial_bytes)
            rows.append(
                {
                    "scheme": profile.name,
                    "rtt_ms": rtt_ms,
                    "loss_percent": loss_percent,
                    "trials": repetitions,
                    "successes": successes,
                    "success_rate_percent": round(successes / repetitions * 100.0, 3),
                    "median_completion_ms_successes": round(statistics.median(completion), 6) if completion else "",
                    "p95_completion_ms_successes": round(percentile(completion, 0.95), 6) if completion else "",
                    "retransmissions_total": retransmissions,
                    "median_bytes_successes": round(statistics.median(successful_bytes), 3) if successful_bytes else "",
                    "all_attempt_bytes": total_bytes,
                    "retry_policy": "up to 3 retransmissions per logical message",
                    "measurement_type": "common stop-and-wait loss emulation",
                }
            )
    return rows


def infrastructure_experiment() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    scenarios = [
        ("all-reachable", True, True, 0, 0),
        ("peer-link-restored-infrastructure-unreachable", False, True, 5, 5),
        ("bounds-exceeded-infrastructure-unreachable", False, True, 9, 9),
        ("peer-unreachable", False, False, 5, 5),
    ]
    for scenario, infrastructure, peer, gap, drift in scenarios:
        # D2D-MAP is direct after enrollment; it has no epoch-reconciliation
        # concept, so the gap/drift columns are deliberately marked N/A.
        d2d = peer
        rows.append(
            {
                "scenario": scenario,
                "scheme": "D2D-MAP reference",
                "outcome": "Success" if d2d else "No peer link",
                "executed_path": "direct five-message peer authentication" if d2d else "no execution",
                "gap_drift_semantics": "Not defined",
            }
        )
        paf = peer and infrastructure
        rows.append(
            {
                "scenario": scenario,
                "scheme": "PAF-IoD reference",
                "outcome": "Success" if paf else ("No peer link" if not peer else "Fail: GS unavailable"),
                "executed_path": "user-GS-drone three-message route" if paf else "GS reachability check",
                "gap_drift_semantics": "Not defined",
            }
        )
        kemtls = peer
        rows.append(
            {
                "scenario": scenario,
                "scheme": "KEMTLS structural reference",
                "outcome": "Success" if kemtls else "Server unreachable",
                "executed_path": "fresh client-server handshake" if kemtls else "no execution",
                "gap_drift_semantics": "Out of scope",
            }
        )
        if not peer:
            gtr_outcome = "No peer link"
            gtr_path = "no execution"
        elif gap <= 8 and drift <= 8:
            gtr_outcome = "Success (R1)"
            gtr_path = "verifier-less bounded reconciliation"
        elif infrastructure:
            gtr_outcome = "R2 required"
            gtr_path = "full re-attestation"
        else:
            gtr_outcome = "Wait: R2 unavailable"
            gtr_path = "fail-closed bound check"
        rows.append(
            {
                "scenario": scenario,
                "scheme": "GT-R",
                "outcome": gtr_outcome,
                "executed_path": gtr_path,
                "gap_drift_semantics": f"g={gap}, delta={drift}, bounds=8",
            }
        )
    return rows


def feature_matrix() -> list[dict[str, object]]:
    return [
        {
            "scheme": "D2D-MAP",
            "topology": "drone-to-drone",
            "online_third_party_at_auth": "No",
            "mutual_endpoint_authentication": "Yes",
            "independent_epoch_reconciliation": "Not defined",
            "rollback_protection": "Not defined",
            "recovery_after_ratchet_state_disclosure": "Not applicable",
            "post_quantum_key_establishment": "No",
            "physical_PUF_required": "Yes",
            "forward_secrecy": "Not established in a ratchet/AKE model",
            "explicit_bilateral_state_adoption": "No",
        },
        {
            "scheme": "PAF-IoD",
            "topology": "user-ground station-drone",
            "online_third_party_at_auth": "Yes (ground station)",
            "mutual_endpoint_authentication": "Mediated by ground station",
            "independent_epoch_reconciliation": "Not defined",
            "rollback_protection": "Not defined",
            "recovery_after_ratchet_state_disclosure": "Not applicable",
            "post_quantum_key_establishment": "No",
            "physical_PUF_required": "Yes",
            "forward_secrecy": "Not established in a ratchet/AKE model",
            "explicit_bilateral_state_adoption": "No",
        },
        {
            "scheme": "KEMTLS (base paper flow)",
            "topology": "client-server",
            "online_third_party_at_auth": "No online CA; server must be reachable",
            "mutual_endpoint_authentication": "No (server-only base flow; client auth is an extension)",
            "independent_epoch_reconciliation": "Not defined",
            "rollback_protection": "Not defined",
            "recovery_after_ratchet_state_disclosure": "Not applicable",
            "post_quantum_key_establishment": "Yes (paper used NIST-round-2 candidates)",
            "physical_PUF_required": "No",
            "forward_secrecy": "Yes after the relevant KEMTLS stage",
            "explicit_bilateral_state_adoption": "No",
        },
        {
            "scheme": "GT-R",
            "topology": "peer-to-peer DDIL reconnect",
            "online_third_party_at_auth": "No within configured bounds",
            "mutual_endpoint_authentication": "Yes",
            "independent_epoch_reconciliation": "Yes, bounded",
            "rollback_protection": "Yes (lse and RoT counter)",
            "recovery_after_ratchet_state_disclosure": "Yes under stated freshness assumptions",
            "post_quantum_key_establishment": "Yes (ML-KEM-768)",
            "physical_PUF_required": "No",
            "forward_secrecy": "Pre-gap epoch-granular; optional delayed FS-KEM coverage",
            "explicit_bilateral_state_adoption": "Yes (CONF_I/ACK_R)",
        },
    ]


def existing_and_reported() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in load_csv(GTR_ACTUAL):
        if float(row["rtt_ms"]) in {10.0, 50.0, 100.0, 200.0}:
            rows.append(
                {
                    "scheme": "GT-R executable",
                    "condition": f"RTT {row['rtt_ms']} ms, loss 0%",
                    "trials": row["trials"],
                    "median_ms": row["mutual_ttsc_median_ms"],
                    "p95_ms": row["mutual_ttsc_p95_ms"],
                    "bytes": row["application_protocol_bytes_median"],
                    "origin": "2026-09-30 WSL2 netns rerun",
                    "timing_boundary": "TCP connect through verified ACK_R and matching bilateral adoption",
                }
            )
    for row in load_csv(PQTLS_ACTUAL):
        if float(row["rtt_ms"]) in {10.0, 50.0, 100.0, 200.0}:
            rows.append(
                {
                    "scheme": "Mutual PQ-TLS executable",
                    "condition": f"RTT {row['rtt_ms']} ms, loss 0%",
                    "trials": row["trials"],
                    "median_ms": row["median_ms"],
                    "p95_ms": row["p95_ms"],
                    "bytes": "not recorded in this summary",
                    "origin": "2026-09-30 WSL2 netns rerun",
                    "timing_boundary": "process launch through protected HTTP response and orderly close",
                }
            )
    rows.extend(
        [
            {
                "scheme": "D2D-MAP paper",
                "condition": "Arduino UNO R3, UART 9.8 kbps",
                "trials": "at least 50 consecutive runs",
                "median_ms": "not reported (mean 340.294)",
                "p95_ms": "not reported",
                "bytes": 218,
                "origin": "paper-reported",
                "timing_boundary": "complete protocol on two Arduino boards",
            },
            {
                "scheme": "PAF-IoD paper",
                "condition": "operation-count model using measured primitive times",
                "trials": "primitive averages over 100 runs",
                "median_ms": "not reported (sum 11.6279)",
                "p95_ms": "not reported",
                "bytes": 300,
                "origin": "paper-reported",
                "timing_boundary": "summed user, GS, and drone computation; network delay excluded",
            },
            {
                "scheme": "KEMTLS KKDD paper",
                "condition": "RTT 31.1 ms, 1 Gbps, loss 0%",
                "trials": 100000,
                "median_ms": "paper figure/table aggregate 63.9",
                "p95_ms": "not reported in selected table",
                "bytes": 9398,
                "origin": "paper-reported",
                "timing_boundary": "initial client send through encrypted application request",
            },
            {
                "scheme": "KEMTLS KKDD paper",
                "condition": "RTT 195.6 ms, 10 Mbps, loss 0%",
                "trials": 100000,
                "median_ms": "paper figure/table aggregate 418.9",
                "p95_ms": "not reported in selected table",
                "bytes": 9398,
                "origin": "paper-reported",
                "timing_boundary": "initial client send through encrypted application request",
            },
        ]
    )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=1000)
    parser.add_argument("--kem-samples", type=int, default=100)
    parser.add_argument("--seed", type=int, default=20260922)
    args = parser.parse_args()
    if args.repetitions < 1 or args.kem_samples < 1:
        raise SystemExit("sample counts must be positive")
    RESULTS.mkdir(parents=True, exist_ok=True)

    d2d = D2DMAPReference()
    paf = PAFIoDReference()
    d2d_times, d2d_last = benchmark_reference("D2D-MAP", d2d, args.repetitions)
    paf_times, paf_last = benchmark_reference("PAF-IoD", paf, args.repetitions)
    kem_times, kem_meta, openssl_version = benchmark_kemtls_structure(args.kem_samples)
    gtr_local = load_gtr_local_samples()

    validation = {
        "D2D-MAP": {
            "executions": args.repetitions,
            "successes": args.repetitions,
            "last_execution": d2d_last,
            "original_implementation": False,
        },
        "PAF-IoD": {
            "executions": args.repetitions,
            "successes": args.repetitions,
            "last_execution": paf_last,
            "ground_station_absent_result": asdict(paf.run(ground_station_available=False)),
            "AEGIS_reproduced": False,
            "AEAD_surrogate": "AES-GCM",
            "physical_PUF_reproduced": False,
            "PUF_surrogate": "deterministic HMAC CRP table",
            "original_implementation": False,
        },
        "KEMTLS-structure": {
            **kem_meta,
            "openssl": openssl_version,
            "paper_algorithm_suite_reproduced": False,
            "note": "Current ML-KEM-768 structural core; not original Rustls KKDD implementation.",
        },
    }
    (RESULTS / "reference_validation.json").write_text(
        json.dumps(validation, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    cpu_rows = []
    for name, values, kind in (
        ("D2D-MAP reference", d2d_times, "1000 executed clean-room sessions"),
        ("PAF-IoD reference", paf_times, "1000 executed clean-room sessions"),
        ("KEMTLS structure ML-KEM-768", kem_times, f"{args.kem_samples} executed crypto samples"),
        ("GT-R calibrated local component", gtr_local, "2026-09-30 RTT-10 rerun residual after subtracting 4 RTT"),
    ):
        cpu_rows.append(
            {
                "scheme": name,
                "samples": len(values),
                "median_ms": round(statistics.median(values), 6),
                "p95_ms": round(percentile(values, 0.95), 6),
                "min_ms": round(min(values), 6),
                "max_ms": round(max(values), 6),
                "measurement": kind,
            }
        )
    write_csv(RESULTS / "cpu_reference.csv", cpu_rows)

    profiles = [
        Profile(
            "D2D-MAP reference",
            (42, 58, 34, 42, 42),
            5,
            tuple(d2d_times),
            "independent executable; HMAC CRP-table PUF surrogate",
        ),
        Profile(
            "PAF-IoD reference",
            (100, 100, 100),
            3,
            tuple(paf_times),
            "independent executable; AES-GCM/PUF surrogates",
        ),
        Profile(
            "KEMTLS structural reference",
            (1250, 6000, 1100, 1048),
            4,
            tuple(kem_times),
            "independent two-KEM structure with ML-KEM-768; 9398-B KKDD wire profile",
        ),
        Profile(
            "GT-R calibrated profile",
            (3200, 4400, 1600, 100, 365, 364),
            6,
            tuple(gtr_local),
            "existing executable GT-R local overhead; common model begins at M1",
        ),
    ]
    normal = normal_experiment(profiles, args.repetitions, args.seed)
    loss = loss_experiment(profiles, args.repetitions, args.seed + 1)
    infra = infrastructure_experiment()
    features = feature_matrix()
    reported = existing_and_reported()
    write_csv(RESULTS / "normal_same_model.csv", normal)
    write_csv(RESULTS / "loss_same_model.csv", loss)
    write_csv(RESULTS / "infrastructure_outage.csv", infra)
    write_csv(RESULTS / "feature_matrix.csv", features)
    write_csv(RESULTS / "existing_and_reported_measurements.csv", reported)

    def selected(rows: list[dict[str, object]], scheme: str, loss_percent: float) -> dict[str, object]:
        for row in rows:
            if row["scheme"] == scheme and float(row["rtt_ms"]) == 100.0 and float(row["loss_percent"]) == loss_percent:
                return row
        raise KeyError((scheme, loss_percent))

    macro_lines = ["% Generated by run_external_comparison.py; do not edit manually."]
    macro_specs = (
        ("ExtDtwoD", "D2D-MAP reference"),
        ("ExtPaf", "PAF-IoD reference"),
        ("ExtKemtls", "KEMTLS structural reference"),
        ("ExtGtr", "GT-R calibrated profile"),
    )
    for prefix, scheme in macro_specs:
        zero = selected(normal, scheme, 0.0)
        loss20 = selected(loss, scheme, 20.0)
        macro_lines.extend(
            [
                rf"\newcommand{{\{prefix}Trials}}{{{int(zero['trials'])}}}",
                rf"\newcommand{{\{prefix}Messages}}{{{int(zero['messages'])}}}",
                rf"\newcommand{{\{prefix}Bytes}}{{{int(zero['protocol_bytes'])}}}",
                rf"\newcommand{{\{prefix}ZeroMedian}}{{{float(zero['median_completion_ms']):.3f}}}",
                rf"\newcommand{{\{prefix}ZeroPtf}}{{{float(zero['p95_completion_ms']):.3f}}}",
                rf"\newcommand{{\{prefix}TwentySuccess}}{{{float(loss20['success_rate_percent']):.1f}}}",
                rf"\newcommand{{\{prefix}TwentyMedian}}{{{float(loss20['median_completion_ms_successes']):.3f}}}",
                rf"\newcommand{{\{prefix}TwentyPtf}}{{{float(loss20['p95_completion_ms_successes']):.3f}}}",
            ]
        )
    macro_text = "\n".join(macro_lines) + "\n"
    (RESULTS / "external_comparison_macros.tex").write_text(macro_text, encoding="utf-8")
    PAPER_MACROS.parent.mkdir(parents=True, exist_ok=True)
    PAPER_MACROS.write_text(macro_text, encoding="utf-8")

    manifest = {
        "schema": "gtr.external-comparison.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "platform": platform.platform(),
        "python": sys.version,
        "seed": args.seed,
        "common_model_trials_per_condition": args.repetitions,
        "kemtls_crypto_samples": args.kem_samples,
        "normal_conditions": {"rtt_ms": [10, 50, 100, 200], "loss_percent": 0, "link_mbps": 10},
        "loss_conditions": {"rtt_ms": 100, "loss_percent": [0, 5, 10, 20]},
        "retry_policy": "up to three retransmissions per logical message for every common-model profile",
        "important_boundaries": [
            "D2D-MAP and PAF-IoD are independent clean-room references, not original-author code.",
            "PUF behavior is a deterministic HMAC CRP-table surrogate; no physical PUF property is measured.",
            "PAF-IoD uses AES-GCM as an explicit AEGIS surrogate, so its CPU time is not an AEGIS reproduction.",
            "KEMTLS crypto samples use standardized ML-KEM-768, not the paper's NIST-round-2 KKDD suite.",
            "The KEMTLS wire profile uses the paper-reported 9398 TCP-payload bytes and a four-flight high-level model.",
            "GT-R common-model local cost is calibrated from the 2026-09-30 RTT-10 executable rerun after removing its measured network component.",
            "Every common-model completion interval begins with the first application-layer protocol message; TCP connection setup is excluded.",
            "The common loss experiment is an application-layer stop-and-wait emulation, not native TCP behavior or a physical radio test.",
        ],
        "source_hashes": {
            "reference_protocols.py": sha256_file(HERE / "reference_protocols.py"),
            "run_external_comparison.py": sha256_file(HERE / "run_external_comparison.py"),
            "rerun_gtr_summary.csv": sha256_file(GTR_ACTUAL),
            "rerun_pqtls_summary.csv": sha256_file(PQTLS_ACTUAL),
        },
        "outputs": [
            "reference_validation.json",
            "cpu_reference.csv",
            "normal_same_model.csv",
            "loss_same_model.csv",
            "infrastructure_outage.csv",
            "existing_and_reported_measurements.csv",
            "feature_matrix.csv",
            "external_comparison_macros.tex",
        ],
    }
    (RESULTS / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps({"status": "ok", "outputs": manifest["outputs"]}, indent=2))


if __name__ == "__main__":
    main()
