#!/usr/bin/env python3
"""Independent executable references for external GT-R comparisons.

These are clean-room control-flow implementations derived from the published
protocol descriptions.  They are not the original authors' implementations.

The D2D-MAP reference preserves the five published messages and their exact
reported byte lengths.  The PAF-IoD reference preserves its three-party route,
three 800-bit messages, fresh values, PUF call, integrity checks, and common
key confirmation.  Python's AES-GCM is used as an explicit AEAD surrogate for
PAF-IoD's AEGIS calls because an AEGIS implementation is not available in the
workspace.  Consequently PAF-IoD CPU timings are reference-harness timings,
not a reproduction of the paper's primitive timings.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
import struct
from dataclasses import dataclass

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def h(*parts: bytes, size: int = 32) -> bytes:
    digest = hashlib.sha256()
    for part in parts:
        digest.update(struct.pack("!I", len(part)))
        digest.update(part)
    return digest.digest()[:size]


def xor(a: bytes, b: bytes) -> bytes:
    if len(a) != len(b):
        raise ValueError("xor inputs must have equal lengths")
    return bytes(x ^ y for x, y in zip(a, b))


def puf(device_secret: bytes, challenge: bytes, size: int = 8) -> bytes:
    """Deterministic CRP-table emulator, not a physical PUF."""
    return hmac.new(device_secret, challenge, hashlib.sha256).digest()[:size]


def checked_frame(body: bytes, target_size: int, tag_size: int = 8) -> bytes:
    if len(body) + tag_size != target_size:
        raise ValueError(
            f"body/tag do not match target: {len(body)}+{tag_size}!={target_size}"
        )
    return body + h(body, size=tag_size)


def checked_body(frame: bytes, tag_size: int = 8) -> bytes:
    body, tag = frame[:-tag_size], frame[-tag_size:]
    if not hmac.compare_digest(tag, h(body, size=tag_size)):
        raise ValueError("message-integrity check failed")
    return body


@dataclass(frozen=True)
class ExecutionResult:
    success: bool
    agreed_key: bool
    message_sizes: tuple[int, ...]
    messages: int
    protocol_bytes: int
    online_infrastructure_used: bool


class D2DMAPReference:
    """Five-message D2D-MAP authentication reference.

    Published wire sizes are m0..m4 = 42, 58, 34, 42, and 42 bytes.  The
    paper uses 64-bit identifiers/PUF values in its detailed byte accounting;
    the one-byte drone identifiers below reproduce the same totals.
    """

    sizes = (42, 58, 34, 42, 42)

    def __init__(self) -> None:
        self.id_i = b"I"
        self.id_j = b"J"
        self.puf_i = secrets.token_bytes(32)
        self.puf_j = secrets.token_bytes(32)
        self.x_i = tuple(secrets.token_bytes(8) for _ in range(3))
        self.x_j = tuple(secrets.token_bytes(8) for _ in range(3))

        # Enrollment-time extended CRP values.  The executable reference uses
        # the exact response values needed by the authentication equalities.
        ri = tuple(puf(self.puf_i, c) for c in self.x_i)
        rj = tuple(puf(self.puf_j, c) for c in self.x_j)
        self.beta_ij = (h(ri[0], ri[1], size=8), h(ri[0], ri[2], size=8))
        self.beta_ji = (h(rj[0], rj[1], size=8), h(rj[0], rj[2], size=8))

    def run(self) -> ExecutionResult:
        ni = secrets.token_bytes(8)
        ri = tuple(puf(self.puf_i, c) for c in self.x_i)
        m0 = checked_frame(self.id_i + self.id_j + ni + b"".join(ri), 42)

        b0 = checked_body(m0)
        if b0[:2] != self.id_i + self.id_j:
            raise ValueError("D2D-MAP m0 identity mismatch")
        nj = secrets.token_bytes(8)
        rj = tuple(puf(self.puf_j, c) for c in self.x_j)
        auth_j = h(self.beta_ij[0], xor(ni, nj), ni, nj, size=8)
        m1 = checked_frame(
            self.id_j + self.id_i + ni + nj + b"".join(rj) + auth_j, 58
        )

        b1 = checked_body(m1)
        expected_j = h(self.beta_ij[0], xor(ni, nj), ni, nj, size=8)
        if not hmac.compare_digest(b1[-8:], expected_j):
            raise ValueError("D2D-MAP responder authentication failed")
        auth_i = h(self.beta_ji[0], xor(ni, nj), ni, nj, size=8)
        m2 = checked_frame(self.id_i + self.id_j + ni + nj + auth_i, 34)

        b2 = checked_body(m2)
        expected_i = h(self.beta_ji[0], xor(ni, nj), ni, nj, size=8)
        if not hmac.compare_digest(b2[-8:], expected_i):
            raise ValueError("D2D-MAP initiator authentication failed")

        key_j = secrets.token_bytes(8)
        wrapped_key = xor(key_j, h(self.beta_ij[1], size=8))
        auth_j2 = h(self.beta_ji[1], xor(ni, nj), ni, nj, size=8)
        m3 = checked_frame(
            self.id_j + self.id_i + ni + nj + wrapped_key + auth_j2, 42
        )

        b3 = checked_body(m3)
        if not hmac.compare_digest(b3[-8:], auth_j2):
            raise ValueError("D2D-MAP key-source authentication failed")
        key_i = xor(b3[-16:-8], h(self.beta_ij[1], size=8))
        key_confirm = h(key_i, self.beta_ji[1], ni, nj, size=8)
        auth_i2 = h(self.beta_ij[1], xor(ni, nj), ni, nj, size=8)
        m4 = checked_frame(
            self.id_i + self.id_j + ni + nj + key_confirm + auth_i2, 42
        )

        b4 = checked_body(m4)
        expected_confirm = h(key_j, self.beta_ji[1], ni, nj, size=8)
        if not hmac.compare_digest(b4[-16:-8], expected_confirm):
            raise ValueError("D2D-MAP key confirmation failed")
        if not hmac.compare_digest(b4[-8:], auth_i2):
            raise ValueError("D2D-MAP final authentication failed")

        frames = (m0, m1, m2, m3, m4)
        observed = tuple(map(len, frames))
        if observed != self.sizes:
            raise AssertionError((observed, self.sizes))
        return ExecutionResult(
            success=True,
            agreed_key=hmac.compare_digest(key_i, key_j),
            message_sizes=observed,
            messages=len(frames),
            protocol_bytes=sum(observed),
            online_infrastructure_used=False,
        )


class PAFIoDReference:
    """Three-party PAF-IoD reference with exact published message sizes."""

    sizes = (100, 100, 100)

    def __init__(self) -> None:
        self.user_gs = AESGCM.generate_key(bit_length=128)
        self.gs_drone = AESGCM.generate_key(bit_length=128)
        self.drone_puf = secrets.token_bytes(32)
        self.challenge = secrets.token_bytes(16)

    @staticmethod
    def _pack_aead(key: bytes, plaintext: bytes, aad: bytes, target: int) -> bytes:
        nonce = secrets.token_bytes(12)
        ct = AESGCM(key).encrypt(nonce, plaintext, aad)
        body = nonce + ct
        if len(body) > target:
            raise ValueError("reference AEAD payload exceeds published message size")
        return body + secrets.token_bytes(target - len(body))

    @staticmethod
    def _open_aead(key: bytes, frame: bytes, plaintext_size: int, aad: bytes) -> bytes:
        nonce = frame[:12]
        ct = frame[12 : 12 + plaintext_size + 16]
        return AESGCM(key).decrypt(nonce, ct, aad)

    def run(self, *, ground_station_available: bool = True) -> ExecutionResult:
        if not ground_station_available:
            return ExecutionResult(
                success=False,
                agreed_key=False,
                message_sizes=(),
                messages=0,
                protocol_bytes=0,
                online_infrastructure_used=False,
            )

        user_nonce = secrets.token_bytes(16)
        user_plain = user_nonce + h(b"user-login", user_nonce, size=16)
        mg1 = self._pack_aead(self.user_gs, user_plain, b"PAF-MG1", 100)

        recovered_user = self._open_aead(self.user_gs, mg1, 32, b"PAF-MG1")
        if recovered_user != user_plain:
            raise ValueError("PAF-IoD MG1 verification failed")
        gs_nonce = secrets.token_bytes(16)
        bridge = user_nonce + gs_nonce
        mg2 = self._pack_aead(self.gs_drone, bridge, b"PAF-MG2", 100)

        recovered_bridge = self._open_aead(self.gs_drone, mg2, 32, b"PAF-MG2")
        if recovered_bridge != bridge:
            raise ValueError("PAF-IoD MG2 verification failed")
        response = puf(self.drone_puf, self.challenge, size=16)
        key_drone = h(user_nonce, gs_nonce, response, size=32)
        proof = h(key_drone, b"PAF-key-confirm", size=32)
        mg3 = self._pack_aead(self.user_gs, response + proof, b"PAF-MG3", 100)

        recovered = self._open_aead(self.user_gs, mg3, 48, b"PAF-MG3")
        response_u, proof_u = recovered[:16], recovered[16:]
        key_user = h(user_nonce, gs_nonce, response_u, size=32)
        if not hmac.compare_digest(proof_u, h(key_user, b"PAF-key-confirm", size=32)):
            raise ValueError("PAF-IoD key confirmation failed")

        frames = (mg1, mg2, mg3)
        observed = tuple(map(len, frames))
        if observed != self.sizes:
            raise AssertionError((observed, self.sizes))
        return ExecutionResult(
            success=True,
            agreed_key=hmac.compare_digest(key_user, key_drone),
            message_sizes=observed,
            messages=len(frames),
            protocol_bytes=sum(observed),
            online_infrastructure_used=True,
        )


def self_test() -> dict[str, dict[str, object]]:
    d2d = D2DMAPReference().run()
    paf = PAFIoDReference().run()
    paf_no_gs = PAFIoDReference().run(ground_station_available=False)
    return {
        "D2D-MAP": d2d.__dict__,
        "PAF-IoD": paf.__dict__,
        "PAF-IoD-no-GS": paf_no_gs.__dict__,
    }


if __name__ == "__main__":
    import json

    print(json.dumps(self_test(), indent=2))
