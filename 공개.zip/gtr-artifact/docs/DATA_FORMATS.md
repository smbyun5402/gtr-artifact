# Data formats

- CSV and `.csv.gz` contain tabular outcomes. The compressed files decompress directly to CSV; they are not executable archives.
- JSON and JSONL contain summaries, environment/provenance, and individual trial records. Selected metadata strings are redacted; numeric, Boolean, and null outcomes remain unchanged.
- The four retained `.npy` files are non-object numeric arrays. They can be loaded with `numpy.load(path, allow_pickle=False)`.
- Eight old NumPy object containers are supplied as `.npy.json` rather than pickle-based `.npy` files. Their values were exported with a restricted NumPy-only decoder and round-trip checked. No call to `numpy.load(..., allow_pickle=True)` is needed to read these public exports.

## NumPy JSON wrapper

Each export has schema `gtr.numpy-json.v1`, the original filename, SHA-256 of the original object file, and an `object` field.

- Ordinary string-keyed dictionaries remain JSON objects.
- Arrays carry `$type: ndarray`, NumPy dtype, shape, and nested `data`.
- Tuples carry `$type: tuple` and `items`.
- Non-string-key mappings carry `$type: mapping` and key/value pairs, preserving numeric/tuple keys rather than silently coercing them to strings.
- Non-finite floats, if present, carry `$type: float` and a string value, so the file remains standard JSON.

`tools/load_numpy_json.py` provides an optional NumPy-based reader for these tagged structures. The ordinary JSON can also be inspected without NumPy.

Historical plotting code may refer to the original `.npy` names. Adapt that input to the supplied JSON reader deliberately rather than enabling pickle loading. The final paper-data index primarily uses the retained CSV/JSONL evidence and does not depend on loading a pickle.
