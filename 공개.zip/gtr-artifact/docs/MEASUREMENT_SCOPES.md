# Communication and completion-time scopes

The following quantities belong to different accounting or timing boundaries.
They must not be treated as interchangeable measurements at 100-ms RTT.

## Modeled protocol-object budgets

The complete standard execution has a modeled budget of 5358 B:

| Component | Bytes |
|---|---:|
| M1: 1184-B encapsulation key, 1088-B ciphertext, 250-B metadata allowance | 2522 |
| M2: two 1088-B ciphertexts, 32-B tag, 250-B metadata allowance | 2458 |
| M3: 32-B tag, 250-B metadata allowance | 282 |
| M4: 32-B tag | 32 |
| CONF_I and ACK_R: two 32-B adoption tags | 64 |
| Total | 5358 |

Adding two FS-KEM ciphertexts of 1088 B gives 7534 B. The FS-KEM-enabled
signature comparator has a complete modeled budget of 11976 B;
FullReAttest has 9390 B. These are model budgets, not measured serialized
traffic. Enrollment certificates and transport framing are excluded.

### Why the saved policy macros show different numbers

`01_policy_security_simulation/reauth_sim.py`, method `ReauthPolicy._bytes`,
accounts for the modeled four-flight core. The saved
`results/reauth_macros.tex` accordingly contains:

| Saved macro | Stored core budget (B) | Complete budget including adoption tags (B) |
|---|---:|---:|
| RaBytesStd | 5294 | 5358 |
| RaBytesHybrid | 7470 | 7534 |
| RaBytesSig | 11912 | 11976 |
| RaBytesFull | 9390 | 9390 |

For the first three rows, the complete execution includes an additional
64 B for CONF_I and ACK_R. No adoption-tag adjustment is made to the
FullReAttest comparator. This accounting explanation does not modify the
archived simulation data, macros, or source algorithms.
`tools/check_reported_results.py` checks both the saved core budgets and
this explicitly identified 64-B completion adjustment.

## Serialized application traffic: 10029 B

The FS-KEM-enabled executable exchange comprises six application messages
(M1, M2, M3, M4, CONF_I, ACK_R). Its recorded application traffic is 10029 B,
including JSON/Base64 encoding and application framing, but excluding
TCP/IP headers. This is not the same accounting boundary as the modeled
5358/7534-B protocol objects.

Evidence: `02_network_emulation/results/gtr-mutual-complete-n100-final/`.
The controlled external-comparison profile uses message sizes
3200, 4400, 1600, 100, 365, and 364 B, totaling 10029 B.

## Completion times at nominal 100-ms RTT and zero loss

| Quantity | Value | Boundary and interpretation |
|---|---:|---|
| Calibrated common-model median | 356.438 ms (rounded) | M1 through ACK_R in the common link model; not a new end-to-end execution measurement |
| Windows-hosted WSL2 execution median | 495.45 ms (rounded) | Parent immediately before initiator launch through the later endpoint adoption timestamp; includes TCP setup, without physical-TPM NV writes |
| Corrected physical-TPM execution median | 571.40 ms (rounded) | Parent immediately before initiator launch through receipt of the initiator commit/export report; includes fresh TCP setup and both endpoints' NV-counter commits |

The calibration subtracts 40 ms from each successful recorded RTT-10
completion sample, clipping below zero. This is an approximate four-RTT
baseline (one TCP setup RTT plus three RTTs for six sequential messages),
not a measurement isolating CPU time. The residual retains local
process/scheduler/implementation overhead. It is combined with six
one-way delays and message serialization at 10 Mbit/s in the common model.
TCP setup is not added again to that M1-to-ACK_R interval, and physical-TPM
operations are not included in the calibration campaign.

In the WSL2 endpoint, the initiator adoption timestamp is recorded just
after ACK_R verification and **before** its final `persist_next_state`
call. Successful-trial classification nevertheless requires matching
persisted states. That success check does not move the recorded timestamp
to the end of final initiator persistence/export.

The corrected physical-TPM campaign uses two logical endpoints sharing one
physical TPM, with application-layer delay on TCP loopback. It is a
separate benchmark from the WSL2 namespace/netem execution. Subtracting
495.45 from 571.40 must not be presented as an isolated TPM-write cost.

Source locations:

- `02_network_emulation/scripts/run_netns_experiment.py`
- `02_network_emulation/scripts/gtr_net_endpoint.py`
- `04_physical_tpm_corrected/implementation/testbed/reauth_physical_tpm_e2e_corrected.py`
- `05_external_protocol_comparison/scripts/run_external_comparison.py`
- `05_external_protocol_comparison/scripts/refresh_with_20260930_network_results.py`
- `tools/run_external_reference.py`

This document clarifies stored evidence. Preparing this package did not
repeat hardware, network, or cryptographic timing measurements.
