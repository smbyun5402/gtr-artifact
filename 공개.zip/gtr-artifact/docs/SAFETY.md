# Research-code safety

This artifact is a research prototype, not a production authentication implementation, a security certification, or a general TPM administration tool.

- Start with the read-only inspection tools. They need no administrator access and do not contact external services.
- Run hardware TPM and namespace/netem experiments only on a dedicated, owner-approved lab system.
- TPM runners can define, increment, and undefine selected NV handles. Preserve recovery arrangements such as BitLocker recovery keys separately. Do not clear a TPM or change its ownership for these experiments.
- Network runners create/delete fixed-name lab namespaces and alter their simulated network configuration. Do not run them in a production host/network or an existing namespace with conflicting names.
- The vTPM launcher creates disposable VM/TPM state, generates SSH keys, and uses intentionally simplified lab SSH settings. Never expose that lab to an untrusted network or treat those settings as a secure deployment guide.
- Use separate output/work directories. New runs generate secret keys, ratchet state, provisioning files, logs, and possibly packet captures; `.gitignore` and `public_audit.py` reduce accidental disclosure but cannot guarantee that all sensitive material is detected.
- Keys generated for testing must never be reused in a real deployment.
- Third-party cryptographic libraries and prover binaries must be obtained from their official sources and reviewed under their own licenses. No downloaded software is executed by the inspection tools.
- The public-package preparation did not repeat the recorded network/hardware timing experiments. Software-only sanity checks must not be presented as new measurement campaigns.

For disclosure of a concern, contact the manuscript's corresponding author through the author contact information in the manuscript. Do not post credentials or sensitive experiment traces in a public issue. No dedicated security inbox or vulnerability-response service is provided by this artifact.
