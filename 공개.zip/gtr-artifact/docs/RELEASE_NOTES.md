# Package preparation history

## GitHub-ready packaging — 2026-10-16

- Prepared a separate `gtr-artifact/` folder and transfer ZIP; the previous public candidate and private originals were not edited.
- Excluded two Finder `.DS_Store` files from the new copy. No archived experiment data or source algorithm was changed.
- Also excluded 12 already-sanitized physical-TPM precheck candidate/committed/export state files from the public copy. These were diagnostic endpoint snapshots (containing metadata/hashes, not raw session keys). The latest aggregate precheck records, final per-trial outcomes, summaries, and all numerical CSV/NumPy evidence remain unchanged. The previous candidate and a separate author-only review copy retain these snapshots.
- Added the authors' chosen GitHub URL to the README and citation metadata, without claiming that the repository/release is already public or that the manuscript is accepted. Artifact version metadata is `1.0.0`; the corresponding GitHub release/tag must still be created by the authors if used.
- Added `LICENSE_NOTICE.txt`: no project-wide reuse license has been chosen. No MIT/CC license or ownership assignment was invented.
- Added `.gitattributes` to preserve archived LF/CRLF bytes on checkout and expanded generated/private-file exclusions in `.gitignore`.
- Added `MEASUREMENT_SCOPES.md` and read-only checks distinguishing legacy policy-core byte budgets from complete executions with 64 B of final adoption tags, and distinguishing modeled and measured timing boundaries. Stored numerical evidence remains unchanged.
- Hardened the value-redacting public audit and rebuilt the public integrity manifest after documentation/tool changes. Final preparation checks and the transfer ZIP checksum are reported separately to the authors, outside the public ZIP.

The next section records the earlier 2026-10-15 preparation, including the
scope and caveats applicable at that time. References there to an unchosen
repository URL are historical; the URL was supplied on 2026-10-16.

## Public-candidate preparation — 2026-10-15

## Source and preservation

Prepared from `GT-R_research_data_package_2026-10-07.zip`.

Original archive SHA-256:

`089551cb47384fbae9a4a9448e8fc629bd9d5616b3079a102034287d6af62b6b`

The original archive and manuscript were not edited. The archive contained 577 file entries: 237 were copied byte-for-byte, 15 were privacy/portability-sanitized, 8 object-NumPy containers were exported losslessly to JSON, and 317 were omitted. New public documentation and inspection tools were added separately.

## Excluded material

| Category | Files | Reason |
|---|---:|---|
| `provision.json` | 4 | Contains recorded experiment ratchet secret values and credential paths; never reuse or publish them |
| Packet captures | 7 | Full recorded protocol payloads, unnecessary for public summary/trial verification |
| Logs, runtime signatures, or binaries | 28 | Console dumps and runtime artifacts are not part of this public candidate |
| Transient endpoint state | 250 | Per-trial candidate/committed/session-export snapshots, not needed for the retained trial metrics |
| Other runtime state snapshots | 9 | Counter and active/stale/probe snapshots |
| Private-layout wrappers | 3 | Historical runners depend on private lab directory structure |
| Workflow bookkeeping | 9 | Old step/status files superseded by public instructions |
| Superseded metadata/documents | 7 | Root README/map/hash manifest, nested ignores, duplicate environment text, and internal result instructions |

The complete source-to-public disposition report is delivered separately to the authors, not bundled into this repository. Excluded files remain in the original private archive; they were not deleted from the author's records.

## Changes to retained files

- Selected local path strings and host identifiers were redacted. Non-experimental device NV-handle inventories were replaced by same-length redacted string lists. Experimental handle selections, numerical measurements, Boolean outcomes, and parameter values remain unchanged.
- Boot identifiers, where transformed, use deterministic opaque aliases so equality/difference checks remain possible.
- CSV, compressed CSV, and four numeric NumPy arrays are copied byte-for-byte. Eight legacy object-NumPy containers used pickle serialization; a strict NumPy-only decoder exported them to `.npy.json`, with exact round-trip checks for dictionary keys, tuples, array dtype/shape, and values. Their original object files are not in the public copy. No numerical outcomes were replaced, invented, resampled, or recalculated into the recorded result files.
- The old vTPM `host_vm.sh` personal work directory was replaced with a dedicated `GTR_VM_ROOT` lab directory and corresponding path checks. That script was not executed during packaging.
- Historical execution manifests keep their original source/artifact hashes. Use the new root manifest for public-copy integrity. Redacted paths can refer to omitted historical files.
- New portable wrapper `tools/run_external_reference.py` adapts input/output paths and reads the same RTT-10 calibration values from retained JSONL records instead of omitted scratch files. The original reference algorithms, surrogate disclosures, and saved comparison results are unchanged.
- The original ZIP had a Windows software-fTPM 4 x 250 summary but only the older 10-trial harness source. The exact 250-trial source matching that summary's `harness_sha256` was located in the existing experiment workspace and added as `03_implementation_state_safety/software_ftpm/src/gtr_v185_integration.c`, hash `defe2cb7da04532feddcfca4cce90bf3ddf4d975abe5726651584f41882d4b68`. It is a separately documented source addition, not a modified measurement or a fresh experiment. The older C source remains separate.

## Checks conducted

- Read-only archive CRC and SHA-256 checks.
- Structured JSON/JSONL checks for recorded ratchet/session secrets, plus credential-token/private-key patterns and personal-path checks on the public candidate, including decompressed CSV.
- Static syntax and data-format checks; no binary, VM, or TPM command execution.
- Cross-checks against stored results: 600/600 GT-R RTT trials, 600/600 PQ-TLS RTT trials, 63/100 raw UDP vs. 100/100 selective UDP at 20% loss, 100/100 M4-loss restart and ACK-blackout recovery, 1000 safe expiry records, and 50/50 corrected physical-TPM records. Table 7 arithmetic was checked independently of timing measurements.
- Existing software-only unit tests executed in an isolated temporary directory: four policy tests, one ideal-primitive regression covering 13 cases, and four bounded-checker unit tests.

These checks do not prove absence of every sensitive byte, establish license/redistribution rights, validate every scientific claim, or replace a fresh Windows/hardware reproduction. No new physical-TPM or network timing experiment was conducted.

## Earlier pre-publication notes (2026-10-15)

Obtain coauthor/institutional approval, resolve source/data licenses, and review upstream dependency obligations. The current candidate intentionally does not contain a made-up license, GitHub URL, dataset DOI, or journal-acceptance claim. Dataset availability wording must reflect the actual public release or a genuine documented restriction.
