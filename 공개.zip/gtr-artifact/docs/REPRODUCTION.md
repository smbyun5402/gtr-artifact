# Reproduction and inspection

## 1. Inspect the archived evidence first

From the repository root:

```sh
python tools/verify_repository.py
python tools/check_reported_results.py
python tools/public_audit.py
```

These commands use only the Python standard library. The result checker verifies stored trial counts, success counts, summary statistics, and the Table 7 calculation. It does not measure performance or create new experimental evidence.

## 2. Optional software-only checks

Use a dedicated Python 3.12 environment rather than altering your system environment:

```sh
python -m venv .venv
# Activate .venv using the instructions for your shell.
python -m pip install -r requirements.txt
python tools/run_software_tests.py
```

The isolated test runner executes the existing four policy tests, the ideal-primitive state-machine regression, and four bounded-checker unit tests. Its temporary directory is separate from the recorded data. These tests do not establish real-primitive performance, unbounded security, or hardware-TPM behavior.

Recorded campaign dependencies are retained in the original per-directory requirement/manifest files. A different machine or dependency build will not necessarily reproduce the same timing numbers.

## 3. Policy simulation

`01_policy_security_simulation/run_reauth_experiments.py` is the final GT-R policy experiment runner. Older `run_experiments.py`, `run_resync_experiments.py`, and their associated outputs are separate campaigns. Do not pool them or overwrite saved evidence. Run experiments only in a separate working copy.

## 4. Windows-hosted Linux network experiments

The final network scripts live in `02_network_emulation/scripts/`. They require a disposable WSL2/Linux lab, OpenSSL with the required ML-KEM/ML-DSA support, `ip`, `tc`, and administrative rights to create namespaces. The main endpoint uses the OpenSSL CLI; a system OpenSSL without the PQ algorithms is not sufficient.

The relevant runners are:

- `run_netns_experiment.py`: final GT-R RTT flow (`--suite` choices are shown by `--help`).
- `run_pq_tls_peer_baseline.py`: mutual PQ-TLS reference sweep.
- `run_udp_experiment.py`: UDP loss/retransmission behavior.
- `run_m4_loss_recovery_experiment.py`: all-M4-loss followed by a new attempt.
- `run_blackout_experiment.py`: protected-ACK blackout scenarios.
- `run_ack_expiry_experiment.py`: permanent ACK loss and fail-closed expiry.

Always pass a separate `--output` directory where supported. These scripts can create/delete their named lab namespaces and write experimental credentials. Never commit those generated credentials, provisioning files, logs, or captures. This candidate intentionally supplies saved public trial records instead of the secret-bearing original scratch directories.

Some older plotting/analysis scripts, notably `build_paper_network_figures.py`, refer to broader historical campaign folders that were not part of the source ZIP. They are retained for provenance, **not advertised as a working final-figure generation command**. Use the indexed stored final summaries or adapt a plotting workflow deliberately; do not fabricate missing inputs.

## 5. Corrected physical-TPM experiment

Read [SAFETY.md](SAFETY.md) first. The canonical source is:

`04_physical_tpm_corrected/implementation/testbed/reauth_physical_tpm_e2e_corrected.py`

On a dedicated compatible Windows lab system, the helper build source is:

`04_physical_tpm_corrected/implementation/testbed/windows_tpm/build.ps1`

The wrapper `04_physical_tpm_corrected/implementation/Run-GtrPhysicalTpmEndToEndCorrected.ps1` invokes the corrected runner. It expects a separately built `tpm_nv.exe`, suitable Python/cryptography/OpenSSL support, and an elevated PowerShell process. No executable is redistributed here.

The runner defines/increments/undefines its selected TPM NV test handles. Confirm those handles are unused and obtain the device owner's permission. Do not clear the TPM or change its ownership to run these tests. No physical-TPM commands were executed during the public-package preparation.

The final 50-trial experiment is not a pair of independent physical machines and is not a hardware-PQC benchmark: two logical endpoints share one physical TPM, with application-layer delay and software ML-KEM.

## 6. Software/vTPM experiments

The original source and build notes under `03_implementation_state_safety/` are retained, including pinned wolfSSL/wolfTPM commits. The `fwtpm_v185/README.md` describes an older macOS run; use `software_ftpm/README.md`, its hash-matched `src/gtr_v185_integration.c`, and `gtr_v185_integration_n1000.json` for the separately recorded Windows campaign. Its four 250-trial batch summaries are not a raw 1000-latency dataset. Do not rewrite old platform provenance.

The virtual-TPM host helper now uses the dedicated `GTR_VM_ROOT` lab directory, defaulting to `/tmp/gtr-vtpm-lab`, instead of a previous user's home path. It still creates disposable VM/TPM state and uses lab-only SSH settings. Prepare and verify an appropriate Ubuntu cloud image separately; no VM image or SSH key is included. Historical wrappers tied to private lab paths were excluded. The selected phase records are retained, but this package does not claim a one-click reconstruction of every historical VM image.

## 7. External-protocol reference harness

To execute the independent reference harness with portable input/output paths:

```sh
python tools/run_external_reference.py --repetitions 1000 --kem-samples 100
```

It uses the archived RTT-10 per-trial JSONL to compute the same network-residual calibration and writes **new** outputs under ignored `generated/external-reference/`, not over the archived results. It requires the declared cryptographic dependencies and suitable OpenSSL support. New CPU timing samples are machine-dependent; this command is not a claim of byte-identical timing reproduction.

The original source scripts under `05_external_protocol_comparison/scripts/` retain their historical path constants. Use the portable entry point above rather than invoking those old paths directly. The historical refresh script remains a record of the 2026-09-30 derivation and is not a current drop-in command.

Comparison limitations are intentionally preserved: D2D-MAP/PAF-IoD are independently reconstructed flows, PUF and AEGIS paths use disclosed surrogates, and KEMTLS is a current-primitive structural reference rather than the original Rustls KKDD implementation.

## 8. Formal models and mission sizing

`07_formal_verification/README.md` describes model scope and saved results. Its old examples use the former `formal/` path; in this package the files live in `07_formal_verification/`. To run a full bounded campaign in a separate destination:

```sh
python 07_formal_verification/resync_statecheck.py --self-test --suite --mutants --output generated/statecheck.txt --macros-output generated/statecheck_macros.tex
```

That full campaign may be expensive; the software-only test runner runs only unit tests. Tamarin and ProVerif binaries are not bundled. Some exploratory ProVerif runs did not terminate successfully, as documented in the original README.

`08_mission_budget/compute_table7.py` deterministically calculates horizon/storage/counter sizes. Its `KEYGEN_MS_PER_ENTRY` is a fixed rate input, not a fresh timing measurement. `check_reported_results.py` recomputes the rows in memory without overwriting the archived CSV.
