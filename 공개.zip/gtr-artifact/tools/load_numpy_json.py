#!/usr/bin/env python3
"""Read the data-only NumPy JSON exports; never deserialize pickle."""
import json
from pathlib import Path

def load(path):
    import numpy as np

    def decode(value):
        if isinstance(value,list):
            return [decode(x) for x in value]
        if not isinstance(value,dict):
            return value
        tag=value.get("$type")
        if tag=="ndarray":
            dtype=np.dtype(value["dtype"])
            if dtype.hasobject:
                raise ValueError("Nested object arrays are not approved")
            return np.array(decode(value["data"]),dtype=dtype).reshape(value["shape"])
        if tag=="tuple":
            return tuple(decode(x) for x in value["items"])
        if tag=="mapping":
            return {decode(k):decode(v) for k,v in value["items"]}
        if tag=="float":
            return float(value["value"])
        return {k:decode(v) for k,v in value.items()}

    wrapper=json.loads(Path(path).read_text(encoding="utf-8"))
    if wrapper.get("schema")!="gtr.numpy-json.v1":
        raise ValueError("Unsupported export schema")
    return decode(wrapper["object"])
