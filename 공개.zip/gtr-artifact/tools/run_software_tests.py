#!/usr/bin/env python3
"""Run reviewed software-only tests in an isolated temporary working copy."""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    with tempfile.TemporaryDirectory(prefix="gtr-public-check-") as work:
        temp=Path(work)
        env=os.environ.copy()
        env["PYTHONDONTWRITEBYTECODE"]="1"
        env["MPLCONFIGDIR"]=str(temp/"matplotlib-cache")
        env["GTR_WORK"]=str(temp/"primitive-work")
        policy=temp/"policy"
        policy.mkdir()
        for name in ("test_reauth_sim.py","reauth_sim.py"):
            shutil.copy2(ROOT/"01_policy_security_simulation"/name,policy/name)
        subprocess.run([sys.executable,"-m","unittest","-v","test_reauth_sim"],cwd=policy,env=env,check=True)
        implementation=temp/"implementation"
        implementation.mkdir()
        for name in ("test_reauth_demo_logic.py","reauth_demo.py"):
            shutil.copy2(ROOT/"03_implementation_state_safety"/name,implementation/name)
        subprocess.run([sys.executable,"test_reauth_demo_logic.py"],cwd=implementation,env=env,check=True)
        formal=temp/"formal"
        formal.mkdir()
        shutil.copy2(ROOT/"07_formal_verification/resync_statecheck.py",formal/"resync_statecheck.py")
        subprocess.run([sys.executable,"-m","unittest","-v","resync_statecheck.ModelSelfTests"],cwd=formal,env=env,check=True)
    print("PASS: software-only unit tests; no hardware/network timing experiment was run.")

if __name__=="__main__":
    main()
