#!/usr/bin/env python3
"""Conservative value-redacting public-copy checks, not a security guarantee."""
import ast
import gzip
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SKIP={".git",".venv","venv","__pycache__",".pytest_cache"}
TOKEN_RULES={
    "private-key-block":rb"-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----",
    "github-token":rb"(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})",
    "cloud-access-id":rb"(?:AKIA|ASIA)[A-Z0-9]{16}",
    "api-secret":rb"\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}",
    "personal-home-path":rb"(?:/(?:Users|home)/[^/\s\"'<>]+|[A-Za-z]:[\\/]+Users[\\/]+[^\\/\s\"'<>]+)",
    "credential-in-url":rb"https?://[^\s/@:\"']+:[^\s/@\"']+@",
}
SECRET_FIELD=re.compile(r"(?i)(?:^|_)(?:ck\d*|ck_i|ck_j|ssk|session_key|secret_key|private_key|seal_key|root_secret|shared_secret|password|auth_value|owner_auth|access_token|api_key|api_secret|client_secret)(?:_hex|_b64|_base64)?$")
DENY_SUFFIX={".pcap",".pcapng",".pem",".key",".der",".pfx",".p12",".exe",".dll",".obj",".log",".pkl",".pickle",".zip",".tar",".tgz",".qcow2",".img",".iso",".lnk"}
DENY_NAMES={"provision.json","rot_seal.json","candidate-state.json","committed-state.json","session-export.json","session_export.json",".env",".DS_Store","Thumbs.db"}

def inspect_json(obj,prefix=""):
    if isinstance(obj,dict):
        for k,v in obj.items():
            path=prefix+"."+k
            if (SECRET_FIELD.search(k) and isinstance(v,str) and len(v.strip())>=16
                    and not re.search(r"(?i)redacted|removed|not.?included",v)):
                yield path
            yield from inspect_json(v,path)
    elif isinstance(obj,list):
        for value in obj:
            yield from inspect_json(value,prefix+"[]")

def main():
    findings=[]
    scanned=0
    for path in sorted(ROOT.rglob("*")):
        if any(p in SKIP for p in path.relative_to(ROOT).parts):
            continue
        rel=path.relative_to(ROOT).as_posix()
        if path.is_symlink():
            findings.append({"path":rel,"rule":"symlink"})
            continue
        if not path.is_file():
            continue
        scanned+=1
        if (path.suffix.lower() in DENY_SUFFIX or path.name in DENY_NAMES
                or path.name.startswith("._") or "__MACOSX" in path.relative_to(ROOT).parts
                or path.name.startswith(".env.") and path.name!=".env.example"):
            findings.append({"path":rel,"rule":"excluded-artifact-type"})
        if path.stat().st_size>=100*1024*1024:
            findings.append({"path":rel,"rule":"github-100MiB-file-limit"})
        data=path.read_bytes()
        if path.suffix==".npy" and data.startswith(b"\x93NUMPY"):
            width=2 if data[6:8]==b"\x01\x00" else 4
            length=int.from_bytes(data[8:8+width],"little")
            header=ast.literal_eval(data[8+width:8+width+length].decode("latin1").strip())
            if "O" in str(header.get("descr")):
                findings.append({"path":rel,"rule":"object-numpy-pickle-not-approved"})
        if path.name.endswith(".gz"):
            data=gzip.decompress(data)
        # Do not self-match the scanner's own regex literals.
        if path.resolve()!=Path(__file__).resolve():
            for rule,pattern in TOKEN_RULES.items():
                payload=data
                if rule=="personal-home-path" and rel=="03_implementation_state_safety/vtpm_reboot/README.md":
                    # Explicit example VM account named after this project,
                    # not a recorded researcher's personal home directory.
                    payload=payload.replace(b"/home/qartz/",b"/LAB_HOME/")
                if re.search(pattern,payload):
                    findings.append({"path":rel,"rule":rule})
        objects=[]
        if path.suffix==".json":
            objects=[json.loads(data)]
        elif path.suffix==".jsonl":
            objects=[json.loads(x) for x in data.splitlines() if x.strip()]
        keys=sorted(set(k for obj in objects for k in inspect_json(obj)))
        if keys:
            findings.append({"path":rel,"rule":"potential-recorded-secret","field_paths":keys})
    print(json.dumps({"status":"REVIEW" if findings else "PASS","files_scanned":scanned,"findings":findings,"limitations":"Value-redacting file checks cannot prove absence of all secrets, inspect Git history, or establish redistribution permission."},indent=2))
    return 1 if findings else 0

if __name__=="__main__":
    raise SystemExit(main())
