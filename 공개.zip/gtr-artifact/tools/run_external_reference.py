#!/usr/bin/env python3
"""Portable I/O adapter; preserves the original reference algorithms/models."""
import importlib.util
import json
import os
import sys
from pathlib import Path

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]

def main():
    source=ROOT/"05_external_protocol_comparison/scripts"
    sys.path.insert(0,str(source))
    spec=importlib.util.spec_from_file_location("gtr_external_reference",source/"run_external_comparison.py")
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    module.WORKSPACE=ROOT
    module.RESULTS=ROOT/"generated/external-reference"
    module.PAPER_MACROS=module.RESULTS/"external_comparison_macros.tex"
    module.GTR_CORE=ROOT/"04_physical_tpm_corrected/implementation/testbed/reauth_demo.py"
    module.GTR_ACTUAL=ROOT/"02_network_emulation/results/gtr-mutual-complete-n100-final/summary.csv"
    module.PQTLS_ACTUAL=ROOT/"02_network_emulation/results/pq-tls-mutual-complete-n100-final/summary.csv"
    module.OPENSSL=Path(os.environ.get("OPENSSL",str(ROOT/"generated/nonexistent-openssl")))

    def local_samples():
        path=ROOT/"02_network_emulation/results/gtr-mutual-complete-n100-final/trials.jsonl"
        records=[json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        rows=[r for r in records if r["condition"]["id"]=="rtt10-loss0" and r["success"]]
        if len(rows)!=100:
            raise RuntimeError("Expected exactly 100 archived successful RTT-10 trials")
        return [max(0.0,float(r["mutual_adoption_ttsc_ms"])-40.0) for r in rows]

    module.load_gtr_local_samples=local_samples
    module.main()

if __name__=="__main__":
    main()
