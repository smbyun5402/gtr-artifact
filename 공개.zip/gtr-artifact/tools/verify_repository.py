#!/usr/bin/env python3
"""Read-only artifact integrity, syntax, and data-format checks (stdlib only)."""
import ast
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
IGNORE = {".git", ".venv", "venv", "__pycache__", "generated", ".pytest_cache"}

def main():
    manifest = ROOT / "MANIFEST_SHA256.tsv"
    if not manifest.is_file():
        raise SystemExit("Missing MANIFEST_SHA256.tsv")
    records = list(csv.DictReader(manifest.open(encoding="utf-8"), delimiter="\t"))
    errors = []
    checks = {"hashed_files":0,"python_sources":0,"json_files":0,"jsonl_records":0,"csv_rows":0,"numpy_arrays":0}
    for row in records:
        rel = row["path"]
        path = ROOT / rel
        if Path(rel).is_absolute() or ".." in Path(rel).parts or path.is_symlink() or not path.is_file():
            errors.append(f"Unsafe or missing file: {rel}")
            continue
        data = path.read_bytes()
        if len(data) != int(row["bytes"]) or hashlib.sha256(data).hexdigest() != row["sha256"]:
            errors.append(f"Hash/size mismatch: {rel}")
        checks["hashed_files"] += 1
        try:
            if rel.endswith(".py"):
                ast.parse(data.decode("utf-8-sig"),filename=rel)
                checks["python_sources"] += 1
            elif rel.endswith(".json"):
                json.loads(data)
                checks["json_files"] += 1
            elif rel.endswith(".jsonl"):
                for line in data.splitlines():
                    if line.strip():
                        json.loads(line)
                        checks["jsonl_records"] += 1
            elif rel.endswith((".csv", ".csv.gz")):
                payload = gzip.decompress(data) if rel.endswith(".gz") else data
                reader=csv.reader(io.StringIO(payload.decode("utf-8-sig")))
                header=next(reader)
                for n,fields in enumerate(reader,start=2):
                    if fields and len(fields)!=len(header):
                        errors.append(f"CSV column count mismatch: {rel}:{n}")
                    checks["csv_rows"] += 1
            elif rel.endswith(".npy"):
                if not data.startswith(b"\x93NUMPY"):
                    raise ValueError("Invalid NumPy magic")
                version=data[6:8]
                size_len=2 if version==b"\x01\x00" else 4
                header_len=int.from_bytes(data[8:8+size_len],"little")
                header=ast.literal_eval(data[8+size_len:8+size_len+header_len].decode("latin1").strip())
                if "O" in str(header.get("descr")):
                    raise ValueError("Object/pickled arrays are not approved")
                checks["numpy_arrays"] += 1
        except (ValueError,UnicodeError,SyntaxError,StopIteration) as exc:
            errors.append(f"Format error: {rel}: {type(exc).__name__}")
    expected={r["path"] for r in records}|{"MANIFEST_SHA256.tsv"}
    actual={str(p.relative_to(ROOT)).replace("\\","/") for p in ROOT.rglob("*") if p.is_file() and not any(x in IGNORE for x in p.relative_to(ROOT).parts)}
    for path in sorted(actual-expected):
        errors.append(f"Unmanifested file: {path}")
    print(json.dumps({"status":"FAIL" if errors else "PASS","checks":checks,"errors":errors},indent=2))
    return 1 if errors else 0

if __name__=="__main__":
    raise SystemExit(main())
