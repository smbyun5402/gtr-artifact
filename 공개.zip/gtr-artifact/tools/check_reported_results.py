#!/usr/bin/env python3
"""Check recorded outcomes and sizing arithmetic; do not rerun measurements."""
import csv
import hashlib
import importlib.util
import json
import math
import re
import statistics
import sys
from pathlib import Path

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
NET=ROOT/"02_network_emulation/results"

def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def read_lines(path):
    return [json.loads(x) for x in path.read_text(encoding="utf-8-sig").splitlines() if x.strip()]

def percentile(values,q):
    values=sorted(values)
    n=(len(values)-1)*q
    low,high=math.floor(n),math.ceil(n)
    return values[low]+(values[high]-values[low])*(n-low)

def close(a,b):
    assert math.isclose(float(a),float(b),rel_tol=1e-9,abs_tol=1e-6),(a,b)

def main():
    results={}
    # Preserve the saved four-flight policy budgets. Complete GT-R executions
    # additionally account for the two final adoption tags.
    macro_text=(ROOT/"01_policy_security_simulation/results/reauth_macros.tex").read_text(encoding="utf-8-sig")
    core_budget={name:int(value) for name,value in re.findall(
        r"\\newcommand\{\\(RaBytes\w+)\}\{(\d+)\}",macro_text)}
    assert core_budget["RaBytesStd"]==5294
    assert core_budget["RaBytesHybrid"]==7470
    assert core_budget["RaBytesSig"]==11912
    assert core_budget["RaBytesFull"]==9390
    m1=1184+1088+250
    m2=1088+1088+32+250
    m3=32+250
    m4=32
    adoption=2*32
    standard=m1+m2+m3+m4+adoption
    assert standard==core_budget["RaBytesStd"]+adoption==5358
    assert standard+2*1088==core_budget["RaBytesHybrid"]+adoption==7534
    assert core_budget["RaBytesSig"]+adoption==11976
    results["modeled_budget_scopes"]={
        "legacy_policy_core_bytes":{k:core_budget[k] for k in ("RaBytesStd","RaBytesHybrid","RaBytesSig","RaBytesFull")},
        "complete_standard_bytes":standard,
        "complete_fs_kem_bytes":standard+2*1088,
        "complete_signature_fs_kem_bytes":core_budget["RaBytesSig"]+adoption,
        "full_reattest_bytes":core_budget["RaBytesFull"],
        "added_gt_r_adoption_tag_bytes":adoption,
        "classification":"modeled accounting, not serialized traffic"}
    for name in ("gtr-mutual-complete-n100-final","pq-tls-mutual-complete-n100-final"):
        directory=NET/name
        rows=list(csv.DictReader((directory/"summary.csv").open(encoding="utf-8-sig",newline="")))
        raw=read_lines(directory/"trials.jsonl")
        assert len(rows)==6 and len(raw)==600
        for summary in rows:
            condition=summary["condition"]
            trial_rows=[r for r in raw if r["condition"]["id"]==condition]
            assert len(trial_rows)==int(summary["trials"])==100
            assert sum(bool(r["success"]) for r in trial_rows)==int(summary["successes"])==100
            # The two archived baselines use different summary timing labels.
            if "mutual_ttsc_median_ms" in summary:
                values=[r["mutual_adoption_ttsc_ms"] for r in trial_rows if r["success"]]
                close(statistics.median(values),summary["mutual_ttsc_median_ms"])
                close(percentile(values,.95),summary["mutual_ttsc_p95_ms"])
                if condition=="rtt100-loss0":
                    close(summary["application_protocol_bytes_median"],10029)
                    results["wsl2_rtt100"]={"median_ms":statistics.median(values),
                        "serialized_application_bytes":10029,
                        "classification":"recorded execution; no physical-TPM NV writes"}
        results[name]={"trials":len(raw),"successes":sum(bool(r["success"]) for r in raw)}

    udp=read_json(NET/"udp-paired-n100-final/summary.json")
    raw_udp=read_lines(NET/"udp-paired-n100-final/trials.jsonl")
    assert len(raw_udp)==1200
    for row in udp:
        cond=row["condition"]
        subset=[r for r in raw_udp if r["condition"]["id"]==cond["id"]]
        assert len(subset)==row["trials"]==100
        assert sum(bool(r["success"]) for r in subset)==row["successes"]
        if float(cond["loss_percent"])==20.0:
            expected=63 if cond["transport_mode"]=="raw" else 100
            assert row["successes"]==expected
            results["udp20_"+cond["transport_mode"]]={"trials":100,"successes":expected}

    m4=read_json(NET/"m4-loss-recovery-n100-final/summary.json")
    assert m4["trials"]==m4["fresh_reconnect_successes"]==m4["failed_attempts_with_zero_adoptions"]==100
    assert len(read_lines(NET/"m4-loss-recovery-n100-final/trials.jsonl"))==100
    results["m4_loss_safe_restart"]={"trials":100,"successes":100}

    ack=read_json(NET/"adoption-ack-loss-n100-final/summary.json")[0]
    assert ack["trials"]==ack["successes"]==100
    assert len(read_lines(NET/"adoption-ack-loss-n100-final/trials.jsonl"))==100
    results["ack_blackout_recovery"]={"trials":100,"successes":100}

    expiry=read_json(NET/"ack-expiry-n1000-final/summary.json")
    assert expiry["trials"]==expiry["r2_required"]==expiry["expired_candidates_rejected"]==1000
    assert len(read_lines(NET/"ack-expiry-n1000-final/trials.jsonl"))==1000
    results["ack_expiry"]={"trials":1000,"safe_r2_expiries":1000}

    directory=ROOT/"04_physical_tpm_corrected/results/physical-tpm-e2e-corrected"
    tpm=read_json(directory/"latest-summary.json")
    records=read_lines(directory/"latest-trials.jsonl")
    assert len(records)==tpm["results"]["trials_completed"]==50
    assert all(r["success"] and r["evaluation"]["success"] and not r["conflicting_adoption"] for r in records)
    assert all(r["message_send_sequence"]==["M1","M2","M3","M4","CONF_I","ACK_R"] for r in records)
    assert tpm["results"]["initiator_verified_increments"]==tpm["results"]["responder_verified_increments"]==50
    values=[r["ttsc_ms"] for r in records]
    close(statistics.median(values),tpm["results"]["ttsc_ms"]["median"])
    close(percentile(values,.95),tpm["results"]["ttsc_ms"]["p95"])
    results["corrected_physical_tpm"]={"trials":50,"successes":50,"median_ms":statistics.median(values),"p95_ms":percentile(values,.95)}

    modeled=list(csv.DictReader((ROOT/"05_external_protocol_comparison/results/normal_same_model.csv").open(encoding="utf-8-sig",newline="")))
    selected=[r for r in modeled if r["scheme"]=="GT-R calibrated profile" and float(r["rtt_ms"])==100 and float(r["loss_percent"])==0]
    assert len(selected)==1
    row=selected[0]
    assert int(row["messages"])==6 and int(row["protocol_bytes"])==10029
    close(row["median_completion_ms"],356.437576)
    assert sum((3200,4400,1600,100,365,364))==10029
    results["calibrated_rtt100"]={"median_ms":float(row["median_completion_ms"]),
        "serialized_application_bytes":int(row["protocol_bytes"]),
        "classification":"calibrated common-model result, not a new execution measurement"}

    directory=ROOT/"03_implementation_state_safety/software_ftpm"
    ftpm=read_json(directory/"gtr_v185_integration_n1000.json")
    assert len(ftpm["batches"])==4
    assert sum(r["trials"] for r in ftpm["batches"])==sum(r["accepted"] for r in ftpm["batches"])==1000
    assert all(r["trials"]==r["accepted"]==250 for r in ftpm["batches"])
    assert hashlib.sha256((directory/"src/gtr_v185_integration.c").read_bytes()).hexdigest()==ftpm["sources"]["harness_sha256"]
    results["windows_software_ftpm"]={"batches":4,"accepted":1000,"source_hash_matches_recorded_campaign":True,"individual_latency_records_included":False}

    directory=ROOT/"08_mission_budget"
    spec=importlib.util.spec_from_file_location("gtr_budget",directory/"compute_table7.py")
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    saved=list(csv.DictReader((directory/"table7_budget.csv").open(encoding="utf-8-sig",newline="")))
    rows=list(module.build_rows())
    assert len(saved)==len(rows)==4
    for expected,actual in zip(saved,rows):
        assert expected["profile"]==actual["profile"]
        for k in ("N_t","N_ctr","T_req","T_cfg","pk_KiB","sk_KiB"):
            close(expected[k],actual[k])
        assert expected["KeyGen_s"]==f'{actual["KeyGen_s"]:.1f}'
    results["mission_budget"]={"rows":4,"classification":"deterministic sizing; not new measured key-generation timing"}
    print(json.dumps({"status":"PASS","recorded_result_checks":results},indent=2))

if __name__=="__main__":
    main()
