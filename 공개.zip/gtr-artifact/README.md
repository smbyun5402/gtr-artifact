# GT-R: experimental data and research code

Companion material for **GT-R: Verifier-Less Re-Authentication and State Reconciliation for DDIL Networks**, by Seungmin Byun, Gwanwoo Kim, Jiwon Park, and Hakjun Lee.

This repository contains research prototypes, recorded experimental data, and formal models. It is **not production security software**. It does not imply acceptance or publication of the manuscript.

Prepared for the authors' GitHub repository: <https://github.com/smbyun5402/gtr-artifact>.
The presence of that URL in this package does not imply that the repository is already public.

## Start here

No TPM, administrator privileges, network access, or Python packages are needed to inspect the stored results:

```sh
python tools/verify_repository.py
python tools/check_reported_results.py
python tools/public_audit.py
```

Use Python 3.10 or later. The three commands read existing files only; they do not conduct experiments or modify your TPM. `verify_repository.py` also checks file integrity and Python syntax without importing the experimental code.

For optional dependency installation and software-only tests, see [Reproduction](docs/REPRODUCTION.md). Do not run the hardware or network experiment scripts before reading [Safety](docs/SAFETY.md).

## Contents

| Directory | Material |
|---|---|
| `01_policy_security_simulation/` | Policy-boundary and encoded attack-regression simulations; raw and summarized outcomes |
| `02_network_emulation/` | Linux namespace/netem runners; final RTT, loss, interruption, and expiry trial data |
| `03_implementation_state_safety/` | GT-R prototype, state-safety checks, software-fTPM and virtual-TPM artifacts |
| `04_physical_tpm_corrected/` | Corrected 50-trial Windows physical-TPM experiment, prechecks, trial records, and runner source |
| `05_external_protocol_comparison/` | Independently reconstructed reference-flow harness and controlled comparison results |
| `06_fs_kem/` | Reference construction and approximate estimator artifacts |
| `07_formal_verification/` | Tamarin and exploratory ProVerif models; bounded explicit-state checker |
| `08_mission_budget/` | Deterministic mission-size calculation for Table 7 |
| `09_windows_provenance/` | Selected environment and completion records, with host-specific details redacted |
| `tools/` | Read-only integrity/result checks, isolated software tests, and portable external-comparison entry point |

See [PAPER_DATA_MAP.md](PAPER_DATA_MAP.md) for the mapping to figures and tables. Final manuscript PNG/PDF artwork is intentionally not included.

For the distinction between modeled object budgets, encoded message sizes, calibrated completion times, and measured completion times, see [Measurement scopes](docs/MEASUREMENT_SCOPES.md). In particular, the legacy policy macros omit the two final adoption tags (64 B); the complete-execution budgets in the manuscript include them. The recorded files have not been rewritten to hide this difference.

## Interpretation boundaries

- The final network measurements were collected with a Windows host and WSL2 Linux network namespaces; they are not physical-radio measurements.
- The corrected physical-TPM experiment uses **two logical endpoints sharing one physical TPM**, with application-layer delay on TCP loopback. The TPM protects monotonic NV counters; ML-KEM is performed by the OpenSSL-backed software endpoint.
- Older and exploratory artifacts are retained for traceability. In particular, `03_implementation_state_safety/results_raw/fwtpm_v185/` and the associated original README describe an older macOS campaign. They are **not** to be relabelled as Windows results. The Windows software-fTPM campaign is indexed separately in the data map.
- The D2D-MAP and PAF-IoD references are not original-author code. PUF behavior and some primitives use explicitly disclosed surrogates; KEMTLS is a structural reference using current ML-KEM. See the original comparison manifest and [Reproduction](docs/REPRODUCTION.md).
- Saved prover outputs are evidence for their particular model and assumptions only. Exploratory ProVerif files without a completed proof are not successful verification results.
- Table 7 is an engineering sizing calculation using a fixed measured-rate input, not a new set of hardware measurements.

## Data preservation and privacy

Recorded provisioning secrets, packet captures, endpoint state snapshots, raw console logs, signatures, executables, and private-layout wrapper scripts were excluded from the public package. Numerical CSV/numeric-NumPy/compressed-CSV data are preserved byte-for-byte; eight legacy pickled NumPy object containers were exported losslessly to data-only `.npy.json` files. Retained JSON/JSONL records preserve all numerical and Boolean results while selected host paths, device-handle inventories, and host identifiers are redacted. See [Data formats](docs/DATA_FORMATS.md) and [Release notes](docs/RELEASE_NOTES.md).

Original manifests may contain hashes and output paths from the original execution environment. Those historical hashes do **not** replace `MANIFEST_SHA256.tsv`, which checks this public copy.

## Rights, citation, and disclosure

**No project-wide reuse license has been selected.** This package must not be described as MIT-, CC BY-, or otherwise openly licensed. See [LICENSE_NOTICE.txt](LICENSE_NOTICE.txt) and [RIGHTS_AND_DEPENDENCIES.md](RIGHTS_AND_DEPENDENCIES.md). Public GitHub visibility is distinct from an open-source/data license. Questions about additional reuse permissions should be addressed to the manuscript's corresponding author.

`CITATION.cff` identifies artifact version `1.0.0` and the authors' chosen repository URL, without inventing a DOI, publication date, journal acceptance, or an already-published GitHub release. When citing the artifact, identify the actual version/tag or commit used. Data-availability statements must be added or updated only after the stated files are accessible to readers.

AI-assisted tools were used in manuscript and script preparation; the authors remain responsible for reviewing the code, data interpretation, and claims. This public-package preparation did not rerun the Windows, physical-TPM, radio, or cryptographic timing experiments.
