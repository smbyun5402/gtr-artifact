param(
    [ValidateRange(1, 100)]
    [int]$Trials = 50,

    [ValidateRange(0, 10000)]
    [double]$RttMs = 100,

    [ValidatePattern('^0x[0-9A-Fa-f]{8}$')]
    [string]$InitiatorHandle = '0x01510010',

    [ValidatePattern('^0x[0-9A-Fa-f]{8}$')]
    [string]$ResponderHandle = '0x01510011',

    [string]$PythonExe = 'python.exe',

    [string]$OutputRoot = ''
)

$ErrorActionPreference = 'Stop'

if (-not ([Security.Principal.WindowsPrincipal]::new(
    [Security.Principal.WindowsIdentity]::GetCurrent()
)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'The corrected physical TPM End-to-End experiment requires an elevated PowerShell process.'
}

if ($InitiatorHandle.ToLowerInvariant() -eq $ResponderHandle.ToLowerInvariant()) {
    throw 'InitiatorHandle and ResponderHandle must be different.'
}

$runner = Join-Path $PSScriptRoot 'testbed\reauth_physical_tpm_e2e_corrected.py'
$helper = Join-Path $PSScriptRoot 'testbed\windows_tpm\tpm_nv.exe'
if (-not (Test-Path -LiteralPath $runner -PathType Leaf)) {
    throw "Runner not found: $runner"
}
if (-not (Test-Path -LiteralPath $helper -PathType Leaf)) {
    throw "TPM helper not found: $helper"
}
if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
    $OutputRoot = Join-Path $PSScriptRoot 'testbed\results_raw\tpm_physical_e2e_corrected'
}

$arguments = @(
    $runner,
    '--trials', [string]$Trials,
    '--rtt-ms', [string]$RttMs,
    '--initiator-handle', $InitiatorHandle,
    '--responder-handle', $ResponderHandle,
    '--helper', $helper,
    '--output-root', $OutputRoot
)

& $PythonExe @arguments
if ($LASTEXITCODE -ne 0) {
    throw "Corrected physical TPM End-to-End runner failed with exit code $LASTEXITCODE."
}
