#!/usr/bin/env python3
"""Physical-TPM-integrated end-to-end GT-R experiment for Windows.

Each trial launches fresh initiator and responder processes.  Enrollment and
the RTT probe are completed before the timer starts.  The measured path is:

    M1 -> M2 -> M3/CONF_I -> responder TPM commit -> M4/ACK_R
       -> initiator TPM commit -> session export

The TPM helper is restricted to marked NV counters in its managed range and
performs all destructive-object checks itself.  This runner never clears,
initializes, reprovisions, or takes ownership of the TPM.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import platform
import queue
import secrets
import shutil
import socket
import statistics
import subprocess
import sys
import tempfile
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

import reauth_demo as core
import reauth_socket_bench as socket_bench


HERE = Path(__file__).resolve().parent
DEFAULT_HELPER = HERE / "windows_tpm" / "tpm_nv.exe"
DEFAULT_OUTPUT_ROOT = HERE / "results_raw" / "tpm_physical_e2e"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * quantile
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = rank - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def atomic_write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}-{secrets.token_hex(4)}")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def append_jsonl(path: Path, value: object) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, sort_keys=True, separators=(",", ":"))
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def run_helper_json(helper: str, *arguments: str) -> dict:
    started = time.perf_counter()
    completed = subprocess.run(
        [helper, *arguments],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    process_ms = (time.perf_counter() - started) * 1000.0
    stdout_lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    parsed = None
    if stdout_lines:
        try:
            parsed = json.loads(stdout_lines[-1])
        except json.JSONDecodeError:
            parsed = None
    if completed.returncode != 0 or not isinstance(parsed, dict) or not parsed.get("ok"):
        detail = {
            "arguments": list(arguments),
            "returncode": completed.returncode,
            "stdout": completed.stdout[-4000:],
            "stderr": completed.stderr[-4000:],
            "parsed": parsed,
        }
        raise RuntimeError(f"TPM helper failed: {json.dumps(detail, sort_keys=True)}")
    parsed["helper_process_ms"] = process_ms
    return parsed


def setup_role_workspace(trial_directory: str, role: str) -> Path:
    directory = Path(tempfile.mkdtemp(prefix=f"{role}-", dir=trial_directory))
    core.WORK = str(directory)
    core.SEAL_PATH = str(directory / "rot_seal.json")
    return directory


def send_protocol_frame(sock: socket.socket, value: object, one_way_delay_s: float) -> None:
    if one_way_delay_s > 0:
        time.sleep(one_way_delay_s)
    socket_bench.send_frame(sock, value)


def counter_increment_is_exact_once(result: dict) -> bool:
    before = result.get("before")
    after = result.get("after")
    if not isinstance(after, int):
        return False
    if before is None:
        # A freshly defined TPM NV counter is uninitialized.  Its first
        # increment initializes it from the TPM's device-wide counter base,
        # which is not required to be 1.  The helper issues exactly one
        # TPM2_NV_Increment command, so the transition to any positive value
        # is the exact-once evidence for the first trial.
        return after > 0
    return isinstance(before, int) and after == before + 1


def responder_worker(
    port_queue: mp.Queue,
    result_queue: mp.Queue,
    ck0_hex: str,
    sid: str,
    epoch_i: int,
    epoch_j: int,
    one_way_delay_s: float,
    helper: str,
    handle: str,
    trial_directory: str,
) -> None:
    role_directory = setup_role_workspace(trial_directory, "responder")
    announced = False
    tpm_commit = None
    try:
        available, openssl_version = core.openssl_ok()
        if not available:
            raise RuntimeError(openssl_version)
        static_sk, static_pk = core.mlkem_keygen("responder-static")
        dr = core.EpochDrKem("responder-dr")
        dr.tick_to(epoch_j)
        chain, _ = core.chain_fast_forward(bytes.fromhex(ck0_hex), 0, epoch_j)
        converged_epoch = max(epoch_i, epoch_j) + 1

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            listener.bind(("127.0.0.1", 0))
            listener.listen(1)
            port_queue.put({"port": listener.getsockname()[1]})
            announced = True
            connection, _ = listener.accept()
            with connection:
                connection.settimeout(180)
                enrolled_i = socket_bench.recv_frame(connection)
                peer_static_pk = socket_bench.write_public(
                    str(role_directory), "initiator-static-pk.pem", enrolled_i["static_pk"]
                )
                peer_dr_pk = socket_bench.write_public(
                    str(role_directory), "initiator-dr-pk.pem", enrolled_i["dr_pk"]
                )
                socket_bench.send_frame(
                    connection,
                    {
                        "static_pk": socket_bench.b64(core._read_bytes(static_pk)),
                        "dr_pk": socket_bench.b64(core._read_bytes(dr.public_key(converged_epoch))),
                        "epoch": epoch_j,
                    },
                )

                probe = socket_bench.recv_frame(connection)
                if probe.get("type") != "rtt_probe":
                    raise RuntimeError("invalid RTT probe")
                send_protocol_frame(
                    connection,
                    {"type": "rtt_probe_ack", "nonce": probe.get("nonce")},
                    one_way_delay_s,
                )

                m1 = socket_bench.recv_frame(connection)
                n_i = socket_bench.unb64(m1["n_i"])
                eph_pk_bytes = socket_bench.unb64(m1["eph_pk"])
                eph_pk = socket_bench.write_public(
                    str(role_directory), "initiator-eph.pem", m1["eph_pk"]
                )
                ct_sj = socket_bench.unb64(m1["ct_sj"])
                ss_sj = core.mlkem_decap(static_sk, ct_sj)
                ct_e, ss_e = core.mlkem_encap(eph_pk)
                ct_si, ss_si = core.mlkem_encap(peer_static_pk)
                d_si_ct, d_si = core.mlkem_encap(peer_dr_pk)
                n_j = secrets.token_bytes(16)
                chain_ff, _ = core.chain_fast_forward(chain, epoch_j, converged_epoch - 1)
                tr12 = core.H(
                    "tr12",
                    sid,
                    n_i,
                    n_j,
                    epoch_i,
                    epoch_j,
                    converged_epoch,
                    eph_pk_bytes,
                    ct_sj,
                    ct_e,
                    ct_si,
                    d_si_ct,
                )
                kpre = socket_bench.pre_schedule(
                    chain_ff, ss_e, ss_sj, ss_si, tr12, sid, converged_epoch
                )
                tau_j = core.mac(core.hkdf(kpre, b"mac-j"), core.H("tau_j", tr12))
                send_protocol_frame(
                    connection,
                    {
                        "n_j": socket_bench.b64(n_j),
                        "e_j": epoch_j,
                        "ct_e": socket_bench.b64(ct_e),
                        "ct_si": socket_bench.b64(ct_si),
                        "d_si": socket_bench.b64(d_si_ct),
                        "tau_j": socket_bench.b64(tau_j),
                    },
                    one_way_delay_s,
                )

                m3 = socket_bench.recv_frame(connection)
                d_sj_ct = socket_bench.unb64(m3["d_sj"])
                tau_i = socket_bench.unb64(m3["tau_i"])
                d_sj = dr.decap(converged_epoch, d_sj_ct)
                if d_sj is None:
                    raise RuntimeError("responder DR decapsulation failed")
                tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
                expected_tau_i = core.mac(core.hkdf(kpre, b"mac-i"), core.H("tau_i", tr3))
                if not secrets.compare_digest(tau_i, expected_tau_i):
                    raise RuntimeError("M3/CONF_I authentication failed")

                transcript = core.H("tr-final", tr3, tau_i)
                session, _, confirm = socket_bench.final_schedule(
                    kpre, d_sj, d_si, transcript, sid, converged_epoch
                )
                session_hash = hashlib.sha256(session).hexdigest()
                transcript_hash = hashlib.sha256(transcript).hexdigest()

                tpm_commit = run_helper_json(helper, "increment", "--handle", handle)
                if not counter_increment_is_exact_once(tpm_commit):
                    raise RuntimeError("responder TPM counter did not increment exactly once")
                committed_state = {
                    "role": "responder",
                    "adopted": True,
                    "epoch": converged_epoch,
                    "session_sha256": session_hash,
                    "transcript_sha256": transcript_hash,
                    "tpm_handle": handle.lower(),
                    "tpm_counter": tpm_commit["after"],
                    "committed_utc": utc_now(),
                }
                state_path = role_directory / "committed-state.json"
                atomic_write_json(state_path, committed_state)

                gamma = core.mac(confirm, core.H("confirm", transcript))
                send_protocol_frame(
                    connection,
                    {
                        "gamma_j": socket_bench.b64(gamma),
                        "responder_counter": tpm_commit["after"],
                    },
                    one_way_delay_s,
                )

        result_queue.put(
            {
                "role": "responder",
                "ok": True,
                "adopted": True,
                "session_sha256": session_hash,
                "transcript_sha256": transcript_hash,
                "epoch": converged_epoch,
                "tpm": tpm_commit,
                "committed_state": str(state_path),
                "crypto_backend": core.CRYPTO_BACKEND,
                "openssl": openssl_version,
            }
        )
    except Exception as exc:
        if not announced:
            port_queue.put({"error": repr(exc)})
        result_queue.put(
            {
                "role": "responder",
                "ok": False,
                "adopted": False,
                "tpm": tpm_commit,
                "error": repr(exc),
                "traceback": traceback.format_exc(limit=8),
            }
        )


def initiator_worker(
    port: int,
    result_queue: mp.Queue,
    ck0_hex: str,
    sid: str,
    epoch_i: int,
    epoch_j: int,
    one_way_delay_s: float,
    helper: str,
    handle: str,
    trial_directory: str,
) -> None:
    role_directory = setup_role_workspace(trial_directory, "initiator")
    tpm_commit = None
    try:
        available, openssl_version = core.openssl_ok()
        if not available:
            raise RuntimeError(openssl_version)
        static_sk, static_pk = core.mlkem_keygen("initiator-static")
        dr = core.EpochDrKem("initiator-dr")
        dr.tick_to(epoch_i)
        chain, _ = core.chain_fast_forward(bytes.fromhex(ck0_hex), 0, epoch_i)
        converged_epoch = max(epoch_i, epoch_j) + 1

        with socket.create_connection(("127.0.0.1", port), timeout=180) as connection:
            connection.settimeout(180)
            socket_bench.send_frame(
                connection,
                {
                    "static_pk": socket_bench.b64(core._read_bytes(static_pk)),
                    "dr_pk": socket_bench.b64(core._read_bytes(dr.public_key(converged_epoch))),
                    "epoch": epoch_i,
                },
            )
            enrolled_j = socket_bench.recv_frame(connection)
            peer_static_pk = socket_bench.write_public(
                str(role_directory), "responder-static-pk.pem", enrolled_j["static_pk"]
            )
            peer_dr_pk = socket_bench.write_public(
                str(role_directory), "responder-dr-pk.pem", enrolled_j["dr_pk"]
            )

            probe_nonce = secrets.token_hex(8)
            rtt_started = time.perf_counter()
            send_protocol_frame(
                connection,
                {"type": "rtt_probe", "nonce": probe_nonce},
                one_way_delay_s,
            )
            probe_ack = socket_bench.recv_frame(connection)
            observed_rtt_ms = (time.perf_counter() - rtt_started) * 1000.0
            if probe_ack.get("type") != "rtt_probe_ack" or probe_ack.get("nonce") != probe_nonce:
                raise RuntimeError("RTT probe verification failed")

            started_utc = utc_now()
            started = time.perf_counter()
            n_i = secrets.token_bytes(16)
            eph_sk, eph_pk = core.mlkem_keygen("initiator-eph")
            eph_pk_bytes = core._read_bytes(eph_pk)
            ct_sj, ss_sj = core.mlkem_encap(peer_static_pk)
            send_protocol_frame(
                connection,
                {
                    "sid": sid,
                    "n_i": socket_bench.b64(n_i),
                    "e_i": epoch_i,
                    "eph_pk": socket_bench.b64(eph_pk_bytes),
                    "ct_sj": socket_bench.b64(ct_sj),
                },
                one_way_delay_s,
            )

            m2 = socket_bench.recv_frame(connection)
            n_j = socket_bench.unb64(m2["n_j"])
            ct_e = socket_bench.unb64(m2["ct_e"])
            ct_si = socket_bench.unb64(m2["ct_si"])
            d_si_ct = socket_bench.unb64(m2["d_si"])
            tau_j = socket_bench.unb64(m2["tau_j"])
            ss_e = core.mlkem_decap(eph_sk, ct_e)
            ss_si = core.mlkem_decap(static_sk, ct_si)
            d_si = dr.decap(converged_epoch, d_si_ct)
            if d_si is None:
                raise RuntimeError("initiator DR decapsulation failed")
            chain_ff, _ = core.chain_fast_forward(chain, epoch_i, converged_epoch - 1)
            tr12 = core.H(
                "tr12",
                sid,
                n_i,
                n_j,
                epoch_i,
                epoch_j,
                converged_epoch,
                eph_pk_bytes,
                ct_sj,
                ct_e,
                ct_si,
                d_si_ct,
            )
            kpre = socket_bench.pre_schedule(
                chain_ff, ss_e, ss_sj, ss_si, tr12, sid, converged_epoch
            )
            expected_tau_j = core.mac(core.hkdf(kpre, b"mac-j"), core.H("tau_j", tr12))
            if not secrets.compare_digest(tau_j, expected_tau_j):
                raise RuntimeError("M2 authentication failed")

            d_sj_ct, d_sj = core.mlkem_encap(peer_dr_pk)
            tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
            tau_i = core.mac(core.hkdf(kpre, b"mac-i"), core.H("tau_i", tr3))
            send_protocol_frame(
                connection,
                {"d_sj": socket_bench.b64(d_sj_ct), "tau_i": socket_bench.b64(tau_i)},
                one_way_delay_s,
            )

            transcript = core.H("tr-final", tr3, tau_i)
            session, _, confirm = socket_bench.final_schedule(
                kpre, d_sj, d_si, transcript, sid, converged_epoch
            )
            m4 = socket_bench.recv_frame(connection)
            gamma = socket_bench.unb64(m4["gamma_j"])
            expected_gamma = core.mac(confirm, core.H("confirm", transcript))
            if not secrets.compare_digest(gamma, expected_gamma):
                raise RuntimeError("M4/ACK_R confirmation failed")

            session_hash = hashlib.sha256(session).hexdigest()
            transcript_hash = hashlib.sha256(transcript).hexdigest()
            tpm_commit = run_helper_json(helper, "increment", "--handle", handle)
            if not counter_increment_is_exact_once(tpm_commit):
                raise RuntimeError("initiator TPM counter did not increment exactly once")
            committed_state = {
                "role": "initiator",
                "adopted": True,
                "epoch": converged_epoch,
                "session_sha256": session_hash,
                "transcript_sha256": transcript_hash,
                "tpm_handle": handle.lower(),
                "tpm_counter": tpm_commit["after"],
                "committed_utc": utc_now(),
            }
            state_path = role_directory / "committed-state.json"
            atomic_write_json(state_path, committed_state)
            export_path = role_directory / "session-export.json"
            atomic_write_json(
                export_path,
                {
                    "exported": True,
                    "session_sha256": session_hash,
                    "transcript_sha256": transcript_hash,
                    "epoch": converged_epoch,
                    "tpm_counter": tpm_commit["after"],
                },
            )
            ttsc_ms = (time.perf_counter() - started) * 1000.0
            ended_utc = utc_now()

        result_queue.put(
            {
                "role": "initiator",
                "ok": True,
                "adopted": True,
                "session_exported": True,
                "session_sha256": session_hash,
                "transcript_sha256": transcript_hash,
                "epoch": converged_epoch,
                "responder_counter_acknowledged": m4.get("responder_counter"),
                "tpm": tpm_commit,
                "ttsc_ms": ttsc_ms,
                "observed_rtt_ms": observed_rtt_ms,
                "started_utc": started_utc,
                "ended_utc": ended_utc,
                "committed_state": str(state_path),
                "session_export_record": str(export_path),
                "crypto_backend": core.CRYPTO_BACKEND,
                "openssl": openssl_version,
            }
        )
    except Exception as exc:
        result_queue.put(
            {
                "role": "initiator",
                "ok": False,
                "adopted": False,
                "session_exported": False,
                "tpm": tpm_commit,
                "error": repr(exc),
                "traceback": traceback.format_exc(limit=8),
            }
        )


def collect_process_results(
    result_queue: mp.Queue,
    initiator: mp.Process,
    responder: mp.Process,
    timeout_s: float,
) -> list[dict]:
    results: list[dict] = []
    deadline = time.monotonic() + timeout_s
    while len(results) < 2:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        try:
            results.append(result_queue.get(timeout=min(remaining, 5.0)))
        except queue.Empty:
            if not initiator.is_alive() and not responder.is_alive():
                break
    for process in (initiator, responder):
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join(timeout=10)
    return results


def execute_trial(
    trial_id: int,
    helper: Path,
    initiator_handle: str,
    responder_handle: str,
    rtt_ms: float,
    epoch_i: int,
    epoch_j: int,
    run_directory: Path,
    timeout_s: float,
) -> dict:
    trial_started_utc = utc_now()
    trial_directory = run_directory / f"trial-{trial_id:04d}"
    trial_directory.mkdir(parents=True, exist_ok=False)
    one_way_delay_s = rtt_ms / 2000.0
    ck0_hex = secrets.token_bytes(32).hex()
    sid = f"gtr-physical-tpm-e2e-{trial_id:04d}-{secrets.token_hex(4)}"
    port_queue: mp.Queue = mp.Queue()
    result_queue: mp.Queue = mp.Queue()
    responder = mp.Process(
        target=responder_worker,
        args=(
            port_queue,
            result_queue,
            ck0_hex,
            sid,
            epoch_i,
            epoch_j,
            one_way_delay_s,
            str(helper),
            responder_handle,
            str(trial_directory),
        ),
        name=f"gtr-responder-{trial_id:04d}",
    )
    responder.start()
    try:
        startup = port_queue.get(timeout=timeout_s)
    except queue.Empty:
        startup = {"error": "responder startup timeout"}
    if "error" in startup:
        responder.join(timeout=10)
        if responder.is_alive():
            responder.terminate()
            responder.join(timeout=10)
        available = []
        try:
            while True:
                available.append(result_queue.get_nowait())
        except queue.Empty:
            pass
        return {
            "schema": "gtr.physical-tpm-e2e-trial.v1",
            "trial_id": trial_id,
            "started_utc": trial_started_utc,
            "ended_utc": utc_now(),
            "success": False,
            "error": startup["error"],
            "process_results": available,
        }

    initiator = mp.Process(
        target=initiator_worker,
        args=(
            startup["port"],
            result_queue,
            ck0_hex,
            sid,
            epoch_i,
            epoch_j,
            one_way_delay_s,
            str(helper),
            initiator_handle,
            str(trial_directory),
        ),
        name=f"gtr-initiator-{trial_id:04d}",
    )
    initiator.start()
    results = collect_process_results(result_queue, initiator, responder, timeout_s)
    by_role = {item.get("role"): item for item in results if item.get("role")}
    initiator_result = by_role.get("initiator", {})
    responder_result = by_role.get("responder", {})
    both_ok = bool(initiator_result.get("ok") and responder_result.get("ok"))
    state_match = bool(
        both_ok
        and initiator_result.get("session_sha256") == responder_result.get("session_sha256")
        and initiator_result.get("transcript_sha256")
        == responder_result.get("transcript_sha256")
        and initiator_result.get("epoch") == responder_result.get("epoch")
    )
    initiator_once = counter_increment_is_exact_once(initiator_result.get("tpm", {}))
    responder_once = counter_increment_is_exact_once(responder_result.get("tpm", {}))
    both_adopted = bool(
        initiator_result.get("adopted") and responder_result.get("adopted")
    )
    conflicting_adoption = bool(both_adopted and not state_match)
    success = bool(
        both_ok
        and state_match
        and initiator_once
        and responder_once
        and both_adopted
        and initiator_result.get("session_exported")
        and not conflicting_adoption
    )
    return {
        "schema": "gtr.physical-tpm-e2e-trial.v1",
        "trial_id": trial_id,
        "started_utc": initiator_result.get("started_utc", trial_started_utc),
        "ended_utc": initiator_result.get("ended_utc", utc_now()),
        "success": success,
        "configured_rtt_ms": rtt_ms,
        "observed_rtt_ms": initiator_result.get("observed_rtt_ms"),
        "ttsc_ms": initiator_result.get("ttsc_ms"),
        "session_key_hash_match": state_match,
        "transcript_hash_match": state_match,
        "epoch_match": state_match,
        "initiator_adopted": bool(initiator_result.get("adopted")),
        "responder_adopted": bool(responder_result.get("adopted")),
        "conflicting_adoption": conflicting_adoption,
        "initiator_tpm_increment_exactly_once": initiator_once,
        "responder_tpm_increment_exactly_once": responder_once,
        "initiator_tpm": initiator_result.get("tpm"),
        "responder_tpm": responder_result.get("tpm"),
        "session_sha256": initiator_result.get("session_sha256"),
        "transcript_sha256": initiator_result.get("transcript_sha256"),
        "committed_epoch": initiator_result.get("epoch"),
        "process_results": results,
        "process_exit_codes": {
            "initiator": initiator.exitcode,
            "responder": responder.exitcode,
        },
        "error": None if success else "one or more end-to-end success criteria failed",
    }


def powershell_json(script: str) -> dict | None:
    completed = subprocess.run(
        ["powershell.exe", "-NoProfile", "-Command", script],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if completed.returncode != 0 or not completed.stdout.strip():
        return None
    try:
        return json.loads(completed.stdout.strip())
    except json.JSONDecodeError:
        return None


def capture_environment(helper: Path, probe: dict, openssl_version: str) -> dict:
    hardware = powershell_json(
        "$cpu=(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name);"
        "$tpm=Get-CimInstance -Namespace 'Root\\CIMV2\\Security\\MicrosoftTpm' "
        "-ClassName Win32_Tpm | Select-Object -First 1;"
        "[pscustomobject]@{cpu=$cpu;tpm_manufacturer=$tpm.ManufacturerIdTxt;"
        "tpm_firmware=$tpm.ManufacturerVersionFull20;windows_build=[Environment]::OSVersion.Version.ToString()}"
        "|ConvertTo-Json -Compress"
    )
    return {
        "captured_utc": utc_now(),
        "platform": platform.platform(),
        "python": sys.version,
        "python_executable": sys.executable,
        "processor": platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER"),
        "hardware": hardware,
        "openssl": openssl_version,
        "crypto_backend": core.CRYPTO_BACKEND,
        "tpm_helper": str(helper),
        "tpm_helper_sha256": sha256_file(helper),
        "tpm_probe_before": probe,
    }


def write_environment_text(path: Path, environment: dict) -> None:
    hardware = environment.get("hardware") or {}
    lines = [
        f"captured_utc={environment.get('captured_utc')}",
        f"platform={environment.get('platform')}",
        f"windows_build={hardware.get('windows_build')}",
        f"cpu={hardware.get('cpu') or environment.get('processor')}",
        f"tpm_manufacturer={hardware.get('tpm_manufacturer')}",
        f"tpm_firmware={hardware.get('tpm_firmware')}",
        f"openssl={environment.get('openssl')}",
        f"crypto_backend={environment.get('crypto_backend')}",
        f"python={environment.get('python')}",
        f"python_executable={environment.get('python_executable')}",
        f"tpm_helper={environment.get('tpm_helper')}",
        f"tpm_helper_sha256={environment.get('tpm_helper_sha256')}",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=20)
    parser.add_argument("--rtt-ms", type=float, default=100.0)
    parser.add_argument("--initiator-handle", default="0x01510010")
    parser.add_argument("--responder-handle", default="0x01510011")
    parser.add_argument("--initiator-epoch", type=int, default=0)
    parser.add_argument("--responder-epoch", type=int, default=5)
    parser.add_argument("--helper", type=Path, default=DEFAULT_HELPER)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--trial-timeout-seconds", type=float, default=300.0)
    args = parser.parse_args()

    if not 1 <= args.trials <= 100:
        parser.error("--trials must be in the range 1..100")
    if args.rtt_ms < 0 or args.rtt_ms > 10_000:
        parser.error("--rtt-ms must be in the range 0..10000")
    if args.initiator_handle.lower() == args.responder_handle.lower():
        parser.error("initiator and responder handles must be different")
    helper = args.helper.resolve()
    if not helper.is_file():
        parser.error(f"TPM helper not found: {helper}")

    available, openssl_version = core.openssl_ok()
    if not available:
        raise SystemExit(openssl_version)

    run_id = datetime.now().strftime("run-%Y%m%d-%H%M%S-") + secrets.token_hex(4)
    output_root = args.output_root.resolve()
    run_directory = output_root / run_id
    run_directory.mkdir(parents=True, exist_ok=False)
    trials_path = run_directory / "gtr_physical_tpm_e2e_trials.jsonl"
    summary_path = run_directory / "gtr_physical_tpm_e2e_summary.json"
    log_path = run_directory / "run.log"
    environment_path = run_directory / "environment.txt"
    environment_json_path = run_directory / "environment.json"

    def log(message: str) -> None:
        line = f"[{datetime.now().astimezone().isoformat()}] {message}"
        print(line, flush=True)
        with log_path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(line + "\n")
            stream.flush()

    created_handles: list[str] = []
    cleanup = {
        "initiator_undefine_attempted": False,
        "initiator_undefined": False,
        "responder_undefine_attempted": False,
        "responder_undefined": False,
        "verification_probe": None,
        "error": None,
    }
    trials: list[dict] = []
    initial_reads: dict[str, dict] = {}
    final_reads: dict[str, dict] = {}
    fatal_error = None
    started_utc = utc_now()
    probe_before: dict = {}
    environment: dict = {}

    try:
        log(
            "START physical TPM integrated GT-R "
            f"trials={args.trials} rtt_ms={args.rtt_ms} "
            f"initiator_handle={args.initiator_handle} responder_handle={args.responder_handle}"
        )
        probe_before = run_helper_json(str(helper), "probe")
        managed_by_handle = {
            item.get("handle", "").lower(): item
            for item in probe_before.get("managed_handles", [])
        }
        for handle in (args.initiator_handle, args.responder_handle):
            if handle.lower() in managed_by_handle:
                raise RuntimeError(f"selected handle already exists: {handle}")

        environment = capture_environment(helper, probe_before, openssl_version)
        atomic_write_json(environment_json_path, environment)
        write_environment_text(environment_path, environment)

        for role, handle in (
            ("initiator", args.initiator_handle),
            ("responder", args.responder_handle),
        ):
            defined = run_helper_json(str(helper), "define", "--handle", handle)
            if not defined.get("created"):
                raise RuntimeError(f"{role} handle was not freshly created: {handle}")
            created_handles.append(handle)
            initial_reads[role] = run_helper_json(str(helper), "read", "--handle", handle)
            log(f"DEFINED {role} handle={handle} initial={initial_reads[role].get('value')}")

        for trial_id in range(1, args.trials + 1):
            log(f"TRIAL_START {trial_id}/{args.trials}")
            try:
                trial = execute_trial(
                    trial_id,
                    helper,
                    args.initiator_handle,
                    args.responder_handle,
                    args.rtt_ms,
                    args.initiator_epoch,
                    args.responder_epoch,
                    run_directory,
                    args.trial_timeout_seconds,
                )
            except Exception as exc:
                trial = {
                    "schema": "gtr.physical-tpm-e2e-trial.v1",
                    "trial_id": trial_id,
                    "started_utc": utc_now(),
                    "ended_utc": utc_now(),
                    "success": False,
                    "error": repr(exc),
                    "orchestrator_traceback": traceback.format_exc(limit=12),
                }
            trials.append(trial)
            append_jsonl(trials_path, trial)
            log(
                f"TRIAL_DONE {trial_id}/{args.trials} success={trial.get('success')} "
                f"ttsc_ms={trial.get('ttsc_ms')} observed_rtt_ms={trial.get('observed_rtt_ms')}"
            )

        final_reads["initiator"] = run_helper_json(
            str(helper), "read", "--handle", args.initiator_handle
        )
        final_reads["responder"] = run_helper_json(
            str(helper), "read", "--handle", args.responder_handle
        )
    except Exception as exc:
        fatal_error = repr(exc)
        log(f"FATAL {fatal_error}")
        with log_path.open("a", encoding="utf-8") as stream:
            stream.write(traceback.format_exc(limit=20) + "\n")
    finally:
        for role, handle in (
            ("responder", args.responder_handle),
            ("initiator", args.initiator_handle),
        ):
            if handle not in created_handles:
                continue
            cleanup[f"{role}_undefine_attempted"] = True
            try:
                removed = run_helper_json(str(helper), "undefine", "--handle", handle)
                cleanup[f"{role}_undefined"] = bool(removed.get("removed"))
                log(f"CLEANUP {role} handle={handle} removed={removed.get('removed')}")
            except Exception as exc:
                cleanup["error"] = repr(exc)
                log(f"CLEANUP_ERROR {role} handle={handle} error={exc!r}")
        try:
            cleanup["verification_probe"] = run_helper_json(str(helper), "probe")
        except Exception as exc:
            cleanup["error"] = cleanup["error"] or repr(exc)

    successful = [trial for trial in trials if trial.get("success")]
    ttsc_samples = [float(trial["ttsc_ms"]) for trial in successful]
    rtt_samples = [float(trial["observed_rtt_ms"]) for trial in successful]
    responder_increment_samples = [
        float(trial["responder_tpm"]["increment_ms"])
        for trial in successful
        if trial.get("responder_tpm")
    ]
    initiator_increment_samples = [
        float(trial["initiator_tpm"]["increment_ms"])
        for trial in successful
        if trial.get("initiator_tpm")
    ]
    conflicts = sum(1 for trial in trials if trial.get("conflicting_adoption"))
    initiator_verified_increments = sum(
        1 for trial in trials if trial.get("initiator_tpm_increment_exactly_once")
    )
    responder_verified_increments = sum(
        1 for trial in trials if trial.get("responder_tpm_increment_exactly_once")
    )

    def counter_delta(role: str) -> int | None:
        final = final_reads.get(role, {}).get("value")
        initial = initial_reads.get(role, {}).get("value")
        if not isinstance(final, int) or not isinstance(initial, int):
            return None
        return final - initial

    cleanup_handles = {
        item.get("handle", "").lower()
        for item in (cleanup.get("verification_probe") or {}).get("managed_handles", [])
    }
    handles_absent_after_cleanup = (
        args.initiator_handle.lower() not in cleanup_handles
        and args.responder_handle.lower() not in cleanup_handles
    )
    pass_status = bool(
        fatal_error is None
        and len(trials) == args.trials
        and len(successful) == args.trials
        and conflicts == 0
        and initiator_verified_increments == args.trials
        and responder_verified_increments == args.trials
        and cleanup.get("initiator_undefined")
        and cleanup.get("responder_undefined")
        and handles_absent_after_cleanup
        and not cleanup.get("error")
    )
    summary = {
        "schema": "gtr.physical-tpm-e2e-summary.v1",
        "status": "pass" if pass_status else "fail",
        "run_id": run_id,
        "started_utc": started_utc,
        "completed_utc": utc_now(),
        "configuration": {
            "trials_requested": args.trials,
            "configured_rtt_ms": args.rtt_ms,
            "network_delay_injection": "application-level delay of RTT/2 before each protocol send",
            "initiator_handle": args.initiator_handle.lower(),
            "responder_handle": args.responder_handle.lower(),
            "initiator_epoch": args.initiator_epoch,
            "responder_epoch": args.responder_epoch,
            "converged_epoch": max(args.initiator_epoch, args.responder_epoch) + 1,
            "trial_isolation": "fresh initiator and responder OS processes and TCP connection per trial",
            "enrollment_excluded_from_timer": True,
            "rtt_probe_excluded_from_timer": True,
            "message_mapping": "M3 is CONF_I; M4 is ACK_R",
        },
        "results": {
            "trials_completed": len(trials),
            "trials_succeeded": len(successful),
            "trials_failed": len(trials) - len(successful),
            "success_rate": len(successful) / args.trials if args.trials else 0.0,
            "ttsc_ms": {
                "samples": ttsc_samples,
                "median": statistics.median(ttsc_samples) if ttsc_samples else None,
                "p95": percentile(ttsc_samples, 0.95),
            },
            "observed_rtt_ms": {
                "samples": rtt_samples,
                "median": statistics.median(rtt_samples) if rtt_samples else None,
                "p95": percentile(rtt_samples, 0.95),
            },
            "responder_tpm_increment_ms": {
                "samples": responder_increment_samples,
                "median": statistics.median(responder_increment_samples)
                if responder_increment_samples
                else None,
                "p95": percentile(responder_increment_samples, 0.95),
            },
            "initiator_tpm_increment_ms": {
                "samples": initiator_increment_samples,
                "median": statistics.median(initiator_increment_samples)
                if initiator_increment_samples
                else None,
                "p95": percentile(initiator_increment_samples, 0.95),
            },
            "all_session_key_hashes_match": all(
                trial.get("session_key_hash_match") for trial in successful
            )
            and len(successful) == args.trials,
            "all_transcript_hashes_match": all(
                trial.get("transcript_hash_match") for trial in successful
            )
            and len(successful) == args.trials,
            "all_epochs_match": all(trial.get("epoch_match") for trial in successful)
            and len(successful) == args.trials,
            "conflicting_adoptions": conflicts,
        },
        "tpm_counters": {
            "initial_reads": initial_reads,
            "final_reads": final_reads,
            "initiator_delta": counter_delta("initiator"),
            "responder_delta": counter_delta("responder"),
            "initiator_verified_trial_increments": initiator_verified_increments,
            "responder_verified_trial_increments": responder_verified_increments,
            "fresh_counter_note": (
                "A newly defined TPM NV counter is uninitialized and its first "
                "increment may start from a device-wide counter base rather than 1. "
                "Each trial is therefore verified from the helper's before/after pair."
            ),
        },
        "cleanup": {
            **cleanup,
            "selected_handles_absent_after_cleanup": handles_absent_after_cleanup,
        },
        "environment": environment,
        "fatal_error": fatal_error,
        "outputs": {
            "trials_jsonl": str(trials_path),
            "summary_json": str(summary_path),
            "run_log": str(log_path),
            "environment_txt": str(environment_path),
        },
        "limitations": [
            "two logical endpoints share one physical TPM on this Windows PC",
            "100 ms RTT is emulated at the application layer on TCP loopback",
            "the TPM protects monotonic NV counters; ML-KEM operations run through OpenSSL-backed cryptography",
        ],
        "source_sha256": sha256_file(Path(__file__)),
    }
    atomic_write_json(summary_path, summary)
    output_root.mkdir(parents=True, exist_ok=True)
    shutil.copy2(summary_path, output_root / "latest-summary.json")
    shutil.copy2(trials_path, output_root / "latest-trials.jsonl")
    if pass_status:
        (run_directory / "COMPLETE").write_text(utc_now() + "\n", encoding="utf-8")
        log(
            f"COMPLETE success={len(successful)}/{args.trials} "
            f"ttsc_median_ms={summary['results']['ttsc_ms']['median']} "
            f"ttsc_p95_ms={summary['results']['ttsc_ms']['p95']}"
        )
    else:
        log(
            f"FAILED success={len(successful)}/{args.trials} fatal_error={fatal_error} "
            f"cleanup_error={cleanup.get('error')}"
        )
    print(json.dumps({"status": summary["status"], "run_directory": str(run_directory), "summary": summary["results"]}, indent=2))
    return 0 if pass_status else 1


if __name__ == "__main__":
    mp.freeze_support()
    raise SystemExit(main())
