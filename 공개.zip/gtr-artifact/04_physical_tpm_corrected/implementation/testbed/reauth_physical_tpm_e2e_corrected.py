#!/usr/bin/env python3
"""Corrected six-flight GT-R physical-TPM End-to-End experiment.

Measured protocol path:

    fresh TCP connect -> M1 -> M2 -> M3 -> M4 -> CONF_I
    -> responder TPM commit -> ACK_R -> initiator TPM commit -> export

M4 is a key-confirmation-only flight.  It never changes active state and it
never writes either TPM counter.  CONF_I and ACK_R use the paper's role-bound
adoption tags.  The parent process starts TTSC immediately before launching the
fresh initiator process and stops it when that process reports that commit and
session export are complete.

The runner also performs four one-trial boundary checks before the main run:
all-M4 loss, CONF_I loss, ACK_R loss, and duplicate CONF_I replay.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import platform
import queue
import secrets
import shutil
import socket
import statistics
import sys
import tempfile
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

import reauth_demo as core
import reauth_physical_tpm_e2e as shared
import reauth_socket_bench as socket_bench


HERE = Path(__file__).resolve().parent
DEFAULT_HELPER = HERE / "windows_tpm" / "tpm_nv.exe"
DEFAULT_OUTPUT_ROOT = HERE / "results_raw" / "tpm_physical_e2e_corrected"

NORMAL = "normal"
DROP_ALL_M4 = "drop_all_m4"
DROP_CONF_I = "drop_conf_i"
DROP_ACK_R = "drop_ack_r"
DUPLICATE_CONF_I = "duplicate_conf_i"
PRECHECK_MODES = (DROP_ALL_M4, DROP_CONF_I, DROP_ACK_R, DUPLICATE_CONF_I)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def record_event(
    events: list[dict],
    role: str,
    action: str,
    message: str | None = None,
    **details: object,
) -> None:
    item = {
        "role": role,
        "action": action,
        "message": message,
        "monotonic_ns": time.perf_counter_ns(),
        "utc": utc_now(),
    }
    item.update(details)
    events.append(item)


def send_message(
    connection: socket.socket,
    message_type: str,
    payload: dict,
    one_way_delay_s: float,
    events: list[dict],
    role: str,
    **event_details: object,
) -> None:
    record_event(events, role, "send_delay_start", message_type, **event_details)
    if one_way_delay_s > 0:
        time.sleep(one_way_delay_s)
    frame = {"type": message_type, **payload}
    socket_bench.send_frame(connection, frame)
    record_event(events, role, "sent", message_type, **event_details)


def receive_message(
    connection: socket.socket,
    expected_type: str,
    events: list[dict],
    role: str,
) -> dict:
    frame = socket_bench.recv_frame(connection)
    actual_type = frame.get("type")
    record_event(events, role, "received", str(actual_type))
    if actual_type != expected_type:
        raise RuntimeError(f"expected {expected_type}, received {actual_type!r}")
    return frame


def same_counter(left: dict | None, right: dict | None) -> bool:
    if not isinstance(left, dict) or not isinstance(right, dict):
        return False
    return (
        bool(left.get("initialized")) == bool(right.get("initialized"))
        and left.get("value") == right.get("value")
    )


def prepare_trial_material(trial_directory: Path) -> dict[str, str]:
    prepared = trial_directory / "prepared-enrollment"
    prepared.mkdir(parents=True, exist_ok=False)
    core.WORK = str(prepared)
    core.SEAL_PATH = str(prepared / "rot_seal.json")
    initiator_static_sk, initiator_static_pk = core.mlkem_keygen("initiator-static")
    initiator_dr_sk, initiator_dr_pk = core.mlkem_keygen("initiator-dr-eprime")
    responder_static_sk, responder_static_pk = core.mlkem_keygen("responder-static")
    responder_dr_sk, responder_dr_pk = core.mlkem_keygen("responder-dr-eprime")
    return {
        "initiator_static_sk": initiator_static_sk,
        "initiator_static_pk": initiator_static_pk,
        "initiator_dr_sk": initiator_dr_sk,
        "initiator_dr_pk": initiator_dr_pk,
        "responder_static_sk": responder_static_sk,
        "responder_static_pk": responder_static_pk,
        "responder_dr_sk": responder_dr_sk,
        "responder_dr_pk": responder_dr_pk,
    }


def role_workspace(trial_directory: str, role: str) -> Path:
    directory = Path(tempfile.mkdtemp(prefix=f"{role}-", dir=trial_directory))
    core.WORK = str(directory)
    core.SEAL_PATH = str(directory / "rot_seal.json")
    return directory


def responder_worker(
    port_queue: mp.Queue,
    ready_queue: mp.Queue,
    result_queue: mp.Queue,
    ck0_hex: str,
    sid: str,
    epoch_i: int,
    epoch_j: int,
    one_way_delay_s: float,
    helper: str,
    handle: str,
    trial_directory: str,
    material: dict[str, str],
    mode: str,
) -> None:
    events: list[dict] = []
    directory = role_workspace(trial_directory, "responder")
    announced = False
    tpm_commit = None
    tpm_start = None
    tpm_end = None
    before_m4 = None
    after_m4 = None
    active_state = "base"
    candidate_pending = False
    alpha_i_verified = False
    completion_record = None
    try:
        available, openssl_version = core.openssl_ok()
        if not available:
            raise RuntimeError(openssl_version)
        chain, _ = core.chain_fast_forward(bytes.fromhex(ck0_hex), 0, epoch_j)
        converged_epoch = max(epoch_i, epoch_j) + 1
        tpm_start = shared.run_helper_json(helper, "read", "--handle", handle)

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            listener.bind(("127.0.0.1", 0))
            listener.listen(2)
            port_queue.put({"port": listener.getsockname()[1]})
            announced = True

            probe_connection, _ = listener.accept()
            with probe_connection:
                probe_connection.settimeout(60)
                probe = receive_message(
                    probe_connection, "RTT_PROBE", events, "responder"
                )
                send_message(
                    probe_connection,
                    "RTT_PROBE_ACK",
                    {"nonce": probe.get("nonce")},
                    one_way_delay_s,
                    events,
                    "responder",
                )
            ready_queue.put({"ready": True})

            connection, _ = listener.accept()
            with connection:
                connection.settimeout(180)
                record_event(events, "responder", "tcp_accepted", "TCP")
                m1 = receive_message(connection, "M1", events, "responder")
                n_i = socket_bench.unb64(m1["n_i"])
                eph_pk_bytes = socket_bench.unb64(m1["eph_pk"])
                eph_pk = socket_bench.write_public(
                    str(directory), "initiator-eph.pem", m1["eph_pk"]
                )
                ct_sj = socket_bench.unb64(m1["ct_sj"])
                ss_sj = core.mlkem_decap(material["responder_static_sk"], ct_sj)
                ct_e, ss_e = core.mlkem_encap(eph_pk)
                ct_si, ss_si = core.mlkem_encap(material["initiator_static_pk"])
                d_si_ct, d_si = core.mlkem_encap(material["initiator_dr_pk"])
                n_j = secrets.token_bytes(16)
                chain_ff, _ = core.chain_fast_forward(
                    chain, epoch_j, converged_epoch - 1
                )
                tr12 = core.H(
                    "tr12",
                    sid,
                    n_i,
                    n_j,
                    epoch_i,
                    epoch_j,
                    converged_epoch,
                    eph_pk_bytes,
                    ct_sj,
                    ct_e,
                    ct_si,
                    d_si_ct,
                )
                kpre = socket_bench.pre_schedule(
                    chain_ff, ss_e, ss_sj, ss_si, tr12, sid, converged_epoch
                )
                tau_j = core.mac(
                    core.hkdf(kpre, b"mac-j"), core.H("tau_j", tr12)
                )
                send_message(
                    connection,
                    "M2",
                    {
                        "n_j": socket_bench.b64(n_j),
                        "e_j": epoch_j,
                        "ct_e": socket_bench.b64(ct_e),
                        "ct_si": socket_bench.b64(ct_si),
                        "d_si": socket_bench.b64(d_si_ct),
                        "tau_j": socket_bench.b64(tau_j),
                    },
                    one_way_delay_s,
                    events,
                    "responder",
                )

                m3 = receive_message(connection, "M3", events, "responder")
                d_sj_ct = socket_bench.unb64(m3["d_sj"])
                tau_i = socket_bench.unb64(m3["tau_i"])
                d_sj = core.mlkem_decap(material["responder_dr_sk"], d_sj_ct)
                tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
                expected_tau_i = core.mac(
                    core.hkdf(kpre, b"mac-i"), core.H("tau_i", tr3)
                )
                if not secrets.compare_digest(tau_i, expected_tau_i):
                    raise RuntimeError("M3 authentication failed")
                transcript = core.H("tr-final", tr3, tau_i)
                session, next_chain, confirm = socket_bench.final_schedule(
                    kpre, d_sj, d_si, transcript, sid, converged_epoch
                )
                session_hash = hashlib.sha256(session).hexdigest()
                transcript_hash = hashlib.sha256(transcript).hexdigest()
                candidate_path = directory / "candidate-state.json"
                shared.atomic_write_json(
                    candidate_path,
                    {
                        "state": "candidate",
                        "role": "responder",
                        "sid": sid,
                        "epoch": converged_epoch,
                        "session_sha256": session_hash,
                        "transcript_sha256": transcript_hash,
                    },
                )
                candidate_pending = True
                gamma = core.mac(confirm, core.H("confirm", transcript))
                before_m4 = shared.run_helper_json(
                    helper, "read", "--handle", handle
                )
                active_before_m4 = active_state

                if mode == DROP_ALL_M4:
                    record_event(events, "responder", "dropped", "M4")
                    after_m4 = shared.run_helper_json(
                        helper, "read", "--handle", handle
                    )
                    tpm_end = after_m4
                    result_queue.put(
                        {
                            "role": "responder",
                            "ok": True,
                            "expected_boundary_outcome": True,
                            "mode": mode,
                            "active_state": active_state,
                            "candidate_pending": candidate_pending,
                            "tpm_start": tpm_start,
                            "tpm_end": tpm_end,
                            "tpm_commit": None,
                            "m4_invariant": same_counter(before_m4, after_m4)
                            and active_before_m4 == active_state,
                            "m4_dropped": True,
                            "session_sha256": session_hash,
                            "transcript_sha256": transcript_hash,
                            "epoch": converged_epoch,
                            "events": events,
                        }
                    )
                    return

                send_message(
                    connection,
                    "M4",
                    {"gamma_j": socket_bench.b64(gamma)},
                    one_way_delay_s,
                    events,
                    "responder",
                )
                after_m4 = shared.run_helper_json(
                    helper, "read", "--handle", handle
                )
                m4_invariant = (
                    same_counter(before_m4, after_m4)
                    and active_before_m4 == active_state == "base"
                )

                if mode == DROP_CONF_I:
                    try:
                        receive_message(connection, "CONF_I", events, "responder")
                        raise RuntimeError("CONF_I was received in drop_conf_i mode")
                    except (ConnectionError, socket.timeout, OSError):
                        pass
                    tpm_end = shared.run_helper_json(
                        helper, "read", "--handle", handle
                    )
                    result_queue.put(
                        {
                            "role": "responder",
                            "ok": True,
                            "expected_boundary_outcome": True,
                            "mode": mode,
                            "active_state": active_state,
                            "candidate_pending": candidate_pending,
                            "tpm_start": tpm_start,
                            "tpm_end": tpm_end,
                            "tpm_commit": None,
                            "m4_invariant": m4_invariant,
                            "alpha_i_verified": False,
                            "session_sha256": session_hash,
                            "transcript_sha256": transcript_hash,
                            "epoch": converged_epoch,
                            "events": events,
                        }
                    )
                    return

                conf_i = receive_message(connection, "CONF_I", events, "responder")
                expected_alpha_i = core.mac(
                    session, core.H("adopt-i", sid, converged_epoch, transcript)
                )
                alpha_i = socket_bench.unb64(conf_i["tag"])
                if not secrets.compare_digest(alpha_i, expected_alpha_i):
                    raise RuntimeError("CONF_I alpha_i verification failed")
                alpha_i_verified = True
                record_event(events, "responder", "verified", "CONF_I")

                tpm_commit = shared.run_helper_json(
                    helper, "increment", "--handle", handle
                )
                if not shared.counter_increment_is_exact_once(tpm_commit):
                    raise RuntimeError("responder TPM counter did not increment once")
                active_state = "active"
                candidate_pending = False
                alpha_j = core.mac(
                    session, core.H("adopt-r", sid, converged_epoch, transcript)
                )
                completion_record = {
                    "sid": sid,
                    "epoch": converged_epoch,
                    "transcript_sha256": transcript_hash,
                    "alpha_i_sha256": hashlib.sha256(alpha_i).hexdigest(),
                    "alpha_j_sha256": hashlib.sha256(alpha_j).hexdigest(),
                    "tpm_counter": tpm_commit["after"],
                }
                committed_path = directory / "committed-state.json"
                shared.atomic_write_json(
                    committed_path,
                    {
                        "state": active_state,
                        "role": "responder",
                        "session_sha256": session_hash,
                        "transcript_sha256": transcript_hash,
                        "epoch": converged_epoch,
                        "tpm_counter": tpm_commit["after"],
                        "completion_record": completion_record,
                    },
                )
                record_event(events, "responder", "tpm_committed", "CONF_I")

                if mode == DROP_ACK_R:
                    record_event(events, "responder", "dropped", "ACK_R")
                    tpm_end = shared.run_helper_json(
                        helper, "read", "--handle", handle
                    )
                    result_queue.put(
                        {
                            "role": "responder",
                            "ok": True,
                            "expected_boundary_outcome": True,
                            "mode": mode,
                            "active_state": active_state,
                            "candidate_pending": candidate_pending,
                            "tpm_start": tpm_start,
                            "tpm_end": tpm_end,
                            "tpm_commit": tpm_commit,
                            "m4_invariant": m4_invariant,
                            "alpha_i_verified": alpha_i_verified,
                            "alpha_j_sha256": hashlib.sha256(alpha_j).hexdigest(),
                            "completion_record": completion_record,
                            "session_sha256": session_hash,
                            "transcript_sha256": transcript_hash,
                            "epoch": converged_epoch,
                            "events": events,
                        }
                    )
                    return

                send_message(
                    connection,
                    "ACK_R",
                    {"tag": socket_bench.b64(alpha_j)},
                    one_way_delay_s,
                    events,
                    "responder",
                    replay=False,
                )

                duplicate_no_increment = None
                replay_same_ack = None
                if mode == DUPLICATE_CONF_I:
                    duplicate = receive_message(
                        connection, "CONF_I", events, "responder"
                    )
                    duplicate_alpha_i = socket_bench.unb64(duplicate["tag"])
                    if not secrets.compare_digest(duplicate_alpha_i, expected_alpha_i):
                        raise RuntimeError("duplicate CONF_I differs from original")
                    before_duplicate = shared.run_helper_json(
                        helper, "read", "--handle", handle
                    )
                    after_duplicate = shared.run_helper_json(
                        helper, "read", "--handle", handle
                    )
                    duplicate_no_increment = same_counter(
                        before_duplicate, after_duplicate
                    )
                    send_message(
                        connection,
                        "ACK_R",
                        {"tag": socket_bench.b64(alpha_j)},
                        one_way_delay_s,
                        events,
                        "responder",
                        replay=True,
                    )
                    replay_same_ack = True

                tpm_end = shared.run_helper_json(
                    helper, "read", "--handle", handle
                )
                result_queue.put(
                    {
                        "role": "responder",
                        "ok": True,
                        "mode": mode,
                        "active_state": active_state,
                        "candidate_pending": candidate_pending,
                        "tpm_start": tpm_start,
                        "tpm_end": tpm_end,
                        "tpm_commit": tpm_commit,
                        "m4_invariant": m4_invariant,
                        "alpha_i_verified": alpha_i_verified,
                        "alpha_i_sha256": hashlib.sha256(alpha_i).hexdigest(),
                        "alpha_j_sha256": hashlib.sha256(alpha_j).hexdigest(),
                        "completion_record": completion_record,
                        "duplicate_conf_i_no_extra_increment": duplicate_no_increment,
                        "duplicate_conf_i_replayed_same_ack": replay_same_ack,
                        "session_sha256": session_hash,
                        "transcript_sha256": transcript_hash,
                        "epoch": converged_epoch,
                        "events": events,
                        "crypto_backend": core.CRYPTO_BACKEND,
                        "openssl": openssl_version,
                    }
                )
    except Exception as exc:
        if not announced:
            port_queue.put({"error": repr(exc)})
        result_queue.put(
            {
                "role": "responder",
                "ok": False,
                "mode": mode,
                "active_state": active_state,
                "candidate_pending": candidate_pending,
                "tpm_start": tpm_start,
                "tpm_end": tpm_end,
                "tpm_commit": tpm_commit,
                "alpha_i_verified": alpha_i_verified,
                "completion_record": completion_record,
                "events": events,
                "error": repr(exc),
                "traceback": traceback.format_exc(limit=10),
            }
        )


def initiator_worker(
    port: int,
    result_queue: mp.Queue,
    ck0_hex: str,
    sid: str,
    epoch_i: int,
    epoch_j: int,
    one_way_delay_s: float,
    helper: str,
    handle: str,
    trial_directory: str,
    material: dict[str, str],
    mode: str,
) -> None:
    events: list[dict] = []
    directory = role_workspace(trial_directory, "initiator")
    tpm_commit = None
    tpm_start = None
    tpm_end = None
    before_m4 = None
    after_m4 = None
    active_state = "base"
    candidate_pending = False
    gamma_j_verified = False
    alpha_j_verified = False
    try:
        available, openssl_version = core.openssl_ok()
        if not available:
            raise RuntimeError(openssl_version)
        chain, _ = core.chain_fast_forward(bytes.fromhex(ck0_hex), 0, epoch_i)
        converged_epoch = max(epoch_i, epoch_j) + 1
        tpm_start = shared.run_helper_json(helper, "read", "--handle", handle)

        with socket.create_connection(("127.0.0.1", port), timeout=180) as connection:
            connection.settimeout(180)
            record_event(events, "initiator", "tcp_connected", "TCP")
            n_i = secrets.token_bytes(16)
            eph_sk, eph_pk = core.mlkem_keygen("initiator-eph")
            eph_pk_bytes = core._read_bytes(eph_pk)
            ct_sj, ss_sj = core.mlkem_encap(material["responder_static_pk"])
            send_message(
                connection,
                "M1",
                {
                    "sid": sid,
                    "n_i": socket_bench.b64(n_i),
                    "e_i": epoch_i,
                    "eph_pk": socket_bench.b64(eph_pk_bytes),
                    "ct_sj": socket_bench.b64(ct_sj),
                },
                one_way_delay_s,
                events,
                "initiator",
            )

            m2 = receive_message(connection, "M2", events, "initiator")
            n_j = socket_bench.unb64(m2["n_j"])
            ct_e = socket_bench.unb64(m2["ct_e"])
            ct_si = socket_bench.unb64(m2["ct_si"])
            d_si_ct = socket_bench.unb64(m2["d_si"])
            tau_j = socket_bench.unb64(m2["tau_j"])
            ss_e = core.mlkem_decap(eph_sk, ct_e)
            ss_si = core.mlkem_decap(material["initiator_static_sk"], ct_si)
            d_si = core.mlkem_decap(material["initiator_dr_sk"], d_si_ct)
            chain_ff, _ = core.chain_fast_forward(
                chain, epoch_i, converged_epoch - 1
            )
            tr12 = core.H(
                "tr12",
                sid,
                n_i,
                n_j,
                epoch_i,
                epoch_j,
                converged_epoch,
                eph_pk_bytes,
                ct_sj,
                ct_e,
                ct_si,
                d_si_ct,
            )
            kpre = socket_bench.pre_schedule(
                chain_ff, ss_e, ss_sj, ss_si, tr12, sid, converged_epoch
            )
            expected_tau_j = core.mac(
                core.hkdf(kpre, b"mac-j"), core.H("tau_j", tr12)
            )
            if not secrets.compare_digest(tau_j, expected_tau_j):
                raise RuntimeError("M2 authentication failed")

            d_sj_ct, d_sj = core.mlkem_encap(material["responder_dr_pk"])
            tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
            tau_i = core.mac(
                core.hkdf(kpre, b"mac-i"), core.H("tau_i", tr3)
            )
            send_message(
                connection,
                "M3",
                {"d_sj": socket_bench.b64(d_sj_ct), "tau_i": socket_bench.b64(tau_i)},
                one_way_delay_s,
                events,
                "initiator",
            )

            transcript = core.H("tr-final", tr3, tau_i)
            session, next_chain, confirm = socket_bench.final_schedule(
                kpre, d_sj, d_si, transcript, sid, converged_epoch
            )
            session_hash = hashlib.sha256(session).hexdigest()
            transcript_hash = hashlib.sha256(transcript).hexdigest()
            candidate_path = directory / "candidate-state.json"
            shared.atomic_write_json(
                candidate_path,
                {
                    "state": "candidate",
                    "role": "initiator",
                    "sid": sid,
                    "epoch": converged_epoch,
                    "session_sha256": session_hash,
                    "transcript_sha256": transcript_hash,
                },
            )
            candidate_pending = True
            before_m4 = shared.run_helper_json(helper, "read", "--handle", handle)
            active_before_m4 = active_state

            if mode == DROP_ALL_M4:
                try:
                    receive_message(connection, "M4", events, "initiator")
                    raise RuntimeError("M4 was received in drop_all_m4 mode")
                except (ConnectionError, socket.timeout, OSError):
                    pass
                after_m4 = shared.run_helper_json(
                    helper, "read", "--handle", handle
                )
                tpm_end = after_m4
                result_queue.put(
                    {
                        "role": "initiator",
                        "ok": True,
                        "expected_boundary_outcome": True,
                        "mode": mode,
                        "active_state": active_state,
                        "candidate_pending": candidate_pending,
                        "tpm_start": tpm_start,
                        "tpm_end": tpm_end,
                        "tpm_commit": None,
                        "m4_invariant": same_counter(before_m4, after_m4)
                        and active_before_m4 == active_state,
                        "m4_received": False,
                        "session_sha256": session_hash,
                        "transcript_sha256": transcript_hash,
                        "epoch": converged_epoch,
                        "events": events,
                    }
                )
                return

            m4 = receive_message(connection, "M4", events, "initiator")
            gamma = socket_bench.unb64(m4["gamma_j"])
            expected_gamma = core.mac(confirm, core.H("confirm", transcript))
            if not secrets.compare_digest(gamma, expected_gamma):
                raise RuntimeError("M4 gamma_j verification failed")
            gamma_j_verified = True
            record_event(events, "initiator", "verified", "M4")
            after_m4 = shared.run_helper_json(helper, "read", "--handle", handle)
            m4_invariant = (
                same_counter(before_m4, after_m4)
                and active_before_m4 == active_state == "base"
            )

            alpha_i = core.mac(
                session, core.H("adopt-i", sid, converged_epoch, transcript)
            )
            if mode == DROP_CONF_I:
                record_event(events, "initiator", "dropped", "CONF_I")
                tpm_end = shared.run_helper_json(
                    helper, "read", "--handle", handle
                )
                result_queue.put(
                    {
                        "role": "initiator",
                        "ok": True,
                        "expected_boundary_outcome": True,
                        "mode": mode,
                        "active_state": active_state,
                        "candidate_pending": candidate_pending,
                        "tpm_start": tpm_start,
                        "tpm_end": tpm_end,
                        "tpm_commit": None,
                        "m4_invariant": m4_invariant,
                        "gamma_j_verified": gamma_j_verified,
                        "session_sha256": session_hash,
                        "transcript_sha256": transcript_hash,
                        "epoch": converged_epoch,
                        "events": events,
                    }
                )
                return

            send_message(
                connection,
                "CONF_I",
                {"tag": socket_bench.b64(alpha_i)},
                one_way_delay_s,
                events,
                "initiator",
                replay=False,
            )

            if mode == DROP_ACK_R:
                try:
                    receive_message(connection, "ACK_R", events, "initiator")
                    raise RuntimeError("ACK_R was received in drop_ack_r mode")
                except (ConnectionError, socket.timeout, OSError):
                    pass
                tpm_end = shared.run_helper_json(
                    helper, "read", "--handle", handle
                )
                result_queue.put(
                    {
                        "role": "initiator",
                        "ok": True,
                        "expected_boundary_outcome": True,
                        "mode": mode,
                        "active_state": active_state,
                        "candidate_pending": candidate_pending,
                        "tpm_start": tpm_start,
                        "tpm_end": tpm_end,
                        "tpm_commit": None,
                        "m4_invariant": m4_invariant,
                        "gamma_j_verified": gamma_j_verified,
                        "alpha_i_sha256": hashlib.sha256(alpha_i).hexdigest(),
                        "session_sha256": session_hash,
                        "transcript_sha256": transcript_hash,
                        "epoch": converged_epoch,
                        "events": events,
                    }
                )
                return

            ack_r = receive_message(connection, "ACK_R", events, "initiator")
            alpha_j = socket_bench.unb64(ack_r["tag"])
            expected_alpha_j = core.mac(
                session, core.H("adopt-r", sid, converged_epoch, transcript)
            )
            if not secrets.compare_digest(alpha_j, expected_alpha_j):
                raise RuntimeError("ACK_R alpha_j verification failed")
            alpha_j_verified = True
            record_event(events, "initiator", "verified", "ACK_R", replay=False)

            duplicate_ack_same = None
            if mode == DUPLICATE_CONF_I:
                send_message(
                    connection,
                    "CONF_I",
                    {"tag": socket_bench.b64(alpha_i)},
                    one_way_delay_s,
                    events,
                    "initiator",
                    replay=True,
                )
                replay_ack = receive_message(
                    connection, "ACK_R", events, "initiator"
                )
                replay_alpha_j = socket_bench.unb64(replay_ack["tag"])
                duplicate_ack_same = secrets.compare_digest(
                    replay_alpha_j, alpha_j
                ) and secrets.compare_digest(replay_alpha_j, expected_alpha_j)
                if not duplicate_ack_same:
                    raise RuntimeError("duplicate CONF_I did not replay the same ACK_R")
                record_event(events, "initiator", "verified", "ACK_R", replay=True)

            tpm_commit = shared.run_helper_json(
                helper, "increment", "--handle", handle
            )
            if not shared.counter_increment_is_exact_once(tpm_commit):
                raise RuntimeError("initiator TPM counter did not increment once")
            active_state = "active"
            candidate_pending = False
            committed_path = directory / "committed-state.json"
            shared.atomic_write_json(
                committed_path,
                {
                    "state": active_state,
                    "role": "initiator",
                    "session_sha256": session_hash,
                    "transcript_sha256": transcript_hash,
                    "epoch": converged_epoch,
                    "tpm_counter": tpm_commit["after"],
                },
            )
            export_path = directory / "session-export.json"
            shared.atomic_write_json(
                export_path,
                {
                    "exported": True,
                    "session_sha256": session_hash,
                    "transcript_sha256": transcript_hash,
                    "epoch": converged_epoch,
                    "tpm_counter": tpm_commit["after"],
                },
            )
            record_event(events, "initiator", "tpm_committed", "ACK_R")
            record_event(events, "initiator", "session_exported", "EXPORT")
            tpm_end = shared.run_helper_json(helper, "read", "--handle", handle)

        result_queue.put(
            {
                "role": "initiator",
                "ok": True,
                "mode": mode,
                "active_state": active_state,
                "candidate_pending": candidate_pending,
                "session_exported": True,
                "tpm_start": tpm_start,
                "tpm_end": tpm_end,
                "tpm_commit": tpm_commit,
                "m4_invariant": m4_invariant,
                "gamma_j_verified": gamma_j_verified,
                "alpha_j_verified": alpha_j_verified,
                "alpha_i_sha256": hashlib.sha256(alpha_i).hexdigest(),
                "alpha_j_sha256": hashlib.sha256(alpha_j).hexdigest(),
                "duplicate_conf_i_ack_same": duplicate_ack_same,
                "session_sha256": session_hash,
                "transcript_sha256": transcript_hash,
                "epoch": converged_epoch,
                "events": events,
                "crypto_backend": core.CRYPTO_BACKEND,
                "openssl": openssl_version,
            }
        )
    except Exception as exc:
        result_queue.put(
            {
                "role": "initiator",
                "ok": False,
                "mode": mode,
                "active_state": active_state,
                "candidate_pending": candidate_pending,
                "tpm_start": tpm_start,
                "tpm_end": tpm_end,
                "tpm_commit": tpm_commit,
                "gamma_j_verified": gamma_j_verified,
                "alpha_j_verified": alpha_j_verified,
                "events": events,
                "error": repr(exc),
                "traceback": traceback.format_exc(limit=10),
            }
        )


def run_rtt_probe(port: int, one_way_delay_s: float) -> tuple[float, list[dict]]:
    events: list[dict] = []
    with socket.create_connection(("127.0.0.1", port), timeout=60) as connection:
        connection.settimeout(60)
        nonce = secrets.token_hex(8)
        started = time.perf_counter()
        send_message(
            connection,
            "RTT_PROBE",
            {"nonce": nonce},
            one_way_delay_s,
            events,
            "parent",
        )
        response = receive_message(
            connection, "RTT_PROBE_ACK", events, "parent"
        )
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        if response.get("nonce") != nonce:
            raise RuntimeError("RTT probe nonce mismatch")
    return elapsed_ms, events


def collect_results(
    result_queue: mp.Queue,
    initiator: mp.Process,
    responder: mp.Process,
    timeout_s: float,
    parent_start_ns: int,
) -> tuple[list[dict], int | None]:
    results: list[dict] = []
    initiator_report_ns = None
    deadline = time.monotonic() + timeout_s
    while len(results) < 2:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        try:
            item = result_queue.get(timeout=min(remaining, 5.0))
            results.append(item)
            if item.get("role") == "initiator" and initiator_report_ns is None:
                initiator_report_ns = time.perf_counter_ns()
        except queue.Empty:
            if not initiator.is_alive() and not responder.is_alive():
                break
    for process in (initiator, responder):
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join(timeout=10)
    return results, initiator_report_ns


def message_send_sequence(events: list[dict]) -> list[str]:
    return [
        str(item["message"])
        for item in sorted(events, key=lambda item: item["monotonic_ns"])
        if item.get("action") == "sent"
        and item.get("message")
        not in ("RTT_PROBE", "RTT_PROBE_ACK")
    ]


def evaluate_case(mode: str, by_role: dict[str, dict], sequence: list[str]) -> tuple[bool, dict]:
    initiator = by_role.get("initiator", {})
    responder = by_role.get("responder", {})
    both_ok = bool(initiator.get("ok") and responder.get("ok"))
    i_no_change = same_counter(initiator.get("tpm_start"), initiator.get("tpm_end"))
    r_no_change = same_counter(responder.get("tpm_start"), responder.get("tpm_end"))
    i_once = shared.counter_increment_is_exact_once(
        initiator.get("tpm_commit") or {}
    )
    r_once = shared.counter_increment_is_exact_once(
        responder.get("tpm_commit") or {}
    )
    state_match = bool(
        initiator.get("session_sha256")
        and initiator.get("session_sha256") == responder.get("session_sha256")
        and initiator.get("transcript_sha256")
        == responder.get("transcript_sha256")
        and initiator.get("epoch") == responder.get("epoch")
    )
    details = {
        "both_processes_ok": both_ok,
        "initiator_counter_unchanged": i_no_change,
        "responder_counter_unchanged": r_no_change,
        "initiator_increment_exactly_once": i_once,
        "responder_increment_exactly_once": r_once,
        "state_hashes_and_epoch_match": state_match,
        "message_send_sequence": sequence,
    }
    if mode == NORMAL:
        expected_sequence = ["M1", "M2", "M3", "M4", "CONF_I", "ACK_R"]
        success = bool(
            both_ok
            and sequence == expected_sequence
            and initiator.get("m4_invariant")
            and responder.get("m4_invariant")
            and initiator.get("gamma_j_verified")
            and responder.get("alpha_i_verified")
            and initiator.get("alpha_j_verified")
            and i_once
            and r_once
            and initiator.get("active_state") == "active"
            and responder.get("active_state") == "active"
            and initiator.get("session_exported")
            and state_match
        )
    elif mode == DROP_ALL_M4:
        success = bool(
            both_ok
            and sequence == ["M1", "M2", "M3"]
            and i_no_change
            and r_no_change
            and initiator.get("active_state") == "base"
            and responder.get("active_state") == "base"
            and initiator.get("candidate_pending")
            and responder.get("candidate_pending")
            and responder.get("m4_dropped")
        )
    elif mode == DROP_CONF_I:
        success = bool(
            both_ok
            and sequence == ["M1", "M2", "M3", "M4"]
            and i_no_change
            and r_no_change
            and initiator.get("m4_invariant")
            and responder.get("m4_invariant")
            and initiator.get("active_state") == "base"
            and responder.get("active_state") == "base"
            and initiator.get("candidate_pending")
            and responder.get("candidate_pending")
        )
    elif mode == DROP_ACK_R:
        success = bool(
            both_ok
            and sequence == ["M1", "M2", "M3", "M4", "CONF_I"]
            and i_no_change
            and r_once
            and initiator.get("m4_invariant")
            and responder.get("m4_invariant")
            and responder.get("alpha_i_verified")
            and initiator.get("active_state") == "base"
            and responder.get("active_state") == "active"
            and initiator.get("candidate_pending")
            and not responder.get("candidate_pending")
        )
    elif mode == DUPLICATE_CONF_I:
        success = bool(
            both_ok
            and sequence
            == [
                "M1",
                "M2",
                "M3",
                "M4",
                "CONF_I",
                "ACK_R",
                "CONF_I",
                "ACK_R",
            ]
            and i_once
            and r_once
            and responder.get("duplicate_conf_i_no_extra_increment")
            and responder.get("duplicate_conf_i_replayed_same_ack")
            and initiator.get("duplicate_conf_i_ack_same")
            and initiator.get("active_state") == "active"
            and responder.get("active_state") == "active"
            and state_match
        )
    else:
        success = False
    details["success"] = success
    return success, details


def execute_case(
    case_id: str,
    mode: str,
    helper: Path,
    initiator_handle: str,
    responder_handle: str,
    rtt_ms: float,
    epoch_i: int,
    epoch_j: int,
    run_directory: Path,
    timeout_s: float,
) -> dict:
    case_directory = run_directory / case_id
    case_directory.mkdir(parents=True, exist_ok=False)
    material = prepare_trial_material(case_directory)
    ck0_hex = secrets.token_bytes(32).hex()
    sid = secrets.token_hex(16)
    one_way_delay_s = rtt_ms / 2000.0
    port_queue: mp.Queue = mp.Queue()
    ready_queue: mp.Queue = mp.Queue()
    result_queue: mp.Queue = mp.Queue()
    responder = mp.Process(
        target=responder_worker,
        args=(
            port_queue,
            ready_queue,
            result_queue,
            ck0_hex,
            sid,
            epoch_i,
            epoch_j,
            one_way_delay_s,
            str(helper),
            responder_handle,
            str(case_directory),
            material,
            mode,
        ),
        name=f"gtr-corrected-responder-{case_id}",
    )
    responder.start()
    try:
        startup = port_queue.get(timeout=timeout_s)
    except queue.Empty:
        startup = {"error": "responder startup timeout"}
    if "error" in startup:
        responder.terminate()
        responder.join(timeout=10)
        return {
            "schema": "gtr.physical-tpm-e2e-corrected-trial.v1",
            "case_id": case_id,
            "mode": mode,
            "sid": sid,
            "success": False,
            "error": startup["error"],
        }

    observed_rtt_ms, probe_events = run_rtt_probe(
        int(startup["port"]), one_way_delay_s
    )
    try:
        ready = ready_queue.get(timeout=timeout_s)
    except queue.Empty:
        ready = {"ready": False, "error": "responder trial-ready timeout"}
    if not ready.get("ready"):
        responder.terminate()
        responder.join(timeout=10)
        return {
            "schema": "gtr.physical-tpm-e2e-corrected-trial.v1",
            "case_id": case_id,
            "mode": mode,
            "sid": sid,
            "success": False,
            "error": ready.get("error"),
        }

    initiator = mp.Process(
        target=initiator_worker,
        args=(
            int(startup["port"]),
            result_queue,
            ck0_hex,
            sid,
            epoch_i,
            epoch_j,
            one_way_delay_s,
            str(helper),
            initiator_handle,
            str(case_directory),
            material,
            mode,
        ),
        name=f"gtr-corrected-initiator-{case_id}",
    )
    parent_start_utc = utc_now()
    parent_start_ns = time.perf_counter_ns()
    initiator.start()
    results, initiator_report_ns = collect_results(
        result_queue, initiator, responder, timeout_s, parent_start_ns
    )
    parent_end_ns = initiator_report_ns or time.perf_counter_ns()
    parent_end_utc = utc_now()
    by_role = {item.get("role"): item for item in results if item.get("role")}
    all_events = probe_events[:]
    for item in results:
        all_events.extend(item.get("events", []))
    all_events.sort(key=lambda item: item["monotonic_ns"])
    sequence = message_send_sequence(all_events)
    success, evaluation = evaluate_case(mode, by_role, sequence)
    initiator_result = by_role.get("initiator", {})
    responder_result = by_role.get("responder", {})
    conflicting_adoption = bool(
        initiator_result.get("active_state") == "active"
        and responder_result.get("active_state") == "active"
        and not evaluation["state_hashes_and_epoch_match"]
    )
    return {
        "schema": "gtr.physical-tpm-e2e-corrected-trial.v1",
        "case_id": case_id,
        "mode": mode,
        "sid": sid,
        "sid_bits": 128,
        "started_utc": parent_start_utc,
        "ended_utc": parent_end_utc,
        "success": bool(success and not conflicting_adoption),
        "configured_rtt_ms": rtt_ms,
        "observed_rtt_ms": observed_rtt_ms,
        "ttsc_ms": (parent_end_ns - parent_start_ns) / 1_000_000.0,
        "ttsc_boundary": "parent immediately before initiator process launch through initiator commit and export report",
        "fresh_tcp_connection_included": True,
        "enrollment_key_generation_excluded": True,
        "rtt_probe_excluded": True,
        "message_send_sequence": sequence,
        "message_events": all_events,
        "evaluation": evaluation,
        "initiator": initiator_result,
        "responder": responder_result,
        "session_sha256": initiator_result.get("session_sha256"),
        "transcript_sha256": initiator_result.get("transcript_sha256"),
        "committed_epoch": initiator_result.get("epoch"),
        "conflicting_adoption": conflicting_adoption,
        "process_exit_codes": {
            "initiator": initiator.exitcode,
            "responder": responder.exitcode,
        },
        "error": None
        if success and not conflicting_adoption
        else "one or more corrected-flow success criteria failed",
    }


def define_pair(helper: Path, initiator_handle: str, responder_handle: str) -> dict:
    probe = shared.run_helper_json(str(helper), "probe")
    existing = {
        item.get("handle", "").lower()
        for item in probe.get("managed_handles", [])
    }
    for handle in (initiator_handle, responder_handle):
        if handle.lower() in existing:
            raise RuntimeError(f"selected handle already exists: {handle}")
    defined: list[str] = []
    try:
        for handle in (initiator_handle, responder_handle):
            result = shared.run_helper_json(
                str(helper), "define", "--handle", handle
            )
            if not result.get("created"):
                raise RuntimeError(f"handle was not freshly created: {handle}")
            defined.append(handle)
        return {
            "probe_before": probe,
            "defined": defined,
            "initial": {
                "initiator": shared.run_helper_json(
                    str(helper), "read", "--handle", initiator_handle
                ),
                "responder": shared.run_helper_json(
                    str(helper), "read", "--handle", responder_handle
                ),
            },
        }
    except Exception:
        for handle in reversed(defined):
            try:
                shared.run_helper_json(
                    str(helper), "undefine", "--handle", handle
                )
            except Exception:
                pass
        raise


def cleanup_pair(helper: Path, initiator_handle: str, responder_handle: str) -> dict:
    cleanup = {
        "initiator_undefined": False,
        "responder_undefined": False,
        "error": None,
    }
    for role, handle in (
        ("responder", responder_handle),
        ("initiator", initiator_handle),
    ):
        try:
            removed = shared.run_helper_json(
                str(helper), "undefine", "--handle", handle
            )
            cleanup[f"{role}_undefined"] = bool(removed.get("removed"))
        except Exception as exc:
            cleanup["error"] = cleanup["error"] or repr(exc)
    try:
        probe = shared.run_helper_json(str(helper), "probe")
        cleanup["verification_probe"] = probe
        remaining = {
            item.get("handle", "").lower()
            for item in probe.get("managed_handles", [])
        }
        cleanup["selected_handles_absent"] = (
            initiator_handle.lower() not in remaining
            and responder_handle.lower() not in remaining
        )
    except Exception as exc:
        cleanup["error"] = cleanup["error"] or repr(exc)
        cleanup["selected_handles_absent"] = False
    return cleanup


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=50)
    parser.add_argument("--rtt-ms", type=float, default=100.0)
    parser.add_argument("--initiator-handle", default="0x01510010")
    parser.add_argument("--responder-handle", default="0x01510011")
    parser.add_argument("--initiator-epoch", type=int, default=0)
    parser.add_argument("--responder-epoch", type=int, default=5)
    parser.add_argument("--helper", type=Path, default=DEFAULT_HELPER)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--trial-timeout-seconds", type=float, default=300.0)
    args = parser.parse_args()
    if not 1 <= args.trials <= 100:
        parser.error("--trials must be in 1..100")
    if args.rtt_ms < 0 or args.rtt_ms > 10_000:
        parser.error("--rtt-ms must be in 0..10000")
    if args.initiator_handle.lower() == args.responder_handle.lower():
        parser.error("initiator and responder handles must differ")
    helper = args.helper.resolve()
    if not helper.is_file():
        parser.error(f"TPM helper not found: {helper}")
    available, openssl_version = core.openssl_ok()
    if not available:
        raise SystemExit(openssl_version)

    run_id = datetime.now().strftime("run-%Y%m%d-%H%M%S-") + secrets.token_hex(4)
    output_root = args.output_root.resolve()
    run_directory = output_root / run_id
    run_directory.mkdir(parents=True, exist_ok=False)
    trials_path = run_directory / "gtr_physical_tpm_e2e_trials.jsonl"
    prechecks_path = run_directory / "gtr_physical_tpm_e2e_prechecks.json"
    summary_path = run_directory / "gtr_physical_tpm_e2e_summary.json"
    log_path = run_directory / "run.log"
    environment_path = run_directory / "environment.txt"
    environment_json_path = run_directory / "environment.json"

    def log(message: str) -> None:
        line = f"[{datetime.now().astimezone().isoformat()}] {message}"
        print(line, flush=True)
        with log_path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(line + "\n")
            stream.flush()

    started_utc = utc_now()
    probe = shared.run_helper_json(str(helper), "probe")
    environment = shared.capture_environment(helper, probe, openssl_version)
    environment.update(
        {
            "runner": str(Path(__file__).resolve()),
            "runner_sha256": shared.sha256_file(Path(__file__)),
            "flow": "M1 M2 M3 M4 CONF_I ACK_R",
            "ttsc_start": "parent immediately before fresh initiator process launch",
            "ttsc_end": "initiator commit and session export report received by parent",
        }
    )
    shared.atomic_write_json(environment_json_path, environment)
    shared.write_environment_text(environment_path, environment)
    with environment_path.open("a", encoding="utf-8") as stream:
        stream.write(f"runner={environment['runner']}\n")
        stream.write(f"runner_sha256={environment['runner_sha256']}\n")
        stream.write("flow=M1 M2 M3 M4 CONF_I ACK_R\n")
        stream.write(f"ttsc_start={environment['ttsc_start']}\n")
        stream.write(f"ttsc_end={environment['ttsc_end']}\n")

    prechecks: list[dict] = []
    main_trials: list[dict] = []
    precheck_setup = None
    precheck_cleanup = None
    main_setup = None
    main_cleanup = None
    main_final_reads = None
    fatal_error = None

    try:
        log(
            "START corrected physical TPM integrated GT-R "
            f"prechecks=4 trials={args.trials} rtt_ms={args.rtt_ms}"
        )
        precheck_setup = define_pair(
            helper, args.initiator_handle, args.responder_handle
        )
        for index, mode in enumerate(PRECHECK_MODES, 1):
            log(f"PRECHECK_START {index}/4 mode={mode}")
            result = execute_case(
                f"precheck-{index:02d}-{mode}",
                mode,
                helper,
                args.initiator_handle,
                args.responder_handle,
                args.rtt_ms,
                args.initiator_epoch,
                args.responder_epoch,
                run_directory,
                args.trial_timeout_seconds,
            )
            prechecks.append(result)
            shared.atomic_write_json(prechecks_path, prechecks)
            log(
                f"PRECHECK_DONE {index}/4 mode={mode} success={result.get('success')}"
            )
        precheck_cleanup = cleanup_pair(
            helper, args.initiator_handle, args.responder_handle
        )
        if not all(item.get("success") for item in prechecks):
            raise RuntimeError("one or more state-boundary prechecks failed")
        if not precheck_cleanup.get("selected_handles_absent") or precheck_cleanup.get("error"):
            raise RuntimeError("precheck TPM handle cleanup failed")

        prechecks[0]["fresh_execution_restart_verified"] = bool(
            prechecks[1].get("success")
            and prechecks[1].get("message_send_sequence")
            == ["M1", "M2", "M3", "M4"]
        )
        shared.atomic_write_json(prechecks_path, prechecks)

        main_setup = define_pair(
            helper, args.initiator_handle, args.responder_handle
        )
        for trial_id in range(1, args.trials + 1):
            log(f"TRIAL_START {trial_id}/{args.trials}")
            try:
                trial = execute_case(
                    f"trial-{trial_id:04d}",
                    NORMAL,
                    helper,
                    args.initiator_handle,
                    args.responder_handle,
                    args.rtt_ms,
                    args.initiator_epoch,
                    args.responder_epoch,
                    run_directory,
                    args.trial_timeout_seconds,
                )
            except Exception as exc:
                trial = {
                    "schema": "gtr.physical-tpm-e2e-corrected-trial.v1",
                    "case_id": f"trial-{trial_id:04d}",
                    "mode": NORMAL,
                    "success": False,
                    "error": repr(exc),
                    "orchestrator_traceback": traceback.format_exc(limit=12),
                }
            main_trials.append(trial)
            shared.append_jsonl(trials_path, trial)
            log(
                f"TRIAL_DONE {trial_id}/{args.trials} success={trial.get('success')} "
                f"ttsc_ms={trial.get('ttsc_ms')} observed_rtt_ms={trial.get('observed_rtt_ms')}"
            )
        main_final_reads = {
            "initiator": shared.run_helper_json(
                str(helper), "read", "--handle", args.initiator_handle
            ),
            "responder": shared.run_helper_json(
                str(helper), "read", "--handle", args.responder_handle
            ),
        }
    except Exception as exc:
        fatal_error = repr(exc)
        log(f"FATAL {fatal_error}")
        with log_path.open("a", encoding="utf-8") as stream:
            stream.write(traceback.format_exc(limit=20) + "\n")
    finally:
        if main_setup is not None:
            main_cleanup = cleanup_pair(
                helper, args.initiator_handle, args.responder_handle
            )
        elif precheck_setup is not None and precheck_cleanup is None:
            precheck_cleanup = cleanup_pair(
                helper, args.initiator_handle, args.responder_handle
            )

    successful = [trial for trial in main_trials if trial.get("success")]
    ttsc_samples = [float(trial["ttsc_ms"]) for trial in successful]
    rtt_samples = [float(trial["observed_rtt_ms"]) for trial in successful]
    responder_increment_samples = [
        float(trial["responder"]["tpm_commit"]["increment_ms"])
        for trial in successful
    ]
    initiator_increment_samples = [
        float(trial["initiator"]["tpm_commit"]["increment_ms"])
        for trial in successful
    ]
    conflicts = sum(1 for trial in main_trials if trial.get("conflicting_adoption"))
    message_flow_ok = all(
        trial.get("message_send_sequence")
        == ["M1", "M2", "M3", "M4", "CONF_I", "ACK_R"]
        for trial in successful
    ) and len(successful) == args.trials
    m4_invariants_ok = all(
        trial.get("initiator", {}).get("m4_invariant")
        and trial.get("responder", {}).get("m4_invariant")
        for trial in successful
    ) and len(successful) == args.trials
    alpha_verification_ok = all(
        trial.get("responder", {}).get("alpha_i_verified")
        and trial.get("initiator", {}).get("alpha_j_verified")
        for trial in successful
    ) and len(successful) == args.trials
    state_match_ok = all(
        trial.get("evaluation", {}).get("state_hashes_and_epoch_match")
        for trial in successful
    ) and len(successful) == args.trials
    initiator_verified_increments = sum(
        1
        for trial in main_trials
        if trial.get("evaluation", {}).get("initiator_increment_exactly_once")
    )
    responder_verified_increments = sum(
        1
        for trial in main_trials
        if trial.get("evaluation", {}).get("responder_increment_exactly_once")
    )
    prechecks_ok = len(prechecks) == 4 and all(
        item.get("success") for item in prechecks
    )
    precheck_cleanup_ok = bool(
        precheck_cleanup
        and precheck_cleanup.get("initiator_undefined")
        and precheck_cleanup.get("responder_undefined")
        and precheck_cleanup.get("selected_handles_absent")
        and not precheck_cleanup.get("error")
    )
    main_cleanup_ok = bool(
        main_cleanup
        and main_cleanup.get("initiator_undefined")
        and main_cleanup.get("responder_undefined")
        and main_cleanup.get("selected_handles_absent")
        and not main_cleanup.get("error")
    )
    pass_status = bool(
        fatal_error is None
        and prechecks_ok
        and precheck_cleanup_ok
        and len(main_trials) == args.trials
        and len(successful) == args.trials
        and message_flow_ok
        and m4_invariants_ok
        and alpha_verification_ok
        and state_match_ok
        and conflicts == 0
        and initiator_verified_increments == args.trials
        and responder_verified_increments == args.trials
        and main_cleanup_ok
    )

    summary = {
        "schema": "gtr.physical-tpm-e2e-corrected-summary.v1",
        "status": "pass" if pass_status else "fail",
        "run_id": run_id,
        "started_utc": started_utc,
        "completed_utc": utc_now(),
        "configuration": {
            "trials_requested": args.trials,
            "configured_rtt_ms": args.rtt_ms,
            "loss_percent": 0,
            "initiator_handle": args.initiator_handle.lower(),
            "responder_handle": args.responder_handle.lower(),
            "initiator_epoch": args.initiator_epoch,
            "responder_epoch": args.responder_epoch,
            "converged_epoch": max(args.initiator_epoch, args.responder_epoch) + 1,
            "flow": ["M1", "M2", "M3", "M4", "CONF_I", "ACK_R"],
            "network_delay_injection": "50 ms application delay before each message at 100 ms configured RTT",
            "pure_six_flight_delay_ms": 3.0 * args.rtt_ms,
            "trial_isolation": "fresh initiator and responder processes, TCP connection, sid, and nonces",
            "enrollment_key_generation_excluded": True,
            "rtt_probe_excluded": True,
            "fresh_tcp_and_initiator_launch_included": True,
            "ttsc_start": "parent immediately before initiator process launch",
            "ttsc_end": "parent receives initiator commit and export completion",
        },
        "prechecks": {
            "passed": sum(1 for item in prechecks if item.get("success")),
            "total": 4,
            "all_passed": prechecks_ok,
            "all_m4_loss": next(
                (item.get("success") for item in prechecks if item.get("mode") == DROP_ALL_M4),
                False,
            ),
            "conf_i_loss": next(
                (item.get("success") for item in prechecks if item.get("mode") == DROP_CONF_I),
                False,
            ),
            "ack_r_loss": next(
                (item.get("success") for item in prechecks if item.get("mode") == DROP_ACK_R),
                False,
            ),
            "duplicate_conf_i": next(
                (item.get("success") for item in prechecks if item.get("mode") == DUPLICATE_CONF_I),
                False,
            ),
            "fresh_restart_after_m4_loss": bool(
                prechecks and prechecks[0].get("fresh_execution_restart_verified")
            ),
            "cleanup": precheck_cleanup,
        },
        "results": {
            "trials_completed": len(main_trials),
            "trials_succeeded": len(successful),
            "trials_failed": len(main_trials) - len(successful),
            "success_rate": len(successful) / args.trials if args.trials else 0.0,
            "ttsc_ms": {
                "samples": ttsc_samples,
                "median": statistics.median(ttsc_samples) if ttsc_samples else None,
                "p95": shared.percentile(ttsc_samples, 0.95),
            },
            "observed_rtt_ms": {
                "samples": rtt_samples,
                "median": statistics.median(rtt_samples) if rtt_samples else None,
                "p95": shared.percentile(rtt_samples, 0.95),
            },
            "responder_tpm_increment_ms": {
                "samples": responder_increment_samples,
                "median": statistics.median(responder_increment_samples)
                if responder_increment_samples
                else None,
                "p95": shared.percentile(responder_increment_samples, 0.95),
            },
            "initiator_tpm_increment_ms": {
                "samples": initiator_increment_samples,
                "median": statistics.median(initiator_increment_samples)
                if initiator_increment_samples
                else None,
                "p95": shared.percentile(initiator_increment_samples, 0.95),
            },
            "message_flow_all_correct": message_flow_ok,
            "m4_state_and_counter_invariant_all": m4_invariants_ok,
            "alpha_i_and_alpha_j_all_verified": alpha_verification_ok,
            "all_session_transcript_epoch_match": state_match_ok,
            "initiator_verified_increments": initiator_verified_increments,
            "responder_verified_increments": responder_verified_increments,
            "conflicting_adoptions": conflicts,
        },
        "tpm": {
            "main_initial_reads": main_setup.get("initial") if main_setup else None,
            "main_final_reads": main_final_reads,
            "cleanup": main_cleanup,
            "clear_or_ownership_changed": False,
        },
        "environment": environment,
        "fatal_error": fatal_error,
        "outputs": {
            "trials_jsonl": str(trials_path),
            "prechecks_json": str(prechecks_path),
            "summary_json": str(summary_path),
            "run_log": str(log_path),
            "environment_txt": str(environment_path),
        },
        "limitations": [
            "two logical endpoints share one physical TPM on this Windows PC",
            "100 ms RTT is injected at the application layer on TCP loopback",
            "the TPM protects monotonic NV counters; ML-KEM runs through OpenSSL-backed cryptography",
        ],
        "source_sha256": shared.sha256_file(Path(__file__)),
    }
    shared.atomic_write_json(summary_path, summary)
    output_root.mkdir(parents=True, exist_ok=True)
    shutil.copy2(summary_path, output_root / "latest-summary.json")
    if trials_path.exists():
        shutil.copy2(trials_path, output_root / "latest-trials.jsonl")
    if prechecks_path.exists():
        shutil.copy2(prechecks_path, output_root / "latest-prechecks.json")
    if pass_status:
        (run_directory / "COMPLETE").write_text(utc_now() + "\n", encoding="utf-8")
        log(
            f"COMPLETE prechecks=4/4 success={len(successful)}/{args.trials} "
            f"ttsc_median_ms={summary['results']['ttsc_ms']['median']} "
            f"ttsc_p95_ms={summary['results']['ttsc_ms']['p95']}"
        )
    else:
        log(
            f"FAILED prechecks={sum(1 for item in prechecks if item.get('success'))}/4 "
            f"success={len(successful)}/{args.trials} fatal_error={fatal_error}"
        )
    print(
        json.dumps(
            {
                "status": summary["status"],
                "run_directory": str(run_directory),
                "prechecks": summary["prechecks"],
                "results": summary["results"],
            },
            indent=2,
        )
    )
    return 0 if pass_status else 1


if __name__ == "__main__":
    mp.freeze_support()
    raise SystemExit(main())
