# Manuscript-to-data map

The figure/table numbering below refers to the supplied GT-R manuscript. Conceptual artwork and final manuscript PNG/PDF files are not included.

For communication-budget and timing definitions, including why the policy macro byte counts differ by 64 B from the complete-execution budgets, see [docs/MEASUREMENT_SCOPES.md](docs/MEASUREMENT_SCOPES.md). If the manuscript is subsequently renumbered, use the experiment/condition names in this map to identify the same evidence.

| Item | Supporting files | Scope |
|---|---|---|
| Figures 1–3 | No measured input data | Conceptual timeline, architecture, protocol sequence |
| Figure 4 | `01_policy_security_simulation/results/frontier_runs.csv`, `raw_metrics.csv`, `reauth_manifest.json` | Configured policy boundaries |
| Figure 5 | `01_policy_security_simulation/results/raw_metrics.csv`, `episode_outcomes.csv.gz`, `seal_sweep.csv`, `robustness_runs.csv` | Encoded regressions/ablations, not attack-probability estimates |
| Figure 6(a) | `02_network_emulation/results/gtr-mutual-complete-n100-final/` and `pq-tls-mutual-complete-n100-final/` | Recorded summary and per-trial JSONL/CSV |
| Figure 6(b) | `02_network_emulation/results/udp-paired-n100-final/` | Raw/selective UDP trials, including 20% loss |
| Tables 1–2 | No measured input data | Literature comparison and notation |
| Table 3 | `01_policy_security_simulation/results/`, `07_formal_verification/` | Model-specific verification and encoded regression outcomes |
| Table 4 | `03_implementation_state_safety/results/reauth_testbed_manifest.json`, `software_ftpm/gtr_v185_integration_n1000.json`, `results_raw/tpm_hardware/run-20260930-142533-b8bad9c4/run.json`, `results_raw/vtpm_reboot/windows-rerun-20260930/`, and `07_formal_verification/resync_statecheck_result.txt` | Selected Windows implementation, software/hardware TPM, and bounded-state checks; consult the manuscript for each row's exact measurement scope |
| Table 5 | Directories listed below | Repeated-trial completion and recovery |
| Table 6 | `05_external_protocol_comparison/results/*.csv`, `manifest.json`, `reference_validation.json` | Controlled reconstructed reference flows, not a security ranking |
| Table 7 | `08_mission_budget/compute_table7.py`, `table7_budget.csv` | Deterministic sizing, not a hardware rerun |

## Table 5 row-level index

All paths below are relative to the repository root.

| Condition | Result path |
|---|---|
| GT-R RTT sweep | `02_network_emulation/results/gtr-mutual-complete-n100-final/` |
| GT-R + physical TPM | `04_physical_tpm_corrected/results/physical-tpm-e2e-corrected/latest-summary.json`, `latest-prechecks.json`, `latest-trials.jsonl` |
| PQ-TLS RTT sweep | `02_network_emulation/results/pq-tls-mutual-complete-n100-final/` |
| M4 loss / safe restart | `02_network_emulation/results/m4-loss-recovery-n100-final/` |
| 0.75-s ACK blackout | `02_network_emulation/results/adoption-ack-loss-n100-final/` |
| Permanent ACK loss / expiry | `02_network_emulation/results/ack-expiry-n1000-final/` |
| UDP 20% loss | `02_network_emulation/results/udp-paired-n100-final/` |

Per-trial statistics remain available after removal of the provisioning secrets and transient endpoint snapshots. Saved paths referring to excluded files are historical metadata, not promises that those files are public. Raw PCAP and console logs are not included.

## Legacy and exploratory material

Earlier `resync`/`qartz` models, earlier TPM runs dated before the Windows campaign, older fTPM timing files, and exploratory estimator/ProVerif outputs are retained as source-history evidence. Their original platform, dates, limitations, and incomplete-proof status remain intact. Do not use them as interchangeable substitutes for the indexed final campaigns.
