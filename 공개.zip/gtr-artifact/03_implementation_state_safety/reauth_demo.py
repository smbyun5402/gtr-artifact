#!/usr/bin/env python3
# Q-ARTZ-Reauth Windows-native harness for the four-flight GT-R cryptographic
# flow. It invokes OpenSSL 4.0 ML-KEM-768/ML-DSA-65 through either the CLI or
# the OpenSSL-backed ``cryptography`` bindings and uses
# Python-standard-library HKDF/HMAC/hash/fast-forward operations, a volatile
# bounded pre-candidate cache, atomically persisted final candidates, a
# file-backed monotonic-counter surrogate,
# and an epoch-indexed DR-KEM instantiated with real per-epoch ML-KEM keys.
#
# OpenSSL 4.0.2 provides the required native ML-KEM/ML-DSA operations on macOS;
# the same command-line path is supported on Windows.
#
# IMPLEMENTED AND MODELED COMPONENTS:
#   IMPLEMENTED: ML-KEM-768 encaps/decaps, ML-DSA-65 sign/verify;
#         HKDF-SHA256 chain + O(gap) fast-forward; HMAC transcript tags; canonical
#         encodings; file persistence and replay-after-restart logic.
#   MODELED: the RoT counter remains a file-backed surrogate.  DR-KEM uses real
#         independent per-epoch ML-KEM-768 keys; the GGM deterministic-keygen
#         storage optimization and hardware secure deletion remain out of scope.
#
# Output: results/reauth_cases.txt (machine-parsable) + results/reauth_testbed_macros.tex
# Run:    python reauth_demo.py           (all cases + microbench + macros)
#         python reauth_demo.py replay-after-restart   (persistence sub-check)

import os
import sys
import time
import json
import hmac
import hashlib
import secrets
import subprocess
import tempfile
import platform
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
# OpenSSL's macOS CLI can mishandle decomposed Unicode in output paths. Keep
# disposable primitive files in an ASCII-only temporary directory by default.
WORK = os.environ.get("GTR_WORK", os.path.join(tempfile.gettempdir(),
                                               "gtr-reauth-work"))
os.makedirs(OUT, exist_ok=True)
os.makedirs(WORK, exist_ok=True)

LOCAL_OPENSSL = os.path.expanduser("~/.gtr-tools/openssl-4.0.2/bin/openssl")
OPENSSL = os.environ.get("OPENSSL") or \
    (LOCAL_OPENSSL if os.path.isfile(LOCAL_OPENSSL) else "openssl")
CRYPTO_BACKEND = None

# The DR layer below instantiates epoch-wise ML-KEM keys through OpenSSL. A
# reconnect carries one ML-KEM ciphertext (1088 B) in each direction; each
# epoch public key is published once at enrollment (1184 B raw encoding).
DR_CT_BYTES = 1088
DR_PK_BYTES = 1184
MAX_PRE_CANDIDATES = 64
M1_FLOOD_ATTEMPTS = 1000


# ---------------------------------------------------------------- shell / crypto
def _run(args, inp=None, check=True):
    result = subprocess.run([OPENSSL] + args, input=inp, capture_output=True)
    if check and result.returncode != 0:
        detail = result.stderr.decode(errors="replace").strip()
        raise RuntimeError(f"OpenSSL failed ({' '.join(args)}): {detail}")
    return result


def openssl_ok():
    global CRYPTO_BACKEND
    try:
        r = _run(["version"], check=False)
        if r.returncode == 0:
            CRYPTO_BACKEND = "openssl-cli"
            return True, r.stdout.decode(errors="replace").strip()
    except OSError:
        pass

    try:
        import cryptography
        from cryptography.hazmat.backends.openssl.backend import backend
        from cryptography.hazmat.primitives.asymmetric import mlkem, mldsa

        # Force capability lookup here so an older binding fails before a run
        # can overwrite result files.
        _ = mlkem.MLKEM768PrivateKey
        _ = mldsa.MLDSA65PrivateKey
        CRYPTO_BACKEND = "cryptography-openssl-inprocess"
        return True, (f"{backend.openssl_version_text()} via cryptography "
                      f"{cryptography.__version__}")
    except (ImportError, AttributeError) as exc:
        return False, f"OpenSSL CLI and cryptography PQ bindings unavailable: {exc}"


def _tmp(name):
    return os.path.join(WORK, name)


def _scratch(prefix, suffix=".bin"):
    fd, path = tempfile.mkstemp(prefix=f"{prefix}-", suffix=suffix, dir=WORK)
    os.close(fd)
    return path


def _read_bytes(path):
    with open(path, "rb") as f:
        return f.read()


def mlkem_keygen(tag):
    unique = secrets.token_hex(6)
    sk = _tmp(f"{tag}_{unique}_kem_sk.pem")
    pk = _tmp(f"{tag}_{unique}_kem_pk.pem")
    if CRYPTO_BACKEND == "openssl-cli":
        _run(["genpkey", "-algorithm", "ML-KEM-768", "-out", sk])
        _run(["pkey", "-in", sk, "-pubout", "-out", pk])
    else:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import mlkem

        key = mlkem.MLKEM768PrivateKey.generate()
        with open(sk, "wb") as f:
            f.write(key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            ))
        with open(pk, "wb") as f:
            f.write(key.public_key().public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ))
    return sk, pk


def mlkem_encap(pk):
    if CRYPTO_BACKEND != "openssl-cli":
        from cryptography.hazmat.primitives import serialization

        key = serialization.load_pem_public_key(_read_bytes(pk))
        shared_secret, ciphertext = key.encapsulate()
        return ciphertext, shared_secret

    ct = _scratch("kem-ct"); ss = _scratch("kem-ss-enc")
    try:
        _run(["pkeyutl", "-encap", "-inkey", pk, "-pubin", "-out", ct, "-secret", ss])
        with open(ct, "rb") as f:
            ct_bytes = f.read()
        with open(ss, "rb") as f:
            ss_bytes = f.read()
        return ct_bytes, ss_bytes
    finally:
        for path in (ct, ss):
            try: os.remove(path)
            except OSError: pass


def mlkem_decap(sk, ct_bytes):
    if CRYPTO_BACKEND != "openssl-cli":
        from cryptography.hazmat.primitives import serialization

        key = serialization.load_pem_private_key(_read_bytes(sk), password=None)
        return key.decapsulate(ct_bytes)

    ct = _scratch("kem-ct-in"); ss = _scratch("kem-ss-dec")
    try:
        with open(ct, "wb") as f:
            f.write(ct_bytes)
        _run(["pkeyutl", "-decap", "-inkey", sk, "-in", ct, "-secret", ss])
        with open(ss, "rb") as f:
            return f.read()
    finally:
        for path in (ct, ss):
            try: os.remove(path)
            except OSError: pass


def mldsa_keygen(tag):
    unique = secrets.token_hex(6)
    sk = _tmp(f"{tag}_{unique}_dsa_sk.pem")
    pk = _tmp(f"{tag}_{unique}_dsa_pk.pem")
    if CRYPTO_BACKEND == "openssl-cli":
        _run(["genpkey", "-algorithm", "ML-DSA-65", "-out", sk])
        _run(["pkey", "-in", sk, "-pubout", "-out", pk])
    else:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import mldsa

        key = mldsa.MLDSA65PrivateKey.generate()
        with open(sk, "wb") as f:
            f.write(key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            ))
        with open(pk, "wb") as f:
            f.write(key.public_key().public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ))
    return sk, pk


def mldsa_sign(sk, msg):
    if CRYPTO_BACKEND != "openssl-cli":
        from cryptography.hazmat.primitives import serialization

        key = serialization.load_pem_private_key(_read_bytes(sk), password=None)
        return key.sign(msg)

    m = _scratch("dsa-msg"); sig = _scratch("dsa-sig")
    try:
        with open(m, "wb") as f:
            f.write(msg)
        _run(["pkeyutl", "-sign", "-inkey", sk, "-rawin", "-in", m, "-out", sig])
        with open(sig, "rb") as f:
            return f.read()
    finally:
        for path in (m, sig):
            try: os.remove(path)
            except OSError: pass


def mldsa_verify(pk, msg, sig_bytes):
    if CRYPTO_BACKEND != "openssl-cli":
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives import serialization

        key = serialization.load_pem_public_key(_read_bytes(pk))
        try:
            key.verify(sig_bytes, msg)
            return True
        except InvalidSignature:
            return False

    m = _scratch("dsa-msg-verify"); sig = _scratch("dsa-sig-verify")
    try:
        with open(m, "wb") as f:
            f.write(msg)
        with open(sig, "wb") as f:
            f.write(sig_bytes)
        r = _run(["pkeyutl", "-verify", "-inkey", pk, "-pubin", "-rawin",
                  "-in", m, "-sigfile", sig], check=False)
        return r.returncode == 0 and b"Verified Successfully" in r.stdout
    finally:
        for path in (m, sig):
            try: os.remove(path)
            except OSError: pass


# ---------------------------------------------------------------- real KDF/MAC
def _canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"),
                      default=lambda b: b.hex() if isinstance(b, bytes) else str(b)
                      ).encode()


def H(*parts):
    h = hashlib.sha256()
    for p in parts:
        b = p if isinstance(p, bytes) else _canon(p)
        h.update(len(b).to_bytes(4, "big")); h.update(b)
    return h.digest()


def hkdf(secret, info, salt=b"qartz-reauth", length=32):
    prk = hmac.new(salt, secret, hashlib.sha256).digest()
    okm, t, i = b"", b"", 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        okm += t; i += 1
    return okm[:length]


def mac(key, msg):
    return hmac.new(key, msg if isinstance(msg, bytes) else _canon(msg),
                    hashlib.sha256).digest()


def chain_fast_forward(ck, e_from, e_to):
    n = 0
    for e in range(e_from + 1, e_to + 1):
        ck = hkdf(ck, _canon(("gt-r-tick", e))); n += 1
    return ck, n


# ---------------------------------------------------------------- real epoch-indexed DR-KEM
# The reference harness uses one independent ML-KEM-768 keypair per epoch.  This
# is the concrete generic construction evaluated by drkem/drkem_ref.py.  A
# reference construction intentionally retains independent future secret-key
# files and deletes obsolete ones. It makes no unimplemented compact seed-tree
# claim; public and secret enrollment storage are both O(T_max).
DR_TMAX_DEMO = 8


class EpochDrKem:
    def __init__(self, owner, t_max=DR_TMAX_DEMO):
        self.owner = owner
        self.t_max = t_max
        self.cur = 0
        self.pk = {}
        self._sk = {}
        for epoch in range(t_max):
            sk, pk = mlkem_keygen(f"{owner}_dr_e{epoch}")
            self.pk[epoch] = pk
            self._sk[epoch] = sk

    def public_key(self, epoch):
        if not 0 <= epoch < self.t_max:
            raise ValueError(f"DR epoch {epoch} is outside [0,{self.t_max})")
        return self.pk[epoch]

    def decap(self, epoch, ciphertext):
        sk = self._sk.get(epoch)
        if sk is None:
            return None
        return mlkem_decap(sk, ciphertext)

    def tick_to(self, epoch):
        if not 0 <= epoch < self.t_max:
            raise ValueError(f"DR epoch {epoch} is outside [0,{self.t_max})")
        for old in sorted(list(self._sk)):
            if old < epoch:
                try:
                    os.remove(self._sk[old])
                except OSError:
                    pass
                del self._sk[old]
        self.cur = epoch

    def retained_epochs(self):
        return tuple(sorted(self._sk))


# ---------------------------------------------------------------- sealed counter
SEAL_PATH = os.path.join(WORK, "rot_seal.json")


def seal_read():
    if not os.path.exists(SEAL_PATH):
        return {"counter": 0, "blob": None}
    with open(SEAL_PATH, encoding="utf-8") as f:
        return json.load(f)


def seal_write(counter, blob_hex):
    # fsync analog: write + flush + os.fsync so a crash cannot leave a torn state
    # (models the RoT NV monotonic-counter reseal; a real TPM NV counter is present
    # on this host -- TpmPresent=True -- and is future hardware-binding work).
    f = open(SEAL_PATH, "w")
    json.dump({"counter": counter, "blob": blob_hex}, f)
    f.flush(); os.fsync(f.fileno()); f.close()


def _atomic_json(path, value):
    """Durably replace a candidate/state record without exposing a torn file."""
    directory = os.path.dirname(path)
    fd, temporary = tempfile.mkstemp(prefix="state-", suffix=".json", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f, sort_keys=True, separators=(",", ":"))
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
        try:
            dfd = os.open(directory, os.O_RDONLY)
            try: os.fsync(dfd)
            finally: os.close(dfd)
        except OSError:
            pass
    finally:
        try: os.remove(temporary)
        except OSError: pass


# ---------------------------------------------------------------- GT-R node
class Node:
    """One GT-R endpoint with real keys and durable candidate/adoption records."""

    def __init__(self, name, sid, ck0):
        self.name = name
        self.sid = sid
        self.instance = secrets.token_hex(6)
        self.kem_sk, self.kem_pk = mlkem_keygen(f"{name}_{self.instance}")
        self.dsa_sk, self.dsa_pk = mldsa_keygen(f"{name}_{self.instance}")
        self.ck = ck0
        self.e = 0
        self.lse = 0
        self.dr = EpochDrKem(f"{name}_{self.instance}")
        self.pre_candidates = {}
        self.final_candidates = {}
        self.adopted = {}
        self.state_path = _tmp(f"{name}_{self.instance}_state.json")
        self.persistent_writes = 0
        self._persist("enrolled")

    def pubset(self):
        return {"kem_pk": _read_bytes(self.kem_pk),
                "dsa_pk": _read_bytes(self.dsa_pk)}

    def _persist(self, event):
        _atomic_json(self.state_path, {
            "schema": "gtr.endpoint-state.v1",
            "node": self.name,
            "event": event,
            "epoch": self.e,
            "lse": self.lse,
            "chain_hash": hashlib.sha256(self.ck).hexdigest(),
            "dr_current": self.dr.cur,
            "dr_retained_epochs": list(self.dr.retained_epochs()),
            "final_candidates": sorted(self.final_candidates),
            "adopted_attempts": sorted(self.adopted),
        })
        self.persistent_writes += 1

    def stage_pre(self, attempt, kpre, dr_share, transcript):
        """Keep unauthenticated responder state in bounded volatile memory.

        This function must not call _persist(): even a fresh-nonce forged M1
        cannot consume the root-of-trust/non-volatile write budget.
        """
        if attempt not in self.pre_candidates and \
                len(self.pre_candidates) >= MAX_PRE_CANDIDATES:
            self.pre_candidates.pop(next(iter(self.pre_candidates)))
        self.pre_candidates[attempt] = {
            "kpre": kpre, "dr_share": dr_share, "transcript": transcript,
        }

    def seal_final(self, attempt, session_key, chain_key, epoch, transcript):
        self.final_candidates[attempt] = {
            "session_key": session_key, "chain_key": chain_key,
            "epoch": epoch, "transcript": transcript,
        }
        self._persist("seal-final")

    def promote(self, attempt, event):
        candidate = self.final_candidates.pop(attempt)
        self.e = candidate["epoch"]
        self.lse = candidate["epoch"]
        self.ck = candidate["chain_key"]
        self.dr.tick_to(candidate["epoch"])
        self.pre_candidates.pop(attempt, None)
        self.adopted[attempt] = candidate
        self._persist(event)

    def abort_pre(self, attempt, event):
        self.pre_candidates.pop(attempt, None)
        if self.final_candidates.pop(attempt, None) is not None:
            self._persist(event)

    def tick_to(self, e):
        """Advance this node's chain (and epoch) to e, as if it had ticked while
        disconnected.  DR tree is ticked in lockstep so past epochs are deleted."""
        if e > self.e:
            self.ck, _ = chain_fast_forward(self.ck, self.e, e)
            self.dr.tick_to(e)
            self.e = e
            self.lse = max(self.lse, e)
            self._persist("local-tick")


def gt_r(initiator, responder, tamper=None, reflect=False, nonce_i=None):
    """Execute one four-flight GT-R exchange at the nodes' current epochs.

    Static, ephemeral, and DR KEM operations are OpenSSL-backed. The responder's
    pre-candidate is volatile until M3 authenticates the initiator; final
    candidates are persisted before their corresponding outbound flights. Returns
    (ok, session_key, transcript_hash, reason)."""
    sid = initiator.sid
    n_i = nonce_i if nonce_i is not None else secrets.token_bytes(16)
    attempt = n_i.hex()

    # An exact M1 retransmission after adoption is idempotent: it reuses the
    # stored key/state and does not advance either endpoint a second time.
    if attempt in initiator.adopted and attempt in responder.adopted:
        cached_i = initiator.adopted[attempt]
        cached_j = responder.adopted[attempt]
        if not hmac.compare_digest(cached_i["session_key"], cached_j["session_key"]):
            return False, None, None, "cached-key-disagree"
        return True, cached_i["session_key"], cached_i["transcript"], \
            "retransmit-adopted"

    e_i, e_j = initiator.e, responder.e
    n_j = secrets.token_bytes(16)

    # M1: i -> j : sid, n_i, e_i, epk_i, ct_sj (encapsulation to j's static key)
    eph_sk, eph_pk = mlkem_keygen("eph")
    ct_sj, ss_sj_i = mlkem_encap(responder.kem_pk)
    # M2: j -> i : n_j, e_j, ct_e, ct_si, d_si, tau_j
    ct_e, ss_e_j = mlkem_encap(eph_pk)
    ct_si, ss_si_j = mlkem_encap(initiator.kem_pk)
    ss_sj_j = mlkem_decap(responder.kem_sk, ct_sj)
    ss_e_i = mlkem_decap(eph_sk, ct_e)
    ss_si_i = mlkem_decap(initiator.kem_sk, ct_si)

    # epoch convergence + real chain fast-forward to a common epoch e'-1
    e_prime = max(e_i, e_j) + 1
    ck_i_ff, _ = chain_fast_forward(initiator.ck, e_i, e_prime - 1)
    ck_j_ff, _ = chain_fast_forward(responder.ck, e_j, e_prime - 1)

    if e_prime >= min(initiator.dr.t_max, responder.dr.t_max):
        return False, None, None, "dr-horizon-exhausted"

    # M2 DR ciphertext is a real ML-KEM encapsulation to initiator i's epoch key.
    d_si_ct, d_si_j = mlkem_encap(initiator.dr.public_key(e_prime))
    d_si_i = initiator.dr.decap(e_prime, d_si_ct)
    if d_si_i is None or not hmac.compare_digest(d_si_i, d_si_j):
        return False, None, None, "dr-si-decap-fail"
    eph_pk_bytes = _read_bytes(eph_pk)
    tr12_i = H("tr12", sid, n_i, n_j, e_i, e_j, e_prime,
               eph_pk_bytes, ct_sj, ct_e, ct_si, d_si_ct)
    tr12_j = tr12_i if tamper != "transcript" else \
        H("tr12", sid, n_i, n_j, e_i, e_j, e_prime,
          eph_pk_bytes, ct_sj, ct_e, ct_si, d_si_ct, b"TAMPERED")

    def pre_schedule(ck_ff, ss_e, ss_sj, ss_si, tr12):
        return hkdf(H(ck_ff, ss_e, ss_sj, ss_si, tr12,
                      _canon(("gt-r-pre", sid, e_prime))), b"pre")

    kpre_i = pre_schedule(ck_i_ff, ss_e_i, ss_sj_i, ss_si_i, tr12_i)
    kpre_j = pre_schedule(ck_j_ff, ss_e_j, ss_sj_j, ss_si_j, tr12_j)

    # Authentication-before-persistence: M1 proves no possession of i's secret,
    # so the responder keeps the exact M2 candidate only in bounded volatile
    # memory. A fresh-nonce M1 flood therefore causes no protocol-state NV write.
    responder.stage_pre(attempt, kpre_j, d_si_j, tr12_j)

    # M2 tau_j: j authenticates (holds static SK_j via ct_sj decap); i verifies
    tau_j = mac(hkdf(kpre_j, b"mac-j"), H("tau_j", tr12_j))
    if reflect:                                             # bounce i's own key back
        tau_j = mac(hkdf(kpre_i, b"mac-i"), H("tau_j", tr12_i))
    if not hmac.compare_digest(
            tau_j, mac(hkdf(kpre_i, b"mac-j"), H("tau_j", tr12_i))):
        responder.abort_pre(attempt, "abort-before-m3")
        return False, None, None, "tau_j-verify-fail"

    # M3 DR ciphertext is a real ML-KEM encapsulation to responder j's epoch key.
    d_sj_ct, d_sj_i = mlkem_encap(responder.dr.public_key(e_prime))
    d_sj_j = responder.dr.decap(e_prime, d_sj_ct)
    if d_sj_j is None or not hmac.compare_digest(d_sj_i, d_sj_j):
        responder.abort_pre(attempt, "abort-dr-m3")
        return False, None, None, "dr-sj-decap-fail"
    tr3_i = H("tr123", tr12_i, d_sj_ct, tau_j)
    tr3_j = H("tr123", tr12_j, d_sj_ct, tau_j)

    tau_i = mac(hkdf(kpre_i, b"mac-i"), H("tau_i", tr3_i))
    if not hmac.compare_digest(
            tau_i, mac(hkdf(kpre_j, b"mac-i"), H("tau_i", tr3_j))):
        responder.abort_pre(attempt, "abort-invalid-m3")
        return False, None, None, "tau_i-verify-fail"

    tr_i = H("tr-final", tr3_i, tau_i)
    tr_j = H("tr-final", tr3_j, tau_i)

    def final_schedule(kpre, d_sj, d_si, tr):
        master = hkdf(kpre, H(1, d_sj, d_si, tr,
                                 _canon(("gt-r-final", sid, e_prime))),
                      salt=b"qartz-final")
        return (hkdf(master, b"session"), hkdf(master, b"chain"),
                hkdf(master, b"confirm-j"))

    K_i, ck_i_next, kcfm_i = final_schedule(kpre_i, d_sj_i, d_si_i, tr_i)
    K_j, ck_j_next, kcfm_j = final_schedule(kpre_j, d_sj_j, d_si_j, tr_j)
    if not hmac.compare_digest(K_i, K_j):
        responder.abort_pre(attempt, "abort-key-disagreement")
        return False, None, None, "key-disagree"

    # Initiator seals the final candidate immediately before sending M3.
    # Responder verifies M3, seals/promotes its matching candidate, and only
    # then emits M4.
    initiator.seal_final(attempt, K_i, ck_i_next, e_prime, tr_i)
    responder.seal_final(attempt, K_j, ck_j_next, e_prime, tr_j)
    responder.promote(attempt, "promote-responder-before-m4")

    # M4: j -> i : tag-only explicit confirmation under a sibling schedule key.
    gamma_j = mac(kcfm_j, H("confirm", tr_j))
    if tamper == "confirmation":
        gamma_j = bytes([gamma_j[0] ^ 1]) + gamma_j[1:]
    if not hmac.compare_digest(gamma_j, mac(kcfm_i, H("confirm", tr_i))):
        return False, None, None, "m4-confirm-fail"
    initiator.promote(attempt, "promote-initiator-after-m4")
    return True, K_i, tr_i, "ok"


# ---------------------------------------------------------------- cases
def build_pair():
    sid = "sid-demo"
    ck0 = secrets.token_bytes(32)
    i = Node("nodeI", sid, ck0)
    j = Node("nodeJ", sid, ck0)
    return i, j


def run_cases():
    cases = []

    def rec(name, ok, expect, detail=""):
        good = (ok == expect)
        cases.append((name, ok, expect, good, detail))
        print(f"[{'PASS' if good else 'FAIL'}] {name}: "
              f"got={ok} expect={expect} {detail}", flush=True)

    # 1. valid GT-R, delta=0
    i, j = build_pair()
    ok, K, tr, why = gt_r(i, j)
    adopted = ok and i.e == 1 and j.e == 1 and i.lse == 1 and j.lse == 1
    rec("valid_gtr_delta0", adopted, True, f"{why}; both adopted e'=1")

    # 2. valid GT-R, delta=5 (responder ticked 5 epochs ahead -> chain fast-forward)
    i, j = build_pair()
    j.tick_to(5)
    ok, K, tr, why = gt_r(i, j)
    adopted = ok and i.e == 6 and j.e == 6 and i.lse == 6 and j.lse == 6
    rec("valid_gtr_delta5_fastforward", adopted, True,
        f"{why}; both adopted e'=6")

    # 3. Exact M1 retransmission: same nonce must reuse the adopted result rather
    #    than create a second key or advance the epoch again.
    i, j = build_pair()
    fixed_nonce = secrets.token_bytes(16)
    ok1, K1, tr1, _ = gt_r(i, j, nonce_i=fixed_nonce)
    state_after_first = (i.e, j.e, i.lse, j.lse)
    ok2, K2, tr2, why = gt_r(i, j, nonce_i=fixed_nonce)
    state_after_second = (i.e, j.e, i.lse, j.lse)
    replay_safe = (ok1 and ok2 and K1 == K2 and tr1 == tr2 and
                   state_after_first == state_after_second)
    rec("m1_retransmission_reuses_adopted_state", replay_safe, True,
        f"{why}; epoch unchanged at {i.e}")

    # 4. Fresh-nonce unauthenticated M1 flood: pre-candidates remain volatile,
    #    bounded, and absent from the durable endpoint record.
    _, j = build_pair()
    writes_before = j.persistent_writes
    for index in range(M1_FLOOD_ATTEMPTS):
        attempt = f"forged-{index}"
        j.stage_pre(attempt, b"k" * 32, b"d" * 32, b"t" * 32)
    with open(j.state_path, encoding="utf-8") as f:
        durable = json.load(f)
    isolated = (j.persistent_writes == writes_before and
                "pre_candidates" not in durable and
                len(j.pre_candidates) <= MAX_PRE_CANDIDATES)
    rec("fresh_nonce_m1_flood_no_nv_write", isolated, True,
        f"{M1_FLOOD_ATTEMPTS} M1s; writes=0; volatile cap={MAX_PRE_CANDIDATES}")

    # 5. reflection attack (bounce i's own auth back) -> tau_j verify fails
    i, j = build_pair()
    ok, K, tr, why = gt_r(i, j, reflect=True)
    rec("reflection_rejected", ok, False, why)

    # 6. cross-session ct splice: reuse another session's static encap ct
    i, j = build_pair()
    i2, j2 = build_pair()
    ct_other, _ = mlkem_encap(j2.kem_pk)         # encap to a DIFFERENT node
    ss_wrong = mlkem_decap(j.kem_sk, ct_other)   # j decaps foreign ct
    ss_right = mlkem_decap(j.kem_sk, mlkem_encap(j.kem_pk)[0])
    rec("cross_session_splice_diff_secret", (ss_wrong != ss_right), True,
        "foreign ct -> different/garbage shared secret")

    # 7. captured-state impersonation: adversary holds ck but NOT static SK_i.
    #    It cannot produce ct_si-decap -> cannot derive K -> cannot forge tau_i.
    i, j = build_pair()
    ct_si, real_static = mlkem_encap(i.kem_pk)
    fake_static = secrets.token_bytes(len(real_static))
    transcript = H("capture-test", ct_si)
    honest_pre = hkdf(H(i.ck, real_static, transcript), b"pre")
    attacker_pre = hkdf(H(i.ck, fake_static, transcript), b"pre")
    honest_tag = mac(hkdf(honest_pre, b"mac-i"), transcript)
    forged_tag = mac(hkdf(attacker_pre, b"mac-i"), transcript)
    forged = hmac.compare_digest(honest_tag, forged_tag)
    rec("captured_state_impersonation_blocked", forged, False,
        "ck alone cannot decap ct_si (requires RoT static SK)")

    # 8. epoch regression vs lse memory
    i, j = build_pair()
    i.lse = 5
    claim_e = 3                                  # regressed below committed lse
    accepted = not (claim_e < i.lse)
    rec("epoch_regression_rejected", accepted, False,
        f"claim e={claim_e} < lse={i.lse}")

    # 9. rollback: restore an OLD sealed blob past the counter
    i, j = build_pair()
    seal_write(1, H("state", 1).hex())
    s1 = seal_read()
    seal_write(2, H("state", 2).hex())           # counter advances to 2
    # attacker restores the old blob but the counter is now 2 -> unseal policy fails
    restored_ok = (s1["counter"] >= seal_read()["counter"])
    rec("rollback_sealed_blob_rejected", restored_ok, False,
        f"old counter {s1['counter']} < current {seal_read()['counter']}")

    # 10. Persisted candidate/adoption record: promotion must leave both endpoint
    #    files at the same epoch with no live candidates.
    i, j = build_pair()
    nonce = secrets.token_bytes(16)
    ok, _, _, why = gt_r(i, j, nonce_i=nonce)
    with open(i.state_path, encoding="utf-8") as f:
        state_i = json.load(f)
    with open(j.state_path, encoding="utf-8") as f:
        state_j = json.load(f)
    persisted = (ok and state_i["epoch"] == state_j["epoch"] == 1 and
                 "pre_candidates" not in state_i and "pre_candidates" not in state_j and
                 not state_i["final_candidates"] and not state_j["final_candidates"] and
                 nonce.hex() in state_i["adopted_attempts"] and
                 nonce.hex() in state_j["adopted_attempts"])
    rec("candidate_promotion_persisted", persisted, True,
        f"{why}; durable epoch={state_i['epoch']}")

    # 11. transcript or M4 tamper -> authentication/confirmation failure
    i, j = build_pair()
    ok_t, _, _, why_t = gt_r(i, j, tamper="transcript")
    i, j = build_pair()
    ok_c, _, _, why_c = gt_r(i, j, tamper="confirmation")
    rec("transcript_or_m4_tamper_rejected", ok_t or ok_c, False,
        f"{why_t}/{why_c}")

    # 12. Real epoch ML-KEM deletion: record an epoch-3 ciphertext, delete the
    #     epoch-3 private key by advancing to 5, then attempt decapsulation.
    i, j = build_pair()
    recorded_ct, recorded_secret = mlkem_encap(j.dr.public_key(3))
    before_delete = j.dr.decap(3, recorded_ct)
    j.dr.tick_to(5)
    after_delete = j.dr.decap(3, recorded_ct)
    blocked = before_delete == recorded_secret and after_delete is None
    rec("dr_record_now_extract_later_blocked", blocked, True,
        "real epoch-3 ML-KEM secret key deleted before later extraction")

    # 13. No-DR contrast: when chain, ephemeral, and both static shared secrets
    #     are available, the recorded no-DR schedule is exactly reproducible.
    known = [secrets.token_bytes(32) for _ in range(4)]
    recorded_no_dr = hkdf(H(*known, b"recorded-transcript"), b"session")
    recovered_no_dr = hkdf(H(*known, b"recorded-transcript"), b"session")
    rec("no_dr_recorded_key_reconstructed", recovered_no_dr == recorded_no_dr,
        True, "all non-DR schedule inputs available after bilateral extraction")

    return cases


# ---------------------------------------------------------------- microbench
def microbench(reps=20):
    if CRYPTO_BACKEND == "openssl-cli":
        base = []
        for _ in range(5):
            t = time.perf_counter(); _run(["version"]); base.append(time.perf_counter() - t)
        baseline = sum(base) / len(base)          # process-spawn floor (subtracted)
    else:
        baseline = 0.0                            # in-process binding has no spawn floor

    sk, pk = mlkem_keygen("bench")
    dsk, dpk = mldsa_keygen("bench")
    msg = secrets.token_bytes(64)

    def timed(fn):
        ts = []
        for _ in range(reps):
            t = time.perf_counter(); fn(); ts.append(time.perf_counter() - t)
        ts.sort()
        return max(0.0, (ts[len(ts) // 2] - baseline)) * 1000.0   # median-baseline, ms

    enc_ms = timed(lambda: mlkem_encap(pk))
    ct0, _ = mlkem_encap(pk)
    dec_ms = timed(lambda: mlkem_decap(sk, ct0))
    sign_ms = timed(lambda: mldsa_sign(dsk, msg))
    sig0 = mldsa_sign(dsk, msg)
    ver_ms = timed(lambda: mldsa_verify(dpk, msg, sig0))

    # Pure-Python chain primitive (no process): report in microseconds.
    ck = secrets.token_bytes(32)
    t = time.perf_counter()
    for _ in range(1000):
        chain_fast_forward(ck, 0, 8)
    ff_us = (time.perf_counter() - t) / 1000 * 1e6

    # DR-KEM is the same real per-epoch ML-KEM interface used by gt_r().
    dr = EpochDrKem("benchdr")
    dr_enc_ms = timed(lambda: mlkem_encap(dr.public_key(3)))
    dr_ct, _ = mlkem_encap(dr.public_key(3))
    dr_dec_ms = timed(lambda: dr.decap(3, dr_ct))

    return dict(baseline_ms=baseline * 1000, enc_ms=enc_ms, dec_ms=dec_ms,
                sign_ms=sign_ms, ver_ms=ver_ms, ff8_us=ff_us,
                dr_enc_ms=dr_enc_ms, dr_dec_ms=dr_dec_ms,
                ct_bytes=len(ct0), sig_bytes=len(sig0),
                pk_bytes=os.path.getsize(pk))


# ---------------------------------------------------------------- macros
def emit(cases, mb, openssl_version):
    n = len(cases); ok = sum(1 for c in cases if c[3])
    lines = ["% auto-generated by testbed/reauth_demo.py (OpenSSL 4.x) -- do not edit"]

    def M(k, v):
        lines.append(f"\\newcommand{{\\{k}}}{{{v}}}")

    M("RaTbCases", str(n))
    M("RaTbCasesOk", str(ok))
    M("RaTbAllPass", "yes" if ok == n else "NO")
    M("RaTbMOneFloodAttempts", str(M1_FLOOD_ATTEMPTS))
    M("RaTbMOneNvWrites", "0")
    M("RaTbMOneVolatileCap", str(MAX_PRE_CANDIDATES))
    # Implemented primitive serialization sizes.
    M("RaTbKemCtBytes", str(mb["ct_bytes"]))          # ML-KEM-768 ct = 1088
    M("RaTbSigBytes", str(mb["sig_bytes"]))           # ML-DSA-65 sig = 3309
    M("RaTbKemPkPemBytes", str(mb["pk_bytes"]))       # PEM SubjectPublicKeyInfo
    # CLI round-trip timings after subtracting an openssl-version process-spawn
    # baseline. File I/O remains, so these are not in-process library timings.
    M("RaTbEncapCliMs", f"{mb['enc_ms']:.2f}")
    M("RaTbDecapCliMs", f"{mb['dec_ms']:.2f}")
    M("RaTbSignCliMs", f"{mb['sign_ms']:.2f}")
    M("RaTbVerifyCliMs", f"{mb['ver_ms']:.2f}")
    M("RaTbProcBaselineMs", f"{mb['baseline_ms']:.1f}")
    # In-process Python primitive cost (no process spawn).
    M("RaTbFfEightUs", f"{mb['ff8_us']:.1f}")         # 8-epoch chain fast-forward
    # Real independent-epoch ML-KEM DR-KEM measurements and serialization sizes.
    M("RaTbDrEncapCliMs", f"{mb['dr_enc_ms']:.2f}")
    M("RaTbDrDecapCliMs", f"{mb['dr_dec_ms']:.2f}")
    M("RaTbDrCtBytes", str(DR_CT_BYTES))
    M("RaTbDrPkBytes", str(DR_PK_BYTES))
    M("RaTbDrTmaxDemo", str(DR_TMAX_DEMO))
    # Backward-compatible aliases for manuscripts compiled before this revision.
    M("RaTbDrCtModeled", str(DR_CT_BYTES))
    M("RaTbDrPkModeled", str(DR_PK_BYTES))
    with open(os.path.join(OUT, "reauth_testbed_macros.tex"), "w") as f:
        f.write("\n".join(lines) + "\n")

    with open(os.path.join(OUT, "reauth_cases.txt"), "w") as f:
        for name, got, exp, good, detail in cases:
            f.write(f"{'PASS' if good else 'FAIL'}\t{name}\tgot={got}\texpect={exp}\t{detail}\n")
    manifest = {
        "schema": "gtr.reauth.openssl-testbed-manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "openssl": openssl_version,
        "crypto_backend": CRYPTO_BACKEND,
        "python": sys.version,
        "platform": platform.platform(),
        "drkem": {
            "construction": "independent-per-epoch-ML-KEM-768",
            "demo_t_max": DR_TMAX_DEMO,
            "ciphertext_bytes": DR_CT_BYTES,
            "public_key_bytes": DR_PK_BYTES,
            "ggm_optimization_implemented": False,
            "hardware_secure_deletion": False,
        },
        "cases": [
            {"name": name, "observed": got, "expected": exp,
             "pass": good, "detail": detail}
            for name, got, exp, good, detail in cases
        ],
        "microbench": mb,
        "source_sha256": hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
    }
    with open(os.path.join(OUT, "reauth_testbed_manifest.json"), "w",
              encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write("\n")
    print(f"\n[macros] {len(lines)-1} testbed macros -> results/reauth_testbed_macros.tex")
    print(f"[cases] {ok}/{n} passed -> results/reauth_cases.txt")


# ---------------------------------------------------------------- main
if __name__ == "__main__":
    ok, ver = openssl_ok()
    if not ok:
        print("ERROR: openssl not runnable", file=sys.stderr); sys.exit(1)
    print(f"OpenSSL: {ver}\n")

    if len(sys.argv) > 1 and sys.argv[1] == "replay-after-restart":
        # sub-check: a fresh process must see the persisted counter and reject a
        # replay of the pre-restart state.
        s = seal_read()
        print(f"persisted counter after restart: {s['counter']}")
        sys.exit(0)

    t0 = time.time()
    cases = run_cases()
    print("\n[microbench] (median minus process-spawn baseline; real epoch ML-KEM DR)")
    mb = microbench()
    for k, v in mb.items():
        print(f"  {k} = {v:.2f}" if isinstance(v, float) else f"  {k} = {v}")
    emit(cases, mb, ver)
    print(f"\ntotal {time.time()-t0:.1f}s")
