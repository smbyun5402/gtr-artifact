#!/bin/zsh
# Host-side harness: build image, start peer+node, apply netem conditions,
# run all benchmarks, collect results into ./results_raw.
set -e
set -o pipefail
cd "$(dirname "$0")"
cp ../sim/qartz_sim.py .

echo "== build"
docker build -q -t qartz-testbed . || docker build -t qartz-testbed .

docker rm -f qartz-peer qartz-node >/dev/null 2>&1 || true
docker network rm qartz-net >/dev/null 2>&1 || true
docker network create qartz-net >/dev/null

echo "== start peer (TLS servers) + node"
docker run -d --name qartz-peer --network qartz-net --cap-add NET_ADMIN \
    qartz-testbed /qartz/bench_tls_server.sh >/dev/null
docker run -d --name qartz-node --network qartz-net --cap-add NET_ADMIN \
    qartz-testbed sleep infinity >/dev/null
sleep 2

netem() {  # netem <container> <args...>|off
    c=$1; shift
    if [ "$1" = "off" ]; then
        docker exec "$c" tc qdisc del dev eth0 root 2>/dev/null || true
    else
        docker exec "$c" tc qdisc replace dev eth0 root netem "$@"
    fi
}

echo "== bench: crypto"
docker exec qartz-node /qartz/bench_crypto.sh > /dev/null
echo "== guard: real ML-DSA + persisted counter"
docker exec qartz-node python3 /qartz/guard_demo.py
docker exec qartz-node python3 /qartz/guard_demo.py replay-after-restart
echo "== GT-R: state-machine regression tests"
docker exec -w /qartz qartz-node python3 -m unittest -v test_reauth_demo_logic.py
echo "== GT-R: OpenSSL four-flight cases"
docker exec qartz-node python3 /qartz/reauth_demo.py
echo "== GT-R: two-process TCP loopback benchmark"
docker exec qartz-node python3 /qartz/reauth_socket_bench.py --runs 10 \
    --initiator-epoch 0 --responder-epoch 5
echo "== bench: tpm (swtpm)"
docker exec qartz-node /qartz/bench_tpm.sh

echo "== bench: TLS handshakes under netem"
# symmetric netem on both sides; delays are per direction
typeset -A CONDS
CONDS=(clean "delay 10ms" \
       disrupted "delay 100ms 20ms loss 5%" \
       heavy "delay 200ms 50ms loss 15%")
for cond in clean disrupted heavy; do
    netem qartz-node ${=CONDS[$cond]}
    netem qartz-peer ${=CONDS[$cond]}
    docker exec qartz-node python3 /qartz/bench_tls_client.py qartz-peer "$cond" 30
done
netem qartz-node off; netem qartz-peer off

echo "== bench: decision loop under CPU limits"
mkdir -p results_raw
docker run --rm --cpus 1.0  qartz-testbed python3 /qartz/bench_loop.py \
    | tee results_raw/loop_cpu100.txt
docker run --rm --cpus 0.25 qartz-testbed python3 /qartz/bench_loop.py \
    | tee results_raw/loop_cpu025.txt

echo "== integrated run (210 s: 60 clean / 90 blackout / 60 recovery)"
docker exec -d qartz-node python3 /qartz/integrated_node.py qartz-peer 210
sleep 60
netem qartz-node "loss" "100%"
echo "  blackout on"
sleep 90
netem qartz-node off
echo "  link restored"
sleep 70

echo "== collect"
docker cp qartz-node:/qartz/results/. results_raw/ >/dev/null
docker rm -f qartz-peer qartz-node >/dev/null
docker network rm qartz-net >/dev/null
echo "done -> results_raw/"
ls results_raw/
