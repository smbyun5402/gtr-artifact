#!/usr/bin/env python3
"""Two-process TCP loopback benchmark for the four-flight GT-R handshake.

Unlike the policy simulator and the single-process case harness, this program
runs the initiator and responder in separate OS processes and carries M1--M4 as
length-prefixed JSON frames over a real TCP socket.  Cryptographic operations
are the OpenSSL-backed ML-KEM-768 calls from reauth_demo.py. Enrollment/public-key
exchange is completed before the reconnect timer starts.

Run on a host with OpenSSL 4 PQ support:
    python reauth_socket_bench.py --runs 10 --initiator-epoch 0 --responder-epoch 5
"""

import argparse
import base64
import hashlib
import json
import multiprocessing as mp
import os
import platform
import secrets
import socket
import statistics
import struct
import sys
import tempfile
import time
from datetime import datetime, timezone

import reauth_demo as core


HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
os.makedirs(OUT, exist_ok=True)


def b64(value):
    return base64.b64encode(value).decode("ascii")


def unb64(value):
    return base64.b64decode(value.encode("ascii"), validate=True)


def send_frame(sock, value):
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    sock.sendall(struct.pack("!I", len(payload)) + payload)


def recv_exact(sock, count):
    parts = []
    remaining = count
    while remaining:
        part = sock.recv(remaining)
        if not part:
            raise ConnectionError("peer closed the socket")
        parts.append(part)
        remaining -= len(part)
    return b"".join(parts)


def recv_frame(sock):
    length = struct.unpack("!I", recv_exact(sock, 4))[0]
    if length > 16 * 1024 * 1024:
        raise ValueError("oversized frame")
    return json.loads(recv_exact(sock, length).decode())


def write_public(directory, name, encoded):
    path = os.path.join(directory, name)
    with open(path, "wb") as f:
        f.write(unb64(encoded))
    return path


def setup_process_workspace(role):
    directory = tempfile.mkdtemp(prefix=f"gtr-socket-{role}-")
    core.WORK = directory
    core.SEAL_PATH = os.path.join(directory, "rot_seal.json")
    return directory


def pre_schedule(chain, ss_e, ss_sj, ss_si, transcript, sid, epoch):
    return core.hkdf(core.H(chain, ss_e, ss_sj, ss_si, transcript,
                           core._canon(("gt-r-pre", sid, epoch))), b"pre")


def final_schedule(kpre, d_sj, d_si, transcript, sid, epoch):
    master = core.hkdf(
        kpre,
        core.H(1, d_sj, d_si, transcript,
               core._canon(("gt-r-final", sid, epoch))),
        salt=b"qartz-final",
    )
    return (core.hkdf(master, b"session"),
            core.hkdf(master, b"chain"),
            core.hkdf(master, b"confirm-j"))


def responder(port_queue, result_queue, ck0_hex, sid, epoch_i, epoch_j, runs):
    directory = setup_process_workspace("responder")
    announced = False
    try:
        static_sk, static_pk = core.mlkem_keygen("responder-static")
        dr = core.EpochDrKem("responder-dr")
        dr.tick_to(epoch_j)
        chain, _ = core.chain_fast_forward(bytes.fromhex(ck0_hex), 0, epoch_j)
        e_prime = max(epoch_i, epoch_j) + 1
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            listener.bind(("127.0.0.1", 0))
            listener.listen(1)
            port_queue.put({"port": listener.getsockname()[1]})
            announced = True
            conn, _ = listener.accept()
            with conn:
                conn.settimeout(120)
                enrolled_i = recv_frame(conn)
                peer_static_pk = write_public(directory, "initiator-static-pk.pem",
                                              enrolled_i["static_pk"])
                peer_dr_pk = write_public(directory, "initiator-dr-pk.pem",
                                          enrolled_i["dr_pk"])
                send_frame(conn, {
                    "static_pk": b64(core._read_bytes(static_pk)),
                    "dr_pk": b64(core._read_bytes(dr.public_key(e_prime))),
                    "epoch": epoch_j,
                })

                completed = []
                for run in range(runs):
                    m1 = recv_frame(conn)
                    n_i = unb64(m1["n_i"])
                    eph_pk_bytes = unb64(m1["eph_pk"])
                    eph_pk = write_public(directory, f"initiator-eph-{run}.pem",
                                          m1["eph_pk"])
                    ct_sj = unb64(m1["ct_sj"])
                    ss_sj = core.mlkem_decap(static_sk, ct_sj)
                    ct_e, ss_e = core.mlkem_encap(eph_pk)
                    ct_si, ss_si = core.mlkem_encap(peer_static_pk)
                    d_si_ct, d_si = core.mlkem_encap(peer_dr_pk)
                    n_j = secrets.token_bytes(16)
                    chain_ff, _ = core.chain_fast_forward(chain, epoch_j,
                                                          e_prime - 1)
                    tr12 = core.H("tr12", sid, n_i, n_j, epoch_i, epoch_j,
                                  e_prime, eph_pk_bytes, ct_sj, ct_e, ct_si,
                                  d_si_ct)
                    kpre = pre_schedule(chain_ff, ss_e, ss_sj, ss_si, tr12,
                                        sid, e_prime)
                    tau_j = core.mac(core.hkdf(kpre, b"mac-j"),
                                     core.H("tau_j", tr12))
                    send_frame(conn, {
                        "n_j": b64(n_j), "e_j": epoch_j,
                        "ct_e": b64(ct_e), "ct_si": b64(ct_si),
                        "d_si": b64(d_si_ct), "tau_j": b64(tau_j),
                    })

                    m3 = recv_frame(conn)
                    d_sj_ct = unb64(m3["d_sj"])
                    tau_i = unb64(m3["tau_i"])
                    d_sj = dr.decap(e_prime, d_sj_ct)
                    if d_sj is None:
                        raise RuntimeError("responder DR decapsulation failed")
                    tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
                    if not secrets.compare_digest(
                            tau_i, core.mac(core.hkdf(kpre, b"mac-i"),
                                            core.H("tau_i", tr3))):
                        raise RuntimeError("M3 authentication failed")
                    transcript = core.H("tr-final", tr3, tau_i)
                    session, _, confirm = final_schedule(
                        kpre, d_sj, d_si, transcript, sid, e_prime)
                    gamma = core.mac(confirm, core.H("confirm", transcript))
                    send_frame(conn, {"gamma_j": b64(gamma)})
                    completed.append({
                        "run": run,
                        "session_sha256": hashlib.sha256(session).hexdigest(),
                        "transcript_sha256": hashlib.sha256(transcript).hexdigest(),
                    })
        result_queue.put({"role": "responder", "ok": True,
                          "completed": completed})
    except Exception as exc:
        if not announced:
            port_queue.put({"error": repr(exc)})
        result_queue.put({"role": "responder", "ok": False,
                          "error": repr(exc)})


def initiator(port, result_queue, ck0_hex, sid, epoch_i, epoch_j, runs):
    directory = setup_process_workspace("initiator")
    try:
        static_sk, static_pk = core.mlkem_keygen("initiator-static")
        dr = core.EpochDrKem("initiator-dr")
        dr.tick_to(epoch_i)
        chain, _ = core.chain_fast_forward(bytes.fromhex(ck0_hex), 0, epoch_i)
        e_prime = max(epoch_i, epoch_j) + 1
        with socket.create_connection(("127.0.0.1", port), timeout=120) as conn:
            conn.settimeout(120)
            send_frame(conn, {
                "static_pk": b64(core._read_bytes(static_pk)),
                "dr_pk": b64(core._read_bytes(dr.public_key(e_prime))),
                "epoch": epoch_i,
            })
            enrolled_j = recv_frame(conn)
            peer_static_pk = write_public(directory, "responder-static-pk.pem",
                                          enrolled_j["static_pk"])
            peer_dr_pk = write_public(directory, "responder-dr-pk.pem",
                                      enrolled_j["dr_pk"])

            completed = []
            for run in range(runs):
                started = time.perf_counter()
                n_i = secrets.token_bytes(16)
                eph_sk, eph_pk = core.mlkem_keygen(f"initiator-eph-{run}")
                eph_pk_bytes = core._read_bytes(eph_pk)
                ct_sj, ss_sj = core.mlkem_encap(peer_static_pk)
                send_frame(conn, {
                    "sid": sid, "n_i": b64(n_i), "e_i": epoch_i,
                    "eph_pk": b64(eph_pk_bytes), "ct_sj": b64(ct_sj),
                })
                m2 = recv_frame(conn)
                n_j = unb64(m2["n_j"])
                ct_e, ct_si = unb64(m2["ct_e"]), unb64(m2["ct_si"])
                d_si_ct, tau_j = unb64(m2["d_si"]), unb64(m2["tau_j"])
                ss_e = core.mlkem_decap(eph_sk, ct_e)
                ss_si = core.mlkem_decap(static_sk, ct_si)
                d_si = dr.decap(e_prime, d_si_ct)
                if d_si is None:
                    raise RuntimeError("initiator DR decapsulation failed")
                chain_ff, _ = core.chain_fast_forward(chain, epoch_i,
                                                       e_prime - 1)
                tr12 = core.H("tr12", sid, n_i, n_j, epoch_i, epoch_j,
                              e_prime, eph_pk_bytes, ct_sj, ct_e, ct_si,
                              d_si_ct)
                kpre = pre_schedule(chain_ff, ss_e, ss_sj, ss_si, tr12,
                                    sid, e_prime)
                if not secrets.compare_digest(
                        tau_j, core.mac(core.hkdf(kpre, b"mac-j"),
                                        core.H("tau_j", tr12))):
                    raise RuntimeError("M2 authentication failed")
                d_sj_ct, d_sj = core.mlkem_encap(peer_dr_pk)
                tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
                tau_i = core.mac(core.hkdf(kpre, b"mac-i"),
                                 core.H("tau_i", tr3))
                send_frame(conn, {"d_sj": b64(d_sj_ct),
                                  "tau_i": b64(tau_i)})
                transcript = core.H("tr-final", tr3, tau_i)
                session, _, confirm = final_schedule(
                    kpre, d_sj, d_si, transcript, sid, e_prime)
                m4 = recv_frame(conn)
                gamma = unb64(m4["gamma_j"])
                if not secrets.compare_digest(
                        gamma, core.mac(confirm, core.H("confirm", transcript))):
                    raise RuntimeError("M4 confirmation failed")
                completed.append({
                    "run": run,
                    "latency_ms": (time.perf_counter() - started) * 1000,
                    "session_sha256": hashlib.sha256(session).hexdigest(),
                    "transcript_sha256": hashlib.sha256(transcript).hexdigest(),
                })
        result_queue.put({"role": "initiator", "ok": True,
                          "completed": completed})
    except Exception as exc:
        result_queue.put({"role": "initiator", "ok": False,
                          "error": repr(exc)})


def percentile(values, quantile):
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * quantile
    lo, hi = int(rank), min(int(rank) + 1, len(ordered) - 1)
    fraction = rank - lo
    return ordered[lo] * (1 - fraction) + ordered[hi] * fraction


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=int, default=10)
    parser.add_argument("--initiator-epoch", type=int, default=0)
    parser.add_argument("--responder-epoch", type=int, default=5)
    args = parser.parse_args()
    if args.runs < 1:
        parser.error("--runs must be positive")
    e_prime = max(args.initiator_epoch, args.responder_epoch) + 1
    if not 0 <= min(args.initiator_epoch, args.responder_epoch) or \
            e_prime >= core.DR_TMAX_DEMO:
        parser.error(f"epochs require 0 <= e and e' < {core.DR_TMAX_DEMO}")

    available, openssl_version = core.openssl_ok()
    if not available:
        raise SystemExit("OpenSSL is not runnable")
    ck0 = secrets.token_bytes(32).hex()
    sid = "gtr-socket-benchmark"
    port_queue, result_queue = mp.Queue(), mp.Queue()
    server = mp.Process(target=responder,
                        args=(port_queue, result_queue, ck0, sid,
                              args.initiator_epoch, args.responder_epoch,
                              args.runs))
    server.start()
    startup = port_queue.get(timeout=180)
    if "error" in startup:
        server.join(30)
        raise SystemExit(f"responder startup failed: {startup['error']}")
    port = startup["port"]
    client = mp.Process(target=initiator,
                        args=(port, result_queue, ck0, sid,
                              args.initiator_epoch, args.responder_epoch,
                              args.runs))
    client.start()
    received = [result_queue.get(timeout=300), result_queue.get(timeout=300)]
    client.join(30)
    server.join(30)
    by_role = {item["role"]: item for item in received}
    both_ok = all(item.get("ok") for item in received)
    matching = False
    latencies = []
    if both_ok:
        left = by_role["initiator"]["completed"]
        right = by_role["responder"]["completed"]
        matching = len(left) == len(right) == args.runs and all(
            a["session_sha256"] == b["session_sha256"] and
            a["transcript_sha256"] == b["transcript_sha256"]
            for a, b in zip(left, right))
        latencies = [row["latency_ms"] for row in left]
    success = both_ok and matching
    result = {
        "schema": "gtr.two-process-tcp-benchmark.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "transport": "TCP loopback, two OS processes, length-prefixed JSON",
        "enrollment_excluded_from_timer": True,
        "openssl": openssl_version,
        "crypto_backend": core.CRYPTO_BACKEND,
        "python": sys.version,
        "platform": platform.platform(),
        "epochs": {"initiator": args.initiator_epoch,
                   "responder": args.responder_epoch,
                   "converged": e_prime},
        "runs": args.runs,
        "all_sessions_and_transcripts_match": matching,
        "success": success,
        "latency_ms": {
            "samples": latencies,
            "median": statistics.median(latencies) if latencies else None,
            "p95": percentile(latencies, 0.95) if latencies else None,
        },
        "process_results": received,
        "limitations": [
            "loopback is not a UAV/UGV radio link",
            ("OpenSSL CLI process and file I/O are included"
             if core.CRYPTO_BACKEND == "openssl-cli" else
             "OpenSSL-backed cryptography operations execute in process"),
            "enrollment and certificate validation are outside the timer",
        ],
        "source_sha256": hashlib.sha256(core._read_bytes(__file__)).hexdigest(),
    }
    json_path = os.path.join(OUT, "reauth_socket_benchmark.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, sort_keys=True)
        f.write("\n")
    if latencies:
        with open(os.path.join(OUT, "reauth_socket_macros.tex"), "w") as f:
            f.write("% auto-generated by testbed/reauth_socket_bench.py -- do not edit\n")
            f.write(f"\\newcommand{{\\RaSocketRuns}}{{{args.runs}}}\n")
            f.write(f"\\newcommand{{\\RaSocketMedianMs}}{{{statistics.median(latencies):.2f}}}\n")
            f.write(f"\\newcommand{{\\RaSocketPtfMs}}{{{percentile(latencies, 0.95):.2f}}}\n")
            f.write(f"\\newcommand{{\\RaSocketAllMatch}}{{{'yes' if matching else 'NO'}}}\n")
    print(json.dumps({"success": success, "runs": args.runs,
                      "median_ms": result["latency_ms"]["median"],
                      "p95_ms": result["latency_ms"]["p95"]}, indent=2))
    raise SystemExit(0 if success else 1)


if __name__ == "__main__":
    mp.freeze_support()
    main()
