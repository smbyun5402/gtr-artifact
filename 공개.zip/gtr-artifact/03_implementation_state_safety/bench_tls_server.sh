#!/bin/sh
# Three TLS 1.3 servers, one per mode family.
# legacy : X25519 key exchange, ECDSA P-256 certificate
# hybrid : X25519MLKEM768,     ECDSA P-256 certificate
# pqc    : MLKEM768,           ML-DSA-65 certificate
cd /qartz/certs
openssl s_server -port 4431 -cert ec_cert.pem -key ec_key.pem \
    -groups X25519 -tls1_3 -quiet &
openssl s_server -port 4432 -cert ec_cert.pem -key ec_key.pem \
    -groups X25519MLKEM768 -tls1_3 -quiet &
openssl s_server -port 4433 -cert mldsa_cert.pem -key mldsa_key.pem \
    -groups MLKEM768 -tls1_3 -quiet &
echo "servers up"
wait
