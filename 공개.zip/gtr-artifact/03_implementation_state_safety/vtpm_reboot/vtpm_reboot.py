#!/usr/bin/env python3
"""Two-phase QEMU/swtpm reboot experiment using tpm2-tools.

The script deliberately operates on only one NV handle and one persistent key
handle.  It never clears or provisions the TPM hierarchy.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import secrets as random_secrets
import shutil
import stat
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA = "qartz-vtpm-reboot/v1"
MARKER = "QARTZ-vTPM-reboot-state-v1"
DEVICE = Path("/dev/tpmrm0")
TCTI = f"device:{DEVICE}"
DEFAULT_NV_HANDLE = 0x01520000
DEFAULT_KEY_HANDLE = 0x81020000
NV_HANDLE_RANGE = range(0x01520000, 0x01530000)
KEY_HANDLE_RANGE = range(0x81020000, 0x81030000)
INCREMENT_CAP = 3

TOOLS = (
    "tpm2_getcap",
    "tpm2_nvdefine",
    "tpm2_nvincrement",
    "tpm2_nvread",
    "tpm2_nvreadpublic",
    "tpm2_nvundefine",
    "tpm2_createprimary",
    "tpm2_create",
    "tpm2_load",
    "tpm2_evictcontrol",
    "tpm2_readpublic",
    "tpm2_sign",
    "tpm2_verifysignature",
    "tpm2_flushcontext",
)


class ExperimentError(RuntimeError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def handle_text(value: int) -> str:
    return f"0x{value:08x}"


def atomic_bytes(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")
    atomic_bytes(path, data)


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ExperimentError(f"cannot read {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ExperimentError(f"{path} is not a JSON object")
    return value


def redacted_command(arguments: list[str]) -> str:
    return " ".join("<redacted-auth>" if item.startswith("hex:") else item for item in arguments)


def run_tpm(arguments: list[str], *, quiet_error: bool = False) -> str:
    environment = os.environ.copy()
    environment["TPM2TOOLS_TCTI"] = TCTI
    completed = subprocess.run(
        arguments,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()
        if quiet_error:
            detail = "command failed"
        raise ExperimentError(
            f"{redacted_command(arguments)} exited {completed.returncode}: {detail[-800:]}"
        )
    return completed.stdout


def owner_auth_arguments() -> list[str]:
    value = os.environ.get("QARTZ_TPM_OWNER_AUTH", "")
    return ["-P", value] if value else []


def preflight() -> str:
    missing = [tool for tool in TOOLS if shutil.which(tool) is None]
    if missing:
        raise ExperimentError("missing commands: " + ", ".join(missing))
    try:
        device_mode = DEVICE.stat().st_mode
    except OSError as exc:
        raise ExperimentError(f"{DEVICE} is unavailable: {exc}") from exc
    if not stat.S_ISCHR(device_mode):
        raise ExperimentError(f"{DEVICE} is not a character device")
    run_tpm(["tpm2_getcap", "properties-fixed"])
    return run_tpm(["tpm2_getcap", "--version"]).strip()


def boot_id() -> str:
    path = Path("/proc/sys/kernel/random/boot_id")
    try:
        value = path.read_text(encoding="ascii").strip()
    except OSError as exc:
        raise ExperimentError(f"cannot read Linux boot ID: {exc}") from exc
    if not re.fullmatch(r"[0-9a-fA-F-]{36}", value):
        raise ExperimentError("Linux boot ID has an unexpected format")
    return value.lower()


def handle_set(capability: str) -> set[int]:
    output = run_tpm(["tpm2_getcap", capability])
    return {int(item, 16) for item in re.findall(r"0x[0-9a-fA-F]+", output)}


def nv_public_record(handle: int) -> dict[str, str]:
    output = run_tpm(["tpm2_nvreadpublic"])
    lines = output.splitlines()
    start = None
    for index, line in enumerate(lines):
        match = re.match(r"^\s*(0x[0-9a-fA-F]+):\s*$", line)
        if match and int(match.group(1), 16) == handle:
            start = index
            break
    if start is None:
        raise ExperimentError(f"NV handle {handle_text(handle)} is absent")
    end = len(lines)
    for index in range(start + 1, len(lines)):
        if re.match(r"^\s*0x[0-9a-fA-F]+:\s*$", lines[index]):
            end = index
            break
    record = "\n".join(lines[start:end])
    name_match = re.search(r"^\s*name:\s*([0-9a-fA-F]+)\s*$", record, re.MULTILINE)
    if not name_match:
        raise ExperimentError(f"cannot extract the NV Name for {handle_text(handle)}")
    lower = record.lower()
    required = ("sha256", "authread", "authwrite", "no_da")
    counter_type = "nt=counter" in lower or "nt=0x1" in lower
    if (
        any(item not in lower for item in required)
        or not counter_type
        or not re.search(r"^\s*size:\s*8\s*$", record, re.MULTILINE)
    ):
        raise ExperimentError(f"NV public area at {handle_text(handle)} does not match this experiment")
    return {"name": name_match.group(1).lower(), "record": record}


def key_name(handle_or_context: str, work_dir: Path, public_pem: Path | None = None) -> str:
    fd, name_path_text = tempfile.mkstemp(prefix=".key-name.", dir=work_dir)
    os.close(fd)
    name_path = Path(name_path_text)
    try:
        arguments = ["tpm2_readpublic", "-Q", "-c", handle_or_context, "-n", str(name_path)]
        if public_pem is not None:
            arguments += ["-o", str(public_pem), "-f", "pem"]
        run_tpm(arguments)
        value = name_path.read_bytes().hex()
    finally:
        name_path.unlink(missing_ok=True)
    if len(value) < 8:
        raise ExperimentError("TPM key Name is unexpectedly short")
    return value


def nv_counter(handle: int, auth: str, work_dir: Path) -> int:
    fd, counter_path_text = tempfile.mkstemp(prefix=".counter.", dir=work_dir)
    os.close(fd)
    counter_path = Path(counter_path_text)
    try:
        run_tpm(
            [
                "tpm2_nvread",
                "-Q",
                "-C",
                handle_text(handle),
                "-P",
                f"hex:{auth}",
                "-s",
                "8",
                "-o",
                str(counter_path),
                handle_text(handle),
            ]
        )
        raw = counter_path.read_bytes()
    finally:
        counter_path.unlink(missing_ok=True)
    if len(raw) != 8:
        raise ExperimentError(f"NV counter returned {len(raw)} bytes, expected 8")
    return int.from_bytes(raw, byteorder="big", signed=False)


def increment_nv(manifest: dict[str, Any], auth: str, manifest_path: Path) -> None:
    budget = manifest["increment_budget"]
    if budget["cap"] != INCREMENT_CAP or budget["used"] >= budget["cap"]:
        raise ExperimentError("NV increment cap reached; refusing another increment")
    handle = int(manifest["nv"]["handle"], 16)
    run_tpm(
        [
            "tpm2_nvincrement",
            "-Q",
            "-C",
            handle_text(handle),
            "-P",
            f"hex:{auth}",
            handle_text(handle),
        ]
    )
    budget["used"] += 1
    atomic_json(manifest_path, manifest)


def canonical_state(run_id: str, counter: int, slot: str) -> bytes:
    value = {
        "counter": counter,
        "marker": MARKER,
        "run_id": run_id,
        "schema": 1,
        "slot": slot,
    }
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def write_state(path: Path, run_id: str, counter: int, slot: str) -> None:
    atomic_bytes(path, canonical_state(run_id, counter, slot))


def parse_canonical_state(path: Path, expected_run_id: str) -> dict[str, Any]:
    try:
        raw = path.read_bytes()
        value = json.loads(raw)
    except (OSError, json.JSONDecodeError) as exc:
        raise ExperimentError(f"invalid state file {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ExperimentError(f"state file {path} is not an object")
    required = {"counter", "marker", "run_id", "schema", "slot"}
    if set(value) != required or value.get("marker") != MARKER or value.get("run_id") != expected_run_id:
        raise ExperimentError(f"state marker/schema mismatch in {path}")
    if type(value.get("counter")) is not int or value["counter"] < 0 or value.get("schema") != 1:
        raise ExperimentError(f"invalid state counter/schema in {path}")
    if raw != canonical_state(value["run_id"], value["counter"], value["slot"]):
        raise ExperimentError(f"state file {path} is not canonical JSON")
    return value


def sign_state(key_handle: int, key_auth: str, state_path: Path, signature_path: Path) -> None:
    run_tpm(
        [
            "tpm2_sign",
            "-Q",
            "-c",
            handle_text(key_handle),
            "-p",
            f"hex:{key_auth}",
            "-g",
            "sha256",
            "-o",
            str(signature_path),
            str(state_path),
        ]
    )


def verify_bundle(
    key_handle: int,
    state_path: Path,
    signature_path: Path,
    run_id: str,
    current_counter: int,
) -> dict[str, Any]:
    state = parse_canonical_state(state_path, run_id)
    run_tpm(
        [
            "tpm2_verifysignature",
            "-Q",
            "-c",
            handle_text(key_handle),
            "-g",
            "sha256",
            "-m",
            str(state_path),
            "-s",
            str(signature_path),
        ],
        quiet_error=True,
    )
    matches = state["counter"] == current_counter
    return {
        "signature_valid": True,
        "canonical": True,
        "state_counter": state["counter"],
        "tpm_counter": current_counter,
        "counter_matches": matches,
        "accepted": matches,
    }


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_run_files(work_dir: Path) -> tuple[dict[str, Any], dict[str, Any], Path, Path]:
    manifest_path = work_dir / "manifest.json"
    secrets_path = work_dir / "secrets.json"
    manifest = load_json(manifest_path)
    secret_values = load_json(secrets_path)
    if manifest.get("schema") != SCHEMA or secret_values.get("schema") != SCHEMA:
        raise ExperimentError("manifest/secrets schema mismatch")
    return manifest, secret_values, manifest_path, secrets_path


def safe_cleanup(
    manifest: dict[str, Any], secret_values: dict[str, Any], work_dir: Path
) -> dict[str, Any]:
    key_handle = int(manifest["key"]["handle"], 16)
    nv_handle = int(manifest["nv"]["handle"], 16)
    persistent = handle_set("handles-persistent")
    nv_handles = handle_set("handles-nv-index")
    key_present = key_handle in persistent
    nv_present = nv_handle in nv_handles

    # Validate every present object before removing either one.
    if key_present:
        expected_key_name = manifest["key"].get("name")
        if not expected_key_name or key_name(handle_text(key_handle), work_dir) != expected_key_name:
            raise ExperimentError("persistent handle Name mismatch; refusing cleanup")
    if nv_present:
        actual_nv = nv_public_record(nv_handle)["name"]
        allowed_names = manifest["nv"].get("allowed_names", [])
        if actual_nv not in allowed_names:
            raise ExperimentError("NV handle Name mismatch; refusing cleanup")

    if key_present:
        run_tpm(
            ["tpm2_evictcontrol", "-Q", "-C", "o", "-c", handle_text(key_handle)]
            + owner_auth_arguments()
        )
    if nv_present:
        run_tpm(
            ["tpm2_nvundefine", "-Q", "-C", "o"]
            + owner_auth_arguments()
            + [handle_text(nv_handle)]
        )

    key_absent = key_handle not in handle_set("handles-persistent")
    nv_absent = nv_handle not in handle_set("handles-nv-index")
    if not key_absent or not nv_absent:
        raise ExperimentError("cleanup verification failed")
    return {
        "validated_names_before_removal": True,
        "key_was_present": key_present,
        "nv_was_present": nv_present,
        "key_absent_after": key_absent,
        "nv_absent_after": nv_absent,
        "only_manifest_handles_targeted": True,
    }


def phase1(args: argparse.Namespace, tool_version: str) -> dict[str, Any]:
    work_dir: Path = args.work_dir
    manifest_path = work_dir / "manifest.json"
    secrets_path = work_dir / "secrets.json"
    if manifest_path.exists() or secrets_path.exists():
        raise ExperimentError("work directory already contains a run; choose a new --work-dir")
    work_dir.mkdir(parents=True, exist_ok=True)

    nv_handle = args.nv_handle
    key_handle = args.key_handle
    if nv_handle not in NV_HANDLE_RANGE:
        raise ExperimentError("NV handle must be in 0x01520000..0x0152ffff")
    if key_handle not in KEY_HANDLE_RANGE:
        raise ExperimentError("key handle must be in 0x81020000..0x8102ffff")
    if nv_handle in handle_set("handles-nv-index"):
        raise ExperimentError(f"NV handle {handle_text(nv_handle)} is already occupied")
    if key_handle in handle_set("handles-persistent"):
        raise ExperimentError(f"persistent handle {handle_text(key_handle)} is already occupied")

    run_id = random_secrets.token_hex(12)
    secret_values = {
        "schema": SCHEMA,
        "nv_auth": random_secrets.token_hex(16),
        "key_auth": random_secrets.token_hex(16),
    }
    atomic_json(secrets_path, secret_values)
    manifest: dict[str, Any] = {
        "schema": SCHEMA,
        "run_id": run_id,
        "status": "phase1-running",
        "created_at": utc_now(),
        "phase1_boot_id": boot_id(),
        "device": str(DEVICE),
        "tcti": TCTI,
        "tool_version": tool_version,
        "increment_budget": {"cap": INCREMENT_CAP, "used": 0},
        "nv": {
            "handle": handle_text(nv_handle),
            "created": False,
            "attributes": "authread|authwrite|nt=counter|no_da",
            "allowed_names": [],
        },
        "key": {
            "handle": handle_text(key_handle),
            "persisted": False,
            "algorithm": "rsa2048:rsassa-sha256",
            "name": None,
        },
        "files": {
            "stale_state": "stale-state.json",
            "stale_signature": "stale-state.sig",
            "active_state": "active-state.json",
            "active_signature": "active-state.sig",
            "public_key": "signing-key.pem",
        },
    }
    atomic_json(manifest_path, manifest)

    run_tpm(
        [
            "tpm2_nvdefine",
            "-Q",
            "-C",
            "o",
            "-s",
            "8",
            "-g",
            "sha256",
            "-a",
            manifest["nv"]["attributes"],
            "-p",
            f"hex:{secret_values['nv_auth']}",
        ]
        + owner_auth_arguments()
        + [handle_text(nv_handle)]
    )
    initial_nv_public = nv_public_record(nv_handle)
    manifest["nv"]["created"] = True
    manifest["nv"]["allowed_names"] = [initial_nv_public["name"]]
    atomic_json(manifest_path, manifest)

    # Counter NV is uninitialized until its first increment.
    increment_nv(manifest, secret_values["nv_auth"], manifest_path)
    stale_counter = nv_counter(nv_handle, secret_values["nv_auth"], work_dir)
    written_nv_public = nv_public_record(nv_handle)
    manifest["nv"]["allowed_names"] = [written_nv_public["name"]]
    manifest["nv"]["name"] = written_nv_public["name"]
    atomic_json(manifest_path, manifest)

    primary_context = work_dir / "primary.ctx"
    key_public = work_dir / "signing-key.tpm2b-public"
    key_private = work_dir / "signing-key.tpm2b-private"
    key_context = work_dir / "signing-key.ctx"
    public_pem = work_dir / manifest["files"]["public_key"]
    try:
        run_tpm(
            [
                "tpm2_createprimary",
                "-Q",
                "-C",
                "o",
                "-G",
                "rsa2048",
                "-g",
                "sha256",
                "-c",
                str(primary_context),
            ]
            + owner_auth_arguments()
        )
        run_tpm(
            [
                "tpm2_create",
                "-Q",
                "-C",
                str(primary_context),
                "-G",
                "rsa2048:rsassa-sha256",
                "-g",
                "sha256",
                "-a",
                "fixedtpm|fixedparent|sensitivedataorigin|userwithauth|sign|noda",
                "-p",
                f"hex:{secret_values['key_auth']}",
                "-u",
                str(key_public),
                "-r",
                str(key_private),
            ]
        )
        run_tpm(
            [
                "tpm2_load",
                "-Q",
                "-C",
                str(primary_context),
                "-u",
                str(key_public),
                "-r",
                str(key_private),
                "-c",
                str(key_context),
            ]
        )
        expected_key_name = key_name(str(key_context), work_dir, public_pem)
        manifest["key"]["name"] = expected_key_name
        atomic_json(manifest_path, manifest)
        run_tpm(
            [
                "tpm2_evictcontrol",
                "-Q",
                "-C",
                "o",
                "-c",
                str(key_context),
                "-o",
                str(work_dir / "signing-key.handle"),
            ]
            + owner_auth_arguments()
            + [handle_text(key_handle)]
        )
        manifest["key"]["persisted"] = True
        atomic_json(manifest_path, manifest)
    finally:
        for context in (key_context, primary_context):
            if context.exists():
                try:
                    run_tpm(["tpm2_flushcontext", str(context)])
                except ExperimentError:
                    pass

    if key_name(handle_text(key_handle), work_dir) != manifest["key"]["name"]:
        raise ExperimentError("persistent key Name differs immediately after creation")

    stale_state = work_dir / manifest["files"]["stale_state"]
    stale_signature = work_dir / manifest["files"]["stale_signature"]
    write_state(stale_state, run_id, stale_counter, "stale")
    sign_state(key_handle, secret_values["key_auth"], stale_state, stale_signature)
    stale_initial = verify_bundle(key_handle, stale_state, stale_signature, run_id, stale_counter)

    increment_nv(manifest, secret_values["nv_auth"], manifest_path)
    active_counter = nv_counter(nv_handle, secret_values["nv_auth"], work_dir)
    if active_counter != stale_counter + 1:
        raise ExperimentError("NV counter did not advance by exactly one")
    if nv_public_record(nv_handle)["name"] != manifest["nv"]["name"]:
        raise ExperimentError("NV Name changed after the counter was initialized")

    active_state = work_dir / manifest["files"]["active_state"]
    active_signature = work_dir / manifest["files"]["active_signature"]
    write_state(active_state, run_id, active_counter, "active")
    sign_state(key_handle, secret_values["key_auth"], active_state, active_signature)
    active_initial = verify_bundle(key_handle, active_state, active_signature, run_id, active_counter)
    if not stale_initial["accepted"] or not active_initial["accepted"]:
        raise ExperimentError("phase-1 signed-state self-check failed")

    manifest["status"] = "awaiting-reboot"
    manifest["counters"] = {"stale": stale_counter, "active": active_counter}
    manifest["artifact_sha256"] = {
        manifest["files"][name]: sha256_file(work_dir / manifest["files"][name])
        for name in ("stale_state", "stale_signature", "active_state", "active_signature")
    }
    atomic_json(manifest_path, manifest)
    result = {
        "schema": SCHEMA,
        "phase": "phase1",
        "ok": True,
        "timestamp": utc_now(),
        "run_id": run_id,
        "boot_id": manifest["phase1_boot_id"],
        "reboot_required": True,
        "handles": {"nv": handle_text(nv_handle), "key": handle_text(key_handle)},
        "counters": manifest["counters"],
        "increments": manifest["increment_budget"],
        "checks": {
            "handles_were_free": True,
            "nv_public_matches": True,
            "persistent_key_name_matches": True,
            "stale_bundle_initially_valid": True,
            "active_bundle_initially_valid": True,
        },
    }
    atomic_json(work_dir / "phase1-result.json", result)
    return result


def phase2(args: argparse.Namespace, tool_version: str) -> dict[str, Any]:
    work_dir: Path = args.work_dir
    manifest, secret_values, manifest_path, secrets_path = load_run_files(work_dir)
    if manifest.get("status") != "awaiting-reboot":
        raise ExperimentError("manifest is not awaiting a guest reboot")
    current_boot_id = boot_id()
    if current_boot_id == manifest["phase1_boot_id"]:
        raise ExperimentError("Linux boot ID is unchanged; perform a guest reboot before phase2")

    key_handle = int(manifest["key"]["handle"], 16)
    nv_handle = int(manifest["nv"]["handle"], 16)
    if key_handle not in handle_set("handles-persistent") or nv_handle not in handle_set("handles-nv-index"):
        raise ExperimentError("expected persistent key or NV counter did not survive the reboot")
    if key_name(handle_text(key_handle), work_dir) != manifest["key"]["name"]:
        raise ExperimentError("post-reboot persistent key Name mismatch")
    if nv_public_record(nv_handle)["name"] != manifest["nv"]["name"]:
        raise ExperimentError("post-reboot NV Name mismatch")

    before = nv_counter(nv_handle, secret_values["nv_auth"], work_dir)
    if before != manifest["counters"]["active"]:
        raise ExperimentError("post-reboot NV counter differs from the phase-1 commit")

    active = verify_bundle(
        key_handle,
        work_dir / manifest["files"]["active_state"],
        work_dir / manifest["files"]["active_signature"],
        manifest["run_id"],
        before,
    )
    stale = verify_bundle(
        key_handle,
        work_dir / manifest["files"]["stale_state"],
        work_dir / manifest["files"]["stale_signature"],
        manifest["run_id"],
        before,
    )
    if not active["accepted"] or stale["accepted"]:
        raise ExperimentError("normal or stale-bundle decision was incorrect")

    # A fresh signature proves the persistent private key remains usable, not
    # merely that its public area can still be read.
    probe_state = work_dir / "post-reboot-probe.json"
    probe_signature = work_dir / "post-reboot-probe.sig"
    write_state(probe_state, manifest["run_id"], before, "post-reboot-probe")
    sign_state(key_handle, secret_values["key_auth"], probe_state, probe_signature)
    probe = verify_bundle(key_handle, probe_state, probe_signature, manifest["run_id"], before)
    if not probe["accepted"]:
        raise ExperimentError("post-reboot private-key signing check failed")

    # Crash point: advance TPM state, but deliberately do not replace the
    # signed application-state blob.
    increment_nv(manifest, secret_values["nv_auth"], manifest_path)
    after_crash = nv_counter(nv_handle, secret_values["nv_auth"], work_dir)
    if after_crash != before + 1:
        raise ExperimentError("crash-injection increment did not advance by exactly one")
    crash_recovery = verify_bundle(
        key_handle,
        work_dir / manifest["files"]["active_state"],
        work_dir / manifest["files"]["active_signature"],
        manifest["run_id"],
        after_crash,
    )
    if crash_recovery["accepted"]:
        raise ExperimentError("post-increment crash state was unexpectedly accepted")

    cleanup = safe_cleanup(manifest, secret_values, work_dir)
    manifest["status"] = "cleaned"
    manifest["phase2_boot_id"] = current_boot_id
    manifest["completed_at"] = utc_now()
    manifest["counters"]["post_increment_crash"] = after_crash
    atomic_json(manifest_path, manifest)
    secrets_path.unlink(missing_ok=True)

    result = {
        "schema": SCHEMA,
        "phase": "phase2",
        "ok": True,
        "timestamp": utc_now(),
        "run_id": manifest["run_id"],
        "tool_version": tool_version,
        "boot": {
            "phase1": manifest["phase1_boot_id"],
            "phase2": current_boot_id,
            "changed": True,
        },
        "counters": {
            "stale": stale["state_counter"],
            "active_before_crash": before,
            "tpm_after_crash": after_crash,
        },
        "increments": manifest["increment_budget"],
        "checks": {
            "persistent_key_name_matches": True,
            "persistent_nv_name_matches": True,
            "post_reboot_private_key_signs": True,
            "active_bundle_accepted": active["accepted"],
            "stale_signature_valid": stale["signature_valid"],
            "stale_bundle_rejected": not stale["accepted"],
            "post_increment_signature_valid": crash_recovery["signature_valid"],
            "post_increment_crash_rejected": not crash_recovery["accepted"],
        },
        "cleanup": cleanup,
    }
    atomic_json(work_dir / "phase2-result.json", result)
    return result


def cleanup_command(args: argparse.Namespace, tool_version: str) -> dict[str, Any]:
    work_dir: Path = args.work_dir
    manifest, secret_values, manifest_path, secrets_path = load_run_files(work_dir)
    cleanup = safe_cleanup(manifest, secret_values, work_dir)
    manifest["status"] = "cleaned"
    manifest["cleaned_at"] = utc_now()
    atomic_json(manifest_path, manifest)
    secrets_path.unlink(missing_ok=True)
    result = {
        "schema": SCHEMA,
        "phase": "cleanup",
        "ok": True,
        "timestamp": utc_now(),
        "run_id": manifest["run_id"],
        "tool_version": tool_version,
        "cleanup": cleanup,
    }
    atomic_json(work_dir / "cleanup-result.json", result)
    return result


def parse_handle(text: str) -> int:
    try:
        return int(text, 0)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"invalid handle: {text}") from exc


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument(
        "--work-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "work",
        help="persistent guest-disk directory for the two phases",
    )
    value.add_argument("--nv-handle", type=parse_handle, default=DEFAULT_NV_HANDLE)
    value.add_argument("--key-handle", type=parse_handle, default=DEFAULT_KEY_HANDLE)
    value.add_argument("phase", choices=("phase1", "phase2", "cleanup"))
    return value


def main() -> int:
    os.umask(0o077)
    args = parser().parse_args()
    args.work_dir = args.work_dir.resolve()
    try:
        tool_version = preflight()
        if args.phase == "phase1":
            result = phase1(args, tool_version)
        elif args.phase == "phase2":
            result = phase2(args, tool_version)
        else:
            result = cleanup_command(args, tool_version)
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    except (ExperimentError, OSError, KeyError, TypeError, ValueError) as exc:
        result = {
            "schema": SCHEMA,
            "phase": args.phase,
            "ok": False,
            "timestamp": utc_now(),
            "error": str(exc),
        }
        try:
            args.work_dir.mkdir(parents=True, exist_ok=True)
            atomic_json(args.work_dir / f"{args.phase}-error.json", result)
        except OSError:
            pass
        print(json.dumps(result, indent=2, sort_keys=True))
        return 1


if __name__ == "__main__":
    sys.exit(main())
