# QEMU/swtpm guest-reboot experiment

This harness uses a disposable Ubuntu QEMU/KVM guest and a persistent `swtpm`
TPM 2.0 backend. `host_vm.sh` manages the VM from WSL/Linux;
`vtpm_reboot.py` runs inside the guest through `tpm2-tools` and
`/dev/tpmrm0`. The Windows host is not rebooted.

The guest script never calls `tpm2_clear`, changes hierarchy authorization, or
uses an unrecorded TPM handle. Its exact defaults are NV counter `0x01520000`
and persistent signing key `0x81020000`. Phase 1 refuses occupied handles;
overrides are restricted to `0x0152xxxx` and `0x8102xxxx`.

## Host and guest prerequisites

The WSL/Linux host needs QEMU/KVM, `swtpm`, OVMF, cloud-image utilities, and
OpenSSH. `host_vm.sh` expects a separately downloaded and verified Ubuntu Noble
cloud image at:

```text
<REDACTED_LOCAL_PATH>/noble-server-cloudimg-amd64.img
```

Large disks and vTPM state remain under `<REDACTED_LOCAL_PATH>/qartz-vtpm`, outside this
repository. The guest is provisioned with Python 3 and `tpm2-tools` 5.x and
must expose `/dev/tpmrm0`. If the dedicated vTPM has a nonempty owner auth,
pass the same tpm2-tools auth expression as `QARTZ_TPM_OWNER_AUTH` in every
guest invocation.

## Run

From WSL/Linux, prepare and start the disposable guest:

```sh
chmod +x host_vm.sh
./host_vm.sh prepare
./host_vm.sh start
./host_vm.sh wait
scp -i <REDACTED_LOCAL_PATH>/
  -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  vtpm_reboot.py qartz@127.0.0.1:/home/qartz/
```

Phase 1 creates the isolated objects, initializes the NV counter, and signs
canonical stale and active states. Keep the work directory on the guest disk:

```sh
./host_vm.sh ssh \
  'sudo python3 /home/qartz/vtpm_reboot.py --work-dir /var/lib/qartz-vtpm-run1 phase1'
./host_vm.sh reboot
```

For the stronger cold-VM variant, replace `reboot` above with a complete stop
and restart of both QEMU and `swtpm`, retaining the same guest disk and TPM
state directory:

```sh
./host_vm.sh poweroff
! pgrep -f '[q]emu-system-x86_64.*qartz-vtpm'
! pgrep -f '[s]wtpm socket.*qartz-vtpm/run'
./host_vm.sh start
./host_vm.sh wait
```

Preserve the host transcript with the result bundle. The published cold-run
sidecar records the stop checks and reused disk/state paths, but those JSON
booleans are orchestration evidence rather than a cryptographic process log.

After the guest returns, phase 2 requires a changed Linux boot ID. It checks
key and counter continuity, signs again with the post-reboot private key,
rejects a correctly signed stale blob, injects a crash after NV increment, and
rejects the now-outdated active blob. It then removes only the two objects
whose TPM Names match the manifest:

```sh
./host_vm.sh ssh \
  'sudo python3 /home/qartz/vtpm_reboot.py --work-dir /var/lib/qartz-vtpm-run1 phase2'
./host_vm.sh poweroff
```

Phase 2 cleans up automatically. If phase 1 is interrupted after recording its
object Names, guarded cleanup is available separately:

```sh
./host_vm.sh ssh \
  'sudo python3 /home/qartz/vtpm_reboot.py --work-dir /var/lib/qartz-vtpm-run1 cleanup'
```

Every invocation emits JSON. `phase1-result.json`, `phase2-result.json`, the
signed canonical states, and `manifest.json` remain in the work directory.
`secrets.json` is mode `0600` and is deleted only after successful TPM cleanup.
There is no increment loop: a manifest-enforced cap allows exactly three NV
increments (initialization, phase-1 commit, and phase-2 crash injection).

## Scope and limitations

This is **swtpm/QEMU functional evidence only**. A cold-VM run demonstrates
continuity after both emulator processes stop; it is not a physical-host
reboot. It is not evidence of physical
TPM non-exportability, tamper resistance, vendor-firmware behavior, NV
endurance, power-loss atomicity, key attestation, or independent endpoints.
The simulated crash is controlled failure injection rather than host power
removal.

The vTPM state is maintained by the hypervisor. A snapshot that rolls back both
the guest disk and the `swtpm` state can roll back the application blob and the
counter together. Report the result only as single-guest vTPM reboot evidence,
not as physical-device or multi-endpoint validation.
