#!/usr/bin/env bash
set -euo pipefail

# Disposable QEMU/KVM guest used only for the Q-ARTZ virtual-TPM reboot test.
# Large VM files remain in the WSL filesystem rather than the repository.
ROOT="${GTR_VM_ROOT:-/tmp/gtr-vtpm-lab}"
[[ "$ROOT" == /* && "$ROOT" != / && "$ROOT" != /tmp && "$ROOT" != /home && "$ROOT" != "${HOME}" ]] || { echo "Use a dedicated absolute GTR_VM_ROOT" >&2; exit 1; }
BASE="$ROOT/base/noble-server-cloudimg-amd64.img"
RUN="$ROOT/run"
TPM_STATE="$RUN/tpmstate"
TPM_SOCKET="$RUN/swtpm.sock"
SSH_KEY="$RUN/ssh_key"
SSH_PORT=2222
QEMU_PID="$RUN/qemu.pid"
SWTPM_PID="$RUN/swtpm.pid"

ssh_guest() {
    ssh -i "$SSH_KEY" -p "$SSH_PORT" \
        -o BatchMode=yes -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 \
        qartz@127.0.0.1 "$@"
}

stop_pidfile() {
    local file="$1" expected="$2"
    if [[ -f "$file" ]]; then
        local pid
        pid=$(cat "$file")
        if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then
            local command
            command=$(tr '\0' ' ' < "/proc/$pid/cmdline" || true)
            if [[ "$command" == *"$expected"* && "$command" == *"$RUN"* ]]; then
                kill "$pid"
                for _ in $(seq 1 30); do
                    kill -0 "$pid" 2>/dev/null || break
                    sleep 0.2
                done
            else
                echo "refusing to stop unexpected process $pid: $command" >&2
                return 1
            fi
        fi
        rm -f "$file"
    fi
}

prepare() {
    [[ -f "$BASE" ]] || { echo "missing verified cloud image: $BASE" >&2; exit 1; }
    mkdir -p "$RUN" "$TPM_STATE"
    stop_pidfile "$QEMU_PID" qemu-system-x86_64 || true
    stop_pidfile "$SWTPM_PID" swtpm || true

    # A fresh overlay and TPM state make every run independent.  The fixed
    # deletion target is checked before removal.
    [[ "$RUN" == "$ROOT/run" && "$TPM_STATE" == "$RUN/tpmstate" ]] || exit 1
    rm -f "$RUN/disk.qcow2" "$RUN/seed.iso" "$RUN/OVMF_VARS_4M.fd" \
          "$RUN/serial.log" "$RUN/monitor.sock" "$RUN/swtpm.log"
    rm -rf "$TPM_STATE"
    mkdir -p "$TPM_STATE"

    qemu-img create -q -f qcow2 -F qcow2 -b "$BASE" "$RUN/disk.qcow2"
    qemu-img resize -q "$RUN/disk.qcow2" 10G
    cp /usr/share/OVMF/OVMF_VARS_4M.fd "$RUN/OVMF_VARS_4M.fd"

    if [[ ! -f "$SSH_KEY" ]]; then
        ssh-keygen -q -t ed25519 -N "" -f "$SSH_KEY"
    fi
    local pubkey
    pubkey=$(cat "$SSH_KEY.pub")
    cat > "$RUN/user-data" <<EOF
#cloud-config
users:
  - default
  - name: qartz
    groups: [adm, sudo, tss]
    shell: /bin/bash
    sudo: ALL=(ALL) NOPASSWD:ALL
    ssh_authorized_keys:
      - $pubkey
package_update: true
packages:
  - tpm2-tools
  - jq
  - python3
runcmd:
  - [sh, -c, 'touch /var/lib/qartz-cloud-ready']
EOF
    cat > "$RUN/meta-data" <<EOF
instance-id: qartz-vtpm-$(date +%s)
local-hostname: qartz-vtpm
EOF
    cloud-localds "$RUN/seed.iso" "$RUN/user-data" "$RUN/meta-data"
    swtpm_setup --tpm2 --tpmstate "dir://$TPM_STATE" --createek \
        --decryption --lock-nvram --logfile "$RUN/swtpm-setup.log" >/dev/null
}

start_swtpm() {
    rm -f "$TPM_SOCKET" "$SWTPM_PID"
    swtpm socket --tpm2 --tpmstate "dir=$TPM_STATE" \
        --ctrl "type=unixio,path=$TPM_SOCKET" \
        --log "file=$RUN/swtpm.log,level=5" \
        --pid "file=$SWTPM_PID" --daemon --flags not-need-init
    for _ in $(seq 1 50); do
        [[ -S "$TPM_SOCKET" ]] && return 0
        sleep 0.1
    done
    echo "swtpm socket did not appear" >&2
    exit 1
}

start_vm() {
    [[ -f "$RUN/disk.qcow2" ]] || { echo "run prepare first" >&2; exit 1; }
    start_swtpm
    rm -f "$QEMU_PID" "$RUN/monitor.sock"
    qemu-system-x86_64 \
        -name qartz-vtpm \
        -machine q35,accel=kvm -cpu host -smp 2 -m 2048 \
        -drive if=pflash,format=raw,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd \
        -drive if=pflash,format=raw,file="$RUN/OVMF_VARS_4M.fd" \
        -drive file="$RUN/disk.qcow2",if=virtio,format=qcow2 \
        -drive file="$RUN/seed.iso",if=virtio,format=raw,readonly=on \
        -netdev user,id=net0,hostfwd=tcp:127.0.0.1:${SSH_PORT}-:22 \
        -device virtio-net-pci,netdev=net0 \
        -chardev socket,id=chrtpm,path="$TPM_SOCKET" \
        -tpmdev emulator,id=tpm0,chardev=chrtpm \
        -device tpm-crb,tpmdev=tpm0 \
        -display none -serial "file:$RUN/serial.log" \
        -monitor "unix:$RUN/monitor.sock,server=on,wait=off" \
        -pidfile "$QEMU_PID" -daemonize
}

wait_ssh() {
    for _ in $(seq 1 180); do
        if ssh_guest true >/dev/null 2>&1; then
            ssh_guest 'cloud-init status --wait >/dev/null; test -e /dev/tpmrm0; command -v tpm2_getcap >/dev/null'
            return 0
        fi
        sleep 2
    done
    echo "guest SSH/cloud-init did not become ready" >&2
    tail -100 "$RUN/serial.log" >&2 || true
    exit 1
}

reboot_guest() {
    local before
    before=$(ssh_guest 'cat /proc/sys/kernel/random/boot_id')
    ssh_guest 'sudo systemctl reboot' >/dev/null 2>&1 || true
    # A fast guest can return before a polling connection observes the brief
    # SSH outage.  The changed boot ID below is the authoritative reboot check.
    sleep 5
    wait_ssh
    local after
    after=$(ssh_guest 'cat /proc/sys/kernel/random/boot_id')
    [[ "$before" != "$after" ]] || { echo "guest boot ID did not change" >&2; exit 1; }
    printf '{"before":"%s","after":"%s"}\n' "$before" "$after"
}

poweroff() {
    ssh_guest 'sudo systemctl poweroff' >/dev/null 2>&1 || true
    if [[ -f "$QEMU_PID" ]]; then
        local pid
        pid=$(cat "$QEMU_PID")
        for _ in $(seq 1 120); do
            kill -0 "$pid" 2>/dev/null || break
            sleep 0.5
        done
    fi
    stop_pidfile "$QEMU_PID" qemu-system-x86_64 || true
    stop_pidfile "$SWTPM_PID" swtpm || true
}

case "${1:-}" in
    prepare) prepare ;;
    start) start_vm ;;
    wait) wait_ssh ;;
    ssh) shift; ssh_guest "$@" ;;
    reboot) reboot_guest ;;
    poweroff) poweroff ;;
    *) echo "usage: $0 {prepare|start|wait|ssh|reboot|poweroff}" >&2; exit 2 ;;
esac
