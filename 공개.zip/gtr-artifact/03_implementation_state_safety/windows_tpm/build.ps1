param(
    [ValidateSet('Release', 'Debug')]
    [string]$Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'

$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (-not (Test-Path -LiteralPath $vswhere)) {
    throw 'Visual Studio Installer (vswhere.exe) was not found.'
}

$vs = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $vs) {
    throw 'A Visual C++ x64 toolchain was not found.'
}

$vcToolsRoot = Join-Path $vs 'VC\Tools\MSVC'
$vcTools = Get-ChildItem -LiteralPath $vcToolsRoot -Directory |
    Sort-Object { [version]$_.Name } -Descending |
    Select-Object -First 1
if (-not $vcTools) {
    throw 'The Visual C++ tools directory was not found.'
}

$kitsRoot = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10'
$sdkVersion = Get-ChildItem -LiteralPath (Join-Path $kitsRoot 'Include') -Directory |
    Sort-Object { [version]$_.Name } -Descending |
    Select-Object -First 1
if (-not $sdkVersion) {
    throw 'A Windows 10/11 SDK was not found.'
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$source = Join-Path $scriptDir 'tpm_nv.cpp'
$output = Join-Path $scriptDir 'tpm_nv.exe'
$object = Join-Path $scriptDir 'tpm_nv.obj'
$cl = Join-Path $vcTools.FullName 'bin\Hostx64\x64\cl.exe'
$sdk = $sdkVersion.Name

$includeArgs = @(
    "/I$($vcTools.FullName)\include",
    "/I$kitsRoot\Include\$sdk\ucrt",
    "/I$kitsRoot\Include\$sdk\shared",
    "/I$kitsRoot\Include\$sdk\um",
    "/I$kitsRoot\Include\$sdk\winrt"
)
$libraryArgs = @(
    "/LIBPATH:$($vcTools.FullName)\lib\x64",
    "/LIBPATH:$kitsRoot\Lib\$sdk\ucrt\x64",
    "/LIBPATH:$kitsRoot\Lib\$sdk\um\x64"
)
$compileArgs = @('/nologo', '/std:c++17', '/EHsc', '/W4', '/WX', '/DUNICODE', '/D_UNICODE')
if ($Configuration -eq 'Release') {
    $compileArgs += @('/O2', '/DNDEBUG')
} else {
    $compileArgs += @('/Od', '/Zi')
}

& $cl @compileArgs @includeArgs "/Fo:$object" "/Fe:$output" $source /link @libraryArgs tbs.lib
if ($LASTEXITCODE -ne 0) {
    throw "Compilation failed with exit code $LASTEXITCODE."
}

Write-Output $output
