[CmdletBinding()]
param(
    [ValidateRange(2, 1000)]
    [int]$Iterations = 30,

    [ValidateRange(16, 4096)]
    [int]$ChallengeBytes = 32
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-SafeErrorRecord {
    param(
        [Parameter(Mandatory = $true)]
        [System.Exception]$Exception,

        [Parameter(Mandatory = $true)]
        [string]$Stage
    )

    return [ordered]@{
        stage          = $Stage
        exception_type = $Exception.GetType().FullName
        hresult        = ('0x{0}' -f $Exception.HResult.ToString('X8'))
    }
}

function Get-LatencySummary {
    param(
        [Parameter(Mandatory = $true)]
        [double[]]$Samples
    )

    if ($Samples.Count -eq 0) {
        return [ordered]@{
            n         = 0
            median_ms = $null
            p95_ms    = $null
        }
    }

    [double[]]$orderedSamples = @($Samples | Sort-Object)
    $n = $orderedSamples.Count
    if (($n % 2) -eq 1) {
        $median = $orderedSamples[[int][Math]::Floor($n / 2)]
    }
    else {
        $upper = [int]($n / 2)
        $lower = $upper - 1
        $median = ($orderedSamples[$lower] + $orderedSamples[$upper]) / 2.0
    }

    # Nearest-rank percentile: x_(ceil(p*n)), using one-based order statistics.
    $p95Index = [Math]::Max(0, [int][Math]::Ceiling(0.95 * $n) - 1)

    return [ordered]@{
        n         = $n
        median_ms = [Math]::Round($median, 3, [MidpointRounding]::AwayFromZero)
        p95_ms    = [Math]::Round(
            $orderedSamples[$p95Index],
            3,
            [MidpointRounding]::AwayFromZero
        )
    }
}

function Test-PrivateExportBlocked {
    param(
        [Parameter(Mandatory = $true)]
        [System.Security.Cryptography.CngKey]$Key,

        [Parameter(Mandatory = $true)]
        [System.Security.Cryptography.CngKeyBlobFormat]$Format
    )

    try {
        [byte[]]$privateBlob = $Key.Export($Format)
        if ($null -ne $privateBlob) {
            [Array]::Clear($privateBlob, 0, $privateBlob.Length)
        }

        return [ordered]@{
            blocked        = $false
            exception_type = $null
            hresult        = $null
        }
    }
    catch {
        return [ordered]@{
            blocked        = $true
            exception_type = $_.Exception.GetType().FullName
            hresult        = ('0x{0}' -f $_.Exception.HResult.ToString('X8'))
        }
    }
}

$providerName = 'Microsoft Platform Crypto Provider'
$provider = New-Object System.Security.Cryptography.CngProvider($providerName)
$childScript = Join-Path $PSScriptRoot 'Invoke-PlatformKeyChild.ps1'
$powerShellExe = Join-Path $env:SystemRoot `
    'System32\WindowsPowerShell\v1.0\powershell.exe'
$keyName = 'QARTZ-Reauth-TPM-{0}' -f [Guid]::NewGuid().ToString('N')

$key = $null
$signer = $null
$verifier = $null
$rng = $null
$keyCreated = $false
$functionalSuccess = $false
$stage = 'preflight'

$result = [ordered]@{
    schema_version       = 'qartz.windows-tpm-key.v1'
    experiment           = 'physical_tpm_backed_signing_key'
    status               = 'error'
    provider             = $providerName
    key_scope            = 'CurrentUser'
    algorithm            = 'RSA-2048/SHA-256/PKCS1-v1_5'
    private_export_policy = 'None'
    requested_iterations = $Iterations
    challenge_bytes      = $ChallengeBytes
    key_properties       = $null
    challenge_verification = $null
    sign_latency_ms      = $null
    verify_latency_ms    = $null
    private_export_tests = $null
    fresh_process        = $null
    cleanup              = [ordered]@{
        attempted    = $false
        deleted      = $false
        exists_after = $null
        error        = $null
    }
    error                = $null
}

try {
    if (-not [System.IO.File]::Exists($childScript)) {
        throw New-Object System.IO.FileNotFoundException(
            'The fresh-process helper script is unavailable.'
        )
    }
    if (-not [System.IO.File]::Exists($powerShellExe)) {
        throw New-Object System.IO.FileNotFoundException(
            'Windows PowerShell is unavailable.'
        )
    }
    if ([System.Security.Cryptography.CngKey]::Exists(
        $keyName,
        $provider,
        [System.Security.Cryptography.CngKeyOpenOptions]::None
    )) {
        throw New-Object System.InvalidOperationException(
            'The randomly generated experiment key name already exists.'
        )
    }

    $stage = 'create_key'
    $creationParameters = New-Object `
        System.Security.Cryptography.CngKeyCreationParameters
    $creationParameters.Provider = $provider
    $creationParameters.KeyUsage = `
        [System.Security.Cryptography.CngKeyUsages]::Signing
    $creationParameters.ExportPolicy = `
        [System.Security.Cryptography.CngExportPolicies]::None
    $creationParameters.KeyCreationOptions = `
        [System.Security.Cryptography.CngKeyCreationOptions]::None
    $lengthProperty = New-Object System.Security.Cryptography.CngProperty(
        'Length',
        [BitConverter]::GetBytes([int]2048),
        [System.Security.Cryptography.CngPropertyOptions]::None
    )
    $creationParameters.Parameters.Add($lengthProperty)

    $key = [System.Security.Cryptography.CngKey]::Create(
        [System.Security.Cryptography.CngAlgorithm]::Rsa,
        $keyName,
        $creationParameters
    )
    $keyCreated = $true

    $stage = 'prepare_signer'
    $signer = New-Object System.Security.Cryptography.RSACng($key)
    $result.key_properties = [ordered]@{
        key_bits      = $signer.KeySize
        machine_scope = [bool]$key.IsMachineKey
        export_policy = $key.ExportPolicy.ToString()
    }
    if ($signer.KeySize -ne 2048 -or $key.IsMachineKey) {
        throw New-Object System.Security.Cryptography.CryptographicException(
            'The created key does not have the required properties.'
        )
    }
    $publicParameters = $signer.ExportParameters($false)
    $verifier = [System.Security.Cryptography.RSA]::Create()
    $verifier.ImportParameters($publicParameters)
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()

    $signSamples = New-Object 'System.Collections.Generic.List[double]'
    $verifySamples = New-Object 'System.Collections.Generic.List[double]'
    $verifiedCount = 0

    $stage = 'challenge_loop'
    for ($i = 0; $i -lt $Iterations; $i++) {
        [byte[]]$challenge = New-Object byte[] $ChallengeBytes
        $rng.GetBytes($challenge)

        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        [byte[]]$signature = $signer.SignData(
            $challenge,
            [System.Security.Cryptography.HashAlgorithmName]::SHA256,
            [System.Security.Cryptography.RSASignaturePadding]::Pkcs1
        )
        $stopwatch.Stop()
        $signSamples.Add($stopwatch.Elapsed.TotalMilliseconds)

        $stopwatch.Restart()
        $verified = $verifier.VerifyData(
            $challenge,
            $signature,
            [System.Security.Cryptography.HashAlgorithmName]::SHA256,
            [System.Security.Cryptography.RSASignaturePadding]::Pkcs1
        )
        $stopwatch.Stop()
        $verifySamples.Add($stopwatch.Elapsed.TotalMilliseconds)

        if (-not $verified) {
            throw New-Object System.Security.Cryptography.CryptographicException(
                'A challenge signature did not verify.'
            )
        }
        $verifiedCount++

        [Array]::Clear($challenge, 0, $challenge.Length)
        [Array]::Clear($signature, 0, $signature.Length)
    }

    $result.challenge_verification = [ordered]@{
        n             = $Iterations
        verified      = $verifiedCount
        all_verified  = ($verifiedCount -eq $Iterations)
    }
    $result.sign_latency_ms = Get-LatencySummary -Samples $signSamples.ToArray()
    $result.verify_latency_ms = Get-LatencySummary -Samples $verifySamples.ToArray()

    $stage = 'private_export_tests'
    $genericPrivate = Test-PrivateExportBlocked `
        -Key $key `
        -Format ([System.Security.Cryptography.CngKeyBlobFormat]::GenericPrivateBlob)
    $pkcs8Private = Test-PrivateExportBlocked `
        -Key $key `
        -Format ([System.Security.Cryptography.CngKeyBlobFormat]::Pkcs8PrivateBlob)
    $result.private_export_tests = [ordered]@{
        GenericPrivateBlob = $genericPrivate
        Pkcs8PrivateBlob   = $pkcs8Private
        all_blocked        = (
            $genericPrivate.blocked -and $pkcs8Private.blocked
        )
    }
    if (-not $result.private_export_tests.all_blocked) {
        throw New-Object System.Security.Cryptography.CryptographicException(
            'A private-key export unexpectedly succeeded.'
        )
    }

    $stage = 'fresh_process_challenge'
    [byte[]]$freshChallenge = New-Object byte[] $ChallengeBytes
    $rng.GetBytes($freshChallenge)
    $freshChallengeBase64 = [Convert]::ToBase64String($freshChallenge)

    $processStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $childOutput = & $powerShellExe `
        -NoLogo `
        -NoProfile `
        -NonInteractive `
        -ExecutionPolicy Bypass `
        -File $childScript `
        -KeyName $keyName `
        -ChallengeBase64 $freshChallengeBase64 2>&1
    $childExitCode = $LASTEXITCODE
    $processStopwatch.Stop()

    if ($childExitCode -ne 0) {
        throw New-Object System.InvalidOperationException(
            'The fresh-process key operation failed.'
        )
    }

    $childText = ($childOutput | ForEach-Object { $_.ToString() }) -join `
        [Environment]::NewLine
    $childResult = $childText | ConvertFrom-Json
    if ($childResult.status -ne 'pass' -or -not $childResult.self_verified) {
        throw New-Object System.InvalidOperationException(
            'The fresh process did not verify its signature.'
        )
    }

    [byte[]]$freshSignature = [Convert]::FromBase64String(
        $childResult.signature_base64
    )
    $parentVerified = $verifier.VerifyData(
        $freshChallenge,
        $freshSignature,
        [System.Security.Cryptography.HashAlgorithmName]::SHA256,
        [System.Security.Cryptography.RSASignaturePadding]::Pkcs1
    )
    if (-not $parentVerified) {
        throw New-Object System.Security.Cryptography.CryptographicException(
            'The parent could not verify the fresh-process signature.'
        )
    }

    $result.fresh_process = [ordered]@{
        process              = 'powershell.exe'
        reopened             = $true
        self_verified        = [bool]$childResult.self_verified
        parent_verified      = [bool]$parentVerified
        open_latency_ms      = [double]$childResult.open_latency_ms
        sign_latency_ms      = [double]$childResult.sign_latency_ms
        process_elapsed_ms   = [Math]::Round(
            $processStopwatch.Elapsed.TotalMilliseconds,
            3,
            [MidpointRounding]::AwayFromZero
        )
    }

    [Array]::Clear($freshChallenge, 0, $freshChallenge.Length)
    [Array]::Clear($freshSignature, 0, $freshSignature.Length)
    $functionalSuccess = $true
}
catch {
    $result.error = Get-SafeErrorRecord -Exception $_.Exception -Stage $stage
}
finally {
    if ($null -ne $rng) {
        try {
            $rng.Dispose()
        }
        catch {
            if ($null -eq $result.cleanup.error) {
                $result.cleanup.error = Get-SafeErrorRecord `
                    -Exception $_.Exception `
                    -Stage 'dispose_rng'
            }
        }
    }
    if ($null -ne $verifier) {
        try {
            $verifier.Dispose()
        }
        catch {
            if ($null -eq $result.cleanup.error) {
                $result.cleanup.error = Get-SafeErrorRecord `
                    -Exception $_.Exception `
                    -Stage 'dispose_verifier'
            }
        }
    }
    if ($null -ne $signer) {
        try {
            $signer.Dispose()
        }
        catch {
            if ($null -eq $result.cleanup.error) {
                $result.cleanup.error = Get-SafeErrorRecord `
                    -Exception $_.Exception `
                    -Stage 'dispose_signer'
            }
        }
    }
    if ($null -ne $key) {
        try {
            $key.Dispose()
        }
        catch {
            if ($null -eq $result.cleanup.error) {
                $result.cleanup.error = Get-SafeErrorRecord `
                    -Exception $_.Exception `
                    -Stage 'dispose_key'
            }
        }
    }

    if ($keyCreated) {
        $result.cleanup.attempted = $true
        $cleanupKey = $null
        try {
            if ([System.Security.Cryptography.CngKey]::Exists(
                $keyName,
                $provider,
                [System.Security.Cryptography.CngKeyOpenOptions]::None
            )) {
                $cleanupKey = [System.Security.Cryptography.CngKey]::Open(
                    $keyName,
                    $provider,
                    [System.Security.Cryptography.CngKeyOpenOptions]::None
                )
                $cleanupKey.Delete()
                $cleanupKey.Dispose()
                $cleanupKey = $null
            }

            $result.cleanup.exists_after = `
                [System.Security.Cryptography.CngKey]::Exists(
                    $keyName,
                    $provider,
                    [System.Security.Cryptography.CngKeyOpenOptions]::None
                )
            $result.cleanup.deleted = -not $result.cleanup.exists_after
        }
        catch {
            $result.cleanup.error = Get-SafeErrorRecord `
                -Exception $_.Exception `
                -Stage 'delete_key'
        }
        finally {
            if ($null -ne $cleanupKey) {
                $cleanupKey.Dispose()
            }
        }
    }
}

if (
    $functionalSuccess -and
    $result.cleanup.deleted -and
    $null -eq $result.cleanup.error
) {
    $result.status = 'pass'
}
elseif ($null -eq $result.error -and $null -ne $result.cleanup.error) {
    $result.error = $result.cleanup.error
}

$result | ConvertTo-Json -Depth 8 -Compress
if ($result.status -ne 'pass') {
    exit 1
}
