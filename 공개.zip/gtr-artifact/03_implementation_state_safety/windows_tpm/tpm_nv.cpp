// Q-ARTZ TPM 2.0 NV-counter helper for Windows.
//
// This program intentionally uses only the Windows TPM Base Services (TBS)
// API and hand-marshals the small TPM 2.0 command subset it needs.  It never
// clears, initializes, or takes ownership of a TPM.  Mutating commands are
// restricted to 0x01510000..0x0151ffff and refuse to touch an existing index
// unless its complete public area carries this tool's marker.

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <tbs.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#pragma comment(lib, "tbs.lib")

namespace {

constexpr std::uint16_t TPM_ST_NO_SESSIONS = 0x8001;
constexpr std::uint16_t TPM_ST_SESSIONS = 0x8002;
constexpr std::uint16_t TPM_ALG_SHA256 = 0x000b;

constexpr std::uint32_t TPM_RH_OWNER = 0x40000001;
constexpr std::uint32_t TPM_RS_PW = 0x40000009;

constexpr std::uint32_t TPM_CC_NV_UNDEFINE_SPACE = 0x00000122;
constexpr std::uint32_t TPM_CC_NV_DEFINE_SPACE = 0x0000012a;
constexpr std::uint32_t TPM_CC_NV_INCREMENT = 0x00000134;
constexpr std::uint32_t TPM_CC_NV_READ = 0x0000014e;
constexpr std::uint32_t TPM_CC_NV_READ_PUBLIC = 0x00000169;
constexpr std::uint32_t TPM_CC_GET_CAPABILITY = 0x0000017a;

constexpr std::uint32_t TPM_CAP_HANDLES = 0x00000001;
constexpr std::uint32_t TPM_HT_NV_INDEX_FIRST = 0x01000000;
constexpr std::uint32_t TPM_HT_NV_INDEX_LAST = 0x01ffffff;

constexpr std::uint32_t TPMA_NV_OWNERWRITE = 0x00000002;
constexpr std::uint32_t TPMA_NV_COUNTER = 0x00000010;
constexpr std::uint32_t TPMA_NV_OWNERREAD = 0x00020000;
constexpr std::uint32_t TPMA_NV_ORDERLY = 0x04000000;
constexpr std::uint32_t TPMA_NV_WRITTEN = 0x20000000;

constexpr std::uint32_t MANAGED_FIRST = 0x01510000;
constexpr std::uint32_t MANAGED_LAST = 0x0151ffff;
constexpr std::uint32_t MANAGED_ATTRIBUTES =
    TPMA_NV_OWNERWRITE | TPMA_NV_COUNTER | TPMA_NV_OWNERREAD;
constexpr std::uint16_t MANAGED_DATA_SIZE = 8;

// SHA-256("QARTZ_REAUTH_TPM_NV_COUNTER_V1").  This authPolicy is a public,
// fixed ownership marker, not an authorization secret.  POLICYREAD and
// POLICYWRITE are deliberately absent; access is through the storage owner.
constexpr std::array<std::uint8_t, 32> MARKER_POLICY = {
    0xa9, 0x97, 0xd6, 0xce, 0x26, 0x74, 0xea, 0xa3,
    0xd1, 0x97, 0x0f, 0x5b, 0xc3, 0x0b, 0x0e, 0xb9,
    0xbb, 0xab, 0x22, 0x68, 0x34, 0xe7, 0x79, 0x27,
    0x3c, 0x39, 0x5e, 0x5d, 0xa4, 0x5b, 0xde, 0x72,
};

constexpr std::uint32_t TPM_RC_SUCCESS = 0;
constexpr std::uint32_t TPM_RC_NV_UNINITIALIZED = 0x0000014a;

class ToolError : public std::runtime_error {
public:
    ToolError(std::string stage, std::string message,
              std::optional<std::uint32_t> tbs = std::nullopt,
              std::optional<std::uint32_t> tpm = std::nullopt)
        : std::runtime_error(std::move(message)), stage(std::move(stage)),
          tbs_result(tbs), tpm_result(tpm) {}

    std::string stage;
    std::optional<std::uint32_t> tbs_result;
    std::optional<std::uint32_t> tpm_result;
};

std::string Hex32(std::uint32_t value) {
    std::ostringstream out;
    out << "0x" << std::hex << std::setw(8) << std::setfill('0') << value;
    return out.str();
}

std::string JsonEscape(const std::string& text) {
    std::ostringstream out;
    for (unsigned char c : text) {
        switch (c) {
        case '\\': out << "\\\\"; break;
        case '"': out << "\\\""; break;
        case '\b': out << "\\b"; break;
        case '\f': out << "\\f"; break;
        case '\n': out << "\\n"; break;
        case '\r': out << "\\r"; break;
        case '\t': out << "\\t"; break;
        default:
            if (c < 0x20) {
                out << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                    << static_cast<unsigned int>(c) << std::dec;
            } else {
                out << static_cast<char>(c);
            }
        }
    }
    return out.str();
}

void PrintError(const std::string& mode, const ToolError& error) {
    std::cout << "{\"ok\":false,\"mode\":\"" << JsonEscape(mode)
              << "\",\"stage\":\"" << JsonEscape(error.stage)
              << "\",\"error\":\"" << JsonEscape(error.what()) << '"';
    if (error.tbs_result) {
        std::cout << ",\"tbs_result\":\"" << Hex32(*error.tbs_result) << '"';
    }
    if (error.tpm_result) {
        std::cout << ",\"tpm_result\":\"" << Hex32(*error.tpm_result) << '"';
    }
    std::cout << "}\n";
}

class ByteWriter {
public:
    void U8(std::uint8_t value) { data_.push_back(value); }

    void U16(std::uint16_t value) {
        data_.push_back(static_cast<std::uint8_t>(value >> 8));
        data_.push_back(static_cast<std::uint8_t>(value));
    }

    void U32(std::uint32_t value) {
        data_.push_back(static_cast<std::uint8_t>(value >> 24));
        data_.push_back(static_cast<std::uint8_t>(value >> 16));
        data_.push_back(static_cast<std::uint8_t>(value >> 8));
        data_.push_back(static_cast<std::uint8_t>(value));
    }

    void Bytes(const std::uint8_t* begin, std::size_t size) {
        data_.insert(data_.end(), begin, begin + size);
    }

    template <std::size_t N>
    void Bytes(const std::array<std::uint8_t, N>& bytes) {
        Bytes(bytes.data(), bytes.size());
    }

    void PatchU32(std::size_t offset, std::uint32_t value) {
        if (offset + 4 > data_.size()) {
            throw ToolError("marshal", "internal size-patch error");
        }
        data_[offset] = static_cast<std::uint8_t>(value >> 24);
        data_[offset + 1] = static_cast<std::uint8_t>(value >> 16);
        data_[offset + 2] = static_cast<std::uint8_t>(value >> 8);
        data_[offset + 3] = static_cast<std::uint8_t>(value);
    }

    std::size_t Size() const { return data_.size(); }
    const std::vector<std::uint8_t>& Data() const { return data_; }

private:
    std::vector<std::uint8_t> data_;
};

class ByteReader {
public:
    ByteReader(const std::vector<std::uint8_t>& data, std::size_t begin,
               std::size_t end, std::string stage)
        : data_(data), pos_(begin), end_(end), stage_(std::move(stage)) {
        if (begin > end || end > data.size()) {
            throw ToolError(stage_, "invalid response bounds");
        }
    }

    std::uint8_t U8() {
        Need(1);
        return data_[pos_++];
    }

    std::uint16_t U16() {
        Need(2);
        const auto value = static_cast<std::uint16_t>(
            (static_cast<std::uint16_t>(data_[pos_]) << 8) |
            static_cast<std::uint16_t>(data_[pos_ + 1]));
        pos_ += 2;
        return value;
    }

    std::uint32_t U32() {
        Need(4);
        const auto value = (static_cast<std::uint32_t>(data_[pos_]) << 24) |
                           (static_cast<std::uint32_t>(data_[pos_ + 1]) << 16) |
                           (static_cast<std::uint32_t>(data_[pos_ + 2]) << 8) |
                           static_cast<std::uint32_t>(data_[pos_ + 3]);
        pos_ += 4;
        return value;
    }

    std::uint64_t U64() {
        const std::uint64_t high = U32();
        const std::uint64_t low = U32();
        return (high << 32) | low;
    }

    std::vector<std::uint8_t> Bytes(std::size_t size) {
        Need(size);
        std::vector<std::uint8_t> result(data_.begin() + pos_,
                                         data_.begin() + pos_ + size);
        pos_ += size;
        return result;
    }

    std::size_t Position() const { return pos_; }
    std::size_t Remaining() const { return end_ - pos_; }

private:
    void Need(std::size_t size) {
        if (size > end_ - pos_) {
            throw ToolError(stage_, "truncated TPM response");
        }
    }

    const std::vector<std::uint8_t>& data_;
    std::size_t pos_;
    std::size_t end_;
    std::string stage_;
};

struct TpmResponse {
    std::uint16_t tag = 0;
    std::uint32_t size = 0;
    std::uint32_t code = 0;
    std::vector<std::uint8_t> bytes;
};

class TbsContext {
public:
    TbsContext() = default;
    TbsContext(const TbsContext&) = delete;
    TbsContext& operator=(const TbsContext&) = delete;

    TbsContext(TbsContext&& other) noexcept : handle_(other.handle_) {
        other.handle_ = nullptr;
    }

    TbsContext& operator=(TbsContext&& other) noexcept {
        if (this != &other) {
            if (handle_ != nullptr) Tbsip_Context_Close(handle_);
            handle_ = other.handle_;
            other.handle_ = nullptr;
        }
        return *this;
    }

    ~TbsContext() {
        if (handle_ != nullptr) {
            Tbsip_Context_Close(handle_);
        }
    }

    TBS_RESULT Open() {
        TBS_CONTEXT_PARAMS2 params{};
        params.version = TBS_CONTEXT_VERSION_TWO;
        params.includeTpm20 = 1;
        const auto result = Tbsi_Context_Create(
            reinterpret_cast<PCTBS_CONTEXT_PARAMS>(&params), &handle_);
        if (result != TBS_SUCCESS) {
            handle_ = nullptr;
        }
        return result;
    }

    bool IsOpen() const { return handle_ != nullptr; }
    TBS_HCONTEXT Handle() const { return handle_; }

    TpmResponse Submit(const std::vector<std::uint8_t>& command,
                       const std::string& stage) const {
        if (!IsOpen()) {
            throw ToolError(stage, "TBS context is not open");
        }
        if (command.size() > std::numeric_limits<UINT32>::max()) {
            throw ToolError(stage, "command is too large");
        }
        std::vector<std::uint8_t> output(TBS_IN_OUT_BUF_SIZE_MAX);
        UINT32 output_size = static_cast<UINT32>(output.size());
        const TBS_RESULT result = Tbsip_Submit_Command(
            handle_, TBS_COMMAND_LOCALITY_ZERO, TBS_COMMAND_PRIORITY_NORMAL,
            command.data(), static_cast<UINT32>(command.size()), output.data(),
            &output_size);
        if (result != TBS_SUCCESS) {
            throw ToolError(stage, "TBS command submission failed", result);
        }
        if (output_size > output.size()) {
            throw ToolError(stage, "TBS returned an invalid output size");
        }
        output.resize(output_size);
        if (output.size() < 10) {
            throw ToolError(stage, "TPM response header is truncated");
        }
        ByteReader reader(output, 0, output.size(), stage);
        TpmResponse response;
        response.tag = reader.U16();
        response.size = reader.U32();
        response.code = reader.U32();
        if (response.size < 10 || response.size != output.size()) {
            throw ToolError(stage, "TPM response size does not match TBS output");
        }
        if (response.tag != TPM_ST_NO_SESSIONS && response.tag != TPM_ST_SESSIONS) {
            throw ToolError(stage, "TPM returned an invalid response tag");
        }
        response.bytes = std::move(output);
        return response;
    }

private:
    TBS_HCONTEXT handle_ = nullptr;
};

class OwnerAuth {
public:
    OwnerAuth() { bytes_.fill(0); }
    OwnerAuth(const OwnerAuth&) = delete;
    OwnerAuth& operator=(const OwnerAuth&) = delete;

    ~OwnerAuth() { SecureZeroMemory(bytes_.data(), bytes_.size()); }

    TBS_RESULT Load(TBS_HCONTEXT context) {
        SecureZeroMemory(bytes_.data(), bytes_.size());
        length_ = static_cast<UINT32>(bytes_.size());
        const TBS_RESULT result = Tbsi_Get_OwnerAuth(
            context, TBS_OWNERAUTH_TYPE_STORAGE_20, bytes_.data(), &length_);
        if (result != TBS_SUCCESS || length_ > bytes_.size()) {
            SecureZeroMemory(bytes_.data(), bytes_.size());
            length_ = 0;
        }
        return result;
    }

    const std::uint8_t* Data() const { return bytes_.data(); }
    std::size_t Size() const { return length_; }

private:
    // TPM2B_AUTH is bounded by the largest TPM hash digest (SHA-512).
    std::array<std::uint8_t, 64> bytes_{};
    UINT32 length_ = 0;
};

void RequireTpmSuccess(const TpmResponse& response, const std::string& stage) {
    if (response.code != TPM_RC_SUCCESS) {
        throw ToolError(stage, "TPM command failed", std::nullopt,
                        response.code);
    }
}

ByteWriter CommandHeader(std::uint16_t tag, std::uint32_t command_code) {
    ByteWriter command;
    command.U16(tag);
    command.U32(0); // patched after marshalling
    command.U32(command_code);
    return command;
}

std::vector<std::uint8_t> Finalize(ByteWriter& command) {
    if (command.Size() > std::numeric_limits<std::uint32_t>::max()) {
        throw ToolError("marshal", "TPM command is too large");
    }
    command.PatchU32(2, static_cast<std::uint32_t>(command.Size()));
    return command.Data();
}

void AppendPasswordAuthorization(ByteWriter& command, const OwnerAuth& owner) {
    if (owner.Size() > std::numeric_limits<std::uint16_t>::max()) {
        throw ToolError("marshal", "storage-owner authorization is too large");
    }
    const std::uint32_t auth_size =
        4 + 2 + 1 + 2 + static_cast<std::uint32_t>(owner.Size());
    command.U32(auth_size);
    command.U32(TPM_RS_PW);
    command.U16(0); // nonce
    command.U8(0);  // sessionAttributes
    command.U16(static_cast<std::uint16_t>(owner.Size()));
    command.Bytes(owner.Data(), owner.Size());
}

std::vector<std::uint32_t> EnumerateNvHandles(const TbsContext& context) {
    std::vector<std::uint32_t> handles;
    std::uint32_t property = TPM_HT_NV_INDEX_FIRST;

    for (unsigned int page = 0; page < 1024; ++page) {
        auto command = CommandHeader(TPM_ST_NO_SESSIONS, TPM_CC_GET_CAPABILITY);
        command.U32(TPM_CAP_HANDLES);
        command.U32(property);
        command.U32(256);
        const auto response = context.Submit(Finalize(command), "get_capability");
        RequireTpmSuccess(response, "get_capability");

        ByteReader reader(response.bytes, 10, response.size, "get_capability");
        const bool more_data = reader.U8() != 0;
        const auto capability = reader.U32();
        if (capability != TPM_CAP_HANDLES) {
            throw ToolError("get_capability", "TPM returned a different capability");
        }
        const auto count = reader.U32();
        if (count > reader.Remaining() / 4) {
            throw ToolError("get_capability", "invalid TPM handle count");
        }
        std::uint32_t last = 0;
        for (std::uint32_t i = 0; i < count; ++i) {
            const auto handle = reader.U32();
            if (handle >= TPM_HT_NV_INDEX_FIRST && handle <= TPM_HT_NV_INDEX_LAST) {
                handles.push_back(handle);
                last = handle;
            }
        }
        if (!more_data || count == 0 || last == 0 || last == TPM_HT_NV_INDEX_LAST) {
            break;
        }
        if (last < property) {
            throw ToolError("get_capability", "TPM handle enumeration did not advance");
        }
        property = last + 1;
        if (property > TPM_HT_NV_INDEX_LAST) {
            break;
        }
    }
    std::sort(handles.begin(), handles.end());
    handles.erase(std::unique(handles.begin(), handles.end()), handles.end());
    return handles;
}

struct NvPublic {
    std::uint32_t index = 0;
    std::uint16_t name_alg = 0;
    std::uint32_t attributes = 0;
    std::vector<std::uint8_t> auth_policy;
    std::uint16_t data_size = 0;
};

NvPublic ReadNvPublic(const TbsContext& context, std::uint32_t handle) {
    auto command = CommandHeader(TPM_ST_NO_SESSIONS, TPM_CC_NV_READ_PUBLIC);
    command.U32(handle);
    const auto response = context.Submit(Finalize(command), "nv_read_public");
    RequireTpmSuccess(response, "nv_read_public");

    ByteReader reader(response.bytes, 10, response.size, "nv_read_public");
    const auto public_size = reader.U16();
    if (public_size > reader.Remaining()) {
        throw ToolError("nv_read_public", "invalid TPM2B_NV_PUBLIC size");
    }
    const std::size_t public_end = reader.Position() + public_size;
    NvPublic result;
    result.index = reader.U32();
    result.name_alg = reader.U16();
    result.attributes = reader.U32();
    const auto policy_size = reader.U16();
    if (policy_size > public_end - reader.Position()) {
        throw ToolError("nv_read_public", "invalid NV authPolicy size");
    }
    result.auth_policy = reader.Bytes(policy_size);
    result.data_size = reader.U16();
    if (reader.Position() != public_end) {
        throw ToolError("nv_read_public", "unexpected NV public-area fields");
    }
    const auto name_size = reader.U16();
    if (name_size > reader.Remaining()) {
        throw ToolError("nv_read_public", "invalid NV name size");
    }
    reader.Bytes(name_size);
    return result;
}

bool IsManagedHandle(std::uint32_t handle) {
    return handle >= MANAGED_FIRST && handle <= MANAGED_LAST;
}

bool HasExactMarker(const NvPublic& nv, std::uint32_t expected_handle,
                    std::string* reason = nullptr) {
    auto reject = [&](const char* why) {
        if (reason != nullptr) {
            *reason = why;
        }
        return false;
    };
    if (nv.index != expected_handle) return reject("index_mismatch");
    if (nv.name_alg != TPM_ALG_SHA256) return reject("name_alg_mismatch");
    // WRITTEN is the only TPM-maintained bit allowed to change after define.
    if ((nv.attributes & ~TPMA_NV_WRITTEN) != MANAGED_ATTRIBUTES) {
        return reject("attributes_mismatch");
    }
    if ((nv.attributes & TPMA_NV_ORDERLY) != 0) return reject("orderly_index");
    if (nv.data_size != MANAGED_DATA_SIZE) return reject("data_size_mismatch");
    if (nv.auth_policy.size() != MARKER_POLICY.size() ||
        !std::equal(nv.auth_policy.begin(), nv.auth_policy.end(),
                    MARKER_POLICY.begin())) {
        return reject("marker_policy_mismatch");
    }
    return true;
}

NvPublic RequireManagedPublic(const TbsContext& context, std::uint32_t handle) {
    if (!IsManagedHandle(handle)) {
        throw ToolError("safety_check", "handle is outside the managed NV range");
    }
    auto nv = ReadNvPublic(context, handle);
    std::string reason;
    if (!HasExactMarker(nv, handle, &reason)) {
        throw ToolError("safety_check",
                        "refusing nonmatching NV index: " + reason);
    }
    return nv;
}

void DefineNvCounter(const TbsContext& context, std::uint32_t handle,
                     const OwnerAuth& owner) {
    auto command = CommandHeader(TPM_ST_SESSIONS, TPM_CC_NV_DEFINE_SPACE);
    command.U32(TPM_RH_OWNER);
    AppendPasswordAuthorization(command, owner);
    command.U16(0); // empty per-index auth; only OWNERREAD/OWNERWRITE are enabled

    constexpr std::uint16_t public_size =
        4 + 2 + 4 + 2 + static_cast<std::uint16_t>(MARKER_POLICY.size()) + 2;
    command.U16(public_size);
    command.U32(handle);
    command.U16(TPM_ALG_SHA256);
    command.U32(MANAGED_ATTRIBUTES);
    command.U16(static_cast<std::uint16_t>(MARKER_POLICY.size()));
    command.Bytes(MARKER_POLICY);
    command.U16(MANAGED_DATA_SIZE);

    const auto response = context.Submit(Finalize(command), "nv_define");
    RequireTpmSuccess(response, "nv_define");
}

void UndefineNvCounter(const TbsContext& context, std::uint32_t handle,
                       const OwnerAuth& owner) {
    auto command = CommandHeader(TPM_ST_SESSIONS, TPM_CC_NV_UNDEFINE_SPACE);
    command.U32(TPM_RH_OWNER);
    command.U32(handle);
    AppendPasswordAuthorization(command, owner);
    const auto response = context.Submit(Finalize(command), "nv_undefine");
    RequireTpmSuccess(response, "nv_undefine");
}

void IncrementNvCounter(const TbsContext& context, std::uint32_t handle,
                        const OwnerAuth& owner) {
    auto command = CommandHeader(TPM_ST_SESSIONS, TPM_CC_NV_INCREMENT);
    command.U32(TPM_RH_OWNER);
    command.U32(handle);
    AppendPasswordAuthorization(command, owner);
    const auto response = context.Submit(Finalize(command), "nv_increment");
    RequireTpmSuccess(response, "nv_increment");
}

struct CounterRead {
    bool initialized = false;
    std::uint64_t value = 0;
};

CounterRead ReadNvCounter(const TbsContext& context, std::uint32_t handle,
                          const OwnerAuth& owner) {
    auto command = CommandHeader(TPM_ST_SESSIONS, TPM_CC_NV_READ);
    command.U32(TPM_RH_OWNER);
    command.U32(handle);
    AppendPasswordAuthorization(command, owner);
    command.U16(MANAGED_DATA_SIZE);
    command.U16(0); // offset
    const auto response = context.Submit(Finalize(command), "nv_read");
    if (response.code == TPM_RC_NV_UNINITIALIZED) {
        return {};
    }
    RequireTpmSuccess(response, "nv_read");
    if (response.tag != TPM_ST_SESSIONS) {
        throw ToolError("nv_read", "TPM omitted the expected response session");
    }

    ByteReader reader(response.bytes, 10, response.size, "nv_read");
    const auto parameter_size = reader.U32();
    if (parameter_size > reader.Remaining()) {
        throw ToolError("nv_read", "invalid TPM response parameter size");
    }
    const auto parameter_end = reader.Position() + parameter_size;
    const auto data_size = reader.U16();
    if (data_size != MANAGED_DATA_SIZE ||
        data_size > parameter_end - reader.Position()) {
        throw ToolError("nv_read", "TPM returned an invalid counter size");
    }
    CounterRead result;
    result.initialized = true;
    result.value = reader.U64();
    if (reader.Position() != parameter_end) {
        throw ToolError("nv_read", "unexpected NV read parameters");
    }
    return result;
}

OwnerAuth& LoadOwnerAuth(TBS_HCONTEXT context, OwnerAuth& auth) {
    const auto result = auth.Load(context);
    if (result != TBS_SUCCESS) {
        throw ToolError("owner_auth", "storage-owner authorization is unavailable",
                        result);
    }
    return auth;
}

std::uint32_t ParseHandle(const std::string& text) {
    std::size_t parsed = 0;
    unsigned long long value = 0;
    try {
        value = std::stoull(text, &parsed, 0);
    } catch (const std::exception&) {
        throw ToolError("arguments", "invalid handle: " + text);
    }
    if (parsed != text.size() || value > std::numeric_limits<std::uint32_t>::max()) {
        throw ToolError("arguments", "invalid handle: " + text);
    }
    const auto handle = static_cast<std::uint32_t>(value);
    if (!IsManagedHandle(handle)) {
        throw ToolError("safety_check", "handle is outside the managed NV range");
    }
    return handle;
}

unsigned int ParseIterations(const std::string& text) {
    std::size_t parsed = 0;
    unsigned long value = 0;
    try {
        value = std::stoul(text, &parsed, 10);
    } catch (const std::exception&) {
        throw ToolError("arguments", "invalid iteration count: " + text);
    }
    if (parsed != text.size() || value < 1 || value > 20) {
        throw ToolError("arguments", "iterations must be between 1 and 20");
    }
    return static_cast<unsigned int>(value);
}

struct Arguments {
    std::string mode;
    std::optional<std::uint32_t> handle;
    std::optional<unsigned int> iterations;
};

Arguments ParseArguments(int argc, char** argv) {
    if (argc < 2) {
        throw ToolError("arguments", "mode is required");
    }
    Arguments result;
    result.mode = argv[1];
    for (int i = 2; i < argc; ++i) {
        const std::string option = argv[i];
        if (option == "--handle" && i + 1 < argc) {
            if (result.handle) throw ToolError("arguments", "duplicate --handle");
            result.handle = ParseHandle(argv[++i]);
        } else if (option == "--iterations" && i + 1 < argc) {
            if (result.iterations) {
                throw ToolError("arguments", "duplicate --iterations");
            }
            result.iterations = ParseIterations(argv[++i]);
        } else {
            throw ToolError("arguments", "unknown or incomplete option: " + option);
        }
    }

    const bool valid_mode = result.mode == "probe" || result.mode == "define" ||
                            result.mode == "read" || result.mode == "increment" ||
                            result.mode == "bench" || result.mode == "undefine";
    if (!valid_mode) throw ToolError("arguments", "unknown mode: " + result.mode);
    if ((result.mode == "read" || result.mode == "increment" ||
         result.mode == "bench" || result.mode == "undefine") &&
        !result.handle) {
        throw ToolError("arguments", "--handle is required for this mode");
    }
    if (result.mode != "bench" && result.iterations) {
        throw ToolError("arguments", "--iterations is valid only for bench");
    }
    if (result.mode == "probe" && result.handle) {
        throw ToolError("arguments", "probe does not accept --handle");
    }
    if (result.mode == "bench" && !result.iterations) {
        throw ToolError("arguments", "--iterations is required for bench");
    }
    return result;
}

std::string InterfaceName(std::uint32_t type) {
    switch (type) {
    case TPM_IFTYPE_UNKNOWN: return "unknown";
    case TPM_IFTYPE_1: return "tpm12_io_or_mmio";
    case TPM_IFTYPE_TRUSTZONE: return "trustzone";
    case TPM_IFTYPE_HW: return "hardware";
    case TPM_IFTYPE_EMULATOR: return "emulator";
    case TPM_IFTYPE_SPB: return "spb";
    default: return "unrecognized";
    }
}

int RunProbe() {
    TPM_DEVICE_INFO info{};
    info.structVersion = 1;
    const TBS_RESULT device_result = Tbsi_GetDeviceInfo(sizeof(info), &info);

    TbsContext context;
    const TBS_RESULT context_result = context.Open();

    TBS_RESULT owner_result = static_cast<TBS_RESULT>(TBS_E_INVALID_CONTEXT);
    bool owner_available = false;
    if (context.IsOpen()) {
        OwnerAuth owner;
        owner_result = owner.Load(context.Handle());
        owner_available = owner_result == TBS_SUCCESS;
    }

    std::vector<std::uint32_t> handles;
    std::optional<ToolError> enumeration_error;
    if (context.IsOpen()) {
        try {
            handles = EnumerateNvHandles(context);
        } catch (const ToolError& error) {
            enumeration_error = error;
        }
    }

    const bool ok = device_result == TBS_SUCCESS &&
                    info.tpmVersion == TPM_VERSION_20 &&
                    context_result == TBS_SUCCESS && owner_available &&
                    !enumeration_error;
    std::cout << "{\"ok\":" << (ok ? "true" : "false")
              << ",\"mode\":\"probe\",\"device\":{"
              << "\"query_ok\":" << (device_result == TBS_SUCCESS ? "true" : "false")
              << ",\"result\":\"" << Hex32(device_result) << '"';
    if (device_result == TBS_SUCCESS) {
        std::cout << ",\"tpm_version\":" << info.tpmVersion
                  << ",\"is_tpm20\":"
                  << (info.tpmVersion == TPM_VERSION_20 ? "true" : "false")
                  << ",\"interface_type\":" << info.tpmInterfaceType
                  << ",\"interface\":\"" << InterfaceName(info.tpmInterfaceType)
                  << "\",\"implementation_revision\":" << info.tpmImpRevision;
    }
    std::cout << "},\"tbs\":{\"context_ok\":"
              << (context_result == TBS_SUCCESS ? "true" : "false")
              << ",\"result\":\"" << Hex32(context_result) << "\"}"
              << ",\"storage_owner_auth\":{\"available\":"
              << (owner_available ? "true" : "false")
              << ",\"result\":\"" << Hex32(owner_result) << "\"}"
              << ",\"managed_range\":{\"first\":\"" << Hex32(MANAGED_FIRST)
              << "\",\"last\":\"" << Hex32(MANAGED_LAST) << "\"}"
              << ",\"nv_handles\":[";
    for (std::size_t i = 0; i < handles.size(); ++i) {
        if (i != 0) std::cout << ',';
        std::cout << '"' << Hex32(handles[i]) << '"';
    }
    std::cout << "],\"managed_handles\":[";
    bool first_managed = true;
    if (context.IsOpen() && !enumeration_error) {
        for (const auto handle : handles) {
            if (!IsManagedHandle(handle)) continue;
            if (!first_managed) std::cout << ',';
            first_managed = false;
            std::cout << "{\"handle\":\"" << Hex32(handle) << '"';
            try {
                const auto nv = ReadNvPublic(context, handle);
                std::string reason;
                const bool match = HasExactMarker(nv, handle, &reason);
                std::cout << ",\"public_read\":true,\"marker_match\":"
                          << (match ? "true" : "false");
                if (!match) {
                    std::cout << ",\"mismatch\":\"" << JsonEscape(reason) << '"';
                }
            } catch (const ToolError& error) {
                std::cout << ",\"public_read\":false,\"marker_match\":false"
                          << ",\"error\":\"" << JsonEscape(error.what()) << '"';
                if (error.tpm_result) {
                    std::cout << ",\"tpm_result\":\"" << Hex32(*error.tpm_result)
                              << '"';
                }
                if (error.tbs_result) {
                    std::cout << ",\"tbs_result\":\"" << Hex32(*error.tbs_result)
                              << '"';
                }
            }
            std::cout << '}';
        }
    }
    std::cout << ']';
    if (enumeration_error) {
        std::cout << ",\"enumeration_error\":{\"stage\":\""
                  << JsonEscape(enumeration_error->stage) << "\",\"error\":\""
                  << JsonEscape(enumeration_error->what()) << '"';
        if (enumeration_error->tbs_result) {
            std::cout << ",\"tbs_result\":\""
                      << Hex32(*enumeration_error->tbs_result) << '"';
        }
        if (enumeration_error->tpm_result) {
            std::cout << ",\"tpm_result\":\""
                      << Hex32(*enumeration_error->tpm_result) << '"';
        }
        std::cout << '}';
    }
    std::cout << "}\n";
    return ok ? 0 : 2;
}

TbsContext OpenRequiredContext() {
    TbsContext context;
    const auto result = context.Open();
    if (result != TBS_SUCCESS) {
        throw ToolError("tbs_context", "could not open a TPM 2.0 TBS context",
                        result);
    }
    return context;
}

int RunDefine(const Arguments& arguments, TbsContext& context) {
    const auto handles = EnumerateNvHandles(context);
    const std::set<std::uint32_t> existing(handles.begin(), handles.end());
    std::uint32_t handle = 0;
    if (arguments.handle) {
        handle = *arguments.handle;
    } else {
        for (std::uint32_t candidate = MANAGED_FIRST; candidate <= MANAGED_LAST;
             ++candidate) {
            if (existing.find(candidate) == existing.end()) {
                handle = candidate;
                break;
            }
        }
        if (handle == 0) {
            throw ToolError("select_handle", "managed NV range has no free handle");
        }
    }

    if (existing.find(handle) != existing.end()) {
        const auto nv = RequireManagedPublic(context, handle);
        (void)nv;
        std::cout << "{\"ok\":true,\"mode\":\"define\",\"handle\":\""
                  << Hex32(handle)
                  << "\",\"created\":false,\"already_exists\":true}\n";
        return 0;
    }

    OwnerAuth owner;
    LoadOwnerAuth(context.Handle(), owner);
    DefineNvCounter(context, handle, owner);
    // Re-read after creation so a malformed or substituted object is never
    // reported as ours.  This is read-only and does not initialize the counter.
    const auto nv = RequireManagedPublic(context, handle);
    std::cout << "{\"ok\":true,\"mode\":\"define\",\"handle\":\""
              << Hex32(handle) << "\",\"created\":true,\"initialized\":"
              << ((nv.attributes & TPMA_NV_WRITTEN) ? "true" : "false") << "}\n";
    return 0;
}

int RunRead(const Arguments& arguments, TbsContext& context) {
    const auto handle = *arguments.handle;
    RequireManagedPublic(context, handle);
    OwnerAuth owner;
    LoadOwnerAuth(context.Handle(), owner);
    const auto value = ReadNvCounter(context, handle, owner);
    std::cout << "{\"ok\":true,\"mode\":\"read\",\"handle\":\""
              << Hex32(handle) << "\",\"initialized\":"
              << (value.initialized ? "true" : "false") << ",\"value\":";
    if (value.initialized) std::cout << value.value;
    else std::cout << "null";
    std::cout << "}\n";
    return 0;
}

double TimedIncrement(const TbsContext& context, std::uint32_t handle,
                      const OwnerAuth& owner) {
    LARGE_INTEGER frequency{};
    LARGE_INTEGER begin{};
    LARGE_INTEGER end{};
    if (!QueryPerformanceFrequency(&frequency) || frequency.QuadPart <= 0 ||
        !QueryPerformanceCounter(&begin)) {
        throw ToolError("timer", "high-resolution timer is unavailable");
    }
    IncrementNvCounter(context, handle, owner);
    if (!QueryPerformanceCounter(&end)) {
        throw ToolError("timer", "high-resolution timer failed");
    }
    return static_cast<double>(end.QuadPart - begin.QuadPart) * 1000.0 /
           static_cast<double>(frequency.QuadPart);
}

int RunIncrement(const Arguments& arguments, TbsContext& context) {
    const auto handle = *arguments.handle;
    RequireManagedPublic(context, handle);
    OwnerAuth owner;
    LoadOwnerAuth(context.Handle(), owner);
    const auto before = ReadNvCounter(context, handle, owner);
    const double elapsed_ms = TimedIncrement(context, handle, owner);
    const auto after = ReadNvCounter(context, handle, owner);
    if (!after.initialized || (before.initialized && after.value <= before.value)) {
        throw ToolError("verify_increment", "counter did not advance");
    }
    std::cout << std::fixed << std::setprecision(6)
              << "{\"ok\":true,\"mode\":\"increment\",\"handle\":\""
              << Hex32(handle) << "\",\"before\":";
    if (before.initialized) std::cout << before.value;
    else std::cout << "null";
    std::cout << ",\"after\":" << after.value
              << ",\"increment_ms\":" << elapsed_ms << "}\n";
    return 0;
}

double Median(std::vector<double> samples) {
    std::sort(samples.begin(), samples.end());
    const auto middle = samples.size() / 2;
    if ((samples.size() & 1U) != 0) return samples[middle];
    return (samples[middle - 1] + samples[middle]) / 2.0;
}

double Percentile95(std::vector<double> samples) {
    std::sort(samples.begin(), samples.end());
    const std::size_t rank = static_cast<std::size_t>(
        std::ceil(0.95 * static_cast<double>(samples.size())));
    return samples[std::max<std::size_t>(1, rank) - 1];
}

int RunBench(const Arguments& arguments, TbsContext& context) {
    const auto handle = *arguments.handle;
    const auto iterations = *arguments.iterations;
    RequireManagedPublic(context, handle);
    OwnerAuth owner;
    LoadOwnerAuth(context.Handle(), owner);
    const auto before = ReadNvCounter(context, handle, owner);
    auto previous = before;
    std::vector<double> samples;
    samples.reserve(iterations);
    for (unsigned int i = 0; i < iterations; ++i) {
        samples.push_back(TimedIncrement(context, handle, owner));
        const auto current = ReadNvCounter(context, handle, owner);
        if (!current.initialized ||
            (previous.initialized && current.value <= previous.value)) {
            throw ToolError("verify_bench", "counter did not advance monotonically");
        }
        previous = current;
    }
    const auto after = previous;
    std::cout << std::fixed << std::setprecision(6)
              << "{\"ok\":true,\"mode\":\"bench\",\"handle\":\""
              << Hex32(handle) << "\",\"iterations\":" << iterations
              << ",\"before\":";
    if (before.initialized) std::cout << before.value;
    else std::cout << "null";
    std::cout << ",\"after\":" << after.value
              << ",\"median_ms\":" << Median(samples)
              << ",\"p95_ms\":" << Percentile95(samples)
              << ",\"samples_ms\":[";
    for (std::size_t i = 0; i < samples.size(); ++i) {
        if (i != 0) std::cout << ',';
        std::cout << samples[i];
    }
    std::cout << "]}\n";
    return 0;
}

int RunUndefine(const Arguments& arguments, TbsContext& context) {
    const auto handle = *arguments.handle;
    // This exact-marker check is the critical guard against deleting an index
    // owned by Windows or another application.
    RequireManagedPublic(context, handle);
    OwnerAuth owner;
    LoadOwnerAuth(context.Handle(), owner);
    UndefineNvCounter(context, handle, owner);
    std::cout << "{\"ok\":true,\"mode\":\"undefine\",\"handle\":\""
              << Hex32(handle) << "\",\"removed\":true}\n";
    return 0;
}

} // namespace

int main(int argc, char** argv) {
    std::string mode = argc >= 2 ? argv[1] : "";
    try {
        const auto arguments = ParseArguments(argc, argv);
        mode = arguments.mode;
        if (mode == "probe") return RunProbe();

        auto context = OpenRequiredContext();
        if (mode == "define") return RunDefine(arguments, context);
        if (mode == "read") return RunRead(arguments, context);
        if (mode == "increment") return RunIncrement(arguments, context);
        if (mode == "bench") return RunBench(arguments, context);
        if (mode == "undefine") return RunUndefine(arguments, context);
        throw ToolError("arguments", "unreachable mode dispatch");
    } catch (const ToolError& error) {
        PrintError(mode, error);
        return 2;
    } catch (const std::exception& error) {
        PrintError(mode, ToolError("internal", error.what()));
        return 3;
    }
}
