[CmdletBinding()]
param(
    [string]$InputPath,
    [string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($InputPath)) {
    $InputPath = Join-Path $PSScriptRoot '..\results_raw\tpm_hardware\latest.json'
}
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $PSScriptRoot '..\results\reauth_tpm_macros.tex'
}

$run = Get-Content -LiteralPath $InputPath -Raw | ConvertFrom-Json
if ($run.status -ne 'pass') {
    throw 'The latest hardware-TPM run did not pass.'
}
if (-not $run.cleanup.nv_undefined -or -not $run.cleanup.key_deleted) {
    throw 'The latest hardware-TPM run did not record complete cleanup.'
}

$fresh = $run.cases | Where-Object { $_.name -eq 'fresh_process_key_and_counter_reopen' }
if ($null -eq $fresh -or -not $fresh.pass) {
    throw 'The fresh-process TPM case is missing or failed.'
}

$lines = @(
    '% Auto-generated from testbed/results_raw/tpm_hardware/latest.json.',
    ('\newcommand{{\RaTpmCases}}{{{0}}}' -f $run.cases_total),
    ('\newcommand{{\RaTpmCasesOk}}{{{0}}}' -f $run.cases_passed),
    ('\newcommand{{\RaTpmSignN}}{{{0}}}' -f $run.key.sign_latency_ms.n),
    ('\newcommand{{\RaTpmSignMedMs}}{{{0:0.000}}}' -f ([double]$run.key.sign_latency_ms.median_ms)),
    ('\newcommand{{\RaTpmSignPtfMs}}{{{0:0.000}}}' -f ([double]$run.key.sign_latency_ms.p95_ms)),
    ('\newcommand{{\RaTpmNvN}}{{{0}}}' -f $run.nv.bench_iterations),
    ('\newcommand{{\RaTpmNvMedMs}}{{{0:0.000}}}' -f ([double]$run.nv.increment_median_ms)),
    ('\newcommand{{\RaTpmNvPtfMs}}{{{0:0.000}}}' -f ([double]$run.nv.increment_p95_ms)),
    ('\newcommand{{\RaTpmFreshOpenMs}}{{{0:0.000}}}' -f ([double]$fresh.evidence.key_open_ms)),
    ('\newcommand{{\RaTpmWinBuild}}{{{0}}}' -f $run.platform.windows_build),
    ('\newcommand{{\RaTpmFirmware}}{{{0}}}' -f $run.platform.tpm_firmware),
    ('\newcommand{{\RaTpmRestartPending}}{{{0}}}' -f $(if ($run.platform.restart_pending) { 'yes' } else { 'no' }))
)

$directory = Split-Path -Parent $OutputPath
New-Item -ItemType Directory -Path $directory -Force | Out-Null
[IO.File]::WriteAllLines(
    [IO.Path]::GetFullPath($OutputPath),
    $lines,
    (New-Object Text.UTF8Encoding($false))
)
Write-Output ([IO.Path]::GetFullPath($OutputPath))
