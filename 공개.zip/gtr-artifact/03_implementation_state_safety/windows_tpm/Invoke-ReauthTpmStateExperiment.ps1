[CmdletBinding()]
param(
    [ValidateRange(2, 100)]
    [int]$KeyIterations = 30,

    [ValidateRange(1, 10)]
    [int]$NvIterations = 10,

    [ValidatePattern('^0x0151[0-9A-Fa-f]{4}$')]
    [string]$Handle = '0x01510000'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$providerName = 'Microsoft Platform Crypto Provider'
$nvExe = Join-Path $PSScriptRoot 'tpm_nv.exe'
$childScript = Join-Path $PSScriptRoot 'Invoke-PlatformKeyChild.ps1'
$powershellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$resultRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\results_raw\tpm_hardware'))
$runId = [Guid]::NewGuid().ToString('N')
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$runDir = Join-Path $resultRoot ("run-{0}-{1}" -f $stamp, $runId.Substring(0, 8))
$keyName = 'QARTZ-Reauth-State-{0}' -f $runId

function Invoke-Nv {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)

    $text = (& $script:nvExe @Arguments 2>&1 | ForEach-Object { $_.ToString() }) -join "`n"
    $exitCode = $LASTEXITCODE
    try {
        $parsed = $text | ConvertFrom-Json
    }
    catch {
        throw "TPM NV helper returned non-JSON output (exit $exitCode)."
    }
    if ($exitCode -ne 0 -or -not $parsed.ok) {
        $stage = if ($parsed.stage) { $parsed.stage } else { 'unknown' }
        $tpmResult = if ($parsed.tpm_result) { $parsed.tpm_result } else { 'none' }
        $tbsResult = if ($parsed.tbs_result) { $parsed.tbs_result } else { 'none' }
        throw "TPM NV helper failed at $stage (TPM=$tpmResult, TBS=$tbsResult)."
    }
    return $parsed
}

function Get-LatencySummary {
    param([Parameter(Mandatory = $true)][double[]]$Samples)

    [double[]]$sorted = @($Samples | Sort-Object)
    $n = $sorted.Count
    $middle = [int][Math]::Floor($n / 2)
    $median = if (($n % 2) -eq 1) {
        $sorted[$middle]
    }
    else {
        ($sorted[$middle - 1] + $sorted[$middle]) / 2.0
    }
    $p95 = $sorted[[Math]::Max(0, [int][Math]::Ceiling(0.95 * $n) - 1)]
    return [ordered]@{
        n = $n
        median_ms = [Math]::Round($median, 3)
        p95_ms = [Math]::Round($p95, 3)
        samples_ms = @($Samples | ForEach-Object { [Math]::Round($_, 6) })
    }
}

function Get-CanonicalBytes {
    param(
        [Parameter(Mandatory = $true)][string]$Run,
        [Parameter(Mandatory = $true)][UInt64]$Counter,
        [Parameter(Mandatory = $true)][UInt32]$Epoch,
        [Parameter(Mandatory = $true)][string]$Label
    )

    $canonical = 'QARTZ-NV1|{0}|{1}|{2}|{3}' -f $Run, $Counter, $Epoch, $Label
    return [Text.Encoding]::UTF8.GetBytes($canonical)
}

function New-SignedBlob {
    param(
        [Parameter(Mandatory = $true)][UInt64]$Counter,
        [Parameter(Mandatory = $true)][UInt32]$Epoch,
        [Parameter(Mandatory = $true)][string]$Label
    )

    [byte[]]$message = Get-CanonicalBytes -Run $script:runId -Counter $Counter -Epoch $Epoch -Label $Label
    [byte[]]$signature = $script:signer.SignData(
        $message,
        [Security.Cryptography.HashAlgorithmName]::SHA256,
        [Security.Cryptography.RSASignaturePadding]::Pkcs1
    )
    try {
        return [ordered]@{
            schema = 'qartz.signed-state.v1'
            run_id = $script:runId
            counter = $Counter
            epoch = $Epoch
            label = $Label
            signature_base64 = [Convert]::ToBase64String($signature)
        }
    }
    finally {
        [Array]::Clear($message, 0, $message.Length)
        [Array]::Clear($signature, 0, $signature.Length)
    }
}

function Test-BlobSignature {
    param([Parameter(Mandatory = $true)]$Blob)

    $message = $null
    $signature = $null
    try {
        [byte[]]$message = Get-CanonicalBytes `
            -Run ([string]$Blob.run_id) `
            -Counter ([UInt64]$Blob.counter) `
            -Epoch ([UInt32]$Blob.epoch) `
            -Label ([string]$Blob.label)
        [byte[]]$signature = [Convert]::FromBase64String([string]$Blob.signature_base64)
        return $script:verifier.VerifyData(
            $message,
            $signature,
            [Security.Cryptography.HashAlgorithmName]::SHA256,
            [Security.Cryptography.RSASignaturePadding]::Pkcs1
        )
    }
    catch {
        return $false
    }
    finally {
        if ($null -ne $message) { [Array]::Clear($message, 0, $message.Length) }
        if ($null -ne $signature) { [Array]::Clear($signature, 0, $signature.Length) }
    }
}

function Write-DurableBlob {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)]$Blob
    )

    [byte[]]$bytes = [Text.Encoding]::UTF8.GetBytes(($Blob | ConvertTo-Json -Depth 4 -Compress))
    $stream = New-Object IO.FileStream(
        $Path,
        [IO.FileMode]::Create,
        [IO.FileAccess]::Write,
        [IO.FileShare]::None
    )
    try {
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    }
    finally {
        $stream.Dispose()
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

function Read-Blob {
    param([Parameter(Mandatory = $true)][string]$Path)
    return (Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json)
}

function Test-LiveState {
    param([Parameter(Mandatory = $true)][string]$Path)

    $blob = Read-Blob -Path $Path
    $read = Invoke-Nv -Arguments @('read', '--handle', $script:Handle)
    $signatureValid = Test-BlobSignature -Blob $blob
    $counterEqual = $read.initialized -and ([UInt64]$blob.counter -eq [UInt64]$read.value)
    return [ordered]@{
        decision = if ($signatureValid -and $counterEqual) { 'accept' } else { 'reject' }
        signature_valid = [bool]$signatureValid
        counter_equal = [bool]$counterEqual
        blob_counter = [UInt64]$blob.counter
        nv_counter = if ($read.initialized) { [UInt64]$read.value } else { $null }
    }
}

function Test-PrivateExportBlocked {
    param([Parameter(Mandatory = $true)][Security.Cryptography.CngKeyBlobFormat]$Format)
    try {
        [byte[]]$unexpected = $script:key.Export($Format)
        if ($null -ne $unexpected) { [Array]::Clear($unexpected, 0, $unexpected.Length) }
        return $false
    }
    catch {
        return $true
    }
}

function Add-Case {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Expected,
        [Parameter(Mandatory = $true)][string]$Observed,
        [Parameter(Mandatory = $true)]$Evidence
    )
    $script:cases.Add([ordered]@{
        name = $Name
        expected = $Expected
        observed = $Observed
        pass = ($Expected -eq $Observed)
        evidence = $Evidence
    })
}

New-Item -ItemType Directory -Path $runDir -Force | Out-Null
$activePath = Join-Path $runDir 'active.json'
$state1Path = Join-Path $runDir 'state-baseline.json'
$state2Path = Join-Path $runDir 'state-test-reset.json'
$state3Path = Join-Path $runDir 'state-normal-commit.json'

$key = $null
$signer = $null
$verifier = $null
$rng = $null
$keyCreated = $false
$nvCreated = $false
$functionalSuccess = $false
$stage = 'preflight'
$cases = New-Object 'System.Collections.Generic.List[object]'
$cleanup = [ordered]@{
    nv_undefine_attempted = $false
    nv_undefined = $false
    key_delete_attempted = $false
    key_deleted = $false
    error = $null
}
$result = [ordered]@{
    schema = 'qartz.reauth.hardware-tpm-state.v1'
    status = 'error'
    timestamp_utc = [DateTime]::UtcNow.ToString('o')
    scope = 'single_windows_endpoint_process_crash'
    reboot_tested = $false
    power_loss_tested = $false
    handle = $Handle.ToLowerInvariant()
    platform = $null
    key = $null
    nv = $null
    cases = $null
    cases_passed = 0
    cases_total = 0
    cleanup = $cleanup
    error = $null
}

try {
    $principal = New-Object Security.Principal.WindowsPrincipal(
        [Security.Principal.WindowsIdentity]::GetCurrent()
    )
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Administrator elevation is required for TBS owner authorization.'
    }
    foreach ($required in @($nvExe, $childScript, $powershellExe)) {
        if (-not (Test-Path -LiteralPath $required)) { throw "Required file is missing: $required" }
    }

    $stage = 'tpm_preflight'
    $tpm = Get-Tpm
    if (-not $tpm.TpmPresent -or -not $tpm.TpmReady) {
        throw 'A ready TPM 2.0 is not available.'
    }
    $probe = Invoke-Nv -Arguments @('probe')
    if (-not $probe.device.is_tpm20 -or $probe.device.interface -ne 'hardware') {
        throw 'TBS did not identify a hardware-interface TPM 2.0.'
    }
    if (@($probe.managed_handles | Where-Object { $_.handle -eq $Handle }).Count -ne 0) {
        throw 'The selected experiment handle is already defined.'
    }

    $result.platform = [ordered]@{
        windows_build = [Environment]::OSVersion.Version.Build
        tpm_manufacturer = $tpm.ManufacturerIdTxt
        tpm_firmware = ([string]$tpm.ManufacturerVersion).Trim([char]0)
        tpm_ready = [bool]$tpm.TpmReady
        restart_pending = [bool]$tpm.RestartPending
        tbs_interface = $probe.device.interface
        tbs_interface_type = $probe.device.interface_type
    }

    $stage = 'create_platform_key'
    $provider = New-Object Security.Cryptography.CngProvider($providerName)
    $creation = New-Object Security.Cryptography.CngKeyCreationParameters
    $creation.Provider = $provider
    $creation.KeyUsage = [Security.Cryptography.CngKeyUsages]::Signing
    $creation.ExportPolicy = [Security.Cryptography.CngExportPolicies]::None
    $creation.Parameters.Add((New-Object Security.Cryptography.CngProperty(
        'Length',
        [BitConverter]::GetBytes([int]2048),
        [Security.Cryptography.CngPropertyOptions]::None
    )))
    $key = [Security.Cryptography.CngKey]::Create(
        [Security.Cryptography.CngAlgorithm]::Rsa,
        $keyName,
        $creation
    )
    $keyCreated = $true
    $signer = New-Object Security.Cryptography.RSACng($key)
    $publicParameters = $signer.ExportParameters($false)
    $verifier = [Security.Cryptography.RSA]::Create()
    $verifier.ImportParameters($publicParameters)
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()

    $stage = 'benchmark_platform_key'
    $signSamples = New-Object 'System.Collections.Generic.List[double]'
    for ($i = 0; $i -lt $KeyIterations; $i++) {
        [byte[]]$challenge = New-Object byte[] 32
        $rng.GetBytes($challenge)
        $watch = [Diagnostics.Stopwatch]::StartNew()
        [byte[]]$sig = $signer.SignData(
            $challenge,
            [Security.Cryptography.HashAlgorithmName]::SHA256,
            [Security.Cryptography.RSASignaturePadding]::Pkcs1
        )
        $watch.Stop()
        if (-not $verifier.VerifyData(
            $challenge,
            $sig,
            [Security.Cryptography.HashAlgorithmName]::SHA256,
            [Security.Cryptography.RSASignaturePadding]::Pkcs1
        )) { throw 'A TPM-backed signature did not verify.' }
        $signSamples.Add($watch.Elapsed.TotalMilliseconds)
        [Array]::Clear($challenge, 0, $challenge.Length)
        [Array]::Clear($sig, 0, $sig.Length)
    }
    $genericBlocked = Test-PrivateExportBlocked -Format ([Security.Cryptography.CngKeyBlobFormat]::GenericPrivateBlob)
    $pkcs8Blocked = Test-PrivateExportBlocked -Format ([Security.Cryptography.CngKeyBlobFormat]::Pkcs8PrivateBlob)
    $exportObserved = if ($genericBlocked -and $pkcs8Blocked) { 'blocked' } else { 'exported' }
    Add-Case -Name 'private_key_export' -Expected 'blocked' `
        -Observed $exportObserved `
        -Evidence ([ordered]@{ generic_private_blocked = $genericBlocked; pkcs8_private_blocked = $pkcs8Blocked })

    $result.key = [ordered]@{
        provider = $providerName
        algorithm = 'RSA-2048/SHA-256/PKCS1-v1_5'
        export_policy = $key.ExportPolicy.ToString()
        sign_latency_ms = Get-LatencySummary -Samples $signSamples.ToArray()
    }

    $stage = 'define_nv_counter'
    $defined = Invoke-Nv -Arguments @('define', '--handle', $Handle)
    if (-not $defined.created) { throw 'The NV helper did not create a fresh index.' }
    $nvCreated = $true

    $stage = 'baseline_state'
    $initial = Invoke-Nv -Arguments @('increment', '--handle', $Handle)
    $blob1 = New-SignedBlob -Counter ([UInt64]$initial.after) -Epoch 1 -Label 'baseline'
    Write-DurableBlob -Path $activePath -Blob $blob1
    Copy-Item -LiteralPath $activePath -Destination $state1Path
    $live = Test-LiveState -Path $activePath
    Add-Case -Name 'baseline_signed_state' -Expected 'accept' -Observed $live.decision -Evidence $live

    $stage = 'crash_injection'
    $crashIncrement = Invoke-Nv -Arguments @('increment', '--handle', $Handle)
    $live = Test-LiveState -Path $activePath
    Add-Case -Name 'post_increment_process_crash' -Expected 'reject' -Observed $live.decision -Evidence $live

    # Explicit test reset/re-enrollment after the fail-closed case.  This is not
    # transactional recovery and is not reported as such.
    $blob2 = New-SignedBlob -Counter ([UInt64]$crashIncrement.after) -Epoch 2 -Label 'test-reset'
    Write-DurableBlob -Path $activePath -Blob $blob2
    Copy-Item -LiteralPath $activePath -Destination $state2Path

    $stage = 'normal_commit'
    $normalIncrement = Invoke-Nv -Arguments @('increment', '--handle', $Handle)
    $blob3 = New-SignedBlob -Counter ([UInt64]$normalIncrement.after) -Epoch 3 -Label 'normal-commit'
    Write-DurableBlob -Path $activePath -Blob $blob3
    Copy-Item -LiteralPath $activePath -Destination $state3Path
    $live = Test-LiveState -Path $activePath
    Add-Case -Name 'normal_increment_and_reseal' -Expected 'accept' -Observed $live.decision -Evidence $live

    $stage = 'rollback_injection'
    Copy-Item -LiteralPath $state2Path -Destination $activePath -Force
    $live = Test-LiveState -Path $activePath
    Add-Case -Name 'signed_stale_blob_restore' -Expected 'reject' -Observed $live.decision -Evidence $live
    Copy-Item -LiteralPath $state3Path -Destination $activePath -Force

    $stage = 'fresh_process_reopen'
    [byte[]]$freshChallenge = New-Object byte[] 32
    $rng.GetBytes($freshChallenge)
    $childText = (& $powershellExe -NoLogo -NoProfile -NonInteractive `
        -ExecutionPolicy Bypass -File $childScript -KeyName $keyName `
        -ChallengeBase64 ([Convert]::ToBase64String($freshChallenge)) 2>&1 |
        ForEach-Object { $_.ToString() }) -join "`n"
    if ($LASTEXITCODE -ne 0) { throw 'Fresh-process key reopen failed.' }
    $child = $childText | ConvertFrom-Json
    [byte[]]$childSignature = [Convert]::FromBase64String([string]$child.signature_base64)
    $parentVerified = $verifier.VerifyData(
        $freshChallenge,
        $childSignature,
        [Security.Cryptography.HashAlgorithmName]::SHA256,
        [Security.Cryptography.RSASignaturePadding]::Pkcs1
    )
    $freshRead = Invoke-Nv -Arguments @('read', '--handle', $Handle)
    $live = Test-LiveState -Path $activePath
    $freshObserved = if (
        $child.status -eq 'pass' -and
        $parentVerified -and
        [UInt64]$freshRead.value -eq [UInt64]$normalIncrement.after -and
        $live.decision -eq 'accept'
    ) { 'accept' } else { 'reject' }
    Add-Case -Name 'fresh_process_key_and_counter_reopen' -Expected 'accept' -Observed $freshObserved `
        -Evidence ([ordered]@{
            key_reopened = ($child.status -eq 'pass')
            child_signature_verified = [bool]$parentVerified
            nv_counter = [UInt64]$freshRead.value
            state_decision = $live.decision
            key_open_ms = [double]$child.open_latency_ms
            key_sign_ms = [double]$child.sign_latency_ms
        })
    [Array]::Clear($freshChallenge, 0, $freshChallenge.Length)
    [Array]::Clear($childSignature, 0, $childSignature.Length)

    $stage = 'benchmark_nv_counter'
    $bench = Invoke-Nv -Arguments @('bench', '--handle', $Handle, '--iterations', [string]$NvIterations)
    $finalBlob = New-SignedBlob -Counter ([UInt64]$bench.after) -Epoch ([UInt32](3 + $NvIterations)) -Label 'post-benchmark-reseal'
    Write-DurableBlob -Path $activePath -Blob $finalBlob
    $finalLive = Test-LiveState -Path $activePath
    if ($finalLive.decision -ne 'accept') { throw 'Final benchmark reseal did not validate.' }
    $result.nv = [ordered]@{
        attributes = 'OWNERREAD|OWNERWRITE|COUNTER; non-orderly; 8 bytes'
        initial_increment_ms = [double]$initial.increment_ms
        crash_increment_ms = [double]$crashIncrement.increment_ms
        normal_increment_ms = [double]$normalIncrement.increment_ms
        bench_iterations = [int]$bench.iterations
        bench_before = [UInt64]$bench.before
        bench_after = [UInt64]$bench.after
        increment_median_ms = [double]$bench.median_ms
        increment_p95_ms = [double]$bench.p95_ms
        increment_samples_ms = @($bench.samples_ms | ForEach-Object { [double]$_ })
        final_reseal_decision = $finalLive.decision
    }

    $functionalSuccess = (@($cases | Where-Object { -not $_.pass }).Count -eq 0)
}
catch {
    $result.error = [ordered]@{
        stage = $stage
        exception_type = $_.Exception.GetType().FullName
        message = $_.Exception.Message
        hresult = ('0x{0}' -f $_.Exception.HResult.ToString('X8'))
    }
}
finally {
    if ($nvCreated) {
        $cleanup.nv_undefine_attempted = $true
        try {
            $removed = Invoke-Nv -Arguments @('undefine', '--handle', $Handle)
            $cleanup.nv_undefined = [bool]$removed.removed
        }
        catch {
            $cleanup.error = 'NV cleanup failed; the exact handle is retained in the result.'
        }
    }
    foreach ($disposable in @($rng, $verifier, $signer, $key)) {
        if ($null -ne $disposable) {
            try { $disposable.Dispose() } catch { }
        }
    }
    if ($keyCreated) {
        $cleanup.key_delete_attempted = $true
        try {
            $provider = New-Object Security.Cryptography.CngProvider($providerName)
            if ([Security.Cryptography.CngKey]::Exists($keyName, $provider, [Security.Cryptography.CngKeyOpenOptions]::None)) {
                $cleanupKey = [Security.Cryptography.CngKey]::Open($keyName, $provider, [Security.Cryptography.CngKeyOpenOptions]::None)
                $cleanupKey.Delete()
                $cleanupKey.Dispose()
            }
            $cleanup.key_deleted = -not [Security.Cryptography.CngKey]::Exists($keyName, $provider, [Security.Cryptography.CngKeyOpenOptions]::None)
        }
        catch {
            $cleanup.error = if ($cleanup.error) { $cleanup.error + ' Key cleanup failed.' } else { 'Key cleanup failed.' }
        }
    }
}

$result.cases = $cases.ToArray()
$result.cases_total = $cases.Count
$passedCount = 0
foreach ($caseResult in $cases) {
    if ($caseResult.pass) { $passedCount++ }
}
$result.cases_passed = $passedCount
if ($functionalSuccess -and $cleanup.nv_undefined -and $cleanup.key_deleted -and -not $cleanup.error) {
    $result.status = 'pass'
}
$runJson = $result | ConvertTo-Json -Depth 12
$runPath = Join-Path $runDir 'run.json'
[IO.File]::WriteAllText($runPath, $runJson, (New-Object Text.UTF8Encoding($false)))
[IO.File]::WriteAllText((Join-Path $resultRoot 'latest.json'), $runJson, (New-Object Text.UTF8Encoding($false)))
$result | ConvertTo-Json -Depth 12 -Compress
if ($result.status -ne 'pass') { exit 1 }
