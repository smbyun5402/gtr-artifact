[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$KeyName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$ChallengeBase64
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-SafeErrorRecord {
    param(
        [Parameter(Mandatory = $true)]
        [System.Exception]$Exception,

        [Parameter(Mandatory = $true)]
        [string]$Stage
    )

    return [ordered]@{
        stage          = $Stage
        exception_type = $Exception.GetType().FullName
        hresult        = ('0x{0}' -f $Exception.HResult.ToString('X8'))
    }
}

$provider = New-Object System.Security.Cryptography.CngProvider(
    'Microsoft Platform Crypto Provider'
)
$key = $null
$signer = $null
$verifier = $null
$stage = 'decode_challenge'
$exitCode = 1

$result = [ordered]@{
    schema_version    = 'qartz.windows-tpm-key-child.v1'
    status            = 'error'
    open_latency_ms   = $null
    sign_latency_ms   = $null
    self_verified     = $false
    signature_base64  = $null
    error             = $null
}

try {
    $challenge = [Convert]::FromBase64String($ChallengeBase64)
    if ($challenge.Length -eq 0) {
        throw New-Object System.ArgumentException('The challenge must not be empty.')
    }

    $stage = 'open_key'
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $key = [System.Security.Cryptography.CngKey]::Open(
        $KeyName,
        $provider,
        [System.Security.Cryptography.CngKeyOpenOptions]::None
    )
    $stopwatch.Stop()
    $result.open_latency_ms = [Math]::Round(
        $stopwatch.Elapsed.TotalMilliseconds,
        3,
        [MidpointRounding]::AwayFromZero
    )

    $stage = 'prepare_public_verifier'
    $signer = New-Object System.Security.Cryptography.RSACng($key)
    $publicParameters = $signer.ExportParameters($false)
    $verifier = [System.Security.Cryptography.RSA]::Create()
    $verifier.ImportParameters($publicParameters)

    $stage = 'sign'
    $stopwatch.Restart()
    $signature = $signer.SignData(
        $challenge,
        [System.Security.Cryptography.HashAlgorithmName]::SHA256,
        [System.Security.Cryptography.RSASignaturePadding]::Pkcs1
    )
    $stopwatch.Stop()
    $result.sign_latency_ms = [Math]::Round(
        $stopwatch.Elapsed.TotalMilliseconds,
        3,
        [MidpointRounding]::AwayFromZero
    )

    $stage = 'verify'
    $result.self_verified = $verifier.VerifyData(
        $challenge,
        $signature,
        [System.Security.Cryptography.HashAlgorithmName]::SHA256,
        [System.Security.Cryptography.RSASignaturePadding]::Pkcs1
    )
    if (-not $result.self_verified) {
        throw New-Object System.Security.Cryptography.CryptographicException(
            'Signature verification failed.'
        )
    }

    # The signature is public protocol output, not key material.  The parent uses
    # it once to verify that this fresh process reopened the same persisted key.
    $result.signature_base64 = [Convert]::ToBase64String($signature)
    $result.status = 'pass'
    $exitCode = 0
}
catch {
    $result.error = Get-SafeErrorRecord -Exception $_.Exception -Stage $stage
}
finally {
    if ($null -ne $verifier) {
        try {
            $verifier.Dispose()
        }
        catch {
            if ($null -eq $result.error) {
                $result.error = Get-SafeErrorRecord `
                    -Exception $_.Exception `
                    -Stage 'dispose_verifier'
            }
            $result.status = 'error'
            $exitCode = 1
        }
    }
    if ($null -ne $signer) {
        try {
            $signer.Dispose()
        }
        catch {
            if ($null -eq $result.error) {
                $result.error = Get-SafeErrorRecord `
                    -Exception $_.Exception `
                    -Stage 'dispose_signer'
            }
            $result.status = 'error'
            $exitCode = 1
        }
    }
    if ($null -ne $key) {
        try {
            $key.Dispose()
        }
        catch {
            if ($null -eq $result.error) {
                $result.error = Get-SafeErrorRecord `
                    -Exception $_.Exception `
                    -Stage 'dispose_key'
            }
            $result.status = 'error'
            $exitCode = 1
        }
    }
}

$result | ConvertTo-Json -Depth 5 -Compress
exit $exitCode
