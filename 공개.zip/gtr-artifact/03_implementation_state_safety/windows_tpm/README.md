# Windows hardware-TPM state experiment

This harness validates the endpoint-local persistence mechanism used by the
Q-ARTZ-Reauth artifact. It uses only the Windows Platform Crypto Provider and
TPM Base Services (TBS); it does not initialize, clear, reprovision, or take
ownership of the TPM.

## Components

- `tpm_nv.cpp`: minimal TPM 2.0 NV-counter client over TBS.
- `build.ps1`: x64 MSVC/Windows SDK build.
- `Invoke-ReauthTpmStateExperiment.ps1`: signed-state rollback and process-crash
  experiment.
- `Invoke-PlatformKeyExperiment.ps1`: standalone TPM-backed key experiment.
- `Write-ReauthTpmMacros.ps1`: derives paper macros from the latest passing run.

## Safety boundary

Mutating NV operations are restricted to `0x01510000-0x0151ffff`. Before an
increment, benchmark, or undefine operation, the helper requires an exact public
area match: SHA-256 marker, `OWNERREAD|OWNERWRITE|COUNTER`, non-orderly storage,
and an 8-byte data size. Storage-owner authorization is obtained inside the
elevated process through `Tbsi_Get_OwnerAuth`, never printed or written, and
zeroed after use. Benchmarks are capped at 20 increments.

## Reproduction

Run from the repository root in an elevated Windows PowerShell process:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File .\testbed\windows_tpm\build.ps1

powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File .\testbed\windows_tpm\Invoke-ReauthTpmStateExperiment.ps1 `
  -KeyIterations 30 -NvIterations 10 -Handle 0x01510000

powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File .\testbed\windows_tpm\Write-ReauthTpmMacros.ps1
```

The experiment writes raw results to
`testbed/results_raw/tpm_hardware/latest.json` and a timestamped run directory.
Success requires all cases and both object-specific cleanup checks to pass.

The experiment covers a fresh process, not a host reboot or power interruption.
It demonstrates provider-level private-key export blocking, not key attestation
or resistance to invasive physical extraction. The injected crash is the
fail-closed state produced after an NV increment and before blob resealing;
transactional repair remains outside the evaluated mechanism.
