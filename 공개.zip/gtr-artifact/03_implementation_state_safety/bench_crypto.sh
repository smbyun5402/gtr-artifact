#!/bin/sh
# Signature verify cost for the waiver guard: Ed25519 vs ML-DSA-65.
# openssl speed gives ops/s; we also time single verifies of a real token.
set -e
cd /qartz/certs
OUT=/qartz/results/crypto.txt
mkdir -p /qartz/results

echo "== openssl version" > "$OUT"
openssl version >> "$OUT"

echo "== openssl speed (2s each)" >> "$OUT"
for alg in ed25519 ecdsap256 ml-dsa-65 mldsa65 ml-kem-768 mlkem768; do
    openssl speed -seconds 2 "$alg" 2>/dev/null | tail -3 >> "$OUT" || true
done

# realistic waiver token: ~300 B of state-bound fields
head -c 300 /dev/urandom > token.bin
for alg in ed25519 mldsa; do
    key="waiver_${alg}.pem"; pub="waiver_${alg}_pub.pem"
    openssl pkeyutl -sign -inkey "$key" -in token.bin -rawin \
        -out "sig_${alg}.bin" 2>/dev/null || \
    openssl pkeyutl -sign -inkey "$key" -in token.bin \
        -out "sig_${alg}.bin" 2>/dev/null
done
python3 - <<'EOF' >> "$OUT"
import subprocess, time
for alg in ("ed25519", "mldsa"):
    pub, sig = f"waiver_{alg}_pub.pem", f"sig_{alg}.bin"
    # warm up
    cmd = ["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", pub,
           "-in", "token.bin", "-rawin", "-sigfile", sig]
    r = subprocess.run(cmd, capture_output=True)
    if r.returncode != 0:
        cmd = [c for c in cmd if c != "-rawin"]
        subprocess.run(cmd, capture_output=True)
    N = 200
    t0 = time.perf_counter()
    for _ in range(N):
        subprocess.run(cmd, capture_output=True)
    dt = (time.perf_counter() - t0) / N * 1e3
    print(f"single-verify-incl-process {alg}: {dt:.2f} ms")
EOF
cat "$OUT"
