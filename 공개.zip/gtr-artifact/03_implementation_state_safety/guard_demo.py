#!/usr/bin/env python3
# End-to-end anti-downgrade guard on real cryptography:
#   - tokens signed with ML-DSA-65 via OpenSSL 3.5 (real signatures)
#   - file-backed monotonic counter with fsync (survives process restart)
#   - guard checks: signature, expiry, counter equation, state digest
# Case sequence includes a process restart to demonstrate rollback
# protection across "reboot". Run inside the qartz-testbed container.
import subprocess, json, hashlib, os, sys, time

CERTS = "/qartz/certs"
CTR_FILE = "/tmp/guard_ctr"
STATE = {"mode": "HYBRID", "rc": 1, "secEpoch": 3, "keyEpoch": 5}


def digest(state):
    return hashlib.sha256(json.dumps(state, sort_keys=True).encode()).hexdigest()


def read_ctr():
    try:
        return int(open(CTR_FILE).read())
    except FileNotFoundError:
        return 0


def write_ctr(v):
    with open(CTR_FILE, "w") as f:
        f.write(str(v))
        f.flush()
        os.fsync(f.fileno())


def sign(payload: bytes, key=f"{CERTS}/waiver_mldsa.pem") -> bytes:
    open("/tmp/tok.bin", "wb").write(payload)
    subprocess.run(["openssl", "pkeyutl", "-sign", "-inkey", key, "-rawin",
                    "-in", "/tmp/tok.bin", "-out", "/tmp/tok.sig"],
                   check=True, capture_output=True)
    return open("/tmp/tok.sig", "rb").read()


def verify(payload: bytes, sig: bytes,
           pub=f"{CERTS}/waiver_mldsa_pub.pem") -> bool:
    open("/tmp/v.bin", "wb").write(payload)
    open("/tmp/v.sig", "wb").write(sig)
    r = subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin",
                        "-inkey", pub, "-rawin", "-in", "/tmp/v.bin",
                        "-sigfile", "/tmp/v.sig"], capture_output=True)
    return r.returncode == 0


def pa_issue(to_ctr, exp, state=STATE):
    tok = dict(digest=digest(state), to_ctr=to_ctr, exp=exp, sid="s1",
               peer="n2")
    payload = json.dumps(tok, sort_keys=True).encode()
    return payload, sign(payload)


def guard(payload, sig, now):
    t0 = time.perf_counter()
    if not verify(payload, sig):
        return False, "signature", (time.perf_counter() - t0) * 1e3
    tok = json.loads(payload)
    ms = (time.perf_counter() - t0) * 1e3
    if tok["exp"] < now:
        return False, "expiry", ms
    if tok["to_ctr"] != read_ctr() + 1:
        return False, "counter", ms
    if tok["digest"] != digest(STATE):
        return False, "digest", ms
    write_ctr(tok["to_ctr"])                    # single-use: consume
    return True, "accepted", ms


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "replay-after-restart":
        # fresh process: only the persisted counter file survives
        payload = open("/tmp/replay.bin", "rb").read()
        sig = open("/tmp/replay.sig", "rb").read()
        ok, why, ms = guard(payload, sig, now=100)
        print(f"restart-replay: {'ACCEPT' if ok else 'REJECT'} ({why}) "
              f"{ms:.1f}ms ctr={read_ctr()}")
        return

    write_ctr(0)
    results = []

    def case(name, payload, sig, now=100):
        ok, why, ms = guard(payload, sig, now)
        results.append((name, ok, why, ms))
        print(f"{name:22s} {'ACCEPT' if ok else 'REJECT':6s} "
              f"({why}) {ms:.1f}ms ctr={read_ctr()}")

    p1, s1 = pa_issue(to_ctr=1, exp=400)
    open("/tmp/replay.bin", "wb").write(p1)
    open("/tmp/replay.sig", "wb").write(s1)
    case("valid#1", p1, s1)                       # accept, ctr 0->1
    case("replay(valid#1)", p1, s1)               # reject: counter
    p, s = pa_issue(to_ctr=1, exp=400)
    case("rollback(to_ctr=1)", p, s)              # reject: counter
    p, s = pa_issue(to_ctr=2, exp=400)
    case("forged(bitflip)", p, bytes([s[0] ^ 1]) + s[1:])   # reject: signature
    p, s = pa_issue(to_ctr=2, exp=50)
    case("expired", p, s)                         # reject: expiry
    other = dict(STATE, secEpoch=99)
    p, s = pa_issue(to_ctr=2, exp=400, state=other)
    case("wrong-state-digest", p, s)              # reject: digest
    p2, s2 = pa_issue(to_ctr=2, exp=400)
    case("valid#2", p2, s2)                       # accept, ctr 1->2

    ok_all = all((n.startswith("valid")) == acc for n, acc, _, _ in results)
    print(f"in-process cases correct: {ok_all} ({len(results)} cases)")


if __name__ == "__main__":
    main()
