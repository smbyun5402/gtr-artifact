#!/bin/zsh
# Q-ARTZ-Resync latency bench harness (design §4). Two containers on qartz-net
# with NET_ADMIN; tc/netem applied symmetrically (run_all.sh helper pattern);
# 30 reps x {clean,disrupted,heavy} x {resume,deltapatch}. Client writes
# per-rep CSVs into results_raw/ via bind mount. All containers/network are
# torn down on exit (also on failure). Uses the existing qartz-testbed image
# (no rebuild; scripts enter via read-only bind mounts).
set -e
cd "$(dirname "$0")"
mkdir -p results_raw

cleanup() {
    docker rm -f rs-server rs-client >/dev/null 2>&1 || true
    docker network rm qartz-net >/dev/null 2>&1 || true
}
trap cleanup EXIT
cleanup

docker network create qartz-net >/dev/null

echo "== start resync bench server + client containers"
docker run -d --name rs-server --network qartz-net --cap-add NET_ADMIN \
    -v "$PWD/resync_bench_server.py:/qartz/resync_bench_server.py:ro" \
    qartz-testbed python3 /qartz/resync_bench_server.py >/dev/null
docker run -d --name rs-client --network qartz-net --cap-add NET_ADMIN \
    -v "$PWD/resync_bench_client.py:/qartz/resync_bench_client.py:ro" \
    -v "$PWD/results_raw:/qartz/results" \
    qartz-testbed sleep infinity >/dev/null
sleep 2

netem() {  # netem <container> <args...>|off   (run_all.sh helper pattern)
    c=$1; shift
    if [ "$1" = "off" ]; then
        docker exec "$c" tc qdisc del dev eth0 root 2>/dev/null || true
    else
        docker exec "$c" tc qdisc replace dev eth0 root netem "$@"
    fi
}

# symmetric netem on both sides; delays are per direction (as in run_all.sh)
typeset -A CONDS
CONDS=(clean "delay 10ms" \
       disrupted "delay 100ms 20ms loss 5%" \
       heavy "delay 200ms 50ms loss 15%")

for cond in clean disrupted heavy; do
    echo "== resync bench: $cond"
    netem rs-client ${=CONDS[$cond]}
    netem rs-server ${=CONDS[$cond]}
    # NB: loop var must not be named `path` (zsh ties $path to $PATH)
    for rpath in resume deltapatch; do
        docker exec rs-client python3 /qartz/resync_bench_client.py \
            rs-server "$cond" "$rpath" 30
    done
done
netem rs-client off
netem rs-server off

echo "done -> results_raw/resync_tls_*.csv"
ls -l results_raw/resync_tls_*.csv
