#!/usr/bin/env python3
"""Exercise GT-R state/adoption logic without requiring an OpenSSL 4 binary.

The production harness still uses real OpenSSL ML-KEM/ML-DSA.  This test swaps
only those external primitive calls for an in-memory ideal KEM/signature model,
so CI on hosts without PQ-enabled OpenSSL can detect state-machine regressions.
"""

import hashlib
import hmac
import importlib.util
import os
import secrets
import tempfile
import unittest


HERE = os.path.dirname(os.path.abspath(__file__))
SPEC = importlib.util.spec_from_file_location(
    "reauth_demo_under_test", os.path.join(HERE, "reauth_demo.py"))
demo = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(demo)


class IdealCrypto:
    def __init__(self, directory):
        self.directory = directory
        self.pk_for_sk = {}
        self.ct = {}

    def keygen(self, tag):
        token = secrets.token_hex(8)
        sk = os.path.join(self.directory, f"{tag}-{token}-sk")
        pk = os.path.join(self.directory, f"{tag}-{token}-pk")
        for path, value in ((sk, b"ideal-secret"), (pk, b"ideal-public")):
            with open(path, "wb") as f:
                f.write(value)
        self.pk_for_sk[sk] = pk
        return sk, pk

    def encap(self, pk):
        ciphertext = secrets.token_bytes(48)
        shared = secrets.token_bytes(32)
        self.ct[ciphertext] = (pk, shared)
        return ciphertext, shared

    def decap(self, sk, ciphertext):
        record = self.ct.get(ciphertext)
        if record is not None and self.pk_for_sk.get(sk) == record[0]:
            return record[1]
        return hashlib.sha256(b"implicit-reject" + sk.encode() + ciphertext).digest()

    def sign(self, sk, message):
        return hmac.new(sk.encode(), message, hashlib.sha256).digest()

    def verify(self, pk, message, signature):
        for sk, candidate_pk in self.pk_for_sk.items():
            if candidate_pk == pk:
                return hmac.compare_digest(self.sign(sk, message), signature)
        return False


class ReauthLogicTests(unittest.TestCase):
    def test_all_state_machine_cases(self):
        with tempfile.TemporaryDirectory(prefix="gtr-logic-") as directory:
            ideal = IdealCrypto(directory)
            demo.WORK = directory
            demo.OUT = os.path.join(directory, "results")
            os.makedirs(demo.OUT, exist_ok=True)
            demo.SEAL_PATH = os.path.join(directory, "rot_seal.json")
            demo.mlkem_keygen = ideal.keygen
            demo.mlkem_encap = ideal.encap
            demo.mlkem_decap = ideal.decap
            demo.mldsa_keygen = ideal.keygen
            demo.mldsa_sign = ideal.sign
            demo.mldsa_verify = ideal.verify
            cases = demo.run_cases()
            failed = [name for name, _, _, good, _ in cases if not good]
            self.assertEqual([], failed)
            self.assertEqual(13, len(cases))


if __name__ == "__main__":
    unittest.main(verbosity=2)
