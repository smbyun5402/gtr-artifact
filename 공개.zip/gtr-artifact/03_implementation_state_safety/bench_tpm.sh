#!/bin/sh
# swtpm TPM 2.0 quote generation + verification timing (attestation evidence).
set -e
OUT=/qartz/results/tpm.txt
mkdir -p /qartz/results

# idempotent: fresh software TPM state on every invocation
pkill -f "swtpm socket" 2>/dev/null || true
sleep 0.5
rm -rf /tmp/tpmstate && mkdir -p /tmp/tpmstate
swtpm socket --tpmstate dir=/tmp/tpmstate --tpm2 \
    --server type=tcp,port=2321 --ctrl type=tcp,port=2322 \
    --flags not-need-init,startup-clear >/dev/null 2>&1 &
sleep 1
export TPM2TOOLS_TCTI="swtpm:port=2321"

# restricted ECC signing key under the owner hierarchy (avoids EK policy)
tpm2_createprimary -C o -c primary.ctx >/dev/null
tpm2_flushcontext -t
tpm2_create -C primary.ctx -G ecc256:ecdsa-sha256:null -u ak.pub -r ak.priv \
    -a "fixedtpm|fixedparent|sensitivedataorigin|userwithauth|restricted|sign" \
    >/dev/null
tpm2_flushcontext -t
tpm2_load -C primary.ctx -u ak.pub -r ak.priv -c ak.ctx >/dev/null
tpm2_flushcontext -t
tpm2_readpublic -c ak.ctx -f pem -o ak_pem.pub >/dev/null

python3 - <<'EOF' > "$OUT"
import subprocess, time, statistics, os
env = dict(os.environ)

def run_tpm(cmd):
    # self-heal transient-slot exhaustion: flush and retry once
    r = subprocess.run(cmd, capture_output=True, env=env)
    if r.returncode:
        subprocess.run(["tpm2_flushcontext", "-t"], capture_output=True, env=env)
        r = subprocess.run(cmd, capture_output=True, env=env)
    if r.returncode:
        raise SystemExit(f"{cmd[0]} failed:\n{r.stderr.decode()[:800]}")
    return r

subprocess.run(["tpm2_flushcontext", "-t"], capture_output=True, env=env)
qt, ver = [], []
for i in range(50):
    nonce = os.urandom(16).hex()
    t0 = time.perf_counter()
    run_tpm(["tpm2_quote", "-c", "ak.ctx", "-l", "sha256:0,1,2",
             "-q", nonce, "-m", "quote.msg", "-s", "quote.sig",
             "-o", "quote.pcr", "-g", "sha256"])
    t1 = time.perf_counter()
    run_tpm(["tpm2_checkquote", "-u", "ak_pem.pub",
             "-m", "quote.msg", "-s", "quote.sig",
             "-f", "quote.pcr", "-g", "sha256", "-q", nonce])
    t2 = time.perf_counter()
    qt.append((t1 - t0) * 1e3)
    ver.append((t2 - t1) * 1e3)
print(f"swtpm quote gen ms: mean {statistics.mean(qt):.1f} "
      f"p95 {sorted(qt)[47]:.1f}")
print(f"quote verify ms: mean {statistics.mean(ver):.1f} "
      f"p95 {sorted(ver)[47]:.1f}")
EOF
cat "$OUT"
