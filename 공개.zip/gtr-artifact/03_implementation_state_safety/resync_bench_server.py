#!/usr/bin/env python3
# Q-ARTZ-Resync bench responder (node j). Real 4-message resync over TCP:
#   M1 <- {sid, nonce_i}    M2 -> {nonce_j, Sigma_j, SST_j(ML-DSA-65)}
#   M3 <- {Sigma_i, SST_i, Bundle?, decision, Commit_i}   M4 -> {decision, Commit_j}
# Real ML-DSA-65 sign/verify via openssl pkeyutl (image-baked
# Distinct responder AK, initiator AK, and PA keys. HKDF-SHA256 + HMAC commit
# run over the real ctxDigest; the responder durably records HALF-OPEN before
# emitting M4.
# Loss robustness: TCP provides app-layer reliability (retransmission); we
# measure wall time, so netem loss shows up as latency, not failure.
# Framing: 4-byte big-endian length prefix, canonical-JSON body. TCP_NODELAY.
# usage: resync_bench_server.py [port]   (default 7443)
import socket, json, hashlib, hmac, subprocess, os, sys, base64, secrets

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 7443
CERTS = "/qartz/certs"
KEY = f"{CERTS}/node_j_mldsa.pem"
PUB_I = f"{CERTS}/node_i_mldsa_pub.pem"
PA_PUB = f"{CERTS}/waiver_mldsa_pub.pem"
SESSION_SECRET_FILE = f"{CERTS}/resync_session_secret.bin"
TMP = f"/tmp/rsb_{os.getpid()}"


def cj(o): return json.dumps(o, sort_keys=True, separators=(",", ":")).encode()
def H(b): return hashlib.sha256(b).hexdigest()
def b64(b): return base64.b64encode(b).decode()
def ub64(s): return base64.b64decode(s)


def sign(payload: bytes) -> bytes:
    open(TMP + ".bin", "wb").write(payload)
    subprocess.run(["openssl", "pkeyutl", "-sign", "-inkey", KEY, "-rawin",
                    "-in", TMP + ".bin", "-out", TMP + ".sig"],
                   check=True, capture_output=True)
    return open(TMP + ".sig", "rb").read()


def verify(payload: bytes, sig: bytes, pub: str) -> bool:
    open(TMP + ".vbin", "wb").write(payload)
    open(TMP + ".vsig", "wb").write(sig)
    r = subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", pub,
                        "-rawin", "-in", TMP + ".vbin", "-sigfile", TMP + ".vsig"],
                       capture_output=True)
    return r.returncode == 0


def hkdf(ikm, info, salt=b"", length=32):
    prk = hmac.new(salt if salt else b"\x00" * 32, ikm, hashlib.sha256).digest()
    okm, t, i = b"", b"", 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        okm += t
        i += 1
    return okm[:length]


CORE_FIELDS = ("sid", "mode", "reqClass", "secEpoch", "keyEpoch", "polEpoch",
               "policyHash", "manifestDigest")


def core_digest(S): return H(cj({k: S[k] for k in CORE_FIELDS}))
def state_digest(S): return H(cj(S))


def base_sigma(sid):   # deterministic in sid: client and server agree cold
    return {"sid": sid, "mode": "HYBRID", "reqClass": 1, "secEpoch": 3,
            "keyEpoch": 5, "polEpoch": 3, "attEpoch": 7, "transCtr": 0,
            "seqNo": 42, "chainDigest": H(b"chain|" + sid.encode()),
            "manifestDigest": H(b"manifest-v1"), "EARdigest": H(b"ear-7"),
            "policyHash": H(b"policy-v3")}


def session_secret(_sid):
    return open(SESSION_SECRET_FILE, "rb").read()


def make_sst(sigma, nonce_peer, nonce_own, role):
    pay = cj({"obj": "SST", "stateDigest": state_digest(sigma),
              "transCtr": sigma["transCtr"], "attEpoch": sigma["attEpoch"],
              "seqNo": sigma["seqNo"], "chainDigest": sigma["chainDigest"],
              "noncePeer": nonce_peer, "nonceOwn": nonce_own,
              "sid": sigma["sid"], "role": role, "akId": f"AK-{role}"})
    return {"payload": pay.decode(), "sig": b64(sign(pay))}


def persist_phase(sid, phase, sigma, ctx, commit):
    """Atomic file-backed analogue of the RoT commit record."""
    path = f"/tmp/rsb_state_{hashlib.sha256(sid.encode()).hexdigest()}"
    tmp = path + ".tmp"
    data = cj({"sid": sid, "phase": phase, "sigma": sigma,
               "ctxDigest": ctx, "commit": commit,
               "oldTicketInvalid": True})
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def apply_delta(sigma, dd):
    S = dict(sigma)
    S["polEpoch"] = dd["toPolEpoch"]
    S["policyHash"] = dd["toPolicyHash"]
    S["reqClass"] = dd["toReqClass"]
    return S


def ctx_digest(nonce_i, nonce_j, sst_i, sst_j, bundle, decision, state_p):
    def hobj(o):
        return H(cj(o)) if o else H(b"")
    return H(cj({"peerI": "node-i", "peerJ": "node-j",
                 "nonceI": nonce_i, "nonceJ": nonce_j,
                 "hSstI": hobj(sst_i), "hSstJ": hobj(sst_j),
                 "hEarI": H(b""), "hEarJ": H(b""),
                 "hProofI": H(b""), "hProofJ": H(b""),
                 "hWt": hobj(bundle.get("waiver") if bundle else None),
                 "hDelta": hobj(bundle.get("delta") if bundle else None),
                 "hKeyUpd": H(b""), "decision": decision,
                 "deltaSigma": {}, "stateDigestPrime": state_p}))


def commit_mac(kres, label, state_p, ticket_p, ctx):
    msg = label.encode() + b"|" + state_p.encode() + b"|" + ticket_p.encode() + b"|" + ctx.encode()
    return hmac.new(kres, msg, hashlib.sha256).hexdigest()


def recvn(c, n):
    buf = b""
    while len(buf) < n:
        chunk = c.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("peer closed")
        buf += chunk
    return buf


def recv_msg(c):
    return json.loads(recvn(c, int.from_bytes(recvn(c, 4), "big")))


def send_msg(c, o):
    d = cj(o)
    c.sendall(len(d).to_bytes(4, "big") + d)


def handle(c):
    m1 = recv_msg(c)
    sid, nonce_i = m1["sid"], m1["nonceI"]
    sigma = base_sigma(sid)
    nonce_j = secrets.token_hex(16)
    sst_j = make_sst(sigma, nonce_i, nonce_j, "resp")
    send_msg(c, {"nonceJ": nonce_j, "sigmaJ": sigma, "sstJ": sst_j})
    m3 = recv_msg(c)

    def rej(why):
        send_msg(c, {"error": why})

    sst = m3["sstI"]
    pay = sst["payload"].encode()
    if not verify(pay, ub64(sst["sig"]), PUB_I):
        return rej("signature")
    tok = json.loads(pay)
    sigma_i = m3["sigmaI"]
    if not (tok["noncePeer"] == nonce_j and tok["nonceOwn"] == nonce_i
            and tok["role"] == "init" and tok["sid"] == sid
            and tok["transCtr"] == sigma_i["transCtr"]):
        return rej("nonce")
    if tok["stateDigest"] != state_digest(sigma_i):
        return rej("state-digest")
    bundle = m3.get("bundle")
    sigma_p = dict(sigma)
    if bundle:
        d = bundle["delta"]
        if not verify(d["payload"].encode(), ub64(d["sig"]), PA_PUB):
            return rej("delta-sig")
        dd = json.loads(d["payload"])
        w = bundle["waiver"]
        if not verify(w["payload"].encode(), ub64(w["sig"]), PA_PUB):
            return rej("waiver-sig")
        ww = json.loads(w["payload"])
        if ww["toTransCtr"] != 1 or ww["coreDigest"] != core_digest(sigma):
            return rej("waiver")
        if dd["fromCoreDigest"] != core_digest(sigma) \
                or dd["fromPolEpoch"] != sigma["polEpoch"]:
            return rej("base-digest")
        sigma_p = apply_delta(sigma, dd)
    decision = "DeltaPatch" if bundle else "Resume"
    if decision != m3["decision"]:
        return rej("decision-mismatch")
    sigma_p["transCtr"] = 1
    state_p = state_digest(sigma_p)
    ctx = ctx_digest(nonce_i, nonce_j, sst, sst_j, bundle, decision, state_p)
    kr = hkdf(session_secret(sid),
              info=b"resume|" + sid.encode() + b"|" + ctx.encode(),
              salt=b"qartz-resync")
    tk = H(cj(sigma_p) + b"|ttl600")
    if not hmac.compare_digest(
            commit_mac(kr, "commit_i", state_p, tk, ctx), m3["commitI"]):
        return rej("commit-mac")
    commit_j = commit_mac(kr, "commit_j", state_p, tk, ctx)
    persist_phase(sid, "half-open", sigma_p, ctx, commit_j)
    send_msg(c, {"decision": decision, "commitJ": commit_j})


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", PORT))
    srv.listen(16)
    print(f"resync bench server ready on :{PORT}", flush=True)
    while True:
        c, _ = srv.accept()
        try:
            c.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            c.settimeout(120)
            handle(c)
        except Exception as e:
            print(f"conn error: {e}", flush=True)
        finally:
            c.close()


if __name__ == "__main__":
    main()
