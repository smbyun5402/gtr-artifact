#!/usr/bin/env python3
# Q-ARTZ-Resync bench initiator (node i). Runs N reps of the real 4-message
# resync against resync_bench_server.py and writes per-rep wall times to
# /qartz/results/resync_tls_<cond>_<path>.csv.
#   path=resume     : SST exchange + commit only (no bundle)
#   path=deltapatch : adds PA-signed PolicyDelta + waiver verification
# Timed window per rep: TCP connect -> M1..M4 -> Commit_j verified (comparable
# to the TLS-handshake anchor, which also includes TCP setup + process spawn:
# each ML-DSA op here spawns one openssl process, same convention).
# PA object issuance (delta/waiver signing) happens BEFORE the timed window —
# PA signing is provisioning-side work, not reconnect latency.
# Loss robustness: TCP retransmission carries the flight through netem loss;
# app-level retry (fresh connection, up to 3 attempts) covers hard failures.
# usage: resync_bench_client.py <server> <cond> <path> [N] [port]
import socket, json, hashlib, hmac, subprocess, os, sys, time, base64, secrets, csv, math

SERVER = sys.argv[1]
COND = sys.argv[2]
PATH = sys.argv[3]
N = int(sys.argv[4]) if len(sys.argv) > 4 else 30
PORT = int(sys.argv[5]) if len(sys.argv) > 5 else 7443
CERTS = "/qartz/certs"
KEY = f"{CERTS}/node_i_mldsa.pem"
PUB_J = f"{CERTS}/node_j_mldsa_pub.pem"
PA_KEY = f"{CERTS}/waiver_mldsa.pem"
SESSION_SECRET_FILE = f"{CERTS}/resync_session_secret.bin"
TMP = f"/tmp/rsc_{os.getpid()}"


def cj(o): return json.dumps(o, sort_keys=True, separators=(",", ":")).encode()
def H(b): return hashlib.sha256(b).hexdigest()
def b64(b): return base64.b64encode(b).decode()
def ub64(s): return base64.b64decode(s)


def sign(payload: bytes, key: str = KEY) -> bytes:
    open(TMP + ".bin", "wb").write(payload)
    subprocess.run(["openssl", "pkeyutl", "-sign", "-inkey", key, "-rawin",
                    "-in", TMP + ".bin", "-out", TMP + ".sig"],
                   check=True, capture_output=True)
    return open(TMP + ".sig", "rb").read()


def verify(payload: bytes, sig: bytes, pub: str = PUB_J) -> bool:
    open(TMP + ".vbin", "wb").write(payload)
    open(TMP + ".vsig", "wb").write(sig)
    r = subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", pub,
                        "-rawin", "-in", TMP + ".vbin", "-sigfile", TMP + ".vsig"],
                       capture_output=True)
    return r.returncode == 0


def hkdf(ikm, info, salt=b"", length=32):
    prk = hmac.new(salt if salt else b"\x00" * 32, ikm, hashlib.sha256).digest()
    okm, t, i = b"", b"", 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        okm += t
        i += 1
    return okm[:length]


CORE_FIELDS = ("sid", "mode", "reqClass", "secEpoch", "keyEpoch", "polEpoch",
               "policyHash", "manifestDigest")


def core_digest(S): return H(cj({k: S[k] for k in CORE_FIELDS}))
def state_digest(S): return H(cj(S))


def base_sigma(sid):
    return {"sid": sid, "mode": "HYBRID", "reqClass": 1, "secEpoch": 3,
            "keyEpoch": 5, "polEpoch": 3, "attEpoch": 7, "transCtr": 0,
            "seqNo": 42, "chainDigest": H(b"chain|" + sid.encode()),
            "manifestDigest": H(b"manifest-v1"), "EARdigest": H(b"ear-7"),
            "policyHash": H(b"policy-v3")}


def session_secret(_sid):
    return open(SESSION_SECRET_FILE, "rb").read()


def make_sst(sigma, nonce_peer, nonce_own, role):
    pay = cj({"obj": "SST", "stateDigest": state_digest(sigma),
              "transCtr": sigma["transCtr"], "attEpoch": sigma["attEpoch"],
              "seqNo": sigma["seqNo"], "chainDigest": sigma["chainDigest"],
              "noncePeer": nonce_peer, "nonceOwn": nonce_own,
              "sid": sigma["sid"], "role": role, "akId": f"AK-{role}"})
    return {"payload": pay.decode(), "sig": b64(sign(pay, KEY))}


def pa_delta(sigma, to_pol, delta_id):
    pay = cj({"obj": "PolicyDelta", "fromCoreDigest": core_digest(sigma),
              "fromPolEpoch": sigma["polEpoch"], "toPolEpoch": to_pol,
              "fromPolicyHash": sigma["policyHash"],
              "toPolicyHash": H(f"policy-v{to_pol}".encode()),
              "fromReqClass": sigma["reqClass"], "toReqClass": sigma["reqClass"],
              "scope": {"domain": "convoy-a", "caps": ["telemetry", "c2"]},
              "deltaID": delta_id, "exp": 10**10, "relaxationBits": 0})
    return {"payload": pay.decode(), "sig": b64(sign(pay, PA_KEY))}


def pa_waiver(sigma, to_ctr):
    pay = cj({"obj": "Waiver", "coreDigest": core_digest(sigma),
              "toTransCtr": to_ctr, "ttlExc": 300,
              "scope": {"domain": "convoy-a", "caps": ["telemetry", "c2"]},
              "capDigest": H(b"caps-telemetry-c2"), "exp": 10**10,
              "nonceW": secrets.token_hex(8)})
    return {"payload": pay.decode(), "sig": b64(sign(pay, PA_KEY))}


def persist_phase(sid, phase, sigma, ctx, commit):
    path = f"/tmp/rsc_state_{hashlib.sha256(sid.encode()).hexdigest()}"
    tmp = path + ".tmp"
    data = cj({"sid": sid, "phase": phase, "sigma": sigma,
               "ctxDigest": ctx, "commit": commit,
               "oldTicketInvalid": True})
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def apply_delta(sigma, dd):
    S = dict(sigma)
    S["polEpoch"] = dd["toPolEpoch"]
    S["policyHash"] = dd["toPolicyHash"]
    S["reqClass"] = dd["toReqClass"]
    return S


def ctx_digest(nonce_i, nonce_j, sst_i, sst_j, bundle, decision, state_p):
    def hobj(o):
        return H(cj(o)) if o else H(b"")
    return H(cj({"peerI": "node-i", "peerJ": "node-j",
                 "nonceI": nonce_i, "nonceJ": nonce_j,
                 "hSstI": hobj(sst_i), "hSstJ": hobj(sst_j),
                 "hEarI": H(b""), "hEarJ": H(b""),
                 "hProofI": H(b""), "hProofJ": H(b""),
                 "hWt": hobj(bundle.get("waiver") if bundle else None),
                 "hDelta": hobj(bundle.get("delta") if bundle else None),
                 "hKeyUpd": H(b""), "decision": decision,
                 "deltaSigma": {}, "stateDigestPrime": state_p}))


def commit_mac(kres, label, state_p, ticket_p, ctx):
    msg = label.encode() + b"|" + state_p.encode() + b"|" + ticket_p.encode() + b"|" + ctx.encode()
    return hmac.new(kres, msg, hashlib.sha256).hexdigest()


def recvn(c, n):
    buf = b""
    while len(buf) < n:
        chunk = c.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("peer closed")
        buf += chunk
    return buf


def recv_msg(c):
    return json.loads(recvn(c, int.from_bytes(recvn(c, 4), "big")))


def send_msg(c, o):
    d = cj(o)
    c.sendall(len(d).to_bytes(4, "big") + d)


def one_rep(sid, sigma, bundle):
    """Timed 4-message resync. Returns wall ms."""
    t0 = time.perf_counter()
    c = socket.create_connection((SERVER, PORT), timeout=60)
    try:
        c.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        nonce_i = secrets.token_hex(16)
        send_msg(c, {"sid": sid, "nonceI": nonce_i, "path": PATH})
        m2 = recv_msg(c)
        nonce_j, sst_j = m2["nonceJ"], m2["sstJ"]
        pj = sst_j["payload"].encode()
        if not verify(pj, ub64(sst_j["sig"]), PUB_J):
            raise RuntimeError("SST_j signature")
        tj = json.loads(pj)
        if not (tj["noncePeer"] == nonce_i and tj["role"] == "resp"
                and tj["sid"] == sid and tj["transCtr"] == 1
                and tj["stateDigest"] == state_digest(sigma)):
            raise RuntimeError("SST_j freshness/state")
        sst_i = make_sst(sigma, nonce_j, nonce_i, "init")
        decision = "DeltaPatch" if bundle else "Resume"
        sigma_p = apply_delta(sigma, json.loads(bundle["delta"]["payload"])) \
            if bundle else dict(sigma)
        sigma_p["transCtr"] = 1
        state_p = state_digest(sigma_p)
        ctx = ctx_digest(nonce_i, nonce_j, sst_i, sst_j, bundle, decision, state_p)
        kr = hkdf(session_secret(sid),
                  info=b"resume|" + sid.encode() + b"|" + ctx.encode(),
                  salt=b"qartz-resync")
        tk = H(cj(sigma_p) + b"|ttl600")
        commit_i = commit_mac(kr, "commit_i", state_p, tk, ctx)
        persist_phase(sid, "candidate", sigma_p, ctx, commit_i)
        send_msg(c, {"sigmaI": sigma, "sstI": sst_i, "bundle": bundle,
                     "decision": decision,
                     "commitI": commit_i})
        m4 = recv_msg(c)
        if "error" in m4:
            raise RuntimeError(f"server rejected: {m4['error']}")
        if not hmac.compare_digest(
                commit_mac(kr, "commit_j", state_p, tk, ctx), m4["commitJ"]):
            raise RuntimeError("Commit_j MAC")
        persist_phase(sid, "open", sigma_p, ctx, m4["commitJ"])
        return (time.perf_counter() - t0) * 1e3
    finally:
        c.close()


def main():
    os.makedirs("/qartz/results", exist_ok=True)
    out = open(f"/qartz/results/resync_tls_{COND}_{PATH}.csv", "w", newline="")
    w = csv.writer(out)
    w.writerow(["condition", "path", "rep", "ok", "attempts", "wall_ms"])
    n_ok, walls = 0, []
    for rep in range(N):
        sid = f"{COND}-{PATH}-{rep}"
        sigma = base_sigma(sid)
        bundle = None
        if PATH == "deltapatch":       # PA issuance outside the timed window
            bundle = {"delta": pa_delta(sigma, 4, f"delta-{rep}"),
                      "waiver": pa_waiver(sigma, 1)}
        ok, wall, attempts = 0, float("nan"), 0
        rep_t0 = time.perf_counter()
        for attempt in range(3):
            attempts = attempt + 1
            try:
                one_rep(sid, sigma, bundle)
                wall = (time.perf_counter() - rep_t0) * 1e3
                ok = 1
                break
            except Exception as e:
                print(f"rep {rep} attempt {attempt}: {e}", flush=True)
                time.sleep(0.5)
        if not ok:
            wall = (time.perf_counter() - rep_t0) * 1e3
        w.writerow([COND, PATH, rep, ok, attempts, f"{wall:.1f}"])
        out.flush()
        if ok:
            n_ok += 1
            walls.append(wall)
    out.close()
    if walls:
        s = sorted(walls)
        print(f"{COND} {PATH} n_ok={n_ok}/{N} "
              f"mean {sum(walls)/len(walls):.1f} ms "
              f"p95 {s[math.ceil(len(s)*0.95)-1]:.1f} ms", flush=True)
    else:
        print(f"{COND} {PATH} ALL FAILED", flush=True)


if __name__ == "__main__":
    main()
