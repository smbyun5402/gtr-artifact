# Windows-hosted software-fTPM campaign

`gtr_v185_integration_n1000.json` records four separate fresh-fTPM batches of 250 trials each under Windows-hosted WSL2. It supplies batch summaries, not the 1000 individual handshake latency records; do not describe batch p95 ranges as a pooled per-trial distribution.

The associated harness is `src/gtr_v185_integration.c` (250 trials per invocation). Its SHA-256 matches the recorded `sources.harness_sha256` exactly:

`defe2cb7da04532feddcfca4cce90bf3ddf4d975abe5726651584f41882d4b68`

The original private data ZIP included this campaign's summary but only the older 10-trial C harness under `../fwtpm_v185/`. The matching 250-trial source was recovered from the existing experiment workspace and added here without changing it. The older source remains clearly separate for provenance.

## Dependencies and execution scope

- wolfSSL commit: `e941761acef7058ca8cbd4a099f6384010e2cf76`
- wolfTPM commit: `cd6ae53be56f449a67105773adfb16d51843af69`
- Host: Windows 11 with a WSL2 Linux guest
- TPM: separate wolfTPM software-fTPM process over local `mssim`
- Algorithms: ML-KEM-768 and Hash-ML-DSA-65/SHA-256

The older `../fwtpm_v185/README.md` supplies the pinned dependency/build outline, and `../fwtpm_v185/CMakeLists.target.txt` supplies its CMake target line. For the Windows/WSL2 campaign use **this** 250-trial source, not the older 10-trial source, and omit macOS-specific `-framework Security -framework CoreFoundation` flags. Obtain upstream sources separately and review their licenses. The complete upstream dependency trees, VM image, compiled binaries, and original batch-orchestration shell history are not included.

To reproduce the campaign design, each of the four 250-trial invocations must use a fresh software-fTPM server. New timings will depend on the host, dependencies, and scheduler. Source-hash matching is a provenance check, not a new build or timing validation; the harness was not compiled or executed during public packaging.

This is software-fTPM functionality/performance, not physical TPM PQC performance, DDIL radio performance, or proof of physical secure deletion.
