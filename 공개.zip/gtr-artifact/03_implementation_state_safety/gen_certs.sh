#!/bin/sh
# Server certificates for the three mode families.
set -e
mkdir -p /qartz/certs && cd /qartz/certs

# classical: ECDSA P-256 (legacy + hybrid modes)
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 \
    -keyout ec_key.pem -out ec_cert.pem -days 30 -nodes \
    -subj "/CN=qartz-peer" 2>/dev/null

# PQC: ML-DSA-65 (FIPS 204)
openssl req -x509 -newkey ML-DSA-65 \
    -keyout mldsa_key.pem -out mldsa_cert.pem -days 30 -nodes \
    -subj "/CN=qartz-peer" 2>/dev/null

# waiver-token signing keys (guard benchmark)
openssl genpkey -algorithm ED25519 -out waiver_ed25519.pem 2>/dev/null
openssl pkey -in waiver_ed25519.pem -pubout -out waiver_ed25519_pub.pem
openssl genpkey -algorithm ML-DSA-65 -out waiver_mldsa.pem 2>/dev/null
openssl pkey -in waiver_mldsa.pem -pubout -out waiver_mldsa_pub.pem

# Distinct endpoint attestation keys.  The Resync benchmark must not collapse
# node authentication and policy-authority signatures onto one key.
for node in node_i node_j; do
    openssl genpkey -algorithm ML-DSA-65 -out "${node}_mldsa.pem" 2>/dev/null
    openssl pkey -in "${node}_mldsa.pem" -pubout \
        -out "${node}_mldsa_pub.pem"
done

# Bench-only pre-established session secret.  It is generated randomly at
# image build time instead of being a public hash of sid.
openssl rand 32 > resync_session_secret.bin
echo "certs done"
