#!/usr/bin/env python3
# Decision-loop cost on a CPU-constrained container (the --cpus limit is
# applied by the harness at docker run time).
import os, time, statistics
import numpy as np
from qartz_sim import QARTZ, make_trace

tr = make_trace("S3", 2000, seed=1)
q = QARTZ(rng=np.random.default_rng(1))
for t in range(2000):
    q.step(tr, t)
us = q.step_time_us[100:]          # skip warmup
print(f"steps {len(us)} mean_us {statistics.mean(us):.1f} "
      f"p95_us {sorted(us)[int(len(us)*0.95)]:.1f}")
os.makedirs("/qartz/results", exist_ok=True)
with open("/qartz/results/loop.txt", "w") as f:
    f.write(f"mean_us {statistics.mean(us):.1f} "
            f"p95_us {sorted(us)[int(len(us)*0.95)]:.1f}\n")
