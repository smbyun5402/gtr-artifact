#!/usr/bin/env python3
# Q-ARTZ-Resync end-to-end adversarial demo on real cryptography (design §4).
#   - SSTs signed ML-DSA-65 via OpenSSL 3.5 `pkeyutl -rawin` (node keys generated
#     at first run; PA objects signed with the image-baked
#     /qartz/certs/waiver_mldsa.pem, exactly the guard_demo.py idiom)
#   - canonical JSON (sort_keys, compact separators) for every hashed/signed struct
#   - HKDF-SHA256 (RFC 5869, stdlib hmac/hashlib) -> K_res; HMAC-SHA256 commit
#     over the real ctxDigest of the transcript (design §1.6)
#   - file-backed transCtr with fsync; state lives under /qartz/results (bind
#     mount), so it survives a full container restart ("RoT NV" analog)
# Case table (both-sides 4-message flow, guard = responder j processing M3):
#   valid#1, stale-SST replay, counter regression, wrong-base delta,
#   waiver cross-transcript splice, transcript substitution, duplicate commit,
#   valid#2; `replay-after-restart` runs as a SEPARATE invocation (fresh
#   process/container: only the fsync'd counter + Sigma + keys survive).
# Machine-parsable output -> /qartz/results/resync_cases.txt
# Microbenches: ML-DSA-65 sign/verify (incl-spawn, subprocess per op inside one
# python process; a spawn-noop baseline gives a raw estimate — clearly labeled;
# OpenSSL 3.5.6 `openssl speed` does not support ml-dsa-65, so a persistent
# in-process raw measurement is not achievable with stdlib) and the
# HKDF+HMAC commit path in microseconds.
# Run inside qartz-testbed (bind-mount pattern, see run_resync_bench.sh header).
import subprocess, json, hashlib, hmac, os, sys, time, base64, secrets, statistics, math

HERE = os.path.dirname(os.path.abspath(__file__))
HOST_WORK = os.environ.get("QARTZ_RESYNC_WORK",
                           os.path.join(HERE, "_resync_work"))
CERTS = os.environ.get(
    "QARTZ_CERTS",
    "/qartz/certs" if os.path.isdir("/qartz/certs")
    else os.path.join(HOST_WORK, "certs"))
RESULTS = os.environ.get(
    "QARTZ_RESULTS",
    "/qartz/results" if os.path.isdir("/qartz/results")
    else os.path.join(HERE, "results_raw"))
STATE = os.environ.get("QARTZ_RESYNC_STATE",
                       os.path.join(HOST_WORK, "state"))
PA_KEY = f"{CERTS}/waiver_mldsa.pem"
PA_PUB = f"{CERTS}/waiver_mldsa_pub.pem"
RECORD_FILE = os.path.join(STATE, "node_j_record.json")
NODE_I_RECORD = os.path.join(STATE, "node_i_record.json")
KEY_I = os.path.join(STATE, "node_i.pem"); PUB_I = os.path.join(STATE, "node_i_pub.pem")
KEY_J = os.path.join(STATE, "node_j.pem"); PUB_J = os.path.join(STATE, "node_j_pub.pem")
TMP = os.path.join(HOST_WORK, f"tmp_rs_{os.getpid()}")
EXP = 10**10          # far-future exp: wall-time TTL is a secondary bound (design §1.2)
NOW = 100
SCOPE = {"domain": "convoy-a", "caps": ["telemetry", "c2"]}


def scope_covers(waiver_scope, affected_scope):
    """Return true only for same-domain, full capability containment.

    A non-empty intersection is deliberately insufficient: a waiver for
    ``telemetry`` must not authorize a delta that also relaxes ``c2``.
    """
    if not isinstance(waiver_scope, dict) or not isinstance(affected_scope, dict):
        return False
    if set(waiver_scope) != {"domain", "caps"} \
            or set(affected_scope) != {"domain", "caps"}:
        return False
    waiver_caps = waiver_scope.get("caps")
    affected_caps = affected_scope.get("caps")
    if (not isinstance(waiver_scope.get("domain"), str)
            or not isinstance(affected_scope.get("domain"), str)
            or not isinstance(waiver_caps, list)
            or not isinstance(affected_caps, list)
            or not affected_caps
            or any(not isinstance(cap, str) for cap in waiver_caps + affected_caps)):
        return False
    return (waiver_scope["domain"] == affected_scope["domain"]
            and set(affected_caps).issubset(set(waiver_caps)))

os.makedirs(CERTS, exist_ok=True)
os.makedirs(RESULTS, exist_ok=True)
os.makedirs(STATE, exist_ok=True)


# ---------- canonical encoding / hashing ----------
def cj(o) -> bytes:
    return json.dumps(o, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode()


def strict_json_loads(raw, *, max_bytes=65536, max_depth=16):
    """Decode the restricted canonical JSON profile used on the wire.

    Duplicate keys, floats/NaN, invalid UTF-8 or surrogate code points,
    excessive nesting, and non-canonical encodings are rejected before any
    signature, digest, or policy check consumes the object.
    """
    if isinstance(raw, bytes):
        if len(raw) > max_bytes:
            raise ValueError("json-size")
        text = raw.decode("utf-8", errors="strict")
    elif isinstance(raw, str):
        encoded = raw.encode("utf-8", errors="strict")
        if len(encoded) > max_bytes:
            raise ValueError("json-size")
        text = raw
    else:
        raise TypeError("json-input")

    def unique_pairs(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError("json-duplicate")
            obj[key] = value
        return obj

    def reject_float(_):
        raise ValueError("json-float")

    obj = json.loads(text, object_pairs_hook=unique_pairs,
                     parse_float=reject_float, parse_constant=reject_float)

    def validate(value, depth=0):
        if depth > max_depth:
            raise ValueError("json-depth")
        if isinstance(value, str):
            if any(0xD800 <= ord(ch) <= 0xDFFF for ch in value):
                raise ValueError("json-surrogate")
        elif isinstance(value, bool) or value is None or isinstance(value, int):
            pass
        elif isinstance(value, list):
            for item in value:
                validate(item, depth + 1)
        elif isinstance(value, dict):
            if any(not isinstance(key, str) for key in value):
                raise ValueError("json-key")
            for key, item in value.items():
                validate(key, depth + 1)
                validate(item, depth + 1)
        else:
            raise ValueError("json-type")

    validate(obj)
    if cj(obj).decode("utf-8") != text:
        raise ValueError("json-noncanonical")
    return obj


def H(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def b64(b): return base64.b64encode(b).decode()
def ub64(s): return base64.b64decode(s)


# ---------- real ML-DSA-65 via openssl pkeyutl (guard_demo.py idiom) ----------
def sign(payload: bytes, key: str) -> bytes:
    open(TMP + ".bin", "wb").write(payload)
    subprocess.run(["openssl", "pkeyutl", "-sign", "-inkey", key, "-rawin",
                    "-in", TMP + ".bin", "-out", TMP + ".sig"],
                   check=True, capture_output=True)
    return open(TMP + ".sig", "rb").read()


def verify(payload: bytes, sig: bytes, pub: str) -> bool:
    open(TMP + ".vbin", "wb").write(payload)
    open(TMP + ".vsig", "wb").write(sig)
    r = subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", pub,
                        "-rawin", "-in", TMP + ".vbin", "-sigfile", TMP + ".vsig"],
                       capture_output=True)
    return r.returncode == 0


def ensure_keys(fresh: bool):
    if fresh or not os.path.exists(PA_KEY):
        subprocess.run(["openssl", "genpkey", "-algorithm", "ML-DSA-65",
                        "-out", PA_KEY], check=True, capture_output=True)
        subprocess.run(["openssl", "pkey", "-in", PA_KEY, "-pubout",
                        "-out", PA_PUB], check=True, capture_output=True)
    for priv, pub in ((KEY_I, PUB_I), (KEY_J, PUB_J)):
        if fresh or not os.path.exists(priv):
            subprocess.run(["openssl", "genpkey", "-algorithm", "ML-DSA-65",
                            "-out", priv], check=True, capture_output=True)
            subprocess.run(["openssl", "pkey", "-in", priv, "-pubout", "-out", pub],
                           check=True, capture_output=True)


# ---------- HKDF-SHA256 (RFC 5869, stdlib only) ----------
def hkdf(ikm: bytes, info: bytes, salt: bytes = b"", length: int = 32) -> bytes:
    prk = hmac.new(salt if salt else b"\x00" * 32, ikm, hashlib.sha256).digest()
    okm, t, i = b"", b"", 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        okm += t
        i += 1
    return okm[:length]


# ---------- persisted NV state (single atomic record; survives restart) ----------
def fsync_write(path, data: bytes):
    with open(path, "wb") as f:
        f.write(data); f.flush(); os.fsync(f.fileno())


def atomic_write(path, obj):
    tmp = f"{path}.tmp.{os.getpid()}"
    fsync_write(tmp, cj(obj))
    os.replace(tmp, path)
    if os.name != "nt":
        fd = os.open(os.path.dirname(path), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


_SESSION_SECRET = None


def session_secret() -> bytes:
    global _SESSION_SECRET
    if _SESSION_SECRET is not None:
        return _SESSION_SECRET
    p = os.path.join(STATE, "session_secret")
    if not os.path.exists(p):
        fsync_write(p, secrets.token_bytes(32))
    _SESSION_SECRET = open(p, "rb").read()
    return _SESSION_SECRET


def initial_sigma():
    return {"sid": "s1", "mode": "HYBRID", "reqClass": 1, "secEpoch": 3,
            "keyEpoch": 5, "polEpoch": 3, "attEpoch": 7, "transCtr": 0,
            "seqNo": 42, "chainDigest": H(b"chain-42"),
            "manifestDigest": H(b"manifest-v1"), "EARdigest": H(b"ear-epoch7"),
            "policyHash": H(b"policy-v3")}


def load_record(path=RECORD_FILE):
    if os.path.exists(path):
        return json.load(open(path))
    return {"version": 1, "phase": "pre", "sigma": initial_sigma(),
            "pending": None, "ctxDigest": None, "commitI": None,
            "commitJ": None, "oldTicketInvalid": False}


def load_sigma():
    return load_record()["sigma"]


def read_ctr():
    return int(load_sigma()["transCtr"])


def persist_record(path, phase, sigma, pending=None, ctx=None,
                   commit_i=None, commit_j=None, old_invalid=False):
    atomic_write(path, {"version": 1, "phase": phase, "sigma": sigma,
                        "pending": pending, "ctxDigest": ctx,
                        "commitI": commit_i, "commitJ": commit_j,
                        "oldTicketInvalid": old_invalid})


# ---------- digests over Sigma (design §1.1: two-digest split) ----------
CORE_FIELDS = ("sid", "mode", "reqClass", "secEpoch", "keyEpoch", "polEpoch",
               "policyHash", "manifestDigest")


def core_digest(S):    # stable fields only; ALL PA objects bind to this
    return H(cj({k: S[k] for k in CORE_FIELDS}))


def state_digest(S):   # full state; used only in SST and commit
    return H(cj(S))


# ---------- signed objects (design §1.3) ----------
def make_sst(sigma, ctr_target, nonce_peer, nonce_own, role, key):
    # transCtr field carries the value the counter takes on commit
    # (exact-equation rule, guard_demo convention). Signs the PEER's nonce
    # (freshness) and the role (anti-reflection).
    pay = cj({"obj": "SST", "stateDigest": state_digest(sigma),
              "transCtr": ctr_target, "attEpoch": sigma["attEpoch"],
              "seqNo": sigma["seqNo"], "chainDigest": sigma["chainDigest"],
              "noncePeer": nonce_peer, "nonceOwn": nonce_own,
              "sid": sigma["sid"], "role": role, "akId": f"AK-{role}"})
    return {"payload": pay.decode(), "sig": b64(sign(pay, key))}


def pa_delta(sigma, to_pol, delta_id):
    pay = cj({"obj": "PolicyDelta", "fromCoreDigest": core_digest(sigma),
              "fromPolEpoch": sigma["polEpoch"], "toPolEpoch": to_pol,
              "fromPolicyHash": sigma["policyHash"],
              "toPolicyHash": H(f"policy-v{to_pol}".encode()),
              "fromReqClass": sigma["reqClass"], "toReqClass": sigma["reqClass"],
              "scope": SCOPE, "deltaID": delta_id, "exp": EXP,
              "relaxationBits": 0})
    return {"payload": pay.decode(), "sig": b64(sign(pay, PA_KEY))}


def pa_waiver(sigma, to_ctr):
    pay = cj({"obj": "Waiver", "coreDigest": core_digest(sigma),
              "toTransCtr": to_ctr, "ttlExc": 300, "scope": SCOPE,
              "capDigest": H(b"caps-telemetry-c2"), "exp": EXP,
              "nonceW": secrets.token_hex(8)})
    return {"payload": pay.decode(), "sig": b64(sign(pay, PA_KEY))}


def pa_rescope(obj, scope):
    """Reissue a PA object with a test scope under the real PA key."""
    body = strict_json_loads(obj["payload"])
    body["scope"] = scope
    pay = cj(body)
    return {"payload": pay.decode(), "sig": b64(sign(pay, PA_KEY))}


def apply_delta(sigma, dd):
    S = dict(sigma)
    S["polEpoch"] = dd["toPolEpoch"]
    S["policyHash"] = dd["toPolicyHash"]
    S["reqClass"] = dd["toReqClass"]
    return S


# ---------- ctxDigest / K_res / commit MAC (design §1.6) ----------
def ctx_digest(hs, sst_i, sst_j, bundle, decision, dsigma, state_p):
    def hobj(o):
        return H(cj(o)) if o else H(b"")
    return H(cj({"peerI": "node-i", "peerJ": "node-j",
                 "nonceI": hs["nonceI"], "nonceJ": hs["nonceJ"],
                 "hSstI": hobj(sst_i), "hSstJ": hobj(sst_j),
                 "hEarI": H(b""), "hEarJ": H(b""),
                 "hProofI": H(b""), "hProofJ": H(b""),
                 "hWt": hobj(bundle.get("waiver") if bundle else None),
                 "hDelta": hobj(bundle.get("delta") if bundle else None),
                 "hKeyUpd": H(b""), "decision": decision,
                 "deltaSigma": dsigma, "stateDigestPrime": state_p}))


def k_res(sid, ctx):
    return hkdf(session_secret(), info=b"resume|" + sid.encode() + b"|" + ctx.encode(),
                salt=b"qartz-resync")


def commit_mac(kres, label, state_p, ticket_p, ctx):
    msg = label.encode() + b"|" + state_p.encode() + b"|" + ticket_p.encode() + b"|" + ctx.encode()
    return hmac.new(kres, msg, hashlib.sha256).hexdigest()


def ticket_digest(sigma_p):
    return H(cj(sigma_p) + b"|ttl600")


# ---------- 4-message flow ----------
def new_hs(sigma_j):
    # M1 (i->j: sid, nonce_i) + M2 (j->i: nonce_j, Sigma_j, SST_j)
    hs = {"sid": sigma_j["sid"], "nonceI": secrets.token_hex(16),
          "nonceJ": secrets.token_hex(16)}
    hs["sstJ"] = make_sst(sigma_j, read_ctr() + 1, hs["nonceI"], hs["nonceJ"],
                          "resp", KEY_J)
    return hs


def i_build_m3(hs, sigma_i, bundle, ctr_target):
    # honest initiator: verify responder SST first (mutual auth, untimed here)
    sj = hs["sstJ"]
    assert verify(sj["payload"].encode(), ub64(sj["sig"]), PUB_J), "SST_j sig"
    tj = strict_json_loads(sj["payload"])
    assert tj["noncePeer"] == hs["nonceI"] and tj["role"] == "resp", "SST_j fresh"
    sst_i = make_sst(sigma_i, ctr_target, hs["nonceJ"], hs["nonceI"], "init", KEY_I)
    decision = "DeltaPatch" if bundle else "Resume"
    sigma_p = apply_delta(sigma_i, strict_json_loads(bundle["delta"]["payload"])) \
        if bundle else dict(sigma_i)
    sigma_p["transCtr"] = ctr_target
    state_p = state_digest(sigma_p)
    ctx = ctx_digest(hs, sst_i, sj, bundle, decision, {}, state_p)
    kr = k_res(sigma_i["sid"], ctx)
    tk = ticket_digest(sigma_p)
    m3 = {"sigmaI": sigma_i, "sstI": sst_i, "bundle": bundle,
          "decision": decision,
          "commitI": commit_mac(kr, "commit_i", state_p, tk, ctx)}
    # Initiator persist-before-send: candidate, transcript and old-ticket
    # invalidation are one atomic record before M3 can leave the node.
    persist_record(NODE_I_RECORD, "candidate", sigma_i, pending=sigma_p,
                   ctx=ctx, commit_i=m3["commitI"], old_invalid=True)
    return m3, {"ctx": ctx, "kres": kr, "stateP": state_p, "ticketP": tk}


def j_process_m3(hs, m3):
    # Guard order: signature -> nonce freshness/role -> transCtr equation ->
    # bundle predicate (sigs, waiver single-use, coreDigest base binding) ->
    # decision agreement -> commit MAC. Accept: consume ctr (fsync) + adopt.
    sigma_j = load_sigma()
    t0 = time.perf_counter()

    def rej(why):
        return False, why, (time.perf_counter() - t0) * 1e3, None

    sst = m3["sstI"]
    pay = sst["payload"].encode()
    if not verify(pay, ub64(sst["sig"]), PUB_I):
        return rej("signature")
    try:
        tok = strict_json_loads(pay)
    except (TypeError, ValueError, UnicodeError, json.JSONDecodeError):
        return rej("encoding")
    if not (tok["noncePeer"] == hs["nonceJ"] and tok["nonceOwn"] == hs["nonceI"]
            and tok["role"] == "init" and tok["sid"] == sigma_j["sid"]):
        return rej("nonce")
    sigma_i = m3["sigmaI"]
    if tok["stateDigest"] != state_digest(sigma_i):
        return rej("state-digest")
    expected = read_ctr() + 1
    if tok["transCtr"] != expected:
        # regression/replay of a consumed counter (fresh-signed => quarantine-
        # grade evidence per design §1.5; demo reports the rejecting conjunct)
        return rej("counter")
    bundle = m3.get("bundle")
    sigma_p = dict(sigma_j)
    if bundle:
        d = bundle["delta"]
        if not verify(d["payload"].encode(), ub64(d["sig"]), PA_PUB):
            return rej("delta-sig")
        try:
            dd = strict_json_loads(d["payload"])
        except (TypeError, ValueError, UnicodeError, json.JSONDecodeError):
            return rej("encoding")
        w = bundle["waiver"]
        if not verify(w["payload"].encode(), ub64(w["sig"]), PA_PUB):
            return rej("waiver-sig")
        try:
            ww = strict_json_loads(w["payload"])
        except (TypeError, ValueError, UnicodeError, json.JSONDecodeError):
            return rej("encoding")
        if ww["exp"] < NOW or dd["exp"] < NOW:
            return rej("expiry")
        if ww["toTransCtr"] != expected:
            return rej("waiver-ctr")          # single-use waiver, consumed
        if ww["coreDigest"] != core_digest(sigma_j):
            return rej("waiver-base")
        if dd["fromCoreDigest"] != core_digest(sigma_j) \
                or dd["fromPolEpoch"] != sigma_j["polEpoch"]:
            return rej("base-digest")         # PA object bound to other core
        if not scope_covers(ww.get("scope"), dd.get("scope")):
            return rej("scope")
        sigma_p = apply_delta(sigma_j, dd)
    decision = "DeltaPatch" if bundle else "Resume"
    if decision != m3["decision"]:
        return rej("decision-mismatch")
    sigma_p["transCtr"] = expected
    state_p = state_digest(sigma_p)
    ctx = ctx_digest(hs, sst, hs["sstJ"], bundle, decision, {}, state_p)
    kr = k_res(sigma_j["sid"], ctx)
    tk = ticket_digest(sigma_p)
    if not hmac.compare_digest(
            commit_mac(kr, "commit_i", state_p, tk, ctx), m3["commitI"]):
        return rej("commit-mac")
    m4 = {"decision": decision,
          "commitJ": commit_mac(kr, "commit_j", state_p, tk, ctx)}
    # Responder persist-before-send: the counter, candidate, half-open phase,
    # transcript and both commits are one atomic durable record.
    persist_record(RECORD_FILE, "half-open", sigma_p, pending=sigma_p,
                   ctx=ctx, commit_i=m3["commitI"], commit_j=m4["commitJ"],
                   old_invalid=True)
    ms = (time.perf_counter() - t0) * 1e3
    return True, "accepted", ms, m4


def traffic_key(kres, ctx):
    return hkdf(kres, info=b"traffic|" + ctx.encode(), salt=b"qartz-record")


def accept_first_record(priv):
    """HALF-OPEN -> OPEN only on a record bound to Sigma' and ctxDigest."""
    rec = load_record()
    if rec["phase"] != "half-open" or rec["ctxDigest"] != priv["ctx"]:
        return False
    key_i = traffic_key(priv["kres"], priv["ctx"])
    tag = hmac.new(key_i, ("record|" + priv["stateP"] + "|0").encode(),
                   hashlib.sha256).digest()
    key_j = traffic_key(k_res(rec["sigma"]["sid"], rec["ctxDigest"]),
                        rec["ctxDigest"])
    expected = hmac.new(
        key_j, ("record|" + state_digest(rec["pending"]) + "|0").encode(),
        hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected):
        return False
    persist_record(RECORD_FILE, "open", rec["pending"], ctx=rec["ctxDigest"],
                   commit_i=rec["commitI"], commit_j=rec["commitJ"],
                   old_invalid=True)
    persist_record(NODE_I_RECORD, "open", rec["pending"], ctx=rec["ctxDigest"],
                   commit_i=rec["commitI"], commit_j=rec["commitJ"],
                   old_invalid=True)
    return True


def abort_initiator():
    rec = load_record(NODE_I_RECORD)
    if rec["phase"] == "candidate":
        persist_record(NODE_I_RECORD, "abort", rec["sigma"],
                       ctx=rec["ctxDigest"], commit_i=rec["commitI"],
                       old_invalid=True)


# ---------- case harness ----------
def run_case(out, results, name, expect, hs, m3, priv=None, recover=False):
    ok, why, ms, m4 = j_process_m3(hs, m3)
    if ok and priv is not None:      # i-side: verify Commit_j (mutual)
        if recover:
            # Model M4 loss + responder restart: only the atomic HALF-OPEN
            # record survives, and a bit-identical Commit_j is recovered.
            rec = load_record()
            assert rec["phase"] == "half-open" and rec["commitI"] == m3["commitI"]
            m4 = {"commitJ": rec["commitJ"]}
            why = "accepted-recovered"
        good = hmac.compare_digest(
            commit_mac(priv["kres"], "commit_j", priv["stateP"],
                       priv["ticketP"], priv["ctx"]), m4["commitJ"])
        assert good, "Commit_j verification failed at initiator"
        assert accept_first_record(priv), "Sigma'-bound first record rejected"
    elif not ok:
        abort_initiator()
    verdict = "ACCEPT" if ok else "REJECT"
    line = (f"case={name} expect={expect} verdict={verdict} reason={why} "
            f"ms={ms:.1f} ctr={read_ctr()}")
    print(line, flush=True)
    out.write(line + "\n")
    results.append((name, expect, verdict))


def run_parser_cases(out):
    """Exercise raw encodings that an in-memory dict corpus cannot express."""
    canonical = cj({"a": 1, "b": ["x"]})
    cases = [
        ("canonical", "ACCEPT", canonical),
        ("duplicate-key", "REJECT", b'{"a":1,"a":2}'),
        ("float", "REJECT", b'{"a":1.0}'),
        ("nan", "REJECT", b'{"a":NaN}'),
        ("unicode-surrogate", "REJECT", b'{"a":"\\ud800"}'),
        ("invalid-utf8", "REJECT", b'{"a":"\xff"}'),
        ("noncanonical-space", "REJECT", b'{"a": 1}'),
        ("noncanonical-order", "REJECT", b'{"b":2,"a":1}'),
    ]
    passed = 0
    for name, expected, raw in cases:
        try:
            strict_json_loads(raw)
            verdict, reason = "ACCEPT", "canonical"
        except (TypeError, ValueError, UnicodeError, json.JSONDecodeError) as exc:
            verdict, reason = "REJECT", type(exc).__name__
        passed += int(verdict == expected)
        line = (f"parsercase={name} expect={expected} verdict={verdict} "
                f"reason={reason}")
        print(line, flush=True)
        out.write(line + "\n")
    print(f"parser cases correct: {passed == len(cases)} ({passed}/{len(cases)})")


def microbench(out):
    payload = secrets.token_bytes(300)          # realistic token payload size
    sig = sign(payload, KEY_I)                  # warm caches

    def loop(fn, n=200):
        ts = []
        for _ in range(n):
            t0 = time.perf_counter()
            fn()
            ts.append((time.perf_counter() - t0) * 1e3)
        s = sorted(ts)
        return statistics.mean(ts), s[math.ceil(len(s) * 0.95) - 1]

    sm, sp = loop(lambda: sign(payload, KEY_I))
    vm, vp = loop(lambda: verify(payload, sig, PUB_I))
    nm, np_ = loop(lambda: subprocess.run(["openssl", "version"],
                                          capture_output=True))
    for ln in [f"mldsa-sign-incl-spawn ms: mean {sm:.2f} p95 {sp:.2f} n=200",
               f"mldsa-verify-incl-spawn ms: mean {vm:.2f} p95 {vp:.2f} n=200",
               f"openssl-spawn-noop ms: mean {nm:.2f} p95 {np_:.2f} n=200",
               f"mldsa-sign-raw-est ms: {max(sm - nm, 0):.2f}",
               f"mldsa-verify-raw-est ms: {max(vm - nm, 0):.2f}"]:
        print(ln, flush=True)
        out.write(ln + "\n")

    # HKDF + HMAC commit path (ctxDigest -> K_res -> Commit_i + verify), pure µs
    sigma = load_sigma()
    hs = {"sid": sigma["sid"], "nonceI": "a" * 32, "nonceJ": "b" * 32,
          "sstJ": {"payload": "x" * 400, "sig": b64(b"\x00" * 3309)}}
    sst_i = {"payload": "y" * 400, "sig": b64(b"\x01" * 3309)}
    state_p = state_digest(sigma)
    us = []
    for _ in range(2000):
        t0 = time.perf_counter()
        ctx = ctx_digest(hs, sst_i, hs["sstJ"], None, "Resume", {}, state_p)
        kr = k_res(sigma["sid"], ctx)
        c = commit_mac(kr, "commit_i", state_p, state_p, ctx)
        hmac.compare_digest(c, commit_mac(kr, "commit_i", state_p, state_p, ctx))
        us.append((time.perf_counter() - t0) * 1e6)
    s = sorted(us)
    ln = (f"commit-path us: mean {statistics.mean(us):.1f} "
          f"p95 {s[math.ceil(len(s) * 0.95) - 1]:.1f} n=2000")
    print(ln, flush=True)
    out.write(ln + "\n")


def measure_bytes(out, hs, m3, m4_decision):
    sst_i = m3["sstI"]
    sst_raw = len(sst_i["payload"].encode()) + len(ub64(sst_i["sig"]))
    bundle = m3["bundle"]
    bundle_raw = sum(len(o["payload"].encode()) + len(ub64(o["sig"]))
                     for o in (bundle["delta"], bundle["waiver"]))
    m1 = len(cj({"sid": hs["sid"], "nonceI": hs["nonceI"]}))
    m2 = len(cj({"nonceJ": hs["nonceJ"], "sigmaJ": load_sigma(),
                 "sstJ": hs["sstJ"]}))
    m3b = len(cj(m3))
    m4 = len(cj({"decision": m4_decision, "commitJ": "0" * 64}))
    ln = (f"bytes sst={sst_raw} bundle={bundle_raw} commit=32 "
          f"m1={m1} m2={m2} m3={m3b} m4={m4} flight={m1 + m2 + m3b + m4}")
    print(ln, flush=True)
    out.write(ln + "\n")


def run_main():
    global _SESSION_SECRET
    _SESSION_SECRET = None
    # fresh mission state (keys regenerated; counter reset)
    for f in ("node_j_record.json", "node_i_record.json", "session_secret"):
        p = os.path.join(STATE, f)
        if os.path.exists(p):
            os.remove(p)
    ensure_keys(fresh=True)
    persist_record(RECORD_FILE, "pre", initial_sigma())
    persist_record(NODE_I_RECORD, "pre", initial_sigma())
    out = open(os.path.join(RESULTS, "resync_cases.txt"), "w")
    results = []

    # ---- transcript 1: valid DeltaPatch (polEpoch 3->4), waiver toTransCtr=1
    sigma = load_sigma()
    hs1 = new_hs(sigma)
    d1 = pa_delta(sigma, to_pol=4, delta_id="delta-a")
    w1 = pa_waiver(sigma, to_ctr=1)
    m3_1, priv1 = i_build_m3(hs1, sigma, {"delta": d1, "waiver": w1}, 1)
    run_case(out, results, "valid#1", "ACCEPT", hs1, m3_1, priv1)  # ctr 0->1

    # ---- stale-SST replay: verbatim transcript-1 M3 into a FRESH handshake
    sigma = load_sigma()                       # now polEpoch 4, ctr 1
    hs2 = new_hs(sigma)
    run_case(out, results, "stale-sst-replay", "REJECT", hs2, m3_1)  # nonce

    # ---- Sigma substitution next to a valid fresh SST: digest binding rejects
    hs2b = new_hs(sigma)
    m3, _ = i_build_m3(hs2b, sigma, None, ctr_target=2)
    m3_tampered = strict_json_loads(cj(m3))
    m3_tampered["sigmaI"]["seqNo"] += 1
    run_case(out, results, "tampered-sigma", "REJECT", hs2b, m3_tampered)

    # ---- counter regression: honestly signed Resume targeting consumed ctr 1
    hs3 = new_hs(sigma)
    m3, _ = i_build_m3(hs3, sigma, None, ctr_target=1)
    run_case(out, results, "counter-regression", "REJECT", hs3, m3)  # counter

    # ---- wrong-base delta: PA-signed delta d1 (bound to polEpoch-3 core)
    #      attached at the polEpoch-4 core, with an otherwise-fresh waiver
    hs4 = new_hs(sigma)
    m3, _ = i_build_m3(hs4, sigma, {"delta": d1,
                                    "waiver": pa_waiver(sigma, 2)}, 2)
    run_case(out, results, "wrong-base-delta", "REJECT", hs4, m3)  # base-digest

    # ---- waiver cross-transcript splice: fresh delta + transcript-1 waiver
    hs5 = new_hs(sigma)
    d2 = pa_delta(sigma, to_pol=5, delta_id="delta-b")
    m3, _ = i_build_m3(hs5, sigma, {"delta": d2, "waiver": w1}, 2)
    run_case(out, results, "waiver-splice", "REJECT", hs5, m3)  # waiver-ctr

    # ---- partial-overlap scope: same domain and one shared capability are
    #      insufficient; the waiver must cover every delta capability.
    hs5b = new_hs(sigma)
    d_partial = pa_rescope(
        d2, {"domain": "convoy-a", "caps": ["telemetry", "c2"]})
    w_partial = pa_rescope(
        pa_waiver(sigma, 2),
        {"domain": "convoy-a", "caps": ["telemetry"]})
    m3, _ = i_build_m3(
        hs5b, sigma, {"delta": d_partial, "waiver": w_partial}, 2)
    run_case(out, results, "scope-partial-overlap", "REJECT", hs5b, m3)

    # ---- transcript substitution: swap the delta AFTER Commit_i is computed
    hs6 = new_hs(sigma)
    m3, _ = i_build_m3(hs6, sigma, {"delta": d2,
                                    "waiver": pa_waiver(sigma, 2)}, 2)
    m3t = strict_json_loads(cj(m3))
    m3t["bundle"]["delta"] = pa_delta(sigma, to_pol=5, delta_id="delta-evil")
    run_case(out, results, "transcript-substitution", "REJECT", hs6, m3t)  # mac

    # ---- duplicate commit: transcript-1 M3 re-delivered in its ORIGINAL
    #      handshake context (nonces match; one-shot ctr already consumed)
    run_case(out, results, "duplicate-commit", "REJECT", hs1, m3_1)  # counter

    # ---- transcript 2: valid DeltaPatch (polEpoch 4->5), waiver toTransCtr=2
    hs8 = new_hs(sigma)
    m3_8, priv8 = i_build_m3(hs8, sigma, {"delta": d2,
                                          "waiver": pa_waiver(sigma, 2)}, 2)
    run_case(out, results, "commitJ-loss-recovery", "ACCEPT", hs8, m3_8,
             priv8, recover=True)  # persisted HALF-OPEN -> OPEN, ctr 1->2

    run_parser_cases(out)
    measure_bytes(out, hs8, m3_8, "DeltaPatch")
    microbench(out)

    ok_all = all(e == v for _, e, v in results)
    print(f"in-process cases correct: {ok_all} ({len(results)} cases)")
    out.close()


def run_restart():
    # Fresh process/container: only STATE (fsync'd ctr, Sigma, keys, secret)
    # survived. The rolled-back initiator re-presents the already-consumed
    # transCtr target with a genuinely fresh signature over fresh nonces —
    # exactly the layer that must be caught by the persisted counter (a
    # verbatim replay would already die on nonce freshness).
    ensure_keys(fresh=False)
    out = open(os.path.join(RESULTS, "resync_cases.txt"), "a")
    sigma = load_sigma()
    hs = new_hs(sigma)
    m3, _ = i_build_m3(hs, sigma, None, ctr_target=read_ctr())  # stale target
    ok, why, ms, _ = j_process_m3(hs, m3)
    if not ok:
        abort_initiator()
    verdict = "ACCEPT" if ok else "REJECT"
    line = (f"case=replay-after-restart expect=REJECT verdict={verdict} "
            f"reason={why} ms={ms:.1f} ctr={read_ctr()}")
    print(line)
    out.write(line + "\n")
    out.close()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "replay-after-restart":
        run_restart()
    else:
        run_main()
