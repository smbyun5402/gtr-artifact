/* GT-R-shaped TPM 2.0 v1.85 PQC integration experiment.
 *
 * This is a functional experiment, not the paper's production wire format.
 * All ML-KEM decapsulation and ML-DSA signing operations execute in the
 * separate fwTPM process over the mssim socket. Endpoint software receives
 * only public objects, parent-wrapped private blobs, signatures/ciphertexts,
 * and the TPM command outputs required by the GT-R key schedule.
 */

#ifdef HAVE_CONFIG_H
    #include <config.h>
#endif

#include <wolftpm/tpm2_wrap.h>
#include <hal/tpm_io.h>
#include <wolfssl/wolfcrypt/sha256.h>
#include <wolfssl/wolfcrypt/hmac.h>

#include <stdio.h>
#include <string.h>
#include <time.h>

#if !defined(WOLFTPM2_NO_WRAPPER) && \
    defined(WOLFTPM_MLDSA_SIGN) && defined(WOLFTPM_MLDSA_VERIFY) && \
    defined(WOLFTPM_MLKEM_ENCAP) && defined(WOLFTPM_MLKEM_DECAP) && \
    defined(WOLFTPM_HASH_MLDSA)

#define SS_SZ       32
#define TAG_SZ      32
#define CT_SZ       1088
#define SIG_CAP     5000
#define TRIALS      10
#define KEY_COUNT   7

enum {
    K_STATIC_A = 0, K_STATIC_B, K_EPHEMERAL_A,
    K_DR_A, K_DR_B, K_SIGN_A, K_SIGN_B
};

typedef struct SecretPair {
    byte enc[SS_SZ];
    byte dec[SS_SZ];
} SecretPair;

static double gEncapMs, gDecapMs, gSignMs, gVerifyMs;
static unsigned gEncapCount, gDecapCount, gSignCount, gVerifyCount;

static double now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1000000.0;
}

static int cmp_double(const void* a, const void* b)
{
    double x = *(const double*)a;
    double y = *(const double*)b;
    return (x > y) - (x < y);
}

static void be32(byte out[4], word32 value)
{
    out[0] = (byte)(value >> 24);
    out[1] = (byte)(value >> 16);
    out[2] = (byte)(value >> 8);
    out[3] = (byte)value;
}

static int sha_begin(wc_Sha256* sha)
{
    return wc_InitSha256(sha);
}

static int sha_add(wc_Sha256* sha, const void* data, word32 size)
{
    return wc_Sha256Update(sha, (const byte*)data, size);
}

static int sha_end(wc_Sha256* sha, byte out[32])
{
    int rc = wc_Sha256Final(sha, out);
    wc_Sha256Free(sha);
    return rc;
}

static int labeled_hash(const char* label, const byte* in, word32 inSz,
    byte out[32])
{
    wc_Sha256 sha;
    int rc = sha_begin(&sha);
    if (rc == 0) rc = sha_add(&sha, label, (word32)XSTRLEN(label));
    if (rc == 0) rc = sha_add(&sha, in, inSz);
    if (rc == 0) rc = sha_end(&sha, out);
    else wc_Sha256Free(&sha);
    return rc;
}

static int make_context(word32 trial,
    const byte* ctSj, const byte* ctE, const byte* ctSi,
    const byte* ctDsi, byte out[32])
{
    static const byte sid[16] = {
        'G','T','-','R','-','v','1','8','5','-','T','E','S','T',0,1
    };
    byte ni[32], nj[32], ei[4], ej[4], ep[4];
    wc_Sha256 sha;
    int rc;
    int n;

    for (n = 0; n < 32; n++) {
        ni[n] = (byte)(0x20 + n + trial);
        nj[n] = (byte)(0x80 + n + trial);
    }
    be32(ei, 0);
    be32(ej, 5);
    be32(ep, 6);

    rc = sha_begin(&sha);
    if (rc == 0) rc = sha_add(&sha, "GT-R/M1-M2", 11);
    if (rc == 0) rc = sha_add(&sha, sid, sizeof(sid));
    if (rc == 0) rc = sha_add(&sha, ni, sizeof(ni));
    if (rc == 0) rc = sha_add(&sha, nj, sizeof(nj));
    if (rc == 0) rc = sha_add(&sha, ei, sizeof(ei));
    if (rc == 0) rc = sha_add(&sha, ej, sizeof(ej));
    if (rc == 0) rc = sha_add(&sha, ep, sizeof(ep));
    if (rc == 0) rc = sha_add(&sha, ctSj, CT_SZ);
    if (rc == 0) rc = sha_add(&sha, ctE, CT_SZ);
    if (rc == 0) rc = sha_add(&sha, ctSi, CT_SZ);
    if (rc == 0) rc = sha_add(&sha, ctDsi, CT_SZ);
    if (rc == 0) rc = sha_end(&sha, out);
    else wc_Sha256Free(&sha);
    return rc;
}

static int derive_pre(const byte ctx[32], const byte s1[32],
    const byte s2[32], const byte se[32], byte out[32])
{
    wc_Sha256 sha;
    int rc = sha_begin(&sha);
    if (rc == 0) rc = sha_add(&sha, "GT-R/Kpre", 9);
    if (rc == 0) rc = sha_add(&sha, ctx, 32);
    if (rc == 0) rc = sha_add(&sha, s1, 32);
    if (rc == 0) rc = sha_add(&sha, s2, 32);
    if (rc == 0) rc = sha_add(&sha, se, 32);
    if (rc == 0) rc = sha_end(&sha, out);
    else wc_Sha256Free(&sha);
    return rc;
}

static int derive_final(const byte pre[32], const byte ratchet[32],
    const byte dsi[32], const byte dsj[32], const byte ctx[32], byte out[32])
{
    wc_Sha256 sha;
    int rc = sha_begin(&sha);
    if (rc == 0) rc = sha_add(&sha, "GT-R/ssk/e'=6", 13);
    if (rc == 0) rc = sha_add(&sha, pre, 32);
    if (rc == 0) rc = sha_add(&sha, ratchet, 32);
    if (rc == 0) rc = sha_add(&sha, dsi, 32);
    if (rc == 0) rc = sha_add(&sha, dsj, 32);
    if (rc == 0) rc = sha_add(&sha, ctx, 32);
    if (rc == 0) rc = sha_end(&sha, out);
    else wc_Sha256Free(&sha);
    return rc;
}

static int make_tag(const byte key[32], const char* label,
    const byte ctx[32], byte tag[32])
{
    Hmac hmac;
    int rc = wc_HmacInit(&hmac, NULL, INVALID_DEVID);
    if (rc == 0) rc = wc_HmacSetKey(&hmac, WC_SHA256, key, 32);
    if (rc == 0) rc = wc_HmacUpdate(&hmac,
        (const byte*)label, (word32)XSTRLEN(label));
    if (rc == 0) rc = wc_HmacUpdate(&hmac, ctx, 32);
    if (rc == 0) rc = wc_HmacFinal(&hmac, tag);
    wc_HmacFree(&hmac);
    return rc;
}

static int ratchet_to_epoch5(byte out[32])
{
    byte cur[32];
    byte next[32];
    int i;
    int rc = labeled_hash("GT-R/common-lineage", (const byte*)"ck[0]", 5, cur);
    for (i = 0; rc == 0 && i < 5; i++) {
        rc = labeled_hash("GT-R/FF", cur, sizeof(cur), next);
        XMEMCPY(cur, next, sizeof(cur));
    }
    XMEMCPY(out, cur, sizeof(cur));
    wc_ForceZero(cur, sizeof(cur));
    wc_ForceZero(next, sizeof(next));
    return rc;
}

static int create_mlkem_child(WOLFTPM2_DEV* dev, WOLFTPM2_KEY* srk,
    WOLFTPM2_KEYBLOB* key)
{
    TPMT_PUBLIC tpl;
    int rc;
    XMEMSET(&tpl, 0, sizeof(tpl));
    XMEMSET(key, 0, sizeof(*key));
    rc = wolfTPM2_GetKeyTemplate_MLKEM(&tpl,
        TPMA_OBJECT_decrypt | TPMA_OBJECT_fixedTPM | TPMA_OBJECT_fixedParent |
        TPMA_OBJECT_sensitiveDataOrigin | TPMA_OBJECT_userWithAuth |
        TPMA_OBJECT_noDA, TPM_MLKEM_768);
    if (rc == 0)
        rc = wolfTPM2_CreateLoadedKey(dev, key, &srk->handle, &tpl, NULL, 0);
    return rc;
}

static int create_sign_child(WOLFTPM2_DEV* dev, WOLFTPM2_KEY* srk,
    WOLFTPM2_KEYBLOB* key)
{
    TPMT_PUBLIC tpl;
    int rc;
    XMEMSET(&tpl, 0, sizeof(tpl));
    XMEMSET(key, 0, sizeof(*key));
    rc = wolfTPM2_GetKeyTemplate_HASH_MLDSA(&tpl,
        TPMA_OBJECT_sign | TPMA_OBJECT_fixedTPM | TPMA_OBJECT_fixedParent |
        TPMA_OBJECT_sensitiveDataOrigin | TPMA_OBJECT_userWithAuth |
        TPMA_OBJECT_noDA, TPM_MLDSA_65, TPM_ALG_SHA256);
    if (rc == 0)
        rc = wolfTPM2_CreateLoadedKey(dev, key, &srk->handle, &tpl, NULL, 0);
    return rc;
}

static int kem_exchange(WOLFTPM2_DEV* dev, WOLFTPM2_KEY* key,
    byte ct[CT_SZ], SecretPair* pair)
{
    int ctSz = CT_SZ;
    int encSz = SS_SZ;
    int decSz = SS_SZ;
    double start = now_ms();
    int rc = wolfTPM2_Encapsulate(dev, key, ct, &ctSz,
        pair->enc, &encSz);
    gEncapMs += now_ms() - start;
    gEncapCount++;
    if (rc == 0) {
        start = now_ms();
        rc = wolfTPM2_Decapsulate(dev, key, ct, ctSz,
            pair->dec, &decSz);
        gDecapMs += now_ms() - start;
        gDecapCount++;
    }
    if (rc == 0 && (ctSz != CT_SZ || encSz != SS_SZ || decSz != SS_SZ ||
            XMEMCMP(pair->enc, pair->dec, SS_SZ) != 0))
        rc = TPM_RC_FAILURE;
    return rc;
}

static int kem_exchange_blob(WOLFTPM2_DEV* dev, WOLFTPM2_KEY* srk,
    WOLFTPM2_KEYBLOB* key, byte ct[CT_SZ], SecretPair* pair)
{
    int rc = wolfTPM2_LoadKey(dev, key, &srk->handle);
    if (rc == 0)
        rc = kem_exchange(dev, (WOLFTPM2_KEY*)key, ct, pair);
    wolfTPM2_UnloadHandle(dev, &key->handle);
    return rc;
}

static int sign_and_verify(WOLFTPM2_DEV* dev, WOLFTPM2_KEY* key,
    const byte digest[32], byte* sig, int* sigSz)
{
    TPMT_TK_VERIFIED ticket;
    int rc;
    XMEMSET(&ticket, 0, sizeof(ticket));
    {
        double start = now_ms();
        rc = wolfTPM2_SignDigest(dev, key, digest, 32, NULL, 0, sig, sigSz);
        gSignMs += now_ms() - start;
        gSignCount++;
    }
    if (rc == 0) {
        double start = now_ms();
        rc = wolfTPM2_VerifyDigestSignature(dev, key, digest, 32,
            sig, *sigSz, NULL, 0, &ticket);
        gVerifyMs += now_ms() - start;
        gVerifyCount++;
    }
    if (rc == 0 && ticket.tag != TPM_ST_DIGEST_VERIFIED)
        rc = TPM_RC_FAILURE;
    return rc;
}


static int sign_and_verify_blob(WOLFTPM2_DEV* dev, WOLFTPM2_KEY* srk,
    WOLFTPM2_KEYBLOB* key, const byte digest[32], byte* sig, int* sigSz)
{
    int rc = wolfTPM2_LoadKey(dev, key, &srk->handle);
    if (rc == 0)
        rc = sign_and_verify(dev, (WOLFTPM2_KEY*)key, digest, sig, sigSz);
    wolfTPM2_UnloadHandle(dev, &key->handle);
    return rc;
}

static int one_handshake(WOLFTPM2_DEV* dev, WOLFTPM2_KEY* srk,
    WOLFTPM2_KEYBLOB keys[KEY_COUNT],
    word32 trial, double* elapsed, byte savedCtDrB[CT_SZ],
    byte savedDrSecret[SS_SZ])
{
    byte ctSj[CT_SZ], ctSi[CT_SZ], ctE[CT_SZ], ctDsi[CT_SZ], ctDsj[CT_SZ];
    SecretPair sj, si, eph, dsi, dsj;
    byte ctx[32], preA[32], preB[32], ratchetA[32], ratchetB[32];
    byte kmjA[32], kmjB[32], kmiA[32], kmiB[32], kcA[32], kcB[32];
    byte tauJ[32], tauJCheck[32], tauI[32], tauICheck[32];
    byte gammaJ[32], gammaCheck[32], finalA[32], finalB[32];
    byte sig[SIG_CAP];
    int sigSz = sizeof(sig);
    int rc;
    double start = now_ms();

    XMEMSET(&sj, 0, sizeof(sj)); XMEMSET(&si, 0, sizeof(si));
    XMEMSET(&eph, 0, sizeof(eph)); XMEMSET(&dsi, 0, sizeof(dsi));
    XMEMSET(&dsj, 0, sizeof(dsj));

    /* M1: A encapsulates to B's static key. */
    rc = kem_exchange_blob(dev, srk, &keys[K_STATIC_B], ctSj, &sj);
    /* M2: B encapsulates to A's ephemeral, static, and DR public keys. */
    if (rc == 0) rc = kem_exchange_blob(dev, srk,
        &keys[K_EPHEMERAL_A], ctE, &eph);
    if (rc == 0) rc = kem_exchange_blob(dev, srk,
        &keys[K_STATIC_A], ctSi, &si);
    if (rc == 0) rc = kem_exchange_blob(dev, srk,
        &keys[K_DR_A], ctDsi, &dsi);
    if (rc == 0) rc = make_context(trial, ctSj, ctE, ctSi, ctDsi, ctx);

    /* Endpoint-local Kpre calculations use the corresponding halves. */
    if (rc == 0) rc = derive_pre(ctx, sj.enc, si.dec, eph.dec, preA);
    if (rc == 0) rc = derive_pre(ctx, sj.dec, si.enc, eph.enc, preB);
    if (rc == 0 && XMEMCMP(preA, preB, 32) != 0) rc = TPM_RC_FAILURE;
    if (rc == 0) rc = labeled_hash("Kmj", preA, 32, kmjA);
    if (rc == 0) rc = labeled_hash("Kmj", preB, 32, kmjB);
    if (rc == 0) rc = labeled_hash("Kmi", preA, 32, kmiA);
    if (rc == 0) rc = labeled_hash("Kmi", preB, 32, kmiB);
    if (rc == 0) rc = labeled_hash("Kc", preA, 32, kcA);
    if (rc == 0) rc = labeled_hash("Kc", preB, 32, kcB);
    if (rc == 0) rc = make_tag(kmjB, "M2/responder", ctx, tauJ);
    if (rc == 0) rc = make_tag(kmjA, "M2/responder", ctx, tauJCheck);
    if (rc == 0 && XMEMCMP(tauJ, tauJCheck, TAG_SZ) != 0)
        rc = TPM_RC_FAILURE;

    /* Optional signature-mode check: B signs the authenticated M1-M2 digest. */
    if (rc == 0) rc = sign_and_verify_blob(dev, srk,
        &keys[K_SIGN_B], ctx, sig, &sigSz);
    if (rc == 0 && sigSz != 3309) rc = TPM_RC_FAILURE;

    /* M3: A encapsulates to B's DR key and authenticates the flight. */
    if (rc == 0) rc = kem_exchange_blob(dev, srk,
        &keys[K_DR_B], ctDsj, &dsj);
    if (rc == 0) rc = make_tag(kmiA, "M3/initiator", ctx, tauI);
    if (rc == 0) rc = make_tag(kmiB, "M3/initiator", ctx, tauICheck);
    if (rc == 0 && XMEMCMP(tauI, tauICheck, TAG_SZ) != 0)
        rc = TPM_RC_FAILURE;

    /* Both peers independently fast-forward a common lineage to epoch 5,
     * then adopt e'=max(0,5)+1=6 after M4 confirmation. */
    if (rc == 0) rc = ratchet_to_epoch5(ratchetA);
    if (rc == 0) rc = ratchet_to_epoch5(ratchetB);
    if (rc == 0) rc = derive_final(preA, ratchetA,
        dsi.dec, dsj.enc, ctx, finalA);
    if (rc == 0) rc = derive_final(preB, ratchetB,
        dsi.enc, dsj.dec, ctx, finalB);
    if (rc == 0 && XMEMCMP(finalA, finalB, 32) != 0)
        rc = TPM_RC_FAILURE;

    /* M4: responder key confirmation. */
    if (rc == 0) rc = make_tag(kcB, "M4/confirm", finalB, gammaJ);
    if (rc == 0) rc = make_tag(kcA, "M4/confirm", finalA, gammaCheck);
    if (rc == 0 && XMEMCMP(gammaJ, gammaCheck, TAG_SZ) != 0)
        rc = TPM_RC_FAILURE;

    if (rc == 0 && trial == 0) {
        XMEMCPY(savedCtDrB, ctDsj, CT_SZ);
        XMEMCPY(savedDrSecret, dsj.enc, SS_SZ);
    }
    *elapsed = now_ms() - start;

    wc_ForceZero(&sj, sizeof(sj)); wc_ForceZero(&si, sizeof(si));
    wc_ForceZero(&eph, sizeof(eph)); wc_ForceZero(&dsi, sizeof(dsi));
    wc_ForceZero(&dsj, sizeof(dsj)); wc_ForceZero(preA, sizeof(preA));
    wc_ForceZero(preB, sizeof(preB)); wc_ForceZero(finalA, sizeof(finalA));
    wc_ForceZero(finalB, sizeof(finalB));
    return rc;
}

int main(void)
{
    WOLFTPM2_DEV dev;
    WOLFTPM2_KEY srk;
    WOLFTPM2_KEYBLOB keys[KEY_COUNT];
    WOLFTPM2_KEYBLOB reloadCopy;
    byte ctDrB[CT_SZ], expectedDr[SS_SZ], gotDr[SS_SZ];
    byte tamperedDigest[32], signature[SIG_CAP];
    double samples[TRIALS], sorted[TRIALS];
    int gotDrSz, sigSz, rc, negRc, i;

    XMEMSET(&dev, 0, sizeof(dev)); XMEMSET(&srk, 0, sizeof(srk));
    XMEMSET(keys, 0, sizeof(keys)); XMEMSET(&reloadCopy, 0, sizeof(reloadCopy));

    printf("GT-R / TPM 2.0 v1.85 PQC integration experiment\n");
    printf("transport=mssim, TPM=separate fwTPM process, trials=%d\n", TRIALS);

    rc = wolfTPM2_Init(&dev, TPM2_IoCb, NULL);
    if (rc != 0) goto exit;
    rc = wolfTPM2_CreateSRK(&dev, &srk, TPM_ALG_RSA, NULL, 0);
    if (rc != 0) goto exit;

    for (i = 0; i < 5 && rc == 0; i++) {
        rc = create_mlkem_child(&dev, &srk, &keys[i]);
        if (rc == 0) wolfTPM2_UnloadHandle(&dev, &keys[i].handle);
    }
    for (i = 5; i < KEY_COUNT && rc == 0; i++) {
        rc = create_sign_child(&dev, &srk, &keys[i]);
        if (rc == 0) wolfTPM2_UnloadHandle(&dev, &keys[i].handle);
    }
    if (rc != 0) goto exit;

    printf("keys: 5 distinct ML-KEM-768 + 2 distinct Hash-ML-DSA-65 loaded\n");
    printf("private representation: parent-wrapped blobs only; no plaintext private field\n");
    for (i = 0; i < KEY_COUNT; i++) {
        if (keys[i].priv.size == 0) {
            printf("ERROR: child key %d has no parent-wrapped private blob\n", i);
            rc = TPM_RC_FAILURE;
            goto exit;
        }
    }

    for (i = 0; i < TRIALS; i++) {
        rc = one_handshake(&dev, &srk, keys, (word32)i, &samples[i],
            ctDrB, expectedDr);
        if (rc != 0) goto exit;
    }
    XMEMCPY(sorted, samples, sizeof(samples));
    qsort(sorted, TRIALS, sizeof(sorted[0]), cmp_double);
    printf("M1-M4: %d/%d accepted; delta=5; converged epoch=6; session keys match\n",
        TRIALS, TRIALS);
    printf("authentication: M2/M3 MACs + M4 confirmation + ML-DSA transcript check passed\n");
    printf("latency (software fTPM loopback, key creation excluded): median=%.3f ms, p95=%.3f ms\n",
        (sorted[4] + sorted[5]) / 2.0, sorted[9]);
    printf("primitive means: ML-KEM encap=%.3f ms (%u), decap=%.3f ms (%u); "
           "Hash-ML-DSA sign=%.3f ms (%u), verify=%.3f ms (%u)\n",
        gEncapMs / gEncapCount, gEncapCount,
        gDecapMs / gDecapCount, gDecapCount,
        gSignMs / gSignCount, gSignCount,
        gVerifyMs / gVerifyCount, gVerifyCount);

    /* Negative transcript test: a signature must not verify a changed digest. */
    XMEMSET(tamperedDigest, 0x3c, sizeof(tamperedDigest));
    sigSz = sizeof(signature);
    rc = wolfTPM2_LoadKey(&dev, &keys[K_SIGN_A], &srk.handle);
    if (rc != 0) goto exit;
    rc = wolfTPM2_SignDigest(&dev, (WOLFTPM2_KEY*)&keys[K_SIGN_A],
        tamperedDigest, sizeof(tamperedDigest), NULL, 0, signature, &sigSz);
    if (rc != 0) {
        wolfTPM2_UnloadHandle(&dev, &keys[K_SIGN_A].handle);
        goto exit;
    }
    tamperedDigest[0] ^= 1;
    {
        TPMT_TK_VERIFIED ticket;
        XMEMSET(&ticket, 0, sizeof(ticket));
        negRc = wolfTPM2_VerifyDigestSignature(&dev,
            (WOLFTPM2_KEY*)&keys[K_SIGN_A], tamperedDigest,
            sizeof(tamperedDigest), signature, sigSz, NULL, 0, &ticket);
        if (negRc == 0 && ticket.tag == TPM_ST_DIGEST_VERIFIED) {
            printf("ERROR: tampered transcript signature accepted\n");
            rc = TPM_RC_FAILURE;
            goto exit;
        }
    }
    wolfTPM2_UnloadHandle(&dev, &keys[K_SIGN_A].handle);
    printf("negative transcript: altered digest rejected\n");

    /* Flush + reload proves the parent-wrapped blob restores the same child.
     * Then destroy that blob and show that the flushed handle cannot be used
     * and the child cannot be reloaded from the destroyed representation. */
    XMEMCPY(&reloadCopy, &keys[K_DR_B], sizeof(reloadCopy));
    rc = wolfTPM2_LoadKey(&dev, &keys[K_DR_B], &srk.handle);
    if (rc != 0) goto exit;
    {
        TPM_HANDLE staleHandle = keys[K_DR_B].handle.hndl;
        wolfTPM2_UnloadHandle(&dev, &keys[K_DR_B].handle);
        keys[K_DR_B].handle.hndl = staleHandle;
    }
    gotDrSz = sizeof(gotDr);
    negRc = wolfTPM2_Decapsulate(&dev, (WOLFTPM2_KEY*)&keys[K_DR_B],
        ctDrB, sizeof(ctDrB), gotDr, &gotDrSz);
    if (negRc == 0) {
        printf("ERROR: flushed DR handle remained usable\n");
        rc = TPM_RC_FAILURE;
        goto exit;
    }
    keys[K_DR_B].handle.hndl = 0;
    rc = wolfTPM2_LoadKey(&dev, &reloadCopy, &srk.handle);
    if (rc != 0) goto exit;
    gotDrSz = sizeof(gotDr);
    rc = wolfTPM2_Decapsulate(&dev, (WOLFTPM2_KEY*)&reloadCopy,
        ctDrB, sizeof(ctDrB), gotDr, &gotDrSz);
    if (rc != 0 || gotDrSz != SS_SZ ||
            XMEMCMP(gotDr, expectedDr, SS_SZ) != 0) {
        rc = TPM_RC_FAILURE;
        goto exit;
    }
    printf("reload: flushed DR child restored from parent-wrapped blob and decapsulated correctly\n");

    wolfTPM2_UnloadHandle(&dev, &reloadCopy.handle);
    wc_ForceZero(reloadCopy.priv.buffer, sizeof(reloadCopy.priv.buffer));
    reloadCopy.priv.size = 0;
    negRc = wolfTPM2_LoadKey(&dev, &reloadCopy, &srk.handle);
    if (negRc == 0) {
        printf("ERROR: destroyed DR private blob unexpectedly reloaded\n");
        rc = TPM_RC_FAILURE;
        goto exit;
    }
    printf("deletion path: flushed handle rejected; destroyed wrapped blob could not reload\n");
    printf("RESULT: PASS\n");
    rc = 0;

exit:
    if (rc != 0)
        printf("RESULT: FAIL rc=0x%x (%s)\n", rc, wolfTPM2_GetRCString(rc));
    for (i = 0; i < KEY_COUNT; i++)
        wolfTPM2_UnloadHandle(&dev, &keys[i].handle);
    wolfTPM2_UnloadHandle(&dev, &reloadCopy.handle);
    wolfTPM2_UnloadHandle(&dev, &srk.handle);
    wolfTPM2_Cleanup(&dev);
    wc_ForceZero(gotDr, sizeof(gotDr));
    wc_ForceZero(expectedDr, sizeof(expectedDr));
    return rc == 0 ? 0 : 1;
}

#else
int main(void)
{
    printf("Required TPM 2.0 v1.85 PQC features were not compiled.\n");
    return 1;
}
#endif
