# TPM 2.0 v1.85 PQC GT-R integration experiment

This directory contains the GT-R-shaped four-flight integration harness used
for the software-fTPM result reported in the paper. It is a functional command-
path experiment, not a physical hardware-TPM or DDIL-radio benchmark.

## Pinned sources

- wolfSSL commit: `e941761acef7058ca8cbd4a099f6384010e2cf76`
- wolfTPM commit: `cd6ae53be56f449a67105773adfb16d51843af69`
- TPM interface: TPM 2.0 v1.85 software fTPM over local `mssim`
- Algorithms: ML-KEM-768 and Hash-ML-DSA-65/SHA-256
- Host used for the recorded result: macOS arm64

## What the test checks

- Five distinct ML-KEM-768 child keys and two distinct Hash-ML-DSA-65 child
  keys are created by the fTPM and retained outside it only as public objects
  and parent-wrapped private blobs.
- M1-M4 is exercised for `(e_i,e_j)=(0,5)`, giving `delta=5` and `e'=6`.
- Initiator and responder independently derive the same pre-key and final
  session key.
- M2/M3 MACs, M4 confirmation, and a Hash-ML-DSA transcript signature verify.
- A modified transcript digest is rejected.
- A flushed DR-key handle is rejected, the parent-wrapped key reloads, and
  reload fails after destruction of that wrapped blob.

The harness keeps no plaintext private-key coefficient field in the client.
TPM command outputs such as ML-KEM shared secrets are returned to endpoint
software because they feed the GT-R key schedule.

## Build

The commands below use an arbitrary work directory represented by `$WORK`.
Do not reuse system variables such as `$HOME` for this purpose.

```sh
mkdir -p "$WORK"
cd "$WORK"
git clone https://github.com/wolfSSL/wolfssl.git
git -C wolfssl checkout e941761acef7058ca8cbd4a099f6384010e2cf76

cmake -S wolfssl -B wolfssl/build-pqc \
  -DBUILD_SHARED_LIBS=OFF \
  -DCMAKE_INSTALL_PREFIX="$WORK/wolfpqc-prefix" \
  -DWOLFSSL_TPM=yes \
  -DWOLFSSL_PKCALLBACKS=yes \
  -DWOLFSSL_KEYGEN=yes \
  -DWOLFSSL_MLKEM=yes \
  -DWOLFSSL_MLDSA=yes \
  -DWOLFSSL_EXPERIMENTAL=yes \
  -DWOLFSSL_HARDEN=yes
cmake --build wolfssl/build-pqc --target install -j4

git clone https://github.com/wolfSSL/wolfTPM.git
git -C wolfTPM checkout cd6ae53be56f449a67105773adfb16d51843af69
cp gtr_v185_integration.c wolfTPM/examples/pqc/gtr_v185_integration.c
```

Add the single line in `CMakeLists.target.txt` next to the other
`add_tpm_example(...)` calls in wolfTPM's top-level `CMakeLists.txt`, then run:

```sh
cmake -S wolfTPM -B wolfTPM/build-pqc \
  -DBUILD_SHARED_LIBS=OFF \
  -DWOLFTPM_FWTPM=yes \
  -DWOLFTPM_INTERFACE=SWTPM \
  -DWITH_WOLFSSL="$WORK/wolfpqc-prefix" \
  -DCMAKE_C_FLAGS="-DWOLFTPM_V185 -DWOLFTPM_PQC" \
  -DCMAKE_EXE_LINKER_FLAGS="-framework Security -framework CoreFoundation"
cmake --build wolfTPM/build-pqc \
  --target fwtpm_server fwtpm_unit_test gtr_v185_integration -j4
```

The two framework linker flags are macOS-specific. On Linux, omit
`CMAKE_EXE_LINKER_FLAGS`.

## Run

Start the fTPM server in one terminal:

```sh
cd "$WORK/wolfTPM/build-pqc"
./bin/fwtpm_server
```

Run the test in another terminal:

```sh
cd "$WORK/wolfTPM/build-pqc"
./bin/fwtpm_unit_test
./bin/gtr_v185_integration
```

The integration process exits with status 0 only when all positive and
negative checks pass. The recorded output is in
`../results_raw/fwtpm_v185/latest.txt`; structured values are in
`../results_raw/fwtpm_v185/latest.json`. Paper macros are in
`../results/reauth_fwtpm185_macros.tex`.

## Scope

The measured latency shares the host CPU and uses a local socket. It must not be
reported as discrete hardware-TPM latency or UAV/UGV radio latency. The blob-
destruction check establishes functional loss of reload capability after a
flush; it is not evidence of physical media erasure or invasive-attack
resistance.
