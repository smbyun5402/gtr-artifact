#!/usr/bin/env python3
# Full-handshake wall time per mode (includes TCP setup and process spawn;
# the spawn overhead is constant across modes, so mode deltas are valid).
import subprocess, sys, time, statistics, csv, os, math

PEER = sys.argv[1]
COND = sys.argv[2]          # label of the current netem condition
N = int(sys.argv[3]) if len(sys.argv) > 3 else 30

MODES = [("legacy", 4431, "X25519", "ec_cert.pem"),
         ("hybrid", 4432, "X25519MLKEM768", "ec_cert.pem"),
         ("pqc", 4433, "MLKEM768", "mldsa_cert.pem")]

os.makedirs("/qartz/results", exist_ok=True)
out = open(f"/qartz/results/tls_{COND}.csv", "w", newline="")
w = csv.writer(out)
w.writerow(["condition", "mode", "n_ok", "mean_ms", "p50_ms", "p95_ms"])

for mode, port, groups, cert in MODES:
    times = []
    for i in range(N):
        t0 = time.perf_counter()
        r = subprocess.run(
            ["openssl", "s_client", "-connect", f"{PEER}:{port}",
             "-groups", groups, "-CAfile", f"/qartz/certs/{cert}",
             "-tls1_3", "-brief"],
            input=b"", capture_output=True, timeout=30)
        dt = (time.perf_counter() - t0) * 1e3
        if b"Protocol version: TLSv1.3" in r.stderr:
            times.append(dt)
    if times:
        s = sorted(times)
        w.writerow([COND, mode, len(times), f"{statistics.mean(times):.1f}",
                    f"{s[len(s)//2]:.1f}",
                    f"{s[math.ceil(len(s)*0.95)-1]:.1f}"])
        print(COND, mode, len(times), f"mean {statistics.mean(times):.1f} ms",
              flush=True)
    else:
        w.writerow([COND, mode, 0, "nan", "nan", "nan"])
        print(COND, mode, "ALL FAILED", flush=True)
out.close()
