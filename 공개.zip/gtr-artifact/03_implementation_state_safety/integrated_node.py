#!/usr/bin/env python3
# Integrated run on the real stack: availability comes from real pings
# through netem, integrity evidence from real swtpm quotes; the Q-ARTZ
# estimator/controller runs unmodified. The harness scripts the link
# timeline: clean -> total blackout -> recovery.
import subprocess, time, os, csv, sys
import numpy as np
from qartz_sim import QARTZ, Trace, DIMS

PEER = sys.argv[1]
DUR = int(sys.argv[2]) if len(sys.argv) > 2 else 210   # seconds
STEP = 0.2                                             # 5 steps/s
N = int(DUR / STEP)

# TPM setup (same as bench_tpm.sh, state prepared by harness)
env = dict(os.environ, TPM2TOOLS_TCTI="swtpm:port=2321")

def tpm_quote():
    nonce = os.urandom(16).hex()
    t0 = time.perf_counter()
    cmd = ["tpm2_quote", "-c", "ak.ctx", "-l", "sha256:0,1,2",
           "-q", nonce, "-m", "/tmp/q.msg", "-s", "/tmp/q.sig",
           "-o", "/tmp/q.pcr", "-g", "sha256"]
    r = subprocess.run(cmd, capture_output=True, env=env, cwd="/qartz")
    if r.returncode:   # self-heal transient-slot exhaustion
        subprocess.run(["tpm2_flushcontext", "-t"], capture_output=True,
                       env=env, cwd="/qartz")
        r = subprocess.run(cmd, capture_output=True, env=env, cwd="/qartz")
    if r.returncode:
        return False, (time.perf_counter() - t0) * 1e3
    verify = subprocess.run(
        ["tpm2_checkquote", "-u", "ak_pem.pub", "-m", "/tmp/q.msg",
         "-s", "/tmp/q.sig", "-f", "/tmp/q.pcr", "-g", "sha256",
         "-q", nonce], capture_output=True, env=env, cwd="/qartz")
    return verify.returncode == 0, (time.perf_counter() - t0) * 1e3

def ping_ok():
    try:
        r = subprocess.run(["ping", "-c", "1", "-W", "1", PEER],
                           capture_output=True, timeout=STEP * 0.70)
        return r.returncode == 0
    except subprocess.TimeoutExpired:
        return False

rng = np.random.default_rng(7)
Z = lambda: np.zeros(N)
tr = Trace(T=N, a_true=Z(), outage=np.zeros(N, bool),
           compromised=np.zeros(N, bool),
           misuse=np.clip(0.03 + 0.03 * np.abs(rng.standard_normal(N)), 0, 1),
           ev_arrive={d: np.zeros(N, bool) for d in DIMS},
           ev_q={d: np.clip(0.92 + 0.04 * rng.standard_normal(N), 0, 1)
                 for d in DIMS},
           ev_assure={"integrity": 0.95, "runtime": 0.70, "provenance": 0.85},
           chi_soft=np.clip(0.95 + 0.03 * rng.standard_normal(N), 0, 1),
           hardfail=np.zeros(N, int),
           res_reported=np.full(N, 0.8), res_true=np.full(N, 0.8),
           peer_legacy_only=np.zeros(N, bool),
           pa_reachable=np.ones(N, bool), waiver_kind=[None] * N,
           secrecy_critical=False, attack_window=None)

q = QARTZ(rng=np.random.default_rng(9))
base = {"integrity": 1 / 50.0, "runtime": 1 / 5.0, "provenance": 1 / 80.0}
link = 1.0
rows = []
t_start = time.monotonic()
deadline = t_start
for t in range(N):
    ok = ping_ok()
    link = 0.8 * link + 0.2 * (1.0 if ok else 0.0)
    tr.a_true[t] = link
    for d in DIMS:
        p = base[d] * min(1.0, link / 0.8)
        if d == "integrity":
            # real attestation evidence: an actual swtpm quote when due
            if rng.random() < p:
                got, ms = tpm_quote()
                tr.ev_arrive[d][t] = got and ok
        else:
            tr.ev_arrive[d][t] = rng.random() < p
    d = q.step(tr, t)
    rows.append([round(time.monotonic() - t_start, 3), round(link, 3),
                 round(min(d["rho"].values()), 3),
                 round(np.mean(list(d["T"].values())), 3), d["profile"],
                 d["mode"], int(d["allow"])])
    deadline += STEP
    lag = deadline - time.monotonic()
    if lag > 0:
        time.sleep(lag)
    else:
        # Drop accumulated scheduling debt: never replay missed control steps
        # as a zero-time burst after the link recovers.
        deadline = time.monotonic()

with open("/qartz/results/integrated.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["wall_s", "a", "min_rho", "mean_T", "profile", "mode", "allow"])
    w.writerows(rows)
print("integrated run done:", len(rows), "steps")
