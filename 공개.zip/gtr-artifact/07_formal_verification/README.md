# Symbolic models

The directory contains two independent protocol analyses. `resync.spthy`
models the Q-ARTZ-Resync state-agreement/commit core. The `gtr*` and ProVerif
files model the earlier GT-R pre-confirmation key-exchange core. A result for
one model is not evidence for the other.

## Q-ARTZ-Resync Tamarin result

`resync.spthy` models fresh, role-labelled SST signatures over both run nonces
and the advertised state digest; deterministic ordered construction of the
candidate post-state and `stateDigest`; transcript- and state-bound,
role-separated two-sided commits; linear per-session counter reservation; and
an abort tombstone that rejects a delayed valid M4 without adopting it.

With Tamarin 1.12.0,

```sh
tamarin-prover --prove --auto-sources --quiet -d=60 resync.spthy
```

all 14 lemmas verify with all wellformedness checks successful. Two
`exists-trace` lemmas witness a complete two-sided adoption and a separate
abort followed by delayed-M4 rejection. The remaining lemmas establish SST
origin/fresh-run binding, candidate and digest agreement, commit
authentication in both directions, adopted-state agreement, per-role counter
single use, replay provenance, and abort/non-adoption. The recorded result is
`resync_tamarin_result.txt`.

This is an unbounded-session Dolev--Yao analysis under uncompromised
attestation keys and base session secret. It deliberately abstracts `max+1`
counter arithmetic as the deterministic constructor `next_ctr(ci,cr)` and
allows one active reconnect attempt per fresh `sid`. It does not verify the
full four-way classifier, PA bundles, chain/merge proof semantics, TPM
atomicity or crash recovery, compromise, full re-attestation, or post-commit
AEAD record processing. Those claims must not be attributed to this result.

## Q-ARTZ-Resync bounded explicit-state result

`resync_statecheck.py` is an independent executable finite abstraction of two
endpoints, M1--M4 plus the first state-bound record, durable
`PRE`/`CANDIDATE`/`HALF_OPEN`/`OPEN`/`ABORT`/`QUARANTINE` records,
persist-before-send, CAS reservations, abort tombstones, and a reorderable
network. Run from the repository root with:

```sh
python formal/resync_statecheck.py --self-test --suite --mutants \
  --output formal/resync_statecheck_result.txt \
  --macros-output formal/resync_statecheck_macros.tex
```

The recorded fixed-point suite explored three separate campaigns: (1) one run
with one drop, duplicate, and archived replay; (2) one run with two sends per
stage, one drop, and one crash/restart; and (3) two potentially concurrent
runs for CAS conflicts. In total it reached 425,763 states and 1,952,660
transitions to maximum BFS depth 25. All 2,964 bounded terminal states were
either matching OPEN (824) or safe abort/quarantine (2,140), with zero
stranded terminals, depth cuts, or invariant violations. All four unit tests
passed, and intentional no-CAS, forgotten-tombstone, no-commit-binding,
no-candidate-binding, and no-decision-binding mutants were detected with
minimal counterexamples.
Detailed per-campaign bounds, crash-cutpoint transition counts, and witnesses
for success, delayed-M4 rejection, M4-loss retry, half-open crash recovery,
stale replay rejection, and concurrent CAS rejection are in
`resync_statecheck_result.txt`. `resync_statecheck_macros.tex` exposes the
exact aggregate counts for LaTeX without hardcoding them.

Completeness applies only to each printed finite campaign separately; the
three fault budgets are not jointly cross-multiplied. Perfect symbolic tags
abstract signatures and MACs. The checker does not establish unbounded
liveness, cryptographic security, the full PA classifier or chain proofs, TPM
behavior, parser memory safety, AEAD implementation correctness, or physical
UAV/UGV behavior.

## GT-R Tamarin result

`gtr.spthy` models the uncompromised pre-confirmation static-KEM
message-binding core. With Tamarin 1.12.0,

```sh
tamarin-prover --prove --auto-sources gtr.spthy
```

verifies all five lemmas for unbounded symbolic sessions: executability, key
secrecy, agreement in both directions, and responder injective agreement. The
recorded output is `gtr_tamarin_result.txt`.

The abstraction intentionally excludes epochs, the complete hybrid schedule,
M4 adoption confirmation, compromise, rollback, and crash semantics. Those
mechanisms are addressed by the computational analysis and are not established
by the Tamarin result.

## Files

- `resync.spthy`: verified Q-ARTZ-Resync state/commit core.
- `resync_tamarin_result.txt`: Resync prover version, command, and results.
- `resync_statecheck.py`: bounded explicit-state checker and self-tests.
- `resync_statecheck_result.txt`: authoritative campaign bounds, counts,
  witnesses, and mutant counterexamples.
- `resync_statecheck_macros.tex`: auto-generated aggregate LaTeX counts.
- `gtr.spthy`: verified Tamarin abstraction.
- `gtr_tamarin_result.txt`: prover version, command, and lemma results.
- `gtr.pv`: exploratory full ProVerif encoding.
- `gtr_core.pv`, `gtr_bounded.pv`, `gtr_min.pv`: progressively reduced
  ProVerif encodings.
- `t_sanity.pv`: installation sanity check.

## GT-R ProVerif status

The supplied ProVerif 2.05 encodings did not reach a result within the tested
resource limits. They are retained as exploratory artifacts and are not cited
as verification evidence. The terminating `t_sanity.pv` check confirms the
local ProVerif installation.

## Environment

The successful Tamarin run used the prebuilt Linux release with Maude and
Graphviz under WSL2 Ubuntu. The ProVerif runs used the CLI build installed from
the opam source package.
