#!/usr/bin/env python3
"""Bounded explicit-state checker for the Q-ARTZ-Resync commit protocol.

This is an executable finite abstraction, not a cryptographic proof and not an
unbounded liveness proof.  It models two fixed roles, durable protocol records,
an adversarially scheduled network, and at most two reconnect runs.  Perfect
symbolic tags stand in for signatures/MACs; the interesting state is the
persist-before-send/CAS/commit/recovery discipline.

The default command performs the complete reachable-state search under the
printed bounds and writes a human-readable certificate.  ``--self-test`` also
runs small intentional-mutant checks to make sure the asserted invariants are
capable of finding the mistakes they are meant to exclude.
"""

from __future__ import annotations

import argparse
import collections
import dataclasses
import datetime as _dt
import pathlib
import sys
import time
import unittest
from dataclasses import dataclass, replace
from typing import Dict, Iterable, Iterator, NamedTuple, Optional, Sequence


PRE, CANDIDATE, HALF_OPEN, OPEN, ABORT, QUARANTINE = range(6)
PHASE_NAME = {
    PRE: "PRE",
    CANDIDATE: "CANDIDATE",
    HALF_OPEN: "HALF_OPEN",
    OPEN: "OPEN",
    ABORT: "ABORT",
    QUARANTINE: "QUARANTINE",
}

M1, M2, M3, M4, RECORD = range(1, 6)
MSG_NAME = {M1: "M1", M2: "M2", M3: "M3", M4: "M4", RECORD: "RECORD"}

V_DIVERGENT_OPEN = 1 << 0
V_OPEN_WITHOUT_DURABLE_COMMIT = 1 << 1
V_ABORTED_ADOPTED = 1 << 2
V_COUNTER_REUSED = 1 << 3
V_TICKET_REUSED = 1 << 4
V_SEQUENCE_REUSED = 1 << 5
V_STALE_REPLAY_OPENED = 1 << 6
V_BAD_BINDING_ACCEPTED = 1 << 7
V_NONMONOTONE_RESUME = 1 << 8
V_ABORT_RESERVATION_LOST = 1 << 9

VIOLATION_NAME = {
    V_DIVERGENT_OPEN: "no divergent OPEN",
    V_OPEN_WITHOUT_DURABLE_COMMIT: "OPEN has its durable candidate/commit",
    V_ABORTED_ADOPTED: "aborted candidate is never adopted",
    V_COUNTER_REUSED: "target counter is single-use",
    V_TICKET_REUSED: "input ticket is single-use",
    V_SEQUENCE_REUSED: "target sequence number is single-use",
    V_STALE_REPLAY_OPENED: "stale/tombstoned replay cannot open",
    V_BAD_BINDING_ACCEPTED: "candidate/decision/commit binding is checked",
    V_NONMONOTONE_RESUME: "successful Resume advances c* and q*",
    V_ABORT_RESERVATION_LOST: "abort preserves c*/q*/ticket reservations",
}


class Msg(NamedTuple):
    kind: int
    run: int
    candidate: int
    ci: int
    cr: int
    qi: int
    qr: int
    ticket: int
    decision: int
    tag: int


class Envelope(NamedTuple):
    msg: Msg
    adversarial_replay: int = 0


@dataclass(frozen=True, slots=True)
class Endpoint:
    alive: int
    phase: int
    active_run: int
    current_candidate: int
    counter: int
    sequence: int
    ticket: int
    durable_candidate: int
    durable_context: int
    base_ci: int
    base_cr: int
    base_qi: int
    base_qr: int
    input_ticket: int
    target_counter: int
    target_sequence: int
    decision: int
    aborted_candidates: int
    counter_uses: tuple[int, ...]
    sequence_uses: tuple[int, ...]
    ticket_uses: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class State:
    initiator: Endpoint
    responder: Endpoint
    started: int
    completed: int
    m1_sends: tuple[int, ...]
    m3_sends: tuple[int, ...]
    m4_sends: tuple[int, ...]
    record_sends: tuple[int, ...]
    network: tuple[Envelope, ...]
    history: tuple[Msg, ...]
    drops: int
    duplicates: int
    replays: int
    crashes: int
    injections: int
    recovery_flags: int = 0
    fault_flags: int = 0
    violation_flags: int = 0


@dataclass(frozen=True, slots=True)
class Bounds:
    runs: int = 2
    max_sends: int = 2
    drops: int = 1
    duplicates: int = 1
    replays: int = 1
    crashes: int = 1
    max_network: int = 6
    depth_limit: int = 0


@dataclass(frozen=True, slots=True)
class Mutation:
    no_cas: bool = False
    forget_tombstone_on_abort: bool = False
    no_commit_binding: bool = False
    no_candidate_binding: bool = False
    no_decision_binding: bool = False

    @property
    def name(self) -> str:
        names = [f.name for f in dataclasses.fields(self) if getattr(self, f.name)]
        return "+".join(names) if names else "none"


@dataclass
class SearchResult:
    bounds: Bounds
    mutation: Mutation
    states: int
    transitions: int
    max_depth: int
    terminal_states: int
    terminal_success: int
    terminal_safe_abort: int
    terminal_stranded: int
    cut_states: int
    crash_cut_states: int
    crash_cutpoints: Dict[str, int]
    duplicate_steps: int
    replay_steps: int
    reorder_choices: int
    violations: Dict[int, list[str]]
    witnesses: Dict[str, list[str]]
    deterministic_recovery: bool
    acyclic: bool

    @property
    def passed(self) -> bool:
        return not self.violations and self.terminal_stranded == 0 and self.cut_states == 0


def _bit(run: int) -> int:
    return 1 << run


def _replace_tuple(values: tuple[int, ...], at: int, value: int) -> tuple[int, ...]:
    out = list(values)
    out[at] = value
    return tuple(out)


def _add_network(network: tuple[Envelope, ...], env: Envelope) -> tuple[Envelope, ...]:
    return tuple(sorted(network + (env,)))


def _add_history(history: tuple[Msg, ...], msg: Msg) -> tuple[Msg, ...]:
    return tuple(sorted(set(history + (msg,))))


def candidate_id(run: int, counter: int, sequence: int) -> int:
    # 0 is the genesis state; positive values bind the run and both targets.
    return 1 + run * 16 + counter * 4 + sequence


def context_id(candidate: int, ticket: int, decision: int) -> int:
    return candidate * 100 + ticket * 10 + decision


def tag_for(kind: int, candidate: int, ticket: int, decision: int) -> int:
    return kind * 100_000 + context_id(candidate, ticket, decision)


def fresh_endpoint(max_value: int) -> Endpoint:
    empty = (0,) * (max_value + 1)
    return Endpoint(
        alive=1,
        phase=PRE,
        active_run=-1,
        current_candidate=0,
        counter=0,
        sequence=0,
        ticket=0,
        durable_candidate=0,
        durable_context=0,
        base_ci=-1,
        base_cr=-1,
        base_qi=-1,
        base_qr=-1,
        input_ticket=-1,
        target_counter=-1,
        target_sequence=-1,
        decision=-1,
        aborted_candidates=0,
        counter_uses=empty,
        sequence_uses=empty,
        ticket_uses=empty,
    )


def initial_state(bounds: Bounds) -> State:
    # A successful run advances at most once per run.
    endpoint = fresh_endpoint(bounds.runs + 1)
    zeros = (0,) * bounds.runs
    return State(
        initiator=endpoint,
        responder=endpoint,
        started=0,
        completed=0,
        m1_sends=zeros,
        m3_sends=zeros,
        m4_sends=zeros,
        record_sends=zeros,
        network=(),
        history=(),
        drops=0,
        duplicates=0,
        replays=0,
        crashes=0,
        injections=0,
    )


def _stable(ep: Endpoint) -> bool:
    return ep.alive and ep.phase in (PRE, OPEN)


def _candidate_mask(candidate: int) -> int:
    return 0 if candidate <= 0 else 1 << candidate


def _reserve(values: tuple[int, ...], token: int, run: int, no_cas: bool) -> Optional[tuple[int, ...]]:
    owner = _bit(run)
    present = values[token]
    if present not in (0, owner) and not no_cas:
        return None
    # OR deliberately exposes reuse in the no-CAS mutant instead of hiding it.
    return _replace_tuple(values, token, present | owner)


def _durable_fingerprint(ep: Endpoint) -> tuple:
    return (
        ep.phase,
        ep.active_run,
        ep.current_candidate,
        ep.counter,
        ep.sequence,
        ep.ticket,
        ep.durable_candidate,
        ep.durable_context,
        ep.base_ci,
        ep.base_cr,
        ep.base_qi,
        ep.base_qr,
        ep.input_ticket,
        ep.target_counter,
        ep.target_sequence,
        ep.decision,
        ep.aborted_candidates,
        ep.counter_uses,
        ep.sequence_uses,
        ep.ticket_uses,
    )


def make_m1(state: State, run: int) -> Msg:
    i = state.initiator
    return Msg(M1, run, -1, i.counter, -1, i.sequence, -1, i.ticket, 1, 10_000 + run)


def make_m2(m1: Msg, r: Endpoint) -> Msg:
    # The symbolic SST binds both role-labelled snapshots and the decision.
    tag = 20_000 + m1.run * 100 + m1.ci * 10 + r.counter + m1.qi + r.sequence
    return Msg(M2, m1.run, -1, m1.ci, r.counter, m1.qi, r.sequence,
               r.ticket, 1, tag)


def make_m3(ep: Endpoint) -> Msg:
    return Msg(
        M3,
        ep.active_run,
        ep.durable_candidate,
        ep.base_ci,
        ep.base_cr,
        ep.base_qi,
        ep.base_qr,
        ep.input_ticket,
        ep.decision,
        tag_for(M3, ep.durable_candidate, ep.input_ticket, ep.decision),
    )


def make_m4(ep: Endpoint) -> Msg:
    return Msg(
        M4,
        ep.active_run,
        ep.durable_candidate,
        ep.base_ci,
        ep.base_cr,
        ep.base_qi,
        ep.base_qr,
        ep.input_ticket,
        ep.decision,
        tag_for(M4, ep.durable_candidate, ep.input_ticket, ep.decision),
    )


def make_record(ep: Endpoint) -> Msg:
    return Msg(
        RECORD,
        ep.active_run,
        ep.durable_candidate,
        ep.base_ci,
        ep.base_cr,
        ep.base_qi,
        ep.base_qr,
        ep.input_ticket,
        ep.decision,
        tag_for(RECORD, ep.durable_candidate, ep.input_ticket, ep.decision),
    )


def _emit(state: State, msg: Msg, send_field: str, run: int) -> State:
    sends = getattr(state, send_field)
    return replace(
        state,
        **{
            send_field: _replace_tuple(sends, run, sends[run] + 1),
            "network": _add_network(state.network, Envelope(msg, 0)),
            "history": _add_history(state.history, msg),
        },
    )


def _persist_candidate_i(state: State, msg: Msg, mutation: Mutation) -> Optional[State]:
    i = state.initiator
    stable_or_mutant = _stable(i) or (
        mutation.no_cas and i.alive and i.phase == CANDIDATE
    )
    if not stable_or_mutant or msg.run < 0 or msg.run >= len(state.m1_sends):
        return None
    if not (state.started & _bit(msg.run)) or state.completed & _bit(msg.run):
        return None
    if msg.kind != M2 or msg.ci != i.counter or msg.qi != i.sequence or msg.ticket != i.ticket:
        return None
    target_c = max(msg.ci, msg.cr) + 1
    target_q = max(msg.qi, msg.qr) + 1
    if target_c >= len(i.counter_uses) or target_q >= len(i.sequence_uses):
        return None
    cand = candidate_id(msg.run, target_c, target_q)
    cu = _reserve(i.counter_uses, target_c, msg.run, mutation.no_cas)
    qu = _reserve(i.sequence_uses, target_q, msg.run, mutation.no_cas)
    tu = _reserve(i.ticket_uses, msg.ticket, msg.run, mutation.no_cas)
    if cu is None or qu is None or tu is None:
        return None
    ctx = context_id(cand, msg.ticket, msg.decision)
    ni = replace(
        i,
        phase=CANDIDATE,
        active_run=msg.run,
        durable_candidate=cand,
        durable_context=ctx,
        base_ci=msg.ci,
        base_cr=msg.cr,
        base_qi=msg.qi,
        base_qr=msg.qr,
        input_ticket=msg.ticket,
        target_counter=target_c,
        target_sequence=target_q,
        decision=msg.decision,
        counter_uses=cu,
        sequence_uses=qu,
        ticket_uses=tu,
    )
    return replace(state, initiator=ni)


def _valid_m3(msg: Msg, r: Endpoint, mutation: Mutation) -> tuple[bool, bool]:
    target_c = max(msg.ci, msg.cr) + 1
    target_q = max(msg.qi, msg.qr) + 1
    expected_cand = candidate_id(msg.run, target_c, target_q)
    cand_ok = msg.candidate == expected_cand
    tag_ok = msg.tag == tag_for(M3, expected_cand, msg.ticket, msg.decision)
    snapshot_ok = (
        msg.cr == r.counter
        and msg.qr == r.sequence
        and msg.ticket == r.ticket
        and msg.decision == 1
    )
    accepted = snapshot_ok and (cand_ok or mutation.no_candidate_binding) and (
        tag_ok or mutation.no_commit_binding
    )
    binding_bad = accepted and not (cand_ok and tag_ok)
    return accepted, binding_bad


def _persist_half_open_r(state: State, msg: Msg, mutation: Mutation) -> Optional[State]:
    r = state.responder
    stable_or_mutant = _stable(r) or (
        mutation.no_cas and r.alive and r.phase == HALF_OPEN
    )
    if not stable_or_mutant or msg.run < 0 or msg.run >= len(state.m1_sends):
        return None
    if not (state.started & _bit(msg.run)) or state.completed & _bit(msg.run):
        return None
    valid, binding_bad = _valid_m3(msg, r, mutation)
    if not valid:
        return None
    target_c = max(msg.ci, msg.cr) + 1
    target_q = max(msg.qi, msg.qr) + 1
    if target_c >= len(r.counter_uses) or target_q >= len(r.sequence_uses):
        return None
    cu = _reserve(r.counter_uses, target_c, msg.run, mutation.no_cas)
    qu = _reserve(r.sequence_uses, target_q, msg.run, mutation.no_cas)
    tu = _reserve(r.ticket_uses, msg.ticket, msg.run, mutation.no_cas)
    if cu is None or qu is None or tu is None:
        return None
    # A no-candidate-binding mutant adopts the wire candidate.  This makes the
    # resulting disagreement observable instead of silently recomputing it.
    cand = msg.candidate if mutation.no_candidate_binding else candidate_id(msg.run, target_c, target_q)
    ctx = context_id(cand, msg.ticket, msg.decision)
    nr = replace(
        r,
        phase=HALF_OPEN,
        active_run=msg.run,
        durable_candidate=cand,
        durable_context=ctx,
        base_ci=msg.ci,
        base_cr=msg.cr,
        base_qi=msg.qi,
        base_qr=msg.qr,
        input_ticket=msg.ticket,
        target_counter=target_c,
        target_sequence=target_q,
        decision=msg.decision,
        counter_uses=cu,
        sequence_uses=qu,
        ticket_uses=tu,
    )
    flags = state.violation_flags | (V_BAD_BINDING_ACCEPTED if binding_bad else 0)
    return replace(state, responder=nr, violation_flags=flags)


def _matches_durable(msg: Msg, ep: Endpoint, kind: int, mutation: Mutation) -> tuple[bool, bool]:
    if msg.kind != kind or msg.run != ep.active_run:
        return False, False
    candidate_ok = msg.candidate == ep.durable_candidate
    decision_ok = msg.decision == ep.decision
    tag_ok = msg.tag == tag_for(kind, ep.durable_candidate, ep.input_ticket, ep.decision)
    accepted = (candidate_ok or mutation.no_candidate_binding) and (
        decision_ok or mutation.no_decision_binding
    ) and (
        tag_ok or mutation.no_commit_binding
    )
    return accepted, accepted and not (candidate_ok and decision_ok and tag_ok)


def _open_i(state: State, msg: Msg, replay: bool, mutation: Mutation) -> Optional[State]:
    i = state.initiator
    if not i.alive or i.phase != CANDIDATE:
        return None
    valid, binding_bad = _matches_durable(msg, i, M4, mutation)
    if not valid:
        return None
    was_stale = bool(i.aborted_candidates & _candidate_mask(msg.candidate)) or msg.run != i.active_run
    adopted = msg.candidate if mutation.no_candidate_binding else i.durable_candidate
    flags = state.violation_flags
    if binding_bad:
        flags |= V_BAD_BINDING_ACCEPTED
    if replay and was_stale:
        flags |= V_STALE_REPLAY_OPENED
    ni = replace(
        i,
        phase=OPEN,
        current_candidate=adopted,
        counter=i.target_counter,
        sequence=i.target_sequence,
        ticket=i.target_counter,
        durable_candidate=adopted,
        durable_context=context_id(adopted, i.input_ticket, i.decision),
    )
    return replace(state, initiator=ni, violation_flags=flags)


def _open_r(state: State, msg: Msg, replay: bool, mutation: Mutation) -> Optional[State]:
    r = state.responder
    if not r.alive or r.phase != HALF_OPEN:
        return None
    valid, binding_bad = _matches_durable(msg, r, RECORD, mutation)
    if not valid:
        return None
    was_stale = bool(r.aborted_candidates & _candidate_mask(msg.candidate)) or msg.run != r.active_run
    adopted = msg.candidate if mutation.no_candidate_binding else r.durable_candidate
    flags = state.violation_flags
    if binding_bad:
        flags |= V_BAD_BINDING_ACCEPTED
    if replay and was_stale:
        flags |= V_STALE_REPLAY_OPENED
    nr = replace(
        r,
        phase=OPEN,
        current_candidate=adopted,
        counter=r.target_counter,
        sequence=r.target_sequence,
        ticket=r.target_counter,
        durable_candidate=adopted,
        durable_context=context_id(adopted, r.input_ticket, r.decision),
    )
    return replace(state, responder=nr, completed=state.completed | _bit(msg.run), violation_flags=flags)


def _deliver(state: State, index: int, mutation: Mutation) -> tuple[State, str]:
    env = state.network[index]
    msg = env.msg
    network = state.network[:index] + state.network[index + 1 :]
    base = replace(state, network=network)
    accepted = False
    result: Optional[State] = None

    if msg.kind == M1:
        r = base.responder
        if (
            _stable(r)
            and 0 <= msg.run < len(base.m1_sends)
            and base.started & _bit(msg.run)
            and not (base.completed & _bit(msg.run))
        ):
            m2 = make_m2(msg, r)
            if len(base.network) < 6:
                result = replace(
                    base,
                    network=_add_network(base.network, Envelope(m2, 0)),
                    history=_add_history(base.history, m2),
                )
                accepted = True
    elif msg.kind == M2:
        result = _persist_candidate_i(base, msg, mutation)
        accepted = result is not None
    elif msg.kind == M3:
        r = base.responder
        if r.alive and r.phase == HALF_OPEN and r.active_run == msg.run and r.durable_candidate == msg.candidate:
            # Duplicate authenticated M3 is idempotent; durable state is unchanged.
            accepted = msg.tag == tag_for(M3, msg.candidate, msg.ticket, msg.decision)
            result = base if accepted else None
        else:
            result = _persist_half_open_r(base, msg, mutation)
            accepted = result is not None
    elif msg.kind == M4:
        result = _open_i(base, msg, bool(env.adversarial_replay), mutation)
        accepted = result is not None
    elif msg.kind == RECORD:
        result = _open_r(base, msg, bool(env.adversarial_replay), mutation)
        accepted = result is not None

    if result is None:
        result = base
    suffix = "accept" if accepted else "reject"
    replay = " stale-replay" if env.adversarial_replay else ""
    detail = ""
    if not accepted and msg.kind == M4:
        i = base.initiator
        bound = (
            msg.run == i.active_run
            and msg.candidate == i.durable_candidate
            and msg.decision == i.decision
            and msg.tag == tag_for(M4, i.durable_candidate, i.input_ticket, i.decision)
        )
        detail = " bound-delayed" if bound else " invalid-binding"
    return result, f"deliver {MSG_NAME[msg.kind]}[r{msg.run}]{replay}{detail}: {suffix}"


def _abort_endpoint(ep: Endpoint, mutation: Mutation) -> Endpoint:
    aborted = ep.aborted_candidates | _candidate_mask(ep.durable_candidate)
    cu, qu, tu = ep.counter_uses, ep.sequence_uses, ep.ticket_uses
    if mutation.forget_tombstone_on_abort and ep.active_run >= 0:
        owner = _bit(ep.active_run)
        if 0 <= ep.target_counter < len(cu):
            cu = _replace_tuple(cu, ep.target_counter, cu[ep.target_counter] & ~owner)
        if 0 <= ep.target_sequence < len(qu):
            qu = _replace_tuple(qu, ep.target_sequence, qu[ep.target_sequence] & ~owner)
        if 0 <= ep.input_ticket < len(tu):
            tu = _replace_tuple(tu, ep.input_ticket, tu[ep.input_ticket] & ~owner)
    return replace(
        ep,
        phase=ABORT,
        aborted_candidates=aborted,
        counter_uses=cu,
        sequence_uses=qu,
        ticket_uses=tu,
    )


def transitions(state: State, bounds: Bounds, mutation: Mutation) -> Iterator[tuple[str, State, str]]:
    """Yield canonical (action, successor, event-class) triples."""

    # Start or retry M1.  Starting both runs before either M2 is processed is
    # the bounded concurrent-run case; the later candidate loses the CAS/busy check.
    if _stable(state.initiator) and len(state.network) < bounds.max_network:
        for run in range(bounds.runs):
            done = state.completed & _bit(run)
            if done:
                continue
            sends = state.m1_sends[run]
            if sends >= bounds.max_sends:
                continue
            if not (state.started & _bit(run)) or sends > 0:
                msg = make_m1(state, run)
                ns = _emit(
                    replace(state, started=state.started | _bit(run)),
                    msg,
                    "m1_sends",
                    run,
                )
                yield f"send M1[r{run}] #{sends + 1}", ns, "send"

    # Persisted records are the sole source of M3/M4/RECORD: persist-before-send.
    i = state.initiator
    if (
        i.alive
        and i.phase == CANDIDATE
        and state.m3_sends[i.active_run] < bounds.max_sends
        and len(state.network) < bounds.max_network
    ):
        ns = _emit(state, make_m3(i), "m3_sends", i.active_run)
        yield f"send M3[r{i.active_run}] from durable CANDIDATE", ns, "send"

    r = state.responder
    if (
        r.alive
        and r.phase == HALF_OPEN
        and state.m4_sends[r.active_run] < bounds.max_sends
        and len(state.network) < bounds.max_network
    ):
        ns = _emit(state, make_m4(r), "m4_sends", r.active_run)
        yield f"send M4[r{r.active_run}] from durable HALF_OPEN", ns, "send"

    if (
        i.alive
        and i.phase == OPEN
        and i.active_run >= 0
        and not (state.completed & _bit(i.active_run))
        and state.record_sends[i.active_run] < bounds.max_sends
        and len(state.network) < bounds.max_network
    ):
        ns = _emit(state, make_record(i), "record_sends", i.active_run)
        yield f"send state-bound RECORD[r{i.active_run}]", ns, "send"

    # Any queued message may be delivered next; this is exhaustive reordering.
    seen_env: set[Envelope] = set()
    for index, env in enumerate(state.network):
        if env in seen_env:
            continue
        seen_env.add(env)
        ns, action = _deliver(state, index, mutation)
        yield action, ns, "deliver-replay" if env.adversarial_replay else "deliver"

    # Bounded network adversary.
    if state.drops < bounds.drops:
        seen_env.clear()
        for index, env in enumerate(state.network):
            if env in seen_env:
                continue
            seen_env.add(env)
            ns = replace(
                state,
                network=state.network[:index] + state.network[index + 1 :],
                drops=state.drops + 1,
                fault_flags=state.fault_flags
                | (
                    1
                    if env.msg.kind == M4
                    and state.initiator.phase == CANDIDATE
                    and state.m4_sends[env.msg.run] == 1
                    else 0
                ),
            )
            yield f"drop {MSG_NAME[env.msg.kind]}[r{env.msg.run}]", ns, "drop"

    if state.duplicates < bounds.duplicates and len(state.network) < bounds.max_network:
        for env in sorted(set(state.network)):
            if state.network.count(env) >= 2:
                continue
            ns = replace(
                state,
                network=_add_network(state.network, env),
                duplicates=state.duplicates + 1,
            )
            yield f"duplicate {MSG_NAME[env.msg.kind]}[r{env.msg.run}]", ns, "duplicate"

    if state.replays < bounds.replays and len(state.network) < bounds.max_network:
        for msg in state.history:
            env = Envelope(msg, 1)
            if env in state.network:
                continue
            ns = replace(
                state,
                network=_add_network(state.network, env),
                replays=state.replays + 1,
            )
            yield f"inject archived {MSG_NAME[msg.kind]}[r{msg.run}]", ns, "replay"

    # One malformed candidate/commit of each kind is enough for symbolic binding
    # sensitivity; perfect MACs collapse all bit strings into valid vs invalid.
    if len(state.network) < bounds.max_network:
        if i.alive and i.phase == CANDIDATE and not (state.injections & 1):
            good = make_m4(i)
            bad = good._replace(tag=good.tag + 1)
            ns = replace(
                state,
                network=_add_network(state.network, Envelope(bad, 0)),
                injections=state.injections | 1,
            )
            yield f"inject wrong Commit_r[r{i.active_run}]", ns, "inject"
        if (
            mutation.no_decision_binding
            and i.alive
            and i.phase == CANDIDATE
            and not (state.injections & 4)
        ):
            good = make_m4(i)
            bad = good._replace(decision=good.decision + 1)
            ns = replace(
                state,
                network=_add_network(state.network, Envelope(bad, 0)),
                injections=state.injections | 4,
            )
            yield f"inject wrong decision M4[r{i.active_run}]", ns, "inject"
        if r.alive and r.phase in (PRE, OPEN) and not (state.injections & 2):
            # A same-snapshot M3 with a wrong candidate tests candidate binding.
            run = next((x for x in range(bounds.runs) if state.started & _bit(x)), 0)
            tc = max(state.initiator.counter, r.counter) + 1
            tq = max(state.initiator.sequence, r.sequence) + 1
            if tc < len(r.counter_uses) and tq < len(r.sequence_uses):
                correct = candidate_id(run, tc, tq)
                bad = Msg(
                    M3,
                    run,
                    correct + 1,
                    state.initiator.counter,
                    r.counter,
                    state.initiator.sequence,
                    r.sequence,
                    r.ticket,
                    1,
                    tag_for(M3, correct, r.ticket, 1),
                )
                ns = replace(
                    state,
                    network=_add_network(state.network, Envelope(bad, 0)),
                    injections=state.injections | 2,
                )
                yield f"inject wrong candidate M3[r{run}]", ns, "inject"

    # Crashes occur only at durable-state boundaries.  Restart is deterministic
    # because every retransmittable message is a pure function of that record.
    if state.crashes < bounds.crashes:
        if i.alive:
            ns = replace(state, initiator=replace(i, alive=0), crashes=state.crashes + 1)
            yield f"crash I at {PHASE_NAME[i.phase]} persistence boundary", ns, "crash"
        if r.alive:
            ns = replace(state, responder=replace(r, alive=0), crashes=state.crashes + 1)
            yield f"crash R at {PHASE_NAME[r.phase]} persistence boundary", ns, "crash"
    if not i.alive:
        flag = 1 << i.phase
        yield f"restart I from durable {PHASE_NAME[i.phase]}", replace(
            state,
            initiator=replace(i, alive=1),
            recovery_flags=state.recovery_flags | flag,
        ), "restart"
    if not r.alive:
        flag = 1 << (6 + r.phase)
        yield f"restart R from durable {PHASE_NAME[r.phase]}", replace(
            state,
            responder=replace(r, alive=1),
            recovery_flags=state.recovery_flags | flag,
        ), "restart"

    # A local bounded retry timeout installs an abort tombstone.  Reservations
    # deliberately survive abort, so a delayed M4 and a conflicting run cannot
    # resurrect/reuse c*, q*, or the ticket.
    if i.alive and i.phase == CANDIDATE:
        yield f"timeout I candidate r{i.active_run}", replace(state, initiator=_abort_endpoint(i, mutation)), "abort"
    if r.alive and r.phase == HALF_OPEN:
        yield f"timeout R half-open r{r.active_run}", replace(state, responder=_abort_endpoint(r, mutation)), "abort"

    # If no candidate was ever persisted, a bounded handshake timeout safely
    # falls back rather than leaving PRE as a misleading liveness success.
    if i.alive and i.phase == PRE and state.started and all(
        x >= bounds.max_sends for x in state.m1_sends
    ):
        run = min(x for x in range(bounds.runs) if state.started & _bit(x))
        yield f"bounded M1 timeout I r{run}", replace(state, initiator=replace(i, phase=ABORT, active_run=run)), "abort"
    if r.alive and r.phase == PRE and state.started and all(
        x >= bounds.max_sends for x in state.m1_sends
    ):
        run = min(x for x in range(bounds.runs) if state.started & _bit(x))
        yield f"bounded M1 timeout R r{run}", replace(state, responder=replace(r, phase=ABORT, active_run=run)), "abort"

    if i.alive and i.phase == ABORT:
        yield "I enters QUARANTINE/fallback", replace(state, initiator=replace(i, phase=QUARANTINE)), "quarantine"
    if r.alive and r.phase == ABORT:
        yield "R enters QUARANTINE/fallback", replace(state, responder=replace(r, phase=QUARANTINE)), "quarantine"


def state_violations(state: State) -> int:
    flags = state.violation_flags
    i, r = state.initiator, state.responder

    if i.phase == OPEN and r.phase == OPEN:
        if i.current_candidate != r.current_candidate or i.durable_context != r.durable_context:
            flags |= V_DIVERGENT_OPEN

    for ep in (i, r):
        if ep.phase == OPEN:
            expected_ctx = context_id(ep.current_candidate, ep.input_ticket, ep.decision)
            if ep.current_candidate != ep.durable_candidate or ep.durable_context != expected_ctx:
                flags |= V_OPEN_WITHOUT_DURABLE_COMMIT
            if ep.aborted_candidates & _candidate_mask(ep.current_candidate):
                flags |= V_ABORTED_ADOPTED
            if ep.target_counter <= max(ep.base_ci, ep.base_cr) or ep.counter != ep.target_counter:
                flags |= V_NONMONOTONE_RESUME
            if ep.target_sequence <= max(ep.base_qi, ep.base_qr) or ep.sequence != ep.target_sequence:
                flags |= V_NONMONOTONE_RESUME
        if any(mask.bit_count() > 1 for mask in ep.counter_uses):
            flags |= V_COUNTER_REUSED
        if any(mask.bit_count() > 1 for mask in ep.sequence_uses):
            flags |= V_SEQUENCE_REUSED
        if any(mask.bit_count() > 1 for mask in ep.ticket_uses):
            flags |= V_TICKET_REUSED
        if ep.phase in (ABORT, QUARANTINE) and ep.durable_candidate > 0 and ep.active_run >= 0:
            owner = _bit(ep.active_run)
            if (
                ep.target_counter < 0
                or not (ep.counter_uses[ep.target_counter] & owner)
                or ep.target_sequence < 0
                or not (ep.sequence_uses[ep.target_sequence] & owner)
                or ep.input_ticket < 0
                or not (ep.ticket_uses[ep.input_ticket] & owner)
            ):
                flags |= V_ABORT_RESERVATION_LOST
    return flags


def _trace(parents: Dict[State, tuple[Optional[State], str]], state: State, tail: Optional[str] = None) -> list[str]:
    actions: list[str] = []
    cursor: Optional[State] = state
    while cursor is not None:
        parent, action = parents[cursor]
        if action:
            actions.append(action)
        cursor = parent
    actions.reverse()
    if tail:
        actions.append(tail)
    return actions


def _terminal_class(state: State) -> str:
    i, r = state.initiator, state.responder
    if i.phase == OPEN and r.phase == OPEN and i.current_candidate == r.current_candidate:
        return "success"
    if i.phase not in (CANDIDATE, HALF_OPEN) and r.phase not in (CANDIDATE, HALF_OPEN):
        if i.phase in (ABORT, QUARANTINE) or r.phase in (ABORT, QUARANTINE):
            return "safe-abort"
    return "stranded"


def run_search(bounds: Bounds, mutation: Mutation = Mutation()) -> SearchResult:
    start = initial_state(bounds)
    queue = collections.deque([start])
    depth: Dict[State, int] = {start: 0}
    parents: Dict[State, tuple[Optional[State], str]] = {start: (None, "")}
    transitions_count = 0
    max_depth = 0
    terminal_states = terminal_success = terminal_safe_abort = terminal_stranded = 0
    cut_states = crash_cut_states = 0
    crash_cutpoints: Dict[str, int] = collections.Counter()
    duplicate_steps = replay_steps = reorder_choices = 0
    violations: Dict[int, list[str]] = {}
    witnesses: Dict[str, list[str]] = {}
    deterministic_recovery = True
    adjacency: Dict[State, list[State]] = collections.defaultdict(list)

    while queue:
        state = queue.popleft()
        d = depth[state]
        max_depth = max(max_depth, d)

        bad = state_violations(state)
        if bad:
            for flag in VIOLATION_NAME:
                if bad & flag and flag not in violations:
                    violations[flag] = _trace(parents, state)

        all_next = list(transitions(state, bounds, mutation))
        if bounds.depth_limit and d >= bounds.depth_limit:
            if all_next:
                cut_states += 1
                if state.crashes:
                    crash_cut_states += 1
            continue

        if not all_next:
            terminal_states += 1
            cls = _terminal_class(state)
            if cls == "success":
                terminal_success += 1
            elif cls == "safe-abort":
                terminal_safe_abort += 1
            else:
                terminal_stranded += 1
                witnesses.setdefault("stranded-terminal", _trace(parents, state))

        # A dead durable record has exactly one restart successor per endpoint,
        # and restart must preserve every durable field.
        for role, ep in (("I", state.initiator), ("R", state.responder)):
            if not ep.alive:
                restarts = [(a, ns) for a, ns, ev in all_next if ev == "restart" and a.startswith(f"restart {role}")]
                if len(restarts) != 1:
                    deterministic_recovery = False
                else:
                    nep = restarts[0][1].initiator if role == "I" else restarts[0][1].responder
                    if _durable_fingerprint(ep) != _durable_fingerprint(nep):
                        deterministic_recovery = False

        # More than one deliverable envelope witnesses that the search really
        # includes reorder choices, not a fixed channel order.
        delivery_count = sum(ev.startswith("deliver") for _, _, ev in all_next)
        if delivery_count > 1:
            reorder_choices += delivery_count

        for action, ns, event in all_next:
            transitions_count += 1
            adjacency[state].append(ns)
            if event == "duplicate":
                duplicate_steps += 1
            elif event == "replay":
                replay_steps += 1
            elif event == "crash":
                crash_cutpoints[action.removeprefix("crash ")] += 1

            # Minimal BFS witnesses are captured at the transition that proves
            # the event, including rejections that otherwise only remove a msg.
            if event == "abort":
                witnesses.setdefault("safe-abort", _trace(parents, state, action))
            if "stale-replay" in action and action.endswith("reject"):
                witnesses.setdefault("stale-replay-rejection", _trace(parents, state, action))
            if (
                state.initiator.phase == ABORT
                and action.startswith("deliver M4")
                and "bound-delayed: reject" in action
            ):
                witnesses.setdefault("delayed-m4-after-abort-rejection", _trace(parents, state, action))
            if (
                state.started.bit_count() > 1
                and state.initiator.phase == CANDIDATE
                and action.startswith("deliver M2")
                and action.endswith("reject")
            ):
                witnesses.setdefault("concurrent-cas-rejection", _trace(parents, state, action))
            if "wrong Commit" in action or "wrong candidate" in action:
                witnesses.setdefault("binding-attack-injected", _trace(parents, state, action))

            if ns not in depth:
                depth[ns] = d + 1
                parents[ns] = (state, action)
                queue.append(ns)

                if (
                    ns.initiator.phase == OPEN
                    and ns.responder.phase == OPEN
                    and ns.initiator.current_candidate == ns.responder.current_candidate
                ):
                    witnesses.setdefault("successful-open", _trace(parents, ns))
                    if ns.recovery_flags:
                        witnesses.setdefault("crash-recovery-open", _trace(parents, ns))
                    if ns.fault_flags & 1 and any(x >= 2 for x in ns.m4_sends):
                        witnesses.setdefault("m4-loss-retry-open", _trace(parents, ns))
                # Half-open must survive a crash/restart and use a state-bound
                # record before R opens.
                if ns.responder.phase == OPEN and ns.recovery_flags & (1 << (6 + HALF_OPEN)):
                    witnesses.setdefault("half-open-recovery", _trace(parents, ns))

    # Kahn-style acyclicity check over the reachable graph.  This substantiates
    # bounded termination without making an unbounded fairness claim.
    indegree: Dict[State, int] = {s: 0 for s in depth}
    for src, succs in adjacency.items():
        for dst in set(succs):
            if dst != src:
                indegree[dst] = indegree.get(dst, 0) + 1
    q = collections.deque(s for s, deg in indegree.items() if deg == 0)
    removed = 0
    while q:
        s = q.popleft()
        removed += 1
        for dst in set(adjacency.get(s, ())):
            if dst == s:
                continue
            indegree[dst] -= 1
            if indegree[dst] == 0:
                q.append(dst)
    acyclic = removed == len(indegree)

    return SearchResult(
        bounds=bounds,
        mutation=mutation,
        states=len(depth),
        transitions=transitions_count,
        max_depth=max_depth,
        terminal_states=terminal_states,
        terminal_success=terminal_success,
        terminal_safe_abort=terminal_safe_abort,
        terminal_stranded=terminal_stranded,
        cut_states=cut_states,
        crash_cut_states=crash_cut_states,
        crash_cutpoints=dict(sorted(crash_cutpoints.items())),
        duplicate_steps=duplicate_steps,
        replay_steps=replay_steps,
        reorder_choices=reorder_choices,
        violations=violations,
        witnesses=witnesses,
        deterministic_recovery=deterministic_recovery,
        acyclic=acyclic,
    )


def _format_trace(trace: Sequence[str]) -> str:
    if not trace:
        return "    (initial state)"
    return "\n".join(f"    {n:02d}. {step}" for n, step in enumerate(trace, 1))


def format_result(result: SearchResult, mutant_results: Sequence[SearchResult] = ()) -> str:
    b = result.bounds
    lines = [
        "Q-ARTZ-Resync bounded explicit-state verification",
        "=" * 52,
        f"generated_utc: {_dt.datetime.now(_dt.timezone.utc).isoformat()}",
        "model: two fixed endpoints; perfect symbolic signatures/MACs; durable records",
        "scope: finite safety + bounded terminal analysis (NOT unbounded liveness)",
        "",
        "Bounds",
        "------",
        f"runs={b.runs}, max_sends_per_stage={b.max_sends}, drops={b.drops}, "
        f"duplicates={b.duplicates}, archived_replays={b.replays}, crashes={b.crashes}, "
        f"max_network={b.max_network}, depth_limit={b.depth_limit or 'none'}",
        "Crashes are placed at PRE/CANDIDATE/HALF_OPEN/OPEN/ABORT/QUARANTINE durable boundaries.",
        "Network delivery is chosen from every queued envelope; hence reordering is exhaustive.",
        "",
        "Reachability",
        "------------",
        f"states={result.states}",
        f"transitions={result.transitions}",
        f"maximum_BFS_depth={result.max_depth}",
        f"terminal_states={result.terminal_states}",
        f"terminal_success={result.terminal_success}",
        f"terminal_safe_abort_or_quarantine={result.terminal_safe_abort}",
        f"terminal_stranded={result.terminal_stranded}",
        f"depth_cut_states={result.cut_states}",
        f"crash_cut_states={result.crash_cut_states}",
        "crash_cutpoint_transition_counts=" + (
            ", ".join(f"{name}:{count}" for name, count in result.crash_cutpoints.items())
            if result.crash_cutpoints else "none"
        ),
        f"duplicate_adversary_steps={result.duplicate_steps}",
        f"archived_replay_steps={result.replay_steps}",
        f"multi-envelope_reorder_delivery_choices={result.reorder_choices}",
        "",
        "Safety invariants",
        "-----------------",
    ]
    for flag, name in VIOLATION_NAME.items():
        status = "FAIL" if flag in result.violations else "PASS"
        lines.append(f"[{status}] {name}")
        if flag in result.violations:
            lines.append("  Minimal counterexample:")
            lines.append(_format_trace(result.violations[flag]))
    lines.extend(
        [
            f"[{'PASS' if result.deterministic_recovery else 'FAIL'}] restart preserves the durable record and has one recovery successor",
            f"[{'PASS' if result.terminal_stranded == 0 and result.cut_states == 0 else 'FAIL'}] every bounded terminal is matching OPEN or safe abort/quarantine",
            f"[{'PASS' if result.acyclic else 'INFO'}] bounded reachable graph is acyclic after ignoring idempotent self-loops",
            "",
            "Minimal witnesses",
            "-----------------",
        ]
    )
    for name in (
        "successful-open",
        "safe-abort",
        "crash-recovery-open",
        "half-open-recovery",
        "m4-loss-retry-open",
        "stale-replay-rejection",
        "delayed-m4-after-abort-rejection",
        "concurrent-cas-rejection",
        "binding-attack-injected",
        "stranded-terminal",
    ):
        if name in result.witnesses:
            lines.append(f"{name}:")
            lines.append(_format_trace(result.witnesses[name]))
        else:
            lines.append(f"{name}: not reached under these bounds")

    if mutant_results:
        lines.extend(["", "Intentional-mutant sensitivity", "-------------------------------"])
        for mutant in mutant_results:
            detected = sorted(VIOLATION_NAME[x] for x in mutant.violations)
            status = "DETECTED" if detected else "MISSED"
            lines.append(
                f"[{status}] {mutant.mutation.name}: states={mutant.states}, "
                f"first violations={'; '.join(detected) if detected else 'none'}"
            )
            if mutant.violations:
                flag = next(iter(mutant.violations))
                lines.append("  Minimal counterexample:")
                lines.append(_format_trace(mutant.violations[flag]))

    lines.extend(
        [
            "",
            "Interpretation limits",
            "---------------------",
            "* Completeness is only for the finite bounds printed above.",
            "* Perfect symbolic tags model authenticity; cryptographic primitives are not re-proved.",
            "* A same-run exact retransmission may complete an active candidate; an archived message",
            "  cannot open an aborted, consumed, or non-current candidate.",
            "* PA classification, chain proof construction, clock/TPM behavior, parser memory safety,",
            "  AEAD implementation, and physical UAV/UGV behavior are outside this model.",
            "* The terminal check is bounded/fair-scheduler evidence, not an unbounded liveness theorem.",
            "",
            f"OVERALL: {'PASS' if result.passed and result.deterministic_recovery else 'FAIL'}",
        ]
    )
    return "\n".join(lines) + "\n"


def suite_bounds() -> list[tuple[str, Bounds]]:
    """Orthogonal complete campaigns keep the Cartesian product auditable.

    Combining every fault budget with both concurrent runs creates a much
    larger but not qualitatively stronger product.  Each campaign below is
    independently explored to a fixed point; the report is explicit that
    their bounds must not be multiplied together.
    """

    return [
        (
            "network-adversary",
            Bounds(
                runs=1,
                max_sends=1,
                drops=1,
                duplicates=1,
                replays=1,
                crashes=0,
                max_network=5,
            ),
        ),
        (
            "crash-loss-retry",
            Bounds(
                runs=1,
                max_sends=2,
                drops=1,
                duplicates=0,
                replays=0,
                crashes=1,
                max_network=5,
            ),
        ),
        (
            "concurrent-cas",
            Bounds(
                runs=2,
                max_sends=1,
                drops=0,
                duplicates=0,
                replays=0,
                crashes=0,
                max_network=5,
            ),
        ),
    ]


def format_suite(
    named_results: Sequence[tuple[str, SearchResult]],
    mutant_results: Sequence[SearchResult] = (),
    runtime_seconds: Optional[float] = None,
) -> str:
    total_states = sum(r.states for _, r in named_results)
    total_transitions = sum(r.transitions for _, r in named_results)
    passed = all(r.passed and r.deterministic_recovery for _, r in named_results)
    lines = [
        "Q-ARTZ-Resync bounded explicit-state campaign suite",
        "=" * 55,
        f"generated_utc: {_dt.datetime.now(_dt.timezone.utc).isoformat()}",
        f"campaigns={len(named_results)}, summed_states={total_states}, "
        f"summed_transitions={total_transitions}",
        f"suite_and_mutant_runtime_seconds={runtime_seconds:.3f}"
        if runtime_seconds is not None
        else "suite_and_mutant_runtime_seconds=not-recorded",
        "Each campaign is a separate fixed-point exploration; bounds are NOT a Cartesian product.",
        "This is bounded safety/terminal evidence, not an unbounded liveness theorem.",
        "",
        "Campaign summary",
        "----------------",
    ]
    for name, result in named_results:
        b = result.bounds
        lines.append(
            f"{name}: {'PASS' if result.passed and result.deterministic_recovery else 'FAIL'}; "
            f"runs={b.runs}, sends={b.max_sends}, drop/dup/replay/crash="
            f"{b.drops}/{b.duplicates}/{b.replays}/{b.crashes}; "
            f"states={result.states}, transitions={result.transitions}, depth={result.max_depth}, "
            f"terminal={result.terminal_states} "
            f"(open={result.terminal_success}, abort={result.terminal_safe_abort}, "
            f"stranded={result.terminal_stranded}), depth_cuts={result.cut_states}"
        )
    for name, result in named_results:
        lines.extend(["", "#" * 72, f"CAMPAIGN: {name}", "#" * 72, ""])
        lines.append(format_result(result).rstrip())

    if mutant_results:
        lines.extend(["", "#" * 72, "INTENTIONAL-MUTANT SENSITIVITY", "#" * 72])
        for mutant in mutant_results:
            detected = sorted(VIOLATION_NAME[x] for x in mutant.violations)
            lines.append(
                f"[{'DETECTED' if detected else 'MISSED'}] {mutant.mutation.name}: "
                f"states={mutant.states}, transitions={mutant.transitions}; "
                f"violations={'; '.join(detected) if detected else 'none'}"
            )
            if mutant.violations:
                first = next(iter(mutant.violations))
                lines.append("  Minimal counterexample:")
                lines.append(_format_trace(mutant.violations[first]))
        passed = passed and all(bool(x.violations) for x in mutant_results)

    lines.extend(
        [
            "",
            "Suite limitations",
            "-----------------",
            "The campaigns are deliberately orthogonal: network faults, crash/restart, and",
            "two-run concurrency are each exhaustive at their printed bounds but are not",
            "jointly cross-multiplied. Perfect symbolic authenticity and finite runs remain",
            "the principal abstractions. No claim of unbounded liveness is made.",
            "",
            f"SUITE OVERALL: {'PASS' if passed else 'FAIL'}",
        ]
    )
    return "\n".join(lines) + "\n"


def write_suite_macros(
    path: pathlib.Path,
    named_results: Sequence[tuple[str, SearchResult]],
    mutant_results: Sequence[SearchResult],
    runtime_seconds: float,
) -> None:
    results = [result for _, result in named_results]
    values = {
        "RsScCampaigns": len(results),
        "RsScStates": sum(x.states for x in results),
        "RsScTransitions": sum(x.transitions for x in results),
        "RsScMaxDepth": max(x.max_depth for x in results),
        "RsScTerminals": sum(x.terminal_states for x in results),
        "RsScTerminalOpen": sum(x.terminal_success for x in results),
        "RsScTerminalAbort": sum(x.terminal_safe_abort for x in results),
        "RsScTerminalStranded": sum(x.terminal_stranded for x in results),
        "RsScDepthCuts": sum(x.cut_states for x in results),
        "RsScInvariantViolations": sum(len(x.violations) for x in results),
        "RsScMutantsDetected": sum(bool(x.violations) for x in mutant_results),
        "RsScMutantsTotal": len(mutant_results),
        "RsScRuntimeSec": f"{runtime_seconds:.1f}",
    }
    lines = [
        "% auto-generated by formal/resync_statecheck.py -- do not edit",
        "% resync_statecheck_result.txt is the authoritative detailed record",
    ]
    lines.extend(f"\\newcommand{{\\{name}}}{{{value}}}" for name, value in values.items())
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_mutants() -> list[SearchResult]:
    # Small bounds are sufficient to produce short, independently auditable
    # counterexamples.  Two runs are needed for CAS/single-use sensitivity.
    b2 = Bounds(runs=2, max_sends=1, drops=0, duplicates=0, replays=0, crashes=0, max_network=4)
    b1 = Bounds(runs=1, max_sends=1, drops=0, duplicates=0, replays=0, crashes=0, max_network=4)
    return [
        run_search(b2, Mutation(no_cas=True)),
        run_search(b2, Mutation(forget_tombstone_on_abort=True)),
        run_search(b1, Mutation(no_commit_binding=True)),
        run_search(b1, Mutation(no_candidate_binding=True)),
        run_search(b1, Mutation(no_decision_binding=True)),
    ]


class ModelSelfTests(unittest.TestCase):
    def test_invariant_detector_divergent_open(self) -> None:
        b = Bounds(runs=1)
        s = initial_state(b)
        i = replace(
            s.initiator,
            phase=OPEN,
            current_candidate=5,
            durable_candidate=5,
            durable_context=context_id(5, 0, 1),
            input_ticket=0,
            decision=1,
            base_ci=0,
            base_cr=0,
            base_qi=0,
            base_qr=0,
            target_counter=1,
            target_sequence=1,
            counter=1,
            sequence=1,
        )
        r = replace(i, current_candidate=6, durable_candidate=6, durable_context=context_id(6, 0, 1))
        self.assertTrue(state_violations(replace(s, initiator=i, responder=r)) & V_DIVERGENT_OPEN)

    def test_crash_restart_preserves_durable_record(self) -> None:
        b = Bounds(runs=1, crashes=1)
        s = initial_state(b)
        crash = next(ns for a, ns, e in transitions(s, b, Mutation()) if a.startswith("crash I"))
        restarted = next(ns for a, ns, e in transitions(crash, b, Mutation()) if a.startswith("restart I"))
        self.assertEqual(_durable_fingerprint(s.initiator), _durable_fingerprint(crash.initiator))
        self.assertEqual(_durable_fingerprint(s.initiator), _durable_fingerprint(restarted.initiator))

    def test_abort_keeps_reservations(self) -> None:
        b = Bounds(runs=1)
        ep = replace(
            fresh_endpoint(2),
            phase=CANDIDATE,
            active_run=0,
            durable_candidate=5,
            target_counter=1,
            target_sequence=1,
            input_ticket=0,
            counter_uses=(0, 1, 0),
            sequence_uses=(0, 1, 0),
            ticket_uses=(1, 0, 0),
        )
        aborted = _abort_endpoint(ep, Mutation())
        self.assertEqual(aborted.counter_uses[1], 1)
        self.assertEqual(aborted.sequence_uses[1], 1)
        self.assertEqual(aborted.ticket_uses[0], 1)
        self.assertTrue(aborted.aborted_candidates & _candidate_mask(5))

    def test_bad_commit_is_rejected(self) -> None:
        ep = replace(
            fresh_endpoint(2),
            phase=CANDIDATE,
            active_run=0,
            durable_candidate=5,
            durable_context=context_id(5, 0, 1),
            input_ticket=0,
            decision=1,
            target_counter=1,
            target_sequence=1,
            base_ci=0,
            base_cr=0,
            base_qi=0,
            base_qr=0,
        )
        good = make_m4(ep)
        bad = good._replace(tag=good.tag + 1)
        self.assertFalse(_matches_durable(bad, ep, M4, Mutation())[0])
        self.assertTrue(_matches_durable(bad, ep, M4, Mutation(no_commit_binding=True))[0])


def _parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=2, choices=(1, 2))
    parser.add_argument("--max-sends", type=int, default=2)
    parser.add_argument("--drops", type=int, default=1)
    parser.add_argument("--duplicates", type=int, default=1)
    parser.add_argument("--replays", type=int, default=1)
    parser.add_argument("--crashes", type=int, default=1)
    parser.add_argument("--max-network", type=int, default=6)
    parser.add_argument("--depth-limit", type=int, default=0, help="0 explores to the fixed point")
    parser.add_argument(
        "--output",
        type=pathlib.Path,
        default=pathlib.Path(__file__).with_name("resync_statecheck_result.txt"),
    )
    parser.add_argument(
        "--macros-output",
        type=pathlib.Path,
        default=pathlib.Path(__file__).with_name("resync_statecheck_macros.tex"),
    )
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--mutants", action="store_true", help="also run intentional-mutant sensitivity checks")
    parser.add_argument(
        "--suite",
        action="store_true",
        help="run the fixed network, crash, and two-run concurrency campaigns",
    )
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _parse_args(argv)
    if args.self_test:
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(ModelSelfTests)
        outcome = unittest.TextTestRunner(verbosity=2).run(suite)
        if not outcome.wasSuccessful():
            return 2

    search_started = time.perf_counter()
    mutants = run_mutants() if args.mutants else []
    if args.suite:
        named_results = [(name, run_search(bounds)) for name, bounds in suite_bounds()]
        runtime_seconds = time.perf_counter() - search_started
        report = format_suite(named_results, mutants, runtime_seconds)
        write_suite_macros(args.macros_output, named_results, mutants, runtime_seconds)
        success = all(
            result.passed and result.deterministic_recovery
            for _, result in named_results
        ) and (not mutants or all(result.violations for result in mutants))
    else:
        bounds = Bounds(
            runs=args.runs,
            max_sends=args.max_sends,
            drops=args.drops,
            duplicates=args.duplicates,
            replays=args.replays,
            crashes=args.crashes,
            max_network=args.max_network,
            depth_limit=args.depth_limit,
        )
        result = run_search(bounds)
        report = format_result(result, mutants)
        success = result.passed and result.deterministic_recovery
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(report, encoding="utf-8")
    print(report, end="")
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
