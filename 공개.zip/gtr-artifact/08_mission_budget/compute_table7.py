#!/usr/bin/env python3
"""Reproduce the mission-sized FS-KEM budget reported in Table 7."""

import csv
import math
from pathlib import Path


PROFILES = (
    ("2 h / 5 s", 2 * 60 * 60, 5),
    ("12 h / 5 s", 12 * 60 * 60, 5),
    ("12 h / 60 s", 12 * 60 * 60, 60),
    ("12 h / 5 min", 12 * 60 * 60, 5 * 60),
)

K = 1
B = 0
R = 1
X = 0
PUBLIC_KEY_BYTES = 1184
SECRET_KEY_BYTES = 2400
KEYGEN_MS_PER_ENTRY = 4.39453125


def next_power_of_two(value: int) -> int:
    return 1 << (value - 1).bit_length()


def build_rows():
    for label, mission_seconds, epoch_seconds in PROFILES:
        n_t = math.ceil(mission_seconds / epoch_seconds)
        n_e = n_t + B + R
        t_req = n_e + 1
        t_cfg = next_power_of_two(t_req)
        n_ctr = math.ceil((n_t + B) / K) + R + X
        yield {
            "profile": label,
            "N_t": n_t,
            "N_ctr": n_ctr,
            "T_req": t_req,
            "T_cfg": t_cfg,
            "pk_KiB": t_cfg * PUBLIC_KEY_BYTES / 1024,
            "sk_KiB": t_cfg * SECRET_KEY_BYTES / 1024,
            "KeyGen_s": t_cfg * KEYGEN_MS_PER_ENTRY / 1000,
        }


def main():
    output = Path(__file__).with_name("table7_budget.csv")
    fieldnames = ["profile", "N_t", "N_ctr", "T_req", "T_cfg", "pk_KiB", "sk_KiB", "KeyGen_s"]
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in build_rows():
            row["pk_KiB"] = f'{row["pk_KiB"]:.0f}'
            row["sk_KiB"] = f'{row["sk_KiB"]:.0f}'
            row["KeyGen_s"] = f'{row["KeyGen_s"]:.1f}'
            writer.writerow(row)
    print(output)


if __name__ == "__main__":
    main()
