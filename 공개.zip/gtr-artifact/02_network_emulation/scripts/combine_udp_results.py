#!/usr/bin/env python3
"""Assemble completed raw and selective-fragment UDP campaigns.

The raw run was completed before a selective-mode-only measurement defect was
corrected.  The correction did not touch the raw transport path.  This helper
filters the six completed raw conditions and combines them with a clean rerun
of the six selective-fragment conditions, preserving the per-trial records and
recording source hashes in a new manifest.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


FIELDS = [
    "condition", "transport_mode", "loss_percent", "rtt_ms", "trials",
    "successes", "success_rate_percent", "median_ms", "p95_ms",
    "retransmissions_sum", "fragment_retransmissions_sum",
    "fragments_sent_sum", "max_datagram_bytes", "conflicting_adoptions",
]


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def summaries(path: Path, mode: str) -> list[dict]:
    rows = json.loads((path / "summary.json").read_text(encoding="utf-8"))
    selected = [row for row in rows
                if row["condition"]["transport_mode"] == mode]
    selected.sort(key=lambda row: float(row["condition"]["loss_percent"]))
    if len(selected) != 6 or any(row["trials"] != 100 for row in selected):
        raise RuntimeError(f"incomplete {mode} campaign in {path}")
    return selected


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", required=True, type=Path)
    parser.add_argument("--selective-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    raw_dir = args.raw_dir.resolve()
    selective_dir = args.selective_dir.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)

    raw = summaries(raw_dir, "raw")
    selective = summaries(selective_dir, "selective-fragment")
    losses_raw = [row["condition"]["loss_percent"] for row in raw]
    losses_selective = [row["condition"]["loss_percent"] for row in selective]
    if losses_raw != losses_selective:
        raise RuntimeError("raw and selective loss conditions differ")
    combined = raw + selective
    (output / "summary.json").write_text(
        json.dumps(combined, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    with (output / "summary.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(FIELDS)
        for row in combined:
            condition = row["condition"]
            writer.writerow([
                condition["id"], condition["transport_mode"],
                condition["loss_percent"], condition["rtt_ms"], row["trials"],
                row["successes"], row["success_rate_percent"],
                row["ttsc_ms"]["median"], row["ttsc_ms"]["p95"],
                row["application_retransmissions"]["sum"],
                row["fragment_retransmissions_sum"], row["fragments_sent_sum"],
                row["max_datagram_bytes"], row["conflicting_adoptions"],
            ])

    trial_count = 0
    with (output / "trials.jsonl").open("w", encoding="utf-8") as target:
        for source, mode in ((raw_dir, "raw"),
                             (selective_dir, "selective-fragment")):
            with (source / "trials.jsonl").open(encoding="utf-8") as handle:
                for line in handle:
                    row = json.loads(line)
                    if row["condition"]["transport_mode"] == mode:
                        target.write(json.dumps(row, sort_keys=True) + "\n")
                        trial_count += 1
    if trial_count != 1200:
        raise RuntimeError(f"expected 1200 trial records, got {trial_count}")

    manifest = {
        "schema": "gtr.udp.paired-manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": (
            "paired comparison of raw whole-message UDP retry and 900-byte "
            "application fragmentation with per-fragment acknowledgements and "
            "selective retransmission"),
        "conditions": combined,
        "trials": trial_count,
        "source_note": (
            "The completed raw path was retained; a selective-only run was "
            "repeated after removing a harness-only final-receipt accounting "
            "error. The raw transport code path was unchanged."),
        "sources": {
            "raw_trials_sha256": digest(raw_dir / "trials.jsonl"),
            "selective_trials_sha256": digest(selective_dir / "trials.jsonl"),
            "selective_manifest": json.loads(
                (selective_dir / "manifest.json").read_text(encoding="utf-8")),
        },
    }
    (output / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "trials": trial_count}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
