#!/usr/bin/env python3
"""Validate and plot the event-triggered GT-R blackout campaign."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


TRIGGERS = ("after_m2", "before_m3", "before_m4")
DURATIONS = (0.2, 0.5, 1.0, 2.0, 5.0)
LABELS = {
    "after_m2": "after M2 send",
    "before_m3": "before M3 send",
    "before_m4": "before M4 send",
}
COLORS = {
    "after_m2": "#1769aa",
    "before_m3": "#d17c00",
    "before_m4": "#3b8c4a",
}


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save_figure(fig, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def validate(rows: list[dict], summaries: list[dict]) -> None:
    expected = {(trigger, duration) for trigger in TRIGGERS for duration in DURATIONS}
    observed = {
        (row["condition"]["trigger"],
         float(row["condition"]["blackout_seconds"])) for row in summaries}
    if observed != expected:
        raise ValueError(f"unexpected condition matrix: {observed}")
    if len(rows) != 1500 or len(summaries) != 15:
        raise ValueError(
            f"expected 1,500 trials and 15 summaries, got {len(rows)} and {len(summaries)}")
    if not all(row.get("success") for row in rows):
        raise ValueError("at least one blackout trial failed")
    if not all(row.get("candidate_survived_blackout") for row in rows):
        raise ValueError("at least one candidate did not survive the blackout")
    if any(row.get("candidate_conflicts") for row in rows):
        raise ValueError("candidate conflict found")
    if not all(row.get("session_transcript_epoch_match") for row in rows):
        raise ValueError("adopted session/transcript/epoch mismatch found")
    if any(row["trials"] != 100 or row["successes"] != 100
           for row in summaries):
        raise ValueError("each condition must contain 100/100 successful trials")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    summaries = load(args.input / "summary.json")
    rows = load_jsonl(args.input / "trials.jsonl")
    validate(rows, summaries)
    indexed = {
        (row["condition"]["trigger"],
         float(row["condition"]["blackout_seconds"])): row
        for row in summaries
    }

    x = np.asarray(DURATIONS)
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.9))
    for trigger in TRIGGERS:
        selected = [indexed[(trigger, duration)] for duration in DURATIONS]
        median = np.asarray([
            row["recovery_after_restore_ms"]["median"] for row in selected])
        p95 = np.asarray([
            row["recovery_after_restore_ms"]["p95"] for row in selected])
        axes[0].plot(
            x, median, "o-", color=COLORS[trigger], label=f"{LABELS[trigger]} median")
        axes[0].plot(
            x, p95, "--", color=COLORS[trigger], alpha=0.55,
            label=f"{LABELS[trigger]} p95")
        retries = np.asarray([
            row["application_retries_sum"] / row["trials"] for row in selected])
        axes[1].plot(
            x, retries, "o-", color=COLORS[trigger], label=LABELS[trigger])

    axes[0].set_xscale("log")
    axes[0].set_xticks(x, labels=[f"{value:g}" for value in x])
    axes[0].set_xlabel("Blackout duration (s)")
    axes[0].set_ylabel("Recovery after link restoration (ms)")
    axes[0].grid(True, which="both", alpha=0.3)
    axes[0].legend(frameon=False, fontsize=7, ncol=2)

    axes[1].set_xscale("log")
    axes[1].set_xticks(x, labels=[f"{value:g}" for value in x])
    axes[1].set_xlabel("Blackout duration (s)")
    axes[1].set_ylabel("Mean application retries per execution")
    axes[1].set_ylim(-0.05, 3.2)
    axes[1].set_yticks((0, 1, 2, 3))
    axes[1].grid(True, which="both", alpha=0.3)
    axes[1].legend(frameon=False, fontsize=8)
    fig.suptitle("GT-R recovery from event-triggered link blackout (n = 100)")
    fig.tight_layout()
    save_figure(fig, args.output / "gt_r_blackout_n100")

    total_retries = sum(row["application_retries"] for row in rows)
    total_reuse = sum(row["candidate_reuse_count"] for row in rows)
    report = [
        "# GT-R event-triggered blackout experiment",
        "",
        "GT-R was executed at 100 ms configured RTT and zero baseline loss/jitter. "
        "For each trial, both router egress directions were changed to 100% loss at "
        "one of three protocol events and restored after 0.2, 0.5, 1, 2, or 5 s. "
        "Each of the 15 conditions contains 100 executions.",
        "",
        "On timeout, the initiator reconnects with the same attempt identifier and "
        "byte-identical M1/M3, for an initial attempt plus at most three retries. "
        "The responder keeps the unauthenticated pre-candidate in bounded volatile "
        "memory and reuses cached M2/M4 material. Recovery time starts when netem "
        "restores the link and ends when the later endpoint adopts the shared state.",
        "",
        "| Trigger | Blackout | Completed | Recovery median | p95 | Total median | "
        "Retries | Candidate reuse | Conflicts |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for trigger in TRIGGERS:
        for duration in DURATIONS:
            row = indexed[(trigger, duration)]
            report.append(
                f"| {LABELS[trigger]} | {duration:g} s | "
                f"{row['successes']}/{row['trials']} | "
                f"{row['recovery_after_restore_ms']['median']:.2f} ms | "
                f"{row['recovery_after_restore_ms']['p95']:.2f} ms | "
                f"{row['handshake_total_ms']['median']:.2f} ms | "
                f"{row['application_retries_sum']} | {row['candidate_reuse_sum']} | "
                f"{row['candidate_conflicts'] + row['conflicting_adoptions']} |")
    report.extend([
        "",
        "## Integrity checks",
        "",
        "- Completed executions: 1,500/1,500.",
        f"- Application retries: {total_retries:,}; candidate reuse events: {total_reuse:,}.",
        "- Candidate-survival failures: 0; candidate conflicts: 0.",
        "- Session-key, transcript, or converged-epoch conflicts: 0.",
        "- Retry exhaustion: 0.",
        "- Fifteen packet captures were read successfully with tcpdump.",
        "",
        "## Interpretation boundary",
        "",
        "Recovery latency is intentionally non-monotonic because the 0.5, 1, 2, and "
        "4 s exponential socket timeouts quantize when the next connection attempt "
        "can observe restoration. This experiment demonstrates link-outage recovery "
        "while both endpoint processes remain alive. It does not test crash recovery, "
        "persistent-state restoration, or a physical DDIL radio. A harness-only ACK "
        "after M4 lets the responder terminate and is excluded from TTSC.",
        "",
    ])
    (args.output / "RESULTS.md").write_text("\n".join(report), encoding="utf-8")

    targets = [
        args.input / "trials.jsonl", args.input / "summary.json",
        args.input / "manifest.json", Path(__file__).resolve(),
    ]
    targets.extend(sorted((args.input / "pcap").glob("*.pcap")))
    (args.output / "artifact_checksums.json").write_text(
        json.dumps({str(path.resolve()): sha256(path) for path in targets},
                   indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "trials": len(rows), "successes": sum(row["success"] for row in rows),
        "candidate_conflicts": sum(row["candidate_conflicts"] for row in rows),
        "adoption_conflicts": sum(
            not row["session_transcript_epoch_match"] for row in rows),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
