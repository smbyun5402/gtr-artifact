#!/usr/bin/env python3
"""Validate and plot the GT-R jitter experiment."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


EXPECTED_JITTER = (0.0, 10.0, 25.0, 50.0, 100.0)


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save_figure(fig, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    rows = sorted(
        load(args.input / "summary.json"),
        key=lambda row: row["condition"]["jitter_ms"],
    )
    trials = load_jsonl(args.input / "trials.jsonl")
    jitter = tuple(float(row["condition"]["jitter_ms"]) for row in rows)
    if jitter != EXPECTED_JITTER:
        raise ValueError(f"unexpected jitter conditions: {jitter}")
    if len(trials) != 500:
        raise ValueError(f"expected 500 raw trials, got {len(trials)}")
    if any(row["condition"]["rtt_ms"] != 100.0 for row in rows):
        raise ValueError("the jitter experiment must use 100 ms RTT")
    if any(row["condition"]["loss_percent"] != 0.0 for row in rows):
        raise ValueError("the jitter experiment must use zero configured loss")
    if any(row["trials"] != 100 for row in rows):
        raise ValueError("each jitter condition must contain 100 trials")
    if not all(row.get("success") for row in trials):
        raise ValueError("at least one jitter trial failed")
    if not all(row.get("session_transcript_epoch_match") for row in trials):
        raise ValueError("a jitter trial contains conflicting adopted state")

    x = np.asarray(jitter)
    median = np.asarray([row["ttsc_ms"]["median"] for row in rows])
    p95 = np.asarray([row["ttsc_ms"]["p95"] for row in rows])
    p99 = np.asarray([row["ttsc_ms"]["p99"] for row in rows])
    success = np.asarray([row["success_rate_percent"] for row in rows])
    retrans = np.asarray([row["tcp_total_retransmissions"]["sum"] for row in rows])

    fig, axes = plt.subplots(1, 2, figsize=(10.0, 3.8))
    axes[0].plot(x, median, "o-", label="median", linewidth=1.8)
    axes[0].plot(x, p95, "s--", label="p95", linewidth=1.5)
    axes[0].plot(x, p99, "^:", label="p99", linewidth=1.5)
    axes[0].set_xlabel("Configured RTT jitter budget (ms)")
    axes[0].set_ylabel("TTSC (ms)")
    axes[0].grid(True, alpha=0.3)
    axes[0].legend(frameon=False)

    positions = np.arange(len(x))
    axes[1].bar(positions, retrans, color="#c47a2c")
    axes[1].set_xticks(positions, labels=[f"{value:g}" for value in x])
    axes[1].set_xlabel("Configured RTT jitter budget (ms)")
    axes[1].set_ylabel("TCP retransmissions across 100 trials")
    axes[1].grid(True, axis="y", alpha=0.3)
    for index, value in enumerate(success):
        axes[1].text(index, retrans[index], f" {value:.0f}% success",
                     ha="center", va="bottom", fontsize=8)
    fig.suptitle("GT-R under normally distributed jitter (RTT = 100 ms, n = 100)")
    fig.tight_layout()
    save_figure(fig, args.output / "gt_r_jitter_n100")

    report = [
        "# GT-R jitter experiment",
        "",
        "GT-R was executed through Linux network namespaces at 100 ms configured "
        "RTT, zero configured packet loss, and epoch drift 4. The configured jitter "
        "budget was split equally across the two one-way router egress directions "
        "(`tc netem delay 50 ms J/2 distribution normal`). Each condition contains "
        "100 independent TCP and M1--M4 executions.",
        "",
        "| Jitter budget | Completed | Median TTSC | p95 | p99 | Retransmissions | State conflicts |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        condition = row["condition"]
        report.append(
            f"| {condition['jitter_ms']:.0f} ms | {row['successes']}/{row['trials']} | "
            f"{row['ttsc_ms']['median']:.2f} ms | {row['ttsc_ms']['p95']:.2f} ms | "
            f"{row['ttsc_ms']['p99']:.2f} ms | "
            f"{row['tcp_total_retransmissions']['sum']} | "
            f"{row['conflicting_adoptions']} |")
    report.extend([
        "",
        "## Interpretation boundary",
        "",
        "The jitter value is a controlled netem budget, not a measured physical-radio "
        "jitter distribution. TCP retransmission remains enabled, and the experiment "
        "evaluates implemented protocol availability and latency rather than proving "
        "security.",
        "",
    ])
    (args.output / "RESULTS.md").write_text("\n".join(report), encoding="utf-8")

    targets = [
        args.input / "trials.jsonl",
        args.input / "summary.json",
        args.input / "manifest.json",
        Path(__file__).resolve(),
    ]
    targets.extend(sorted((args.input / "pcap").glob("*.pcap")))
    (args.output / "artifact_checksums.json").write_text(
        json.dumps(
            {str(path.resolve()): sha256(path) for path in targets},
            indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "trials": len(trials),
        "successes": sum(row["success"] for row in trials),
        "conflicting_adoptions": sum(
            not row["session_transcript_epoch_match"] for row in trials),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
