#!/usr/bin/env python3
"""Generate manuscript figures/macros from the archived network measurements."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import ScalarFormatter


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=Path("results"))
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    inputs = {}
    def read(relative):
        p = args.results / relative
        b = p.read_bytes()
        inputs[relative] = hashlib.sha256(b).hexdigest()
        return json.loads(b)
    loss = read("loss-main-n100/summary.json")
    rtt = read("rtt-main-n100/summary.json")
    comp = read("analysis-fullreattest-comparison-n100/comparison.json")
    jitter = read("jitter-main-n100/summary.json")
    asym = read("asymmetric-main-n100/summary.json")
    blackout = read("blackout-main-n100/summary.json")
    drift = read("epoch-drift-main-n100/summary.json")
    freq = read("reconnect-frequency-main-n100/summary.json")
    stable = read("analysis-stability-n1000/combined_summary.json")
    stable_loss = read("stability-asymmetric-20x20-n1000/summary.json")[0]
    stable_black = read("stability-blackout-before-m4-5s-n1000/summary.json")[0]
    stable_freq = read("stability-reconnect10-n1000/summary.json")[0]
    raw_black_path = args.results / "stability-blackout-before-m4-5s-n1000/trials.jsonl"
    raw_black = [json.loads(s) for s in raw_black_path.read_text().splitlines() if s.strip()]
    inputs[str(raw_black_path.relative_to(args.results))] = hashlib.sha256(raw_black_path.read_bytes()).hexdigest()
    assert len(raw_black) == 1000 and len(stable["rows"]) == 6
    assert len(drift) == 9 and len(comp) == 6 and len(blackout) == 15
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8,
                         "axes.titlesize": 8.5, "axes.labelsize": 8,
                         "legend.fontsize": 7, "xtick.labelsize": 7,
                         "ytick.labelsize": 7, "pdf.fonttype": 42,
                         "ps.fonttype": 42, "axes.spines.top": False,
                         "axes.spines.right": False})
    blue, orange, green = "#2166ac", "#b35806", "#238b45"
    def panels():
        fig, ax = plt.subplots(1, 2, figsize=(7.16, 2.55), layout="constrained")
        for a in ax:
            a.grid(axis="y", alpha=.25, linewidth=.5)
            a.set_axisbelow(True)
        return fig, ax
    def save(fig, name):
        fig.savefig(args.output / (name + ".pdf"))
        fig.savefig(args.output / (name + ".png"), dpi=300)
        plt.close(fig)
    fig, ax = panels()
    x = [r["rtt_ms"] for r in comp]
    for field, label, color, marker in [("gtr", "GT-R", blue, "o"),
                                         ("fullreattest", "FullReAttest", orange, "s")]:
        ax[0].plot(x, [r[field + "_median_ms"] for r in comp], marker + "-",
                   color=color, ms=3, label=label + " median")
        ax[0].plot(x, [r[field + "_p95_ms"] for r in comp], "--", color=color,
                   lw=1, label=label + " p95")
    ax[0].set(xscale="log", yscale="log", xlabel="Configured RTT (ms)", ylabel="TTSC (ms)",
              title="(a) Workflow comparison (n = 100 per point)")
    ax[0].legend(frameon=False, loc="upper left")
    ax[0].set_xticks([10, 50, 100, 500, 1000])
    ax[0].xaxis.set_major_formatter(ScalarFormatter())
    x = [r["condition"]["jitter_ms"] for r in jitter]
    for stat, label, marker in [("median", "Median", "o-"), ("p95", "p95", "s--")]:
        ax[1].plot(x, [r["ttsc_ms"][stat] for r in jitter], marker, ms=3,
                   color=blue if stat == "median" else orange, label=label)
    ax[1].set(xlabel="Configured jitter budget (ms)", ylabel="TTSC (ms)",
              title="(b) Jitter (RTT = 100 ms, n = 100)")
    ax[1].legend(frameon=False)
    save(fig, "fig_net_delay")

    fig, ax = panels()
    x = [r["condition"]["loss_percent"] for r in loss]
    rates = [100 * r["successes"] / r["trials"] for r in loss]
    ax[0].plot(x, rates, "o-", color=blue, ms=4)
    for xi, yi in zip(x, rates):
        if xi in (0, 10, 20, 30, 40):
            ax[0].annotate(f"{yi:g}%", (xi, yi), xytext=(0, 6),
                           textcoords="offset points", ha="center", fontsize=7)
    ax[0].set(xlabel="Loss in each direction (%)", ylabel="Completed handshakes (%)",
              ylim=(0, 110), title="(a) Symmetric loss (RTT = 50 ms, n = 100)")
    x = np.arange(len(asym))
    for stat, label, marker in [("median", "Median", "o-"), ("p95", "p95", "s--")]:
        ax[1].plot(x, [r["ttsc_ms"][stat] / 1000 for r in asym], marker, ms=3,
                   color=blue if stat == "median" else orange, label=label)
    ax[1].set_xticks(x, [f"{r['condition']['loss_i_to_j_percent']:g}/{r['condition']['loss_j_to_i_percent']:g}" for r in asym])
    ax[1].set(xlabel=r"Directional loss: $i\to j$ / $j\to i$ (%)",
              ylabel="Successful TTSC (s)", title="(b) Directional loss (RTT = 100 ms, n = 100)")
    ax[1].legend(frameon=False)
    save(fig, "fig_net_loss")

    fig, ax = panels()
    for trigger, label, color, marker in [("after_m2", "After M2", blue, "o"),
                                         ("before_m3", "Before M3", orange, "s"),
                                         ("before_m4", "Before M4", green, "^")]:
        points = [r for r in blackout if r["condition"]["trigger"] == trigger]
        ax[0].plot([r["condition"]["blackout_seconds"] for r in points],
                   [r["recovery_after_restore_ms"]["median"] for r in points],
                   marker + "-", color=color, ms=3, label=label)
    ax[0].set(xlabel="Blackout duration (s)", ylabel="Median recovery after restore (ms)",
              title="(a) Handshake interruption (n = 100)")
    ax[0].legend(frameon=False, loc="lower right")
    times = np.sort([r["recovery_after_restore_ms"] for r in raw_black if r["success"]])
    ax[1].step(times, np.arange(1, len(times)+1) / len(times), where="post", color=blue)
    ax[1].set(xlabel="Recovery after link restore (ms)", ylabel="Empirical CDF",
              ylim=(0, 1.02), title="(b) Before M4, 5 s blackout (n = 1,000)")
    save(fig, "fig_net_blackout")

    fig, ax = panels()
    x = np.arange(len(drift))
    ax[0].bar(x, [100*r["r1_completions"]/r["trials"] for r in drift], color=blue, label="R1 completed")
    rejected = [100*(r["policy_correct"]-r["r1_completions"])/r["trials"] for r in drift]
    ax[0].bar(x, rejected, color=orange, label="Correct R2 rejection")
    ax[0].set_xticks(x, [r["condition"]["delta"] for r in drift])
    ax[0].set(xlabel=r"Inter-peer epoch drift $\delta$", ylabel="Trial outcome (%)",
              ylim=(0, 124), title=r"(a) Drift ($\Delta_{max}=8$, $G_{max}=16$)")
    ax[0].legend(frameon=False, loc="upper center", ncol=2, fontsize=6.5)
    x = [r["condition"]["reconnects_per_mission"] for r in freq]
    for stat, label, marker in [("median", "Median, 100 missions", "o-"),
                              ("p95", "p95, 100 missions", "s--")]:
        ax[1].plot(x, [r["mission_cumulative_ttsc_ms"][stat]/1000 for r in freq],
                   marker, color=blue if stat == "median" else orange, ms=3, label=label)
    ax[1].plot(10, stable_freq["mission_cumulative_ttsc_ms"]["median"]/1000,
               "D", color=green, ms=5, label="Median, 1,000 missions")
    ax[1].set_xticks(x)
    ax[1].set(xlabel="Reconnects per logical mission", ylabel="Cumulative TTSC (s)",
              title="(b) Sequential stateful reconnection")
    ax[1].legend(frameon=False, loc="upper left")
    save(fig, "fig_net_state")

    # Numeric outcomes are generated, not duplicated as hand-edited TeX values.
    macros = {}
    def put(k, v, digits=2):
        macros["Net" + k] = f"{v:.{digits}f}" if digits else str(int(v))
    put("RttN", sum(r["trials"] for r in rtt), 0)
    put("RttLow", rtt[0]["ttsc_ms"]["median"])
    put("RttHigh", rtt[-1]["ttsc_ms"]["median"])
    for p in (20, 30, 40):
        name = {20: "Twenty", 30: "Thirty", 40: "Forty"}[p]
        put("Loss" + name + "Pass", next(r["successes"] for r in loss if r["condition"]["loss_percent"] == p), 0)
    put("JitterN", sum(r["trials"] for r in jitter), 0)
    for prefix, row in [("JitterLow", jitter[0]), ("JitterHigh", jitter[-1])]:
        put(prefix + "Median", row["ttsc_ms"]["median"])
        put(prefix + "Ptf", row["ttsc_ms"]["p95"])
    point = next(r for r in comp if r["rtt_ms"] == 100)
    for short, full in [("Gtr", "gtr"), ("Full", "fullreattest")]:
        put("Cmp" + short + "Median", point[full + "_median_ms"])
        put("Cmp" + short + "Ptf", point[full + "_p95_ms"])
    put("CmpRatioLow", min(r["speedup_full_over_gtr"] for r in comp))
    put("CmpRatioHigh", max(r["speedup_full_over_gtr"] for r in comp))
    put("DriftInN", sum(r["r1_completions"] for r in drift), 0)
    put("DriftOutN", sum(r["policy_correct"]-r["r1_completions"] for r in drift), 0)
    put("LossStableN", stable_loss["trials"], 0)
    put("LossStablePass", stable_loss["successes"], 0)
    put("LossStableRate", stable_loss["success_rate_percent"], 1)
    loss_row = stable["rows"][3]
    put("LossCiLow", 100*loss_row["wilson_95"][0])
    put("LossCiHigh", 100*loss_row["wilson_95"][1])
    put("LossStableMedian", stable_loss["ttsc_ms"]["median"])
    put("LossStablePtf", stable_loss["ttsc_ms"]["p95"])
    put("LossStableFail", stable_loss["trials"]-stable_loss["successes"], 0)
    for m, name in [(2,"Two"),(3,"Three"),(4,"Four")]:
        put("Timeout"+name, stable_loss["timeout_stages"][f"TIMEOUT_M{m}"], 0)
    put("BlackoutN", sum(r["trials"] for r in blackout), 0)
    for label, field in [("Recovery", "recovery_after_restore_ms"), ("Total", "handshake_total_ms")]:
        put("Black" + label + "Median", stable_black[field]["median"])
        put("Black" + label + "Ptf", stable_black[field]["p95"])
    put("BlackRetries", stable_black["application_retries_sum"], 0)
    put("BlackReuse", stable_black["candidate_reuse_sum"], 0)
    put("FreqMissions", sum(r["missions"] for r in freq), 0)
    put("FreqCycles", sum(r["executed_cycles"] for r in freq), 0)
    put("StableMissions", stable_freq["missions"], 0)
    put("StableCycles", stable_freq["executed_cycles"], 0)
    put("CycleMedian", stable_freq["cycle_ttsc_ms"]["median"])
    put("CyclePtf", stable_freq["cycle_ttsc_ms"]["p95"])
    put("MissionMedian", stable_freq["mission_cumulative_ttsc_ms"]["median"])
    put("MissionPtf", stable_freq["mission_cumulative_ttsc_ms"]["p95"])
    put("PerfectCiLow", 100*stable["rows"][0]["wilson_95"][0])
    (args.output / "network_macros.tex").write_text(
        "% Generated by build_paper_network_figures.py; do not edit numeric values.\n" +
        "".join(f"\\newcommand{{\\{k}}}{{{v}}}\n" for k, v in macros.items()))
    labels = [r"$\delta=4$", r"$\delta=8$", r"$\delta=9$", r"20\%/20\% loss",
              "5-s blackout before M4", "10 reconnects/mission"]
    outcomes = ["R1 completion", "R1 completion", "Correct R2 rejection",
                "Completion", "Completion", "All cycles complete"]
    metrics = ["TTSC", "TTSC", "--", "TTSC", "Recovery", "Cumulative TTSC"]
    lines = ["% Generated stability table rows; latency is in milliseconds."]
    for i, row in enumerate(stable["rows"]):
        lo, hi = row["wilson_95"]
        latency = "--" if row["latency_ms"]["median"] is None else "/".join(
            f"{row['latency_ms'][k]:.2f}" for k in ("median", "p95"))
        lines.append(f"{labels[i]} & {outcomes[i]} & {row['successes']}/{row['n']} & "
                     f"{100*lo:.2f}--{100*hi:.2f} & {metrics[i]} & {latency} \\\\")
    (args.output / "network_stability_rows.tex").write_text("\n".join(lines)+"\n")
    with (args.output / "network_macros.tex").open("a") as handle:
        handle.write("\\newcommand{\\NetStabilityRows}{%\n" + "\n".join(lines[1:]) + "\n}\n")
    (args.output / "provenance.json").write_text(json.dumps({
        "source_sha256": inputs, "builder_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "notes": "n=100 sweeps and n=1000 stability results are not pooled. Latencies use completed trials only. Figures are data plots, not generated illustrations."
    }, indent=2)+"\n")
    print(f"Wrote four PDF/PNG figures, {len(macros)} macros, stability table, and provenance to {args.output}")


if __name__ == "__main__":
    main()
