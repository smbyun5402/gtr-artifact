#!/usr/bin/env python3
"""Run GT-R M1--M4 under independently impaired link directions."""

from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import os
import platform
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

import run_netns_experiment as network


HERE = Path(__file__).resolve().parent
LOSS_PAIRS = ((0, 0), (5, 5), (5, 20), (20, 5), (20, 20))
FLIGHTS = ("M1", "M2", "M3", "M4")


def parse_loss_pairs(value: str) -> tuple[tuple[float, float], ...]:
    pairs = []
    for item in value.split(","):
        left, separator, right = item.strip().partition(":")
        if not separator:
            raise ValueError("loss pairs must use i_to_j:j_to_i syntax")
        pairs.append((float(left), float(right)))
    return tuple(pairs)


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * quantile
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = rank - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def describe(values: list[float]) -> dict:
    return {
        "median": statistics.median(values) if values else None,
        "p95": percentile(values, 0.95),
        "p99": percentile(values, 0.99),
        "max": max(values) if values else None,
    }


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def apply_egress(device: str, loss_percent: float,
                 one_way_delay_ms: float) -> None:
    network.root_command([
        "ip", "netns", "exec", network.NS_R,
        "tc", "qdisc", "replace", "dev", device, "root", "netem",
        "delay", f"{one_way_delay_ms:.3f}ms",
        "loss", f"{loss_percent:.3f}%",
    ])


def apply_asymmetric_netem(loss_i_to_j: float, loss_j_to_i: float,
                           rtt_ms: float) -> None:
    one_way = rtt_ms / 2.0
    # Router egress vrj0 delivers I -> J; egress vri0 delivers J -> I.
    apply_egress("vrj0", loss_i_to_j, one_way)
    apply_egress("vri0", loss_j_to_i, one_way)


def flight_latency(left: dict, right: dict) -> dict:
    i_events = left.get("events_monotonic_ns", {})
    j_events = right.get("events_monotonic_ns", {})
    endpoints = {
        "M1": (i_events.get("m1_send_started_ns"),
               j_events.get("m1_recv_completed_ns")),
        "M2": (j_events.get("m2_send_started_ns"),
               i_events.get("m2_recv_completed_ns")),
        "M3": (i_events.get("m3_send_started_ns"),
               j_events.get("m3_recv_completed_ns")),
        "M4": (j_events.get("m4_send_started_ns"),
               i_events.get("m4_recv_completed_ns")),
    }
    return {
        flight: ((end - start) / 1_000_000
                 if start is not None and end is not None and end >= start
                 else None)
        for flight, (start, end) in endpoints.items()
    }


def timeout_stage(row: dict) -> str | None:
    for endpoint in (row.get("initiator") or {}, row.get("responder") or {}):
        error = str(endpoint.get("error", ""))
        if "TIMEOUT_" in error:
            return error[error.index("TIMEOUT_"):].split()[0]
    return None


def enrich(row: dict) -> dict:
    left = row.get("initiator") or {}
    right = row.get("responder") or {}
    result = dict(row)
    result.update({
        "flight_latency_ms": flight_latency(left, right),
        "directional_tcp_retransmissions": {
            "i_to_j": left.get("tcp", {}).get("total_retrans"),
            "j_to_i": right.get("tcp", {}).get("total_retrans"),
        },
        "timeout_stage": timeout_stage(row),
        "unexpected_conflicting_adoption": bool(
            row.get("both_endpoints_adopted")
            and not row.get("session_transcript_epoch_match")),
    })
    return result


def summarize(condition: dict, rows: list[dict]) -> dict:
    successful = [row for row in rows if row["success"]]
    ttsc = [row["ttsc_ms"] for row in successful if row["ttsc_ms"] is not None]
    flights = {}
    for flight in FLIGHTS:
        values = [
            row["flight_latency_ms"][flight] for row in successful
            if row["flight_latency_ms"][flight] is not None
        ]
        flights[flight] = describe(values)
    retransmissions = {}
    for direction in ("i_to_j", "j_to_i"):
        values = [
            row["directional_tcp_retransmissions"][direction] for row in rows
            if row["directional_tcp_retransmissions"][direction] is not None
        ]
        retransmissions[direction] = {
            "sum": sum(values) if values else 0,
            "median": statistics.median(values) if values else None,
            "max": max(values) if values else None,
        }
    return {
        "condition": condition,
        "trials": len(rows),
        "successes": len(successful),
        "success_rate_percent": 100 * len(successful) / len(rows),
        "ttsc_ms": describe(ttsc),
        "flight_latency_ms": flights,
        "directional_tcp_retransmissions": retransmissions,
        "timeout_stages": dict(collections.Counter(
            row["timeout_stage"] for row in rows if row["timeout_stage"])),
        "failure_reasons": dict(collections.Counter(
            row["failure_reason"] for row in rows if row["failure_reason"])),
        "conflicting_adoptions": sum(
            row["unexpected_conflicting_adoption"] for row in rows),
    }


def write_summary_csv(path: Path, summaries: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "loss_i_to_j_percent", "loss_j_to_i_percent", "trials",
            "successes", "success_rate_percent", "ttsc_median_ms",
            "ttsc_p95_ms", "ttsc_p99_ms", "m1_p95_ms", "m2_p95_ms",
            "m3_p95_ms", "m4_p95_ms", "i_to_j_retransmissions_sum",
            "j_to_i_retransmissions_sum", "timeouts", "conflicting_adoptions",
        ])
        for row in summaries:
            condition = row["condition"]
            writer.writerow([
                condition["loss_i_to_j_percent"],
                condition["loss_j_to_i_percent"], row["trials"],
                row["successes"], row["success_rate_percent"],
                row["ttsc_ms"]["median"], row["ttsc_ms"]["p95"],
                row["ttsc_ms"]["p99"],
                row["flight_latency_ms"]["M1"]["p95"],
                row["flight_latency_ms"]["M2"]["p95"],
                row["flight_latency_ms"]["M3"]["p95"],
                row["flight_latency_ms"]["M4"]["p95"],
                row["directional_tcp_retransmissions"]["i_to_j"]["sum"],
                row["directional_tcp_retransmissions"]["j_to_i"]["sum"],
                sum(row["timeout_stages"].values()),
                row["conflicting_adoptions"],
            ])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=100)
    parser.add_argument("--rtt-ms", type=float, default=100.0)
    parser.add_argument("--initiator-epoch", type=int, default=0)
    parser.add_argument("--responder-epoch", type=int, default=4)
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument(
        "--loss-pairs", default=",".join(f"{i}:{j}" for i, j in LOSS_PAIRS),
        help="comma-separated i_to_j:j_to_i loss percentages")
    parser.add_argument("--output")
    parser.add_argument("--no-pcap", action="store_true")
    parser.add_argument("--keep-namespaces", action="store_true")
    args = parser.parse_args()
    try:
        loss_pairs = parse_loss_pairs(args.loss_pairs)
    except ValueError as exc:
        parser.error(str(exc))
    if (args.repetitions < 1 or args.rtt_ms < 0 or not loss_pairs
            or any(i < 0 or j < 0 for i, j in loss_pairs)):
        parser.error("repetitions must be positive and RTT non-negative")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-asymmetric")
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "scratch"
    scratch.mkdir()
    log_path = output / "processes.log"

    openssl, openssl_version = network.openssl_environment()
    library_path = os.environ.get("LD_LIBRARY_PATH", "")
    config = network.provision(
        output, args.initiator_epoch, args.responder_epoch)
    conditions = [{
        "id": f"i2j{loss_i}-j2i{loss_j}",
        "loss_i_to_j_percent": float(loss_i),
        "loss_j_to_i_percent": float(loss_j),
        "rtt_ms": args.rtt_ms,
        "jitter_ms": 0.0,
        "repetitions": args.repetitions,
    } for loss_i, loss_j in loss_pairs]
    paths = {"output": output, "scratch": scratch}
    summaries = []
    all_rows = []

    network.setup_topology()
    try:
        apply_asymmetric_netem(0.0, 0.0, 0.0)
        network.verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            for condition in conditions:
                loss_i = condition["loss_i_to_j_percent"]
                loss_j = condition["loss_j_to_i_percent"]
                print(
                    f"[{condition['id']}] i->j={loss_i:g}% "
                    f"j->i={loss_j:g}% RTT={args.rtt_ms:g}ms "
                    f"n={args.repetitions}", flush=True)
                apply_asymmetric_netem(loss_i, loss_j, args.rtt_ms)
                capture = pcap = None
                if not args.no_pcap:
                    capture, pcap = network.start_capture(
                        condition, output, log_handle)
                condition_rows = []
                try:
                    for trial_number in range(1, args.repetitions + 1):
                        raw = network.run_trial(
                            condition, trial_number, paths, config,
                            args.timeout, openssl, library_path, log_handle)
                        row = enrich(raw)
                        condition_rows.append(row)
                        all_rows.append(row)
                        with (output / "trials.jsonl").open(
                                "a", encoding="utf-8") as handle:
                            handle.write(json.dumps(row, sort_keys=True) + "\n")
                        if trial_number % 20 == 0 or not row["success"]:
                            print(
                                f"  trial {trial_number}/{args.repetitions}: "
                                f"{'ok' if row['success'] else row['failure_reason']}",
                                flush=True)
                finally:
                    if capture is not None and pcap is not None:
                        network.stop_capture(capture, pcap)
                summary = summarize(condition, condition_rows)
                summaries.append(summary)
                write_json(output / "summary.json", summaries)
                write_summary_csv(output / "summary.csv", summaries)
                print(
                    f"  success={summary['success_rate_percent']:.1f}% "
                    f"median={summary['ttsc_ms']['median']}ms "
                    f"retx=({summary['directional_tcp_retransmissions']['i_to_j']['sum']},"
                    f"{summary['directional_tcp_retransmissions']['j_to_i']['sum']})",
                    flush=True)
    finally:
        if not args.keep_namespaces:
            network.cleanup_topology()

    manifest = {
        "schema": "gtr.netns.asymmetric.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "experiment": "directionally asymmetric packet loss",
        "network_topology": (
            "gtr_eval_i(10.10.0.2) -- gtr_eval_r -- "
            "gtr_eval_j(10.20.0.2)"
        ),
        "direction_mapping": {
            "router_vrj0_egress": "initiator to responder (M1 and M3)",
            "router_vri0_egress": "responder to initiator (M2 and M4)",
        },
        "transport": "TCP with direction-specific netem loss",
        "timing_scope": (
            "TTSC covers fresh TCP establishment through initiator M4 "
            "verification. Per-flight time runs from application send start to "
            "the peer receiving the complete framed message."
        ),
        "cryptography": (
            "OpenSSL ML-KEM-768 for ephemeral, static, and epoch-indexed FS-KEM; "
            "HKDF-SHA-256/HMAC-SHA-256 for ratchet and authentication"
        ),
        "openssl": openssl_version,
        "python": sys.version,
        "platform": platform.platform(),
        "epochs": {
            "initiator": args.initiator_epoch,
            "responder": args.responder_epoch,
            "converged": max(args.initiator_epoch, args.responder_epoch) + 1,
        },
        "conditions": conditions,
        "source_sha256": {
            Path(__file__).name: sha256(Path(__file__)),
            network.ENDPOINT.name: sha256(network.ENDPOINT),
            "run_netns_experiment.py": sha256(Path(network.__file__)),
            "reauth_demo.py": sha256(HERE / "reauth_demo.py"),
        },
        "outputs": {
            "summary_json": "summary.json",
            "summary_csv": "summary.csv",
            "trials_jsonl": "trials.jsonl",
            "pcap_directory": None if args.no_pcap else "pcap",
            "process_log": "processes.log",
        },
        "limitations": [
            "Loss is independent netem Bernoulli loss, not a physical DDIL radio trace.",
            "TCP retransmission is enabled; no GT-R application-level retry is added.",
            "Per-flight latency includes sender blocking and process scheduling, not only propagation.",
            "A socket timeout identifies the awaited flight, but TCP may hide individual packet loss.",
        ],
    }
    write_json(output / "manifest.json", manifest)
    conflicts = sum(row["unexpected_conflicting_adoption"] for row in all_rows)
    print(json.dumps({
        "output": str(output),
        "trials": len(all_rows),
        "successes": sum(row["success"] for row in all_rows),
        "conflicting_adoptions": conflicts,
    }, indent=2))
    return 2 if conflicts else 0


if __name__ == "__main__":
    raise SystemExit(main())
