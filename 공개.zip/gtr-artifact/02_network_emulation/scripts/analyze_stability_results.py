#!/usr/bin/env python3
"""Audit the completed n=1000 campaign and create a compact statistical report.

Read-only with respect to measured results. Only the analysis output directory
is written. Raw successes are cross-checked against the runner summaries.
"""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import shutil
import statistics
import subprocess

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle


DIRECTORIES = {
    "drift": "stability-epoch-drift-n1000",
    "loss": "stability-asymmetric-20x20-n1000",
    "blackout": "stability-blackout-before-m4-5s-n1000",
    "repeat": "stability-reconnect10-n1000",
}


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def percentiles(values):
    ordered = sorted(values)
    if not ordered:
        return {"median": None, "p95": None, "p99": None}
    def quantile(p):
        x = (len(ordered) - 1) * p
        lo, hi = math.floor(x), math.ceil(x)
        return ordered[lo] + (ordered[hi] - ordered[lo]) * (x - lo)
    return {"median": statistics.median(ordered), "p95": quantile(.95),
            "p99": quantile(.99)}


def wilson(successes, n):
    z = 1.959963984540054
    p = successes / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    radius = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return [max(0, center - radius), min(1, center + radius)]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check_times(actual, recorded, label):
    for key, value in actual.items():
        require(value is None and recorded[key] is None or
                value is not None and math.isclose(value, recorded[key], rel_tol=1e-9),
                f"{label}: {key} does not match raw records")


def fmt(value):
    return "-" if value is None else f"{value:,.2f}"


def pdf_report(path, rows, loss, blackout, repeat):
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle("SmallNote", fontName="Helvetica", fontSize=9,
                             leading=12, spaceAfter=7))
    styles.add(ParagraphStyle("CellSmall", fontName="Helvetica", fontSize=8.6,
                             leading=11))
    styles.add(ParagraphStyle("CellHead", fontName="Helvetica-Bold", fontSize=8.6,
                             leading=11, textColor=colors.white))
    styles.add(ParagraphStyle("SubTitle2", fontSize=10, leading=13,
                             textColor=colors.HexColor("#425466"), spaceAfter=12))
    doc = SimpleDocTemplate(str(path), pagesize=landscape(A4),
                            rightMargin=32, leftMargin=32, topMargin=27,
                            bottomMargin=25, title="GT-R: 1,000-repeat stability campaign",
                            author="GT-R experimental artifact")
    story = [Paragraph("GT-R | 1,000-repeat stability campaign", styles["Title"]),
             Paragraph("Completed campaign - Linux network emulation, not physical UAV/UGV field testing",
                       styles["SubTitle2"])]
    story.append(Paragraph(
        "<b>Coverage:</b> 6,000 outer trials/missions across six conditions, including "
        "10,000 stateful reconnect cycles in 1,000 ten-cycle missions. All conditions "
        "use a configured 100 ms RTT. Real OpenSSL ML-KEM-768/HKDF/HMAC execution "
        "runs between Linux network namespaces through <i>tc netem</i> on one Ubuntu VM.",
        styles["SmallNote"]))
    headers = ["Condition", "Measured outcome", "Observed", "95% Wilson CI", "Latency metric",
               "Median / p95 / p99 (ms)"]
    data = [[Paragraph(h, styles["CellHead"]) for h in headers]]
    for row in rows:
        lo, hi = row["wilson_95"]
        cells = [row["label"], row["outcome"],
                 f"{row['successes']:,}/{row['n']:,} ({100*row['successes']/row['n']:.1f}%)",
                 f"{100*lo:.2f}-{100*hi:.2f}%", row["latency_metric"],
                 " / ".join(fmt(row["latency_ms"][k]) for k in ("median", "p95", "p99"))]
        data.append([Paragraph(c, styles["CellSmall"]) for c in cells])
    table = Table(data, colWidths=[89, 101, 108, 90, 109, 213], repeatRows=1, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#18384f")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor("#f1f5f8"), colors.white]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LINEBELOW", (0, -1), (-1, -1), .5, colors.HexColor("#bccbd5")),
    ]))
    story.extend([table, Spacer(1, 12)])
    notes = [
        ("Loss failures", f"24/1,000 trials did not complete: M2 timeout 14, M3 timeout 6, "
         "M4 timeout 4. Four failures left only the responder adopted; zero conflicting "
         "adoptions were recorded. Successful-only latency excludes these failures. "
         "TCP retransmission is enabled; this suite has no application-level retry."),
        ("Blackout recovery", f"All 1,000 trials recovered with live endpoints and cached candidates. "
         f"Total handshake latency median/p95: {blackout['handshake_total_ms']['median']:.2f}/"
         f"{blackout['handshake_total_ms']['p95']:.2f} ms, including the outage. "
         "There were 3,000 application retries and 3,000 candidate reuses. This is not a crash-recovery test."),
        ("Boundary and state checks", "Drift tests set Delta_max=8 and G_max=16 to isolate drift. "
         "Delta=9 selects R2 without exporting a key; it does not execute verifier-assisted re-attestation. "
         "The ten-cycle missions use Delta_max=G_max=8 and clean restored links. "
         "All 10,000 cycles passed key/transcript/chain, epoch-convergence, and software-state checks."),
        ("Interpretation", "Intervals describe the binomial trial/mission outcome under the evaluated settings; "
         "1,000/1,000 is not a guarantee of universal 100% reliability. The repeated-campaign CI uses "
         "1,000 missions, not 10,000 independent cycles. Its 600-second mission is logical, not real-time. "
         "No physical UAV/UGV, RF channel, mobility, or hardware-RoT endurance was tested here."),
    ]
    for heading, body in notes:
        story.append(Paragraph(f"<b>{heading}.</b> {body}", styles["SmallNote"]))
    story.append(Paragraph("Source: campaign JSONL records and manifests; hashes and packet-capture audit accompany this report. "
                           "No manuscript changes were made.", styles["SmallNote"]))
    doc.build(story)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=Path("results"))
    parser.add_argument("--output", type=Path, default=Path("results/analysis-stability-n1000"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    source_dir = Path(__file__).resolve().parent
    groups = {k: args.results / name for k, name in DIRECTORIES.items()}
    summaries = {k: load(path / "summary.json") for k, path in groups.items()}
    raw = {k: jsonl(path / ("cycles.jsonl" if k == "repeat" else "trials.jsonl"))
           for k, path in groups.items()}
    missions = jsonl(groups["repeat"] / "missions.jsonl")
    require([len(raw[k]) for k in ("drift", "loss", "blackout", "repeat")] ==
            [3000, 1000, 1000, 10000], "Unexpected raw record counts")
    require(len(missions) == 1000, "Expected 1,000 missions")
    rows = []
    def add(label, outcome, records, success_key, latency_key, recorded_latency):
        n = len(records)
        successes = sum(bool(r[success_key]) for r in records)
        times = percentiles([r[latency_key] for r in records
                             if latency_key and r["success"] and r.get(latency_key) is not None])
        check_times(times, recorded_latency, label)
        row = {"label": label, "outcome": outcome, "n": n, "successes": successes,
               "wilson_95": wilson(successes, n), "latency_ms": times,
               "latency_metric": "Successful TTSC"}
        rows.append(row)
        return row
    for summary in summaries["drift"]:
        delta = summary["condition"]["delta"]
        records = [r for r in raw["drift"] if r["condition"]["delta"] == delta]
        require(len(records) == 1000, "Expected 1,000 trials per delta")
        row = add(f"Drift = {delta} epochs", "R1 completion" if delta <= 8 else "Correct R2 rejection",
                  records, "policy_outcome_correct", "ttsc_ms", summary["ttsc_ms"])
        require(row["successes"] == summary["policy_correct"], "Drift summary mismatch")
        require(not any(r["unexpected_adoption"] or r["unexpected_key_export"] for r in records),
                "Unexpected drift adoption/export")
        if delta > 8:
            row["latency_metric"] = "No key completion"
        else:
            require(all(r["success"] and r["epoch_converged"] for r in records), "R1 mismatch")
    loss = summaries["loss"][0]
    add("Loss = 20% / 20%", "Handshake completion", raw["loss"], "success", "ttsc_ms", loss["ttsc_ms"])
    require(rows[-1]["successes"] == loss["successes"], "Loss summary mismatch")
    timeouts = Counter(r["timeout_stage"] for r in raw["loss"] if not r["success"])
    require(dict(timeouts) == loss["timeout_stages"], "Timeout summary mismatch")
    adoptions = Counter(f"i={bool(r['initiator'].get('adopted'))},j={bool(r['responder'].get('adopted'))}"
                        for r in raw["loss"] if not r["success"])
    require(not any(r["unexpected_conflicting_adoption"] for r in raw["loss"]), "Loss conflict")
    blackout = summaries["blackout"][0]
    add("5 s blackout before M4", "Handshake completion", raw["blackout"], "success",
        "recovery_after_restore_ms", blackout["recovery_after_restore_ms"])
    rows[-1]["latency_metric"] = "After link restore"
    require(rows[-1]["successes"] == blackout["successes"], "Blackout summary mismatch")
    require(all(r["candidate_survived_blackout"] and not r["candidate_conflicts"]
                and r["session_transcript_epoch_match"] for r in raw["blackout"]), "Blackout invariant")
    repeat = summaries["repeat"][0]
    add("10 reconnects / mission", "All 10 cycles complete", missions, "success",
        "cumulative_ttsc_ms", repeat["mission_cumulative_ttsc_ms"])
    rows[-1]["latency_metric"] = "Cumulative TTSC"
    require(rows[-1]["successes"] == repeat["successful_missions"], "Mission summary mismatch")
    require(len({(r["mission"], r["cycle"]) for r in raw["repeat"]}) == 10000,
            "Duplicate/missing cycles")
    require(all(all(r[k] for k in ("success", "session_transcript_chain_match", "epoch_convergence",
                                  "candidate_cleanup_verified", "private_committed_state_match"))
                for r in raw["repeat"]), "Cycle invariant failure")
    cycles_by_mission = {}
    for cycle in raw["repeat"]:
        cycles_by_mission.setdefault(cycle["mission"], []).append(cycle)
    for mission in missions:
        cycles = cycles_by_mission[mission["mission"]]
        require({r["cycle"] for r in cycles} == set(range(1, 11)), "Mission cycle indices")
        require(math.isclose(sum(r["ttsc_ms"] for r in cycles), mission["cumulative_ttsc_ms"],
                             rel_tol=1e-9), "Cumulative timing mismatch")
        require(mission["final_converged_epoch"] == 60, "Unexpected final epoch")

    # Snapshot only the public source files whose hashes were recorded at runtime.
    snapshot = args.output / "source_snapshot"
    snapshot.mkdir(exist_ok=True)
    checksums = {}
    pcap_audit = []
    for key, path in groups.items():
        manifest = load(path / "manifest.json")
        for filename, expected in manifest["source_sha256"].items():
            source = source_dir / filename
            require(digest(source) == expected, f"Executed source hash mismatch: {filename}")
            shutil.copy2(source, snapshot / filename)
        names = ["manifest.json", "summary.json", "summary.csv", "processes.log"]
        names += ["cycles.jsonl", "missions.jsonl"] if key == "repeat" else ["trials.jsonl"]
        targets = [path / name for name in names if (path / name).exists()]
        for pcap in sorted((path / "pcap").glob("*.pcap")):
            process = subprocess.Popen(["tcpdump", "-nn", "-r", str(pcap)],
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            count = sum(1 for _ in process.stdout)
            diagnostics = process.stderr.read().decode()
            require(process.wait() == 0 and count > 0, f"Unreadable/empty pcap: {pcap}")
            pcap_audit.append({"path": str(pcap.relative_to(args.results)),
                               "packet_records": count, "bytes": pcap.stat().st_size,
                               "diagnostics": diagnostics.strip()})
            targets.append(pcap)
        for target in targets:
            checksums[str(target.relative_to(args.results))] = digest(target)
    require(len(pcap_audit) == 6, "Expected six condition-specific pcaps")
    report = {"schema": "gtr.stability.analysis.v1", "outer_samples": 6000,
              "stateful_cycles": 10000, "rows": rows, "loss_timeout_stages": dict(timeouts),
              "loss_failed_adoption_patterns": dict(adoptions), "pcaps": pcap_audit,
              "blackout_summary": blackout, "repeated_summary": repeat,
              "statistics_note": "Wilson 95% intervals use the binomial trial/mission unit; temporal independence is an assumption, not established by these measurements."}
    (args.output / "combined_summary.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.output / "artifact_checksums.json").write_text(json.dumps(checksums, indent=2, sort_keys=True) + "\n")
    lines = ["# GT-R 1,000-repeat stability campaign", "", "All selected campaigns completed. The manuscript was not changed.", "",
             "| Condition | Outcome | Count | Wilson 95% CI | Latency median / p95 / p99 (ms) |",
             "|---|---|---:|---|---|"]
    for row in rows:
        lo, hi = row["wilson_95"]
        lines.append(f"| {row['label']} | {row['outcome']} | {row['successes']}/{row['n']} | "
                     f"{100*lo:.2f}-{100*hi:.2f}% | " +
                     " / ".join(fmt(row["latency_ms"][k]) for k in ("median", "p95", "p99")) + " |")
    lines += ["", "## Interpretation and limits", "",
              "- This is a Linux netem/Ubuntu VM network-emulation campaign with actual OpenSSL cryptography, not physical UAV/UGV deployment or RF field testing.",
              "- Drift uses Delta_max=8 and G_max=16 to isolate drift. Delta=9 is correct fail-closed R2 selection, not successful resumption and not a completed verifier exchange.",
              "- Loss is independently configured at 20% in each direction. 976 completed; 24 failed with timeout stages M2=14, M3=6, M4=4. Twenty failures had neither endpoint adopted; four had only the responder adopted. Zero conflicting adoptions were observed. No application retry is used in this suite.",
              "- The socket timeout setting is 15 seconds; it is not a global handshake deadline. Successful TTSC can therefore exceed 15 seconds. Latency percentiles exclude unsuccessful attempts; failures must be reported alongside them.",
              "- Blackout recovery timing begins at link restoration. Total handshake median/p95/p99 including blackout is " +
              " / ".join(fmt(blackout["handshake_total_ms"][k]) for k in ("median", "p95", "p99")) + " ms. Endpoints remain alive; this does not test crash recovery. Three application retries per trial reuse cached candidates.",
              "- Repeated missions use Delta_max=G_max=8, drift=4 per reconnect, and zero loss on restored links. Their 600-second duration is logical, not replayed in real time. All 10,000 cycles meet key/transcript/chain, epoch and software persistence invariants. Cumulative timing excludes logical outage intervals.",
              "- The 1,000-mission CI uses missions as samples; sequential cycles within each mission are not treated as 10,000 independent samples. Wilson intervals assume a binomial sampling model; stable independent probabilities across a single VM run are not proven.",
              "- The measured application traffic is framed JSON/base64, not the compact binary protocol size. Candidate persistence/cleanup here is software-based, not physical RoT endurance or secure-erasure validation.",
              "- A 1,000/1,000 result has a Wilson lower limit of about 99.62%; it is not a universal guarantee of 100% reliability or a cryptographic proof.",
              "", "## Audit and reproduction", "",
              "Raw record counts, outcome summaries, latency quantiles, cycle uniqueness, per-mission sums, final epochs, and manifest source hashes were cross-checked. All six pcaps were read successfully. Packet-record counts on the router's any interface can include both ingress and egress records and must not be interpreted as unique packets.",
              "", "The source_snapshot directory preserves the exact measured source files (hash-checked against each runtime manifest). It excludes credentials, provisioning secrets and scratch state. Public raw output hashes are relative to the results directory in artifact_checksums.json.",
              "", "Run from netns with a Python environment containing reportlab:", "",
              "```sh", "python3 analyze_stability_results.py --results results --output results/analysis-stability-n1000", "```", ""]
    (args.output / "RESULTS.md").write_text("\n".join(lines), encoding="utf-8")
    pdf_dir = args.output / "output" / "pdf"
    pdf_dir.mkdir(parents=True, exist_ok=True)
    pdf_report(pdf_dir / "gt_r_stability_n1000.pdf", rows, loss, blackout, repeat)
    print(json.dumps({"completed": True, "outer_samples": 6000, "stateful_cycles": 10000,
                      "pcap_count": len(pcap_audit), "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
