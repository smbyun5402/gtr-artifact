#!/usr/bin/env python3
"""Create paper-review plots and a compact report from GT-R netns results."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def wilson(successes: int, trials: int, z: float = 1.959963984540054):
    proportion = successes / trials
    denominator = 1 + z * z / trials
    center = (proportion + z * z / (2 * trials)) / denominator
    half = z * math.sqrt(
        proportion * (1 - proportion) / trials + z * z / (4 * trials * trials)
    ) / denominator
    return center - half, center + half


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save_figure(fig, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def plot_loss(rows: list[dict], output: Path) -> None:
    rows = sorted(rows, key=lambda row: row["condition"]["loss_percent"])
    x = np.array([row["condition"]["loss_percent"] for row in rows])
    positions = np.arange(len(rows))
    rate = np.array([row["success_rate_percent"] for row in rows])
    intervals = [wilson(row["successes"], row["trials"]) for row in rows]
    lower = rate - np.array([100 * interval[0] for interval in intervals])
    upper = np.array([100 * interval[1] for interval in intervals]) - rate
    median = np.array([row["ttsc_ms"]["median"] for row in rows])
    p95 = np.array([row["ttsc_ms"]["p95"] for row in rows])
    p99 = np.array([row["ttsc_ms"]["p99"] for row in rows])

    fig, axes = plt.subplots(1, 2, figsize=(10.0, 3.8))
    axes[0].errorbar(
        positions, rate, yerr=np.vstack([lower, upper]), marker="o", capsize=4,
        color="#1666ba", linewidth=1.8,
    )
    axes[0].set_xlabel("Symmetric packet loss (%)")
    axes[0].set_ylabel("Completion rate (%)")
    axes[0].set_ylim(0, 105)
    axes[0].set_xticks(positions, labels=[f"{value:g}" for value in x])
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(positions, median, "o-", label="median", linewidth=1.8)
    axes[1].plot(positions, p95, "s--", label="p95", linewidth=1.5)
    axes[1].plot(positions, p99, "^:", label="p99", linewidth=1.5)
    axes[1].set_xlabel("Symmetric packet loss (%)")
    axes[1].set_ylabel("TTSC (ms, log scale)")
    axes[1].set_yscale("log")
    axes[1].set_xticks(positions, labels=[f"{value:g}" for value in x])
    axes[1].grid(True, which="both", alpha=0.3)
    axes[1].legend(frameon=False)
    fig.suptitle("GT-R under symmetric loss (RTT = 50 ms, n = 100)")
    fig.tight_layout()
    save_figure(fig, output / "gt_r_loss_n100")


def plot_rtt(rows: list[dict], output: Path) -> tuple[float, float]:
    rows = sorted(rows, key=lambda row: row["condition"]["rtt_ms"])
    x = np.array([row["condition"]["rtt_ms"] for row in rows])
    median = np.array([row["ttsc_ms"]["median"] for row in rows])
    p95 = np.array([row["ttsc_ms"]["p95"] for row in rows])
    coefficient = np.polyfit(x, median, 1)
    fitted = coefficient[0] * x + coefficient[1]

    fig, ax = plt.subplots(figsize=(5.5, 3.8))
    ax.plot(x, median, "o-", label="median", linewidth=1.8)
    ax.plot(x, p95, "s--", label="p95", linewidth=1.5)
    ax.plot(
        x, fitted, color="#555555", linestyle=":",
        label=f"fit: {coefficient[0]:.3f}×RTT + {coefficient[1]:.1f} ms",
    )
    ax.set_xlabel("Configured end-to-end RTT (ms)")
    ax.set_ylabel("TTSC (ms)")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    ax.set_title("GT-R reconnect latency (0% loss, n = 100)")
    fig.tight_layout()
    save_figure(fig, output / "gt_r_rtt_n100")
    return float(coefficient[0]), float(coefficient[1])


def table(rows: list[dict], independent: str) -> list[str]:
    lines = [
        "| Condition | Success | Rate | Median TTSC | p95 | p99 | Retransmissions | Conflicts |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    key = "loss_percent" if independent == "loss" else "rtt_ms"
    for row in sorted(rows, key=lambda item: item["condition"][key]):
        lines.append(
            f"| {row['condition']['id']} | {row['successes']}/{row['trials']} | "
            f"{row['success_rate_percent']:.1f}% | "
            f"{row['ttsc_ms']['median']:.2f} ms | "
            f"{row['ttsc_ms']['p95']:.2f} ms | "
            f"{row['ttsc_ms']['p99']:.2f} ms | "
            f"{row['tcp_total_retransmissions']['sum']} | "
            f"{row['conflicting_adoptions']} |"
        )
    return lines


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--loss", type=Path, required=True)
    parser.add_argument("--rtt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    loss_rows = load(args.loss / "summary.json")
    rtt_rows = load(args.rtt / "summary.json")
    plot_loss(loss_rows, args.output)
    slope, intercept = plot_rtt(rtt_rows, args.output)

    loss_trials = sum(row["trials"] for row in loss_rows)
    loss_successes = sum(row["successes"] for row in loss_rows)
    rtt_trials = sum(row["trials"] for row in rtt_rows)
    rtt_successes = sum(row["successes"] for row in rtt_rows)
    conflicts = sum(row["conflicting_adoptions"] for row in loss_rows + rtt_rows)
    failed_loss_trials = loss_trials - loss_successes
    report = [
        "# GT-R Linux netns/netem experiment results",
        "",
        "The experiment used two endpoint namespaces and one router namespace on "
        "Ubuntu 24.04 ARM64. Each trial established a fresh TCP connection and then "
        "ran the real four-flight GT-R reconnect with OpenSSL 4.0.2 ML-KEM-768. "
        "Enrollment and target-epoch FS-KEM provisioning were outside the timer.",
        "",
        f"- Raw trials: {loss_trials + rtt_trials} ({loss_trials} loss, {rtt_trials} RTT)",
        f"- Completed: {loss_successes + rtt_successes}/{loss_trials + rtt_trials}",
        f"- Conflicting adopted keys/epochs/transcripts: {conflicts}",
        "- Socket receive timeout: 15 s per blocking operation",
        "- TTSC scope: TCP connect plus M1--M4 through initiator key confirmation",
        "- RTT impairment: half the configured RTT on each router egress",
        "- Loss impairment: the configured random loss independently on both directions",
        "",
        "## Symmetric packet loss",
        "",
        *table(loss_rows, "loss"),
        "",
        "## RTT sweep",
        "",
        *table(rtt_rows, "rtt"),
        "",
        "The least-squares fit of median TTSC is "
        f"{slope:.3f} × RTT + {intercept:.1f} ms. The slope is close to three "
        "because the timed path contains one RTT for TCP establishment and two RTTs "
        "for M1--M4.",
        "",
        "## Interpretation boundary",
        "",
        f"The {failed_loss_trials} failed loss trials are timeout/availability failures, not successful "
        "acceptances with mismatched cryptographic state. This experiment evaluates "
        "the implemented TCP transport path under emulated impairment; it is not a "
        "physical-radio evaluation and does not by itself prove security.",
        "",
    ]
    (args.output / "RESULTS.md").write_text("\n".join(report), encoding="utf-8")

    artifacts = {}
    published_names = {
        "manifest.json", "processes.log", "summary.csv", "summary.json", "trials.jsonl"
    }
    published_paths = []
    for root in (args.loss, args.rtt):
        published_paths.extend(root / name for name in published_names)
        published_paths.extend(sorted((root / "pcap").glob("*.pcap")))
    published_paths.extend(
        path for path in sorted(args.output.iterdir())
        if path.is_file() and path.name != "artifact_checksums.json"
    )
    for path in published_paths:
        if path.is_file():
            artifacts[str(path)] = {"sha256": sha256(path), "bytes": path.stat().st_size}
    (args.output / "artifact_checksums.json").write_text(
        json.dumps(artifacts, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
