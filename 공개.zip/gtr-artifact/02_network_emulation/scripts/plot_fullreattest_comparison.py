#!/usr/bin/env python3
"""Validate and compare GT-R with the networked FullReAttest baseline."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


EXPECTED_RTTS = (10.0, 50.0, 100.0, 200.0, 500.0, 1000.0)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def grouped_ttsc(rows: list[dict]) -> dict[float, np.ndarray]:
    grouped: dict[float, list[float]] = defaultdict(list)
    for row in rows:
        if row.get("success") and row.get("ttsc_ms") is not None:
            grouped[float(row["condition"]["rtt_ms"])].append(float(row["ttsc_ms"]))
    return {rtt: np.asarray(values) for rtt, values in grouped.items()}


def bootstrap_median_ci(values: np.ndarray, rng: np.random.Generator,
                        draws: int = 20_000) -> tuple[float, float]:
    samples = rng.choice(values, size=(draws, len(values)), replace=True)
    medians = np.median(samples, axis=1)
    low, high = np.quantile(medians, (0.025, 0.975))
    return float(low), float(high)


def bootstrap_ratio_ci(numerator: np.ndarray, denominator: np.ndarray,
                       rng: np.random.Generator,
                       draws: int = 20_000) -> tuple[float, float]:
    num_samples = rng.choice(numerator, size=(draws, len(numerator)), replace=True)
    den_samples = rng.choice(denominator, size=(draws, len(denominator)), replace=True)
    ratios = np.median(num_samples, axis=1) / np.median(den_samples, axis=1)
    low, high = np.quantile(ratios, (0.025, 0.975))
    return float(low), float(high)


def validate(gtr_rows: list[dict], full_rows: list[dict],
             gtr_summary: list[dict], full_summary: list[dict]) -> None:
    if len(gtr_rows) != 600 or len(full_rows) != 600:
        raise ValueError(
            f"expected 600 trials per protocol, got GT-R={len(gtr_rows)}, "
            f"FullReAttest={len(full_rows)}")
    if not all(row.get("success") for row in gtr_rows + full_rows):
        raise ValueError("at least one trial was not successful")
    if not all(row.get("session_transcript_epoch_match") for row in gtr_rows):
        raise ValueError("GT-R contains a state-agreement mismatch")
    if not all(row.get("challenge_evidence_binding_match") for row in full_rows):
        raise ValueError("FullReAttest contains a challenge/evidence mismatch")
    if not all(row.get("tls_handshake_secrets_match") for row in full_rows):
        raise ValueError("FullReAttest contains a TLS-secret mismatch")
    for summaries, label in ((gtr_summary, "GT-R"), (full_summary, "FullReAttest")):
        rtts = tuple(sorted(float(row["condition"]["rtt_ms"]) for row in summaries))
        if rtts != EXPECTED_RTTS:
            raise ValueError(f"unexpected {label} RTT conditions: {rtts}")
        if any(row["trials"] != 100 or row["successes"] != 100 for row in summaries):
            raise ValueError(f"{label} summary does not contain 100/100 per RTT")


def save_figure(fig, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gtr", type=Path, required=True)
    parser.add_argument("--full", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    gtr_rows = load_jsonl(args.gtr / "trials.jsonl")
    full_rows = load_jsonl(args.full / "trials.jsonl")
    gtr_summary = load_json(args.gtr / "summary.json")
    full_summary = load_json(args.full / "summary.json")
    validate(gtr_rows, full_rows, gtr_summary, full_summary)

    gtr_values = grouped_ttsc(gtr_rows)
    full_values = grouped_ttsc(full_rows)
    gtr_by_rtt = {float(row["condition"]["rtt_ms"]): row for row in gtr_summary}
    full_by_rtt = {float(row["condition"]["rtt_ms"]): row for row in full_summary}
    rng = np.random.default_rng(20260903)
    comparison = []
    for rtt in EXPECTED_RTTS:
        gtr_median = float(np.median(gtr_values[rtt]))
        full_median = float(np.median(full_values[rtt]))
        comparison.append({
            "rtt_ms": rtt,
            "trials_per_protocol": 100,
            "gtr_successes": 100,
            "fullreattest_successes": 100,
            "gtr_median_ms": gtr_median,
            "gtr_median_ci95_ms": bootstrap_median_ci(gtr_values[rtt], rng),
            "gtr_p95_ms": gtr_by_rtt[rtt]["ttsc_ms"]["p95"],
            "fullreattest_median_ms": full_median,
            "fullreattest_median_ci95_ms": bootstrap_median_ci(full_values[rtt], rng),
            "fullreattest_p95_ms": full_by_rtt[rtt]["ttsc_ms"]["p95"],
            "fullreattest_attestation_median_ms": (
                full_by_rtt[rtt]["attestation_phase_ms"]["median"]),
            "fullreattest_tls_median_ms": full_by_rtt[rtt]["tls_phase_ms"]["median"],
            "speedup_full_over_gtr": full_median / gtr_median,
            "speedup_ci95": bootstrap_ratio_ci(full_values[rtt], gtr_values[rtt], rng),
        })

    with (args.output / "comparison.csv").open("w", newline="", encoding="utf-8") as handle:
        fieldnames = [
            "rtt_ms", "trials_per_protocol", "gtr_successes",
            "fullreattest_successes", "gtr_median_ms", "gtr_ci95_low_ms",
            "gtr_ci95_high_ms", "gtr_p95_ms", "fullreattest_median_ms",
            "fullreattest_ci95_low_ms", "fullreattest_ci95_high_ms",
            "fullreattest_p95_ms", "attestation_median_ms", "tls_median_ms",
            "speedup_full_over_gtr", "speedup_ci95_low", "speedup_ci95_high",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in comparison:
            writer.writerow({
                "rtt_ms": row["rtt_ms"],
                "trials_per_protocol": row["trials_per_protocol"],
                "gtr_successes": row["gtr_successes"],
                "fullreattest_successes": row["fullreattest_successes"],
                "gtr_median_ms": row["gtr_median_ms"],
                "gtr_ci95_low_ms": row["gtr_median_ci95_ms"][0],
                "gtr_ci95_high_ms": row["gtr_median_ci95_ms"][1],
                "gtr_p95_ms": row["gtr_p95_ms"],
                "fullreattest_median_ms": row["fullreattest_median_ms"],
                "fullreattest_ci95_low_ms": row["fullreattest_median_ci95_ms"][0],
                "fullreattest_ci95_high_ms": row["fullreattest_median_ci95_ms"][1],
                "fullreattest_p95_ms": row["fullreattest_p95_ms"],
                "attestation_median_ms": row["fullreattest_attestation_median_ms"],
                "tls_median_ms": row["fullreattest_tls_median_ms"],
                "speedup_full_over_gtr": row["speedup_full_over_gtr"],
                "speedup_ci95_low": row["speedup_ci95"][0],
                "speedup_ci95_high": row["speedup_ci95"][1],
            })
    (args.output / "comparison.json").write_text(
        json.dumps(comparison, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    x = np.asarray(EXPECTED_RTTS)
    gtr_medians = np.asarray([row["gtr_median_ms"] for row in comparison])
    full_medians = np.asarray([row["fullreattest_median_ms"] for row in comparison])
    gtr_p95 = np.asarray([row["gtr_p95_ms"] for row in comparison])
    full_p95 = np.asarray([row["fullreattest_p95_ms"] for row in comparison])
    speedups = np.asarray([row["speedup_full_over_gtr"] for row in comparison])

    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.8))
    axes[0].plot(x, gtr_medians, "o-", color="#1468a8", label="GT-R median")
    axes[0].plot(x, gtr_p95, "o--", color="#1468a8", alpha=0.65, label="GT-R p95")
    axes[0].plot(x, full_medians, "s-", color="#c23b22", label="FullReAttest median")
    axes[0].plot(x, full_p95, "s--", color="#c23b22", alpha=0.65,
                 label="FullReAttest p95")
    axes[0].set_xlabel("Configured RTT (ms)")
    axes[0].set_ylabel("Time to secure completion (ms)")
    axes[0].set_xscale("log")
    axes[0].set_yscale("log")
    axes[0].set_xticks(x, labels=[f"{value:g}" for value in x])
    axes[0].grid(True, which="both", alpha=0.3)
    axes[0].legend(frameon=False, fontsize=8)

    axes[1].bar(np.arange(len(x)), speedups, color="#4f8f5b")
    axes[1].axhline(1.0, color="#555555", linewidth=1, linestyle=":")
    axes[1].set_xticks(np.arange(len(x)), labels=[f"{value:g}" for value in x])
    axes[1].set_xlabel("Configured RTT (ms)")
    axes[1].set_ylabel("FullReAttest / GT-R median TTSC")
    axes[1].set_ylim(0, max(speedups) * 1.18)
    axes[1].grid(True, axis="y", alpha=0.3)
    for index, value in enumerate(speedups):
        axes[1].text(index, value + 0.04, f"{value:.2f}×", ha="center", fontsize=8)
    fig.suptitle("GT-R versus online FullReAttest (0% loss, n = 100 per RTT)")
    fig.tight_layout()
    save_figure(fig, args.output / "gt_r_vs_fullreattest_rtt_n100")

    attestation = np.asarray([
        row["fullreattest_attestation_median_ms"] for row in comparison])
    tls = np.asarray([row["fullreattest_tls_median_ms"] for row in comparison])
    fig, ax = plt.subplots(figsize=(6.2, 3.9))
    positions = np.arange(len(x))
    ax.bar(positions, attestation, label="Online TPM attestation and verdict")
    ax.bar(positions, tls, bottom=attestation, label="Fresh mutual PQC TLS")
    ax.plot(positions, full_medians, "ko--", linewidth=1, markersize=4,
            label="Measured end-to-end median")
    ax.set_xticks(positions, labels=[f"{value:g}" for value in x])
    ax.set_xlabel("Configured RTT (ms)")
    ax.set_ylabel("Median time (ms)")
    ax.grid(True, axis="y", alpha=0.3)
    ax.legend(frameon=False, fontsize=8)
    ax.set_title("FullReAttest phase breakdown (n = 100 per RTT)")
    fig.tight_layout()
    save_figure(fig, args.output / "fullreattest_phase_breakdown_n100")

    report = [
        "# GT-R versus networked FullReAttest",
        "",
        "This comparison uses 100 independent trials per protocol at each of six "
        "configured RTTs (1,200 total trials). Both paths were measured in the same "
        "Ubuntu 24.04 Linux network-namespace/netem environment at 0% configured loss.",
        "",
        "GT-R measured a fresh TCP connection followed by its M1--M4 reconnect at "
        "epoch drift 4 (initiator epoch 0, responder epoch 4). Static and target-epoch "
        "forward-secure KEM credentials were provisioned before timing. FullReAttest "
        "measured an initiator challenge, a real swtpm TPM quote, remote verifier "
        "verification, an ML-DSA-65-signed allow decision, and a fresh mutually "
        "authenticated TLS 1.3 connection using MLKEM768 and ML-DSA-65 certificates. "
        "Credential and attestation-key provisioning were outside both timed paths.",
        "",
        "| RTT | GT-R median (p95) | FullReAttest median (p95) | Median ratio | Bootstrap 95% CI |",
        "|---:|---:|---:|---:|---:|",
    ]
    for row in comparison:
        report.append(
            f"| {row['rtt_ms']:.0f} ms | {row['gtr_median_ms']:.2f} "
            f"({row['gtr_p95_ms']:.2f}) ms | {row['fullreattest_median_ms']:.2f} "
            f"({row['fullreattest_p95_ms']:.2f}) ms | "
            f"{row['speedup_full_over_gtr']:.2f}x | "
            f"[{row['speedup_ci95'][0]:.2f}, {row['speedup_ci95'][1]:.2f}]x |")
    report.extend([
        "",
        "## Integrity checks",
        "",
        "- GT-R: 600/600 completed; zero conflicting session-key, transcript, or epoch adoptions.",
        "- FullReAttest: 600/600 completed; zero challenge/evidence binding mismatches.",
        "- FullReAttest: zero client/server TLS handshake-secret mismatches.",
        "- Twelve packet captures (six per protocol) were read successfully with tcpdump.",
        "",
        "## Interpretation boundary",
        "",
        "The result shows the cost of these two implemented workflows under the stated "
        "emulation and timing boundaries. It does not establish a universal speedup: "
        "the FullReAttest path includes an online verifier reached over an equally "
        "impaired route, whereas GT-R does not. The TPM is swtpm, the network is netem "
        "rather than a physical DDIL radio, and this campaign does not include packet "
        "loss, jitter, asymmetric paths, or verifier outages for FullReAttest.",
        "",
    ])
    (args.output / "RESULTS.md").write_text("\n".join(report), encoding="utf-8")

    checksum_targets = [
        args.gtr / "trials.jsonl", args.gtr / "summary.json", args.gtr / "manifest.json",
        args.full / "trials.jsonl", args.full / "summary.json", args.full / "manifest.json",
        Path(__file__).resolve(),
    ]
    checksum_targets.extend(sorted((args.gtr / "pcap").glob("*.pcap")))
    checksum_targets.extend(sorted((args.full / "pcap").glob("*.pcap")))
    checksums = {str(path.resolve()): sha256(path) for path in checksum_targets}
    (args.output / "artifact_checksums.json").write_text(
        json.dumps(checksums, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    print(json.dumps({
        "gtr_successes": sum(row["success"] for row in gtr_rows),
        "fullreattest_successes": sum(row["success"] for row in full_rows),
        "conditions": len(comparison),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
