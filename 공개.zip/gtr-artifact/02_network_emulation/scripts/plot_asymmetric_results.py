#!/usr/bin/env python3
"""Validate and plot the directionally asymmetric GT-R experiment."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize
from matplotlib.patches import Rectangle
import numpy as np


EXPECTED_PAIRS = ((0.0, 0.0), (5.0, 5.0), (5.0, 20.0),
                  (20.0, 5.0), (20.0, 20.0))
LEVELS = (0.0, 5.0, 20.0)


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fmt(value: float | None, digits: int = 1) -> str:
    return "-" if value is None else f"{value:.{digits}f}"


def matrix(rows: list[dict], field) -> np.ndarray:
    values = np.full((len(LEVELS), len(LEVELS)), np.nan)
    for row in rows:
        condition = row["condition"]
        y = LEVELS.index(condition["loss_i_to_j_percent"])
        x = LEVELS.index(condition["loss_j_to_i_percent"])
        values[y, x] = field(row)
    return values


def draw_heatmap(ax, values: np.ndarray, title: str, colorbar_label: str,
                 digits: int) -> None:
    cmap = plt.get_cmap("viridis").copy()
    finite = values[np.isfinite(values)]
    norm = Normalize(vmin=float(np.min(finite)), vmax=float(np.max(finite)))
    ax.set_facecolor("#e6e6e6")
    ax.set_xlim(-0.5, len(LEVELS) - 0.5)
    ax.set_ylim(-0.5, len(LEVELS) - 0.5)
    ax.set_aspect("equal")
    ax.set_xticks(range(len(LEVELS)), labels=[f"{value:g}" for value in LEVELS])
    ax.set_yticks(range(len(LEVELS)), labels=[f"{value:g}" for value in LEVELS])
    ax.set_xlabel("Responder to initiator loss (%)")
    ax.set_ylabel("Initiator to responder loss (%)")
    ax.set_title(title)
    for y in range(values.shape[0]):
        for x in range(values.shape[1]):
            value = values[y, x]
            if np.isnan(value):
                color = "#e6e6e6"
                ax.text(x, y, "not run", ha="center", va="center",
                        color="#777777", fontsize=8)
            else:
                color = cmap(norm(value))
                ax.text(x, y, f"{value:.{digits}f}", ha="center", va="center",
                        color="white" if norm(value) < 0.42 else "black",
                        fontsize=9, fontweight="bold")
            ax.add_patch(Rectangle(
                (x - 0.5, y - 0.5), 1, 1, facecolor=color,
                edgecolor="white", linewidth=1.0, zorder=-1,
            ))
    bar = ax.figure.colorbar(
        ScalarMappable(norm=norm, cmap=cmap), ax=ax, fraction=0.046, pad=0.04)
    bar.set_label(colorbar_label)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    summaries = load(args.input / "summary.json")
    trials = load_jsonl(args.input / "trials.jsonl")
    pairs = tuple((row["condition"]["loss_i_to_j_percent"],
                   row["condition"]["loss_j_to_i_percent"])
                  for row in summaries)
    if pairs != EXPECTED_PAIRS:
        raise ValueError(f"unexpected asymmetric conditions: {pairs}")
    if len(trials) != 500 or any(row["trials"] != 100 for row in summaries):
        raise ValueError("expected five conditions with 100 trials each")
    if sum(row["success"] for row in trials) != 499:
        raise ValueError("expected 499 completed handshakes")
    if any(row["unexpected_conflicting_adoption"] for row in trials):
        raise ValueError("a trial contains conflicting adopted state")
    failures = [row for row in trials if not row["success"]]
    if len(failures) != 1 or failures[0]["timeout_stage"] != "TIMEOUT_M4":
        raise ValueError("the single expected failure is not TIMEOUT_M4")
    if failures[0]["initiator"].get("adopted"):
        raise ValueError("the timed-out initiator unexpectedly adopted state")
    if not failures[0]["responder"].get("adopted"):
        raise ValueError("the responder did not record its pre-M4 adoption")

    success = matrix(summaries, lambda row: row["success_rate_percent"])
    latency = matrix(summaries, lambda row: row["ttsc_ms"]["median"])
    labels = [
        f"({int(i)},{int(j)})" for i, j in EXPECTED_PAIRS
    ]
    positions = np.arange(len(summaries))
    width = 0.35
    i_retx = [
        row["directional_tcp_retransmissions"]["i_to_j"]["sum"]
        for row in summaries
    ]
    j_retx = [
        row["directional_tcp_retransmissions"]["j_to_i"]["sum"]
        for row in summaries
    ]

    fig, axes = plt.subplots(2, 2, figsize=(11.2, 7.5))
    draw_heatmap(axes[0, 0], success, "Secure completion", "Success rate (%)", 0)
    draw_heatmap(axes[0, 1], latency, "Median TTSC", "TTSC (ms)", 0)

    axes[1, 0].bar(positions - width / 2, i_retx, width,
                   label="initiator to responder (M1/M3)", color="#2878b5")
    axes[1, 0].bar(positions + width / 2, j_retx, width,
                   label="responder to initiator (M2/M4)", color="#d95f02")
    axes[1, 0].set_xticks(positions, labels=labels)
    axes[1, 0].set_xlabel("Loss pair (initiator-to-responder, responder-to-initiator) %")
    axes[1, 0].set_ylabel("TCP retransmissions across 100 trials")
    axes[1, 0].set_title("Direction-specific retransmission")
    axes[1, 0].grid(True, axis="y", alpha=0.3)
    axes[1, 0].legend(frameon=False, fontsize=8)

    markers = ("o", "s", "^", "D")
    for flight, marker in zip(("M1", "M2", "M3", "M4"), markers):
        axes[1, 1].plot(
            positions,
            [row["flight_latency_ms"][flight]["p95"] for row in summaries],
            marker=marker, linewidth=1.5, label=f"{flight} p95",
        )
    axes[1, 1].set_xticks(positions, labels=labels)
    axes[1, 1].set_xlabel("Loss pair (initiator-to-responder, responder-to-initiator) %")
    axes[1, 1].set_ylabel("Per-flight latency (ms, log scale)")
    axes[1, 1].set_yscale("log")
    axes[1, 1].set_title("Flight-direction tail latency")
    axes[1, 1].grid(True, which="both", alpha=0.3)
    axes[1, 1].legend(frameon=False, ncol=2, fontsize=8)

    fig.suptitle("GT-R under asymmetric loss (RTT = 100 ms, n = 100)")
    fig.tight_layout()
    stem = args.output / "gt_r_asymmetric_loss_n100"
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)

    report = [
        "# GT-R asymmetric-link experiment",
        "",
        "The real OpenSSL ML-KEM M1-M4 path was executed at 100 ms configured "
        "RTT with independent netem loss on the two router egress directions. "
        "M1 and M3 travel from initiator to responder; M2 and M4 travel from "
        "responder to initiator. Each loss pair contains 100 fresh TCP and GT-R "
        "executions at epoch drift 4.",
        "",
        "| Loss (i->j, j->i) | Completed | Median TTSC | p95 | p99 | "
        "M1/M2/M3/M4 p95 (ms) | Retransmissions i->j / j->i | Timeouts | Conflicts |",
        "|:---:|---:|---:|---:|---:|:---:|:---:|:---:|---:|",
    ]
    for row in summaries:
        c = row["condition"]
        flight_text = "/".join(
            fmt(row["flight_latency_ms"][flight]["p95"])
            for flight in ("M1", "M2", "M3", "M4")
        )
        timeouts = sum(row["timeout_stages"].values())
        report.append(
            f"| ({c['loss_i_to_j_percent']:.0f}%, "
            f"{c['loss_j_to_i_percent']:.0f}%) | "
            f"{row['successes']}/{row['trials']} | "
            f"{fmt(row['ttsc_ms']['median'])} ms | "
            f"{fmt(row['ttsc_ms']['p95'])} ms | "
            f"{fmt(row['ttsc_ms']['p99'])} ms | {flight_text} | "
            f"{row['directional_tcp_retransmissions']['i_to_j']['sum']} / "
            f"{row['directional_tcp_retransmissions']['j_to_i']['sum']} | "
            f"{timeouts} | {row['conflicting_adoptions']} |"
        )
    report.extend([
        "",
        "## Result",
        "",
        "The clean, symmetric 5%, and both one-sided 5/20% configurations "
        "completed 100/100 handshakes. In the 5/20% case, responder-to-initiator "
        "retransmissions rose to 140 and the M2/M4 tail increased. Reversing the "
        "loss to 20/5% moved the dominant retransmissions to initiator-to-responder "
        "(164) and increased the M1/M3 tail. This directional reversal confirms "
        "that the impairment was applied independently rather than as aggregate loss.",
        "",
        "At 20/20%, 99/100 handshakes completed. One initiator timed out waiting "
        "for M4 after 15 seconds. The responder had authenticated M3, adopted its "
        "candidate, and attempted M4; the initiator did not adopt. No trial "
        "produced conflicting adopted keys or epochs.",
        "",
        "## Interpretation boundary",
        "",
        "This is independent Bernoulli loss in Linux netem over TCP, not a "
        "physical DDIL radio trace. TCP retransmission hides many individual "
        "packet losses. This campaign intentionally has no GT-R application-level "
        "retry, so the single M4 timeout is a transport-availability result rather "
        "than a cryptographic rejection. Retry and candidate reuse were evaluated "
        "separately in the blackout campaign.",
        "",
    ])
    (args.output / "RESULTS.md").write_text("\n".join(report), encoding="utf-8")

    targets = [
        args.input / "trials.jsonl",
        args.input / "summary.json",
        args.input / "summary.csv",
        args.input / "manifest.json",
        Path(__file__).resolve(),
    ]
    targets.extend(sorted((args.input / "pcap").glob("*.pcap")))
    (args.output / "artifact_checksums.json").write_text(
        json.dumps(
            {str(path.resolve()): sha256(path) for path in targets},
            indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "trials": len(trials),
        "successes": sum(row["success"] for row in trials),
        "m4_timeouts": sum(row["timeout_stage"] == "TIMEOUT_M4" for row in trials),
        "conflicting_adoptions": sum(
            row["unexpected_conflicting_adoption"] for row in trials),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
