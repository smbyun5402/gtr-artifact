#!/usr/bin/env python3
"""GT-R M1--M4 plus CONF_I/ACK_R over UDP with bounded retransmission."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import secrets
import socket
import tempfile
import time
from pathlib import Path

import gtr_blackout_endpoint as protocol
import gtr_net_endpoint as base
import reauth_demo as core


def encode(message: dict) -> bytes:
    return json.dumps(message, sort_keys=True, separators=(",", ":")).encode()


def decode(packet: bytes) -> dict:
    value = json.loads(packet.decode())
    if not isinstance(value, dict):
        raise ValueError("UDP payload is not an object")
    return value


def send(sock: socket.socket, peer: tuple[str, int], message: dict) -> int:
    packet = encode(message)
    sock.sendto(packet, peer)
    return len(packet)


def receive(sock: socket.socket) -> tuple[dict, tuple[str, int], int]:
    packet, peer = sock.recvfrom(65535)
    return decode(packet), peer, len(packet)


def timeout_for(args: argparse.Namespace, attempt: int) -> float:
    return min(args.base_timeout * (2 ** attempt), args.max_timeout)


class SelectiveFragmentChannel:
    """Reliable message transport over UDP using selective fragment retries.

    Protocol messages are encoded once and divided into independently
    acknowledged fragments.  A timeout retransmits only fragment indexes for
    which no acknowledgement has arrived.  The receive path is active while a
    send is awaiting acknowledgements, so crossed replies are acknowledged and
    queued instead of being dropped.
    """

    FRAGMENT_WIRE = "GTR-FRAG-1"
    ACK_WIRE = "GTR-FRAG-ACK-1"

    def __init__(self, sock: socket.socket, args: argparse.Namespace):
        self.sock = sock
        self.args = args
        self.reassembly: dict[str, dict] = {}
        self.completed: list[tuple[dict, tuple[str, int]]] = []
        self.delivered: set[str] = set()
        self.stats = {
            "application_bytes_sent": 0,
            "application_bytes_received": 0,
            "fragments_sent": 0,
            "fragment_retransmissions": 0,
            "fragment_acks_sent": 0,
            "fragment_acks_received": 0,
            "max_datagram_bytes": 0,
        }

    @staticmethod
    def _message_id(message: dict, encoded: bytes) -> str:
        label = f"{message.get('type', 'MSG')}:{message.get('attempt_id', '')}:"
        return label + hashlib.sha256(encoded).hexdigest()[:24]

    def _wire_send(self, peer: tuple[str, int], packet: dict) -> int:
        wire = encode(packet)
        if len(wire) > self.args.max_wire_bytes:
            raise RuntimeError(
                f"fragment wire packet exceeds limit: {len(wire)} > "
                f"{self.args.max_wire_bytes}")
        self.sock.sendto(wire, peer)
        self.stats["application_bytes_sent"] += len(wire)
        self.stats["max_datagram_bytes"] = max(
            self.stats["max_datagram_bytes"], len(wire))
        return len(wire)

    def _ack(self, peer: tuple[str, int], message_id: str, index: int) -> None:
        self._wire_send(peer, {
            "wire": self.ACK_WIRE, "id": message_id, "i": index,
        })
        self.stats["fragment_acks_sent"] += 1

    def _handle_wire(self, packet: bytes, peer: tuple[str, int]
                     ) -> tuple[str, str, int] | None:
        self.stats["application_bytes_received"] += len(packet)
        value = decode(packet)
        wire = value.get("wire")
        if wire == self.ACK_WIRE:
            message_id = str(value.get("id", ""))
            index = int(value.get("i", -1))
            self.stats["fragment_acks_received"] += 1
            return ("ack", message_id, index)
        if wire != self.FRAGMENT_WIRE:
            raise RuntimeError("unexpected selective-fragment wire packet")

        message_id = str(value.get("id", ""))
        index = int(value.get("i", -1))
        count = int(value.get("n", 0))
        if not message_id or count < 1 or count > self.args.max_fragments:
            raise RuntimeError("invalid fragment header")
        if index < 0 or index >= count:
            raise RuntimeError("invalid fragment index")
        try:
            payload = base64.b64decode(value["p"], validate=True)
        except Exception as exc:
            raise RuntimeError("invalid fragment payload") from exc
        if len(payload) > self.args.fragment_bytes:
            raise RuntimeError("fragment payload exceeds configured size")

        self._ack(peer, message_id, index)
        entry = self.reassembly.setdefault(message_id, {
            "count": count, "parts": {}, "peer": peer,
        })
        if entry["count"] != count:
            raise RuntimeError("conflicting fragment count")
        old = entry["parts"].get(index)
        if old is not None and old != payload:
            raise RuntimeError("conflicting duplicate fragment")
        entry["parts"][index] = payload
        if len(entry["parts"]) == count and message_id not in self.delivered:
            assembled = b"".join(entry["parts"][i] for i in range(count))
            message = decode(assembled)
            expected_id = self._message_id(message, assembled)
            if not secrets.compare_digest(message_id, expected_id):
                raise RuntimeError("fragment message identifier mismatch")
            self.completed.append((message, peer))
            self.delivered.add(message_id)
        return ("fragment", message_id, index)

    def _pump(self, timeout: float) -> tuple[str, str, int] | None:
        self.sock.settimeout(max(timeout, 0.001))
        packet, peer = self.sock.recvfrom(self.args.max_wire_bytes + 1)
        if len(packet) > self.args.max_wire_bytes:
            raise RuntimeError("received oversized fragment packet")
        return self._handle_wire(packet, peer)

    def send_message(self, peer: tuple[str, int], message: dict,
                     implicit_ack_predicate=None,
                     fire_and_forget_copies: int = 0) -> None:
        encoded = encode(message)
        count = math.ceil(len(encoded) / self.args.fragment_bytes)
        if count > self.args.max_fragments:
            raise RuntimeError("message exceeds fragment-count limit")
        message_id = self._message_id(message, encoded)
        packets = []
        for index in range(count):
            chunk = encoded[index * self.args.fragment_bytes:
                            (index + 1) * self.args.fragment_bytes]
            packets.append({
                "wire": self.FRAGMENT_WIRE,
                "id": message_id,
                "i": index,
                "n": count,
                "p": base64.b64encode(chunk).decode("ascii"),
            })

        unacked = set(range(count))
        if fire_and_forget_copies:
            for copy_index in range(fire_and_forget_copies):
                for index in range(count):
                    self._wire_send(peer, packets[index])
                    self.stats["fragments_sent"] += 1
                    if copy_index:
                        self.stats["fragment_retransmissions"] += 1
            return
        for attempt in range(self.args.max_retries + 1):
            for index in sorted(unacked):
                self._wire_send(peer, packets[index])
                self.stats["fragments_sent"] += 1
                if attempt:
                    self.stats["fragment_retransmissions"] += 1
            deadline = time.monotonic() + timeout_for(self.args, attempt)
            while unacked and time.monotonic() < deadline:
                try:
                    event = self._pump(deadline - time.monotonic())
                except socket.timeout:
                    break
                if event and event[0] == "ack" and event[1] == message_id:
                    unacked.discard(event[2])
                if (implicit_ack_predicate is not None
                        and any(implicit_ack_predicate(completed[0])
                                for completed in self.completed)):
                    # In this linear request/response protocol, a complete
                    # authenticated next-flight object proves that the peer
                    # reassembled the preceding flight even if its last
                    # fragment ACK was lost.  The queued object is consumed by
                    # the caller's following receive_message invocation.
                    unacked.clear()
            if not unacked:
                return
        raise RuntimeError(
            "selective-fragment retry exhaustion: "
            + ",".join(str(i) for i in sorted(unacked)))

    def receive_message(self, predicate, timeout: float
                        ) -> tuple[dict, tuple[str, int]]:
        deadline = time.monotonic() + timeout
        while True:
            for index, (message, peer) in enumerate(self.completed):
                if predicate(message):
                    self.completed.pop(index)
                    return message, peer
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("selective-fragment receive timeout")
            try:
                self._pump(remaining)
            except socket.timeout as exc:
                raise TimeoutError(
                    "selective-fragment receive timeout") from exc


def run_initiator_fragmented(args: argparse.Namespace, config: dict,
                             work: Path) -> dict:
    state = protocol.prepare_initiator(args, config, work)
    started = time.monotonic_ns()
    peer = (args.peer_address, args.port)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.bind((args.address, 0))
        channel = SelectiveFragmentChannel(sock, args)
        channel.send_message(
            peer, state["m1"],
            lambda m: m.get("type") == "M2"
            and m.get("attempt_id") == state["attempt_id"])
        m2, peer = channel.receive_message(
            lambda m: m.get("type") == "M2"
            and m.get("attempt_id") == state["attempt_id"],
            args.overall_timeout)
        protocol.accept_m2(state, m2, config)

        channel.send_message(
            peer, state["m3"],
            lambda m: m.get("type") == "M4"
            and m.get("attempt_id") == state["attempt_id"])
        m4, peer = channel.receive_message(
            lambda m: m.get("type") == "M4"
            and m.get("attempt_id") == state["attempt_id"],
            args.overall_timeout)
        gamma = base.unb64(m4["gamma_j"])
        expected = core.mac(
            state["confirm"], core.H("confirm", state["transcript"]))
        if not secrets.compare_digest(gamma, expected):
            raise RuntimeError("M4 confirmation failed")
        key_confirmed = time.monotonic_ns()

        confirmation = {
            "type": "CONF_I", "attempt_id": state["attempt_id"],
            "tag": base.b64(core.mac(
                state["session"],
                core.H("adopt-i", state["sid"], state["e_prime"],
                       state["transcript"]))),
        }
        channel.send_message(
            peer, confirmation,
            lambda m: m.get("type") == "ACK_R"
            and m.get("attempt_id") == state["attempt_id"])
        ack_r, peer = channel.receive_message(
            lambda m: m.get("type") == "ACK_R"
            and m.get("attempt_id") == state["attempt_id"],
            args.overall_timeout)
        expected_ack = core.mac(
            state["session"],
            core.H("adopt-r", state["sid"], state["e_prime"],
                   state["transcript"]))
        if not secrets.compare_digest(base.unb64(ack_r["tag"]), expected_ack):
            raise RuntimeError("responder adoption acknowledgement failed")
        adopted = time.monotonic_ns()
        # ACK_RECEIPT is a harness-termination signal, not a GT-R flight.  It
        # is duplicated without waiting for a further transport ACK so the
        # measurement boundary remains verified ACK_R (mutual adoption).
        channel.send_message(peer, {
            "type": "ACK_RECEIPT", "attempt_id": state["attempt_id"],
            "tag": base.b64(core.mac(
                state["session"],
                core.H("ack-receipt", state["sid"], state["e_prime"],
                       state["transcript"]))),
        }, fire_and_forget_copies=args.max_retries + 1)
    stats = channel.stats
    return {
        "schema": "gtr.udp.endpoint.v2", "transport_mode": "selective-fragment",
        "role": "initiator", "ok": True, "adopted": True,
        "attempt_id": state["attempt_id"],
        "session_sha256": hashlib.sha256(state["session"]).hexdigest(),
        "transcript_sha256": hashlib.sha256(state["transcript"]).hexdigest(),
        "converged_epoch": state["e_prime"],
        "initiator_key_confirmation_ms":
            (key_confirmed - started) / 1_000_000,
        "mutual_adoption_ttsc_ms": (adopted - started) / 1_000_000,
        "ttsc_ms": (adopted - started) / 1_000_000,
        "completion_ms": (time.monotonic_ns() - started) / 1_000_000,
        "application_retransmissions": stats["fragment_retransmissions"],
        **stats,
    }


def run_responder_fragmented(args: argparse.Namespace, config: dict,
                             work: Path) -> dict:
    started = time.monotonic_ns()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.bind((args.address, args.port))
        channel = SelectiveFragmentChannel(sock, args)
        Path(args.ready_file).write_text("ready\n", encoding="utf-8")
        m1, peer = channel.receive_message(
            lambda m: m.get("type") == "M1", args.overall_timeout)
        candidate = protocol.build_responder_candidate(m1, config, work)
        channel.send_message(
            peer, candidate["m2"],
            lambda m: m.get("type") == "M3"
            and m.get("attempt_id") == candidate["attempt_id"])

        m3, peer = channel.receive_message(
            lambda m: m.get("type") == "M3"
            and m.get("attempt_id") == candidate["attempt_id"],
            args.overall_timeout)
        protocol.accept_m3(candidate, m3, config)
        channel.send_message(
            peer, candidate["m4"],
            lambda m: m.get("type") == "CONF_I"
            and m.get("attempt_id") == candidate["attempt_id"])

        conf_i, peer = channel.receive_message(
            lambda m: m.get("type") == "CONF_I"
            and m.get("attempt_id") == candidate["attempt_id"],
            args.overall_timeout)
        expected = core.mac(
            candidate["session"],
            core.H("adopt-i", candidate["sid"], candidate["e_prime"],
                   candidate["transcript"]))
        if not secrets.compare_digest(base.unb64(conf_i["tag"]), expected):
            raise RuntimeError("protected confirmation failed")
        candidate["adopted_monotonic_ns"] = time.monotonic_ns()
        ack_r = {
            "type": "ACK_R", "attempt_id": candidate["attempt_id"],
            "tag": base.b64(core.mac(
                candidate["session"],
                core.H("adopt-r", candidate["sid"], candidate["e_prime"],
                       candidate["transcript"]))),
        }
        channel.send_message(
            peer, ack_r,
            lambda m: m.get("type") == "ACK_RECEIPT"
            and m.get("attempt_id") == candidate["attempt_id"])
    stats = channel.stats
    return {
        "schema": "gtr.udp.endpoint.v2", "transport_mode": "selective-fragment",
        "role": "responder", "ok": True, "adopted": True,
        "attempt_id": candidate["attempt_id"],
        "session_sha256": hashlib.sha256(candidate["session"]).hexdigest(),
        "transcript_sha256": hashlib.sha256(candidate["transcript"]).hexdigest(),
        "converged_epoch": candidate["e_prime"],
        "application_retransmissions": stats["fragment_retransmissions"],
        "elapsed_ms": (time.monotonic_ns() - started) / 1_000_000,
        **stats,
    }


def run_initiator(args: argparse.Namespace, config: dict, work: Path) -> dict:
    state = protocol.prepare_initiator(args, config, work)
    started = time.monotonic_ns()
    peer = (args.peer_address, args.port)
    sent = received = retransmissions = 0
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.bind((args.address, 0))
        # M1/M2 stop-and-wait.
        for attempt in range(args.max_retries + 1):
            if attempt:
                retransmissions += 1
            sent += send(sock, peer, state["m1"])
            sock.settimeout(timeout_for(args, attempt))
            try:
                while True:
                    message, _, size = receive(sock)
                    received += size
                    if message.get("type") == "M2" and message.get(
                            "attempt_id") == state["attempt_id"]:
                        protocol.accept_m2(state, message, config)
                        break
                break
            except socket.timeout:
                if attempt == args.max_retries:
                    raise RuntimeError("M2 retry exhaustion")

        # M3/M4 stop-and-wait.
        for attempt in range(args.max_retries + 1):
            if attempt:
                retransmissions += 1
            sent += send(sock, peer, state["m3"])
            sock.settimeout(timeout_for(args, attempt))
            try:
                while True:
                    message, _, size = receive(sock)
                    received += size
                    if message.get("type") == "M4" and message.get(
                            "attempt_id") == state["attempt_id"]:
                        gamma = base.unb64(message["gamma_j"])
                        expected = core.mac(
                            state["confirm"], core.H("confirm", state["transcript"]))
                        if not secrets.compare_digest(gamma, expected):
                            raise RuntimeError("M4 confirmation failed")
                        break
                break
            except socket.timeout:
                if attempt == args.max_retries:
                    raise RuntimeError("M4 retry exhaustion")

        key_confirmed = time.monotonic_ns()
        confirmation = {
            "type": "CONF_I", "attempt_id": state["attempt_id"],
            "tag": base.b64(core.mac(
                state["session"],
                core.H("adopt-i", state["sid"], state["e_prime"],
                       state["transcript"]))),
        }
        for attempt in range(args.max_retries + 1):
            if attempt:
                retransmissions += 1
            sent += send(sock, peer, confirmation)
            sock.settimeout(timeout_for(args, attempt))
            try:
                while True:
                    message, _, size = receive(sock)
                    received += size
                    if message.get("type") == "ACK_R" and message.get(
                            "attempt_id") == state["attempt_id"]:
                        expected_ack = core.mac(
                            state["session"],
                            core.H("adopt-r", state["sid"], state["e_prime"],
                                   state["transcript"]))
                        if not secrets.compare_digest(
                                base.unb64(message["tag"]), expected_ack):
                            raise RuntimeError("responder adoption acknowledgement failed")
                        adopted = time.monotonic_ns()
                        for _ in range(3):
                            sent += send(sock, peer, {
                                "type": "ACK_RECEIPT",
                                "attempt_id": state["attempt_id"],
                                "tag": base.b64(core.mac(
                                    state["session"],
                                    core.H("ack-receipt", state["sid"],
                                           state["e_prime"],
                                           state["transcript"]))),
                            })
                        break
                break
            except socket.timeout:
                if attempt == args.max_retries:
                    raise RuntimeError("protected-confirm retry exhaustion")
    return {
        "schema": "gtr.udp.endpoint.v1", "role": "initiator", "ok": True,
        "adopted": True, "attempt_id": state["attempt_id"],
        "session_sha256": hashlib.sha256(state["session"]).hexdigest(),
        "transcript_sha256": hashlib.sha256(state["transcript"]).hexdigest(),
        "converged_epoch": state["e_prime"],
        "initiator_key_confirmation_ms":
            (key_confirmed - started) / 1_000_000,
        "mutual_adoption_ttsc_ms": (adopted - started) / 1_000_000,
        "ttsc_ms": (adopted - started) / 1_000_000,
        "completion_ms": (time.monotonic_ns() - started) / 1_000_000,
        "application_retransmissions": retransmissions,
        "application_bytes_sent": sent, "application_bytes_received": received,
    }


def run_responder(args: argparse.Namespace, config: dict, work: Path) -> dict:
    started = time.monotonic_ns()
    deadline = time.monotonic() + args.overall_timeout
    candidate = None
    sent = received = duplicate_m1 = duplicate_m3 = 0
    peer = None
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.bind((args.address, args.port))
        sock.settimeout(0.1)
        Path(args.ready_file).write_text("ready\n", encoding="utf-8")
        while time.monotonic() < deadline:
            try:
                message, current_peer, size = receive(sock)
            except socket.timeout:
                continue
            received += size
            kind = message.get("type")
            if candidate is None:
                if kind != "M1":
                    continue
                candidate = protocol.build_responder_candidate(message, config, work)
                peer = current_peer
                sent += send(sock, peer, candidate["m2"])
                continue
            if message.get("attempt_id") != candidate["attempt_id"]:
                continue
            if kind == "M1":
                if not secrets.compare_digest(protocol.digest(message),
                                              candidate["m1_sha256"]):
                    raise RuntimeError("conflicting duplicate M1")
                duplicate_m1 += 1
                sent += send(sock, current_peer, candidate["m2"])
            elif kind == "M3":
                if candidate["m3"] is None:
                    protocol.accept_m3(candidate, message, config)
                else:
                    if not secrets.compare_digest(protocol.digest(message),
                                                  protocol.digest(candidate["m3"])):
                        raise RuntimeError("conflicting duplicate M3")
                    duplicate_m3 += 1
                sent += send(sock, current_peer, candidate["m4"])
            elif kind == "CONF_I" and candidate["session"] is not None:
                expected = core.mac(
                    candidate["session"],
                    core.H("adopt-i", candidate["sid"], candidate["e_prime"],
                           candidate["transcript"]))
                if not secrets.compare_digest(base.unb64(message["tag"]), expected):
                    raise RuntimeError("protected confirmation failed")
                if candidate["adopted_monotonic_ns"] is None:
                    candidate["adopted_monotonic_ns"] = time.monotonic_ns()
                ack_r = core.mac(
                    candidate["session"],
                    core.H("adopt-r", candidate["sid"], candidate["e_prime"],
                           candidate["transcript"]))
                sent += send(sock, current_peer, {
                    "type": "ACK_R", "attempt_id": candidate["attempt_id"],
                    "tag": base.b64(ack_r)})
            elif kind == "ACK_RECEIPT" and candidate["adopted_monotonic_ns"] is not None:
                expected_receipt = core.mac(
                    candidate["session"],
                    core.H("ack-receipt", candidate["sid"], candidate["e_prime"],
                           candidate["transcript"]))
                if not secrets.compare_digest(
                        base.unb64(message["tag"]), expected_receipt):
                    raise RuntimeError("adoption acknowledgement receipt failed")
                break
        else:
            raise RuntimeError("responder overall timeout")
    return {
        "schema": "gtr.udp.endpoint.v1", "role": "responder", "ok": True,
        "adopted": True, "attempt_id": candidate["attempt_id"],
        "session_sha256": hashlib.sha256(candidate["session"]).hexdigest(),
        "transcript_sha256": hashlib.sha256(candidate["transcript"]).hexdigest(),
        "converged_epoch": candidate["e_prime"],
        "duplicate_m1": duplicate_m1, "duplicate_m3": duplicate_m3,
        "application_bytes_sent": sent, "application_bytes_received": received,
        "elapsed_ms": (time.monotonic_ns() - started) / 1_000_000,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--role", choices=("initiator", "responder"), required=True)
    parser.add_argument("--address", required=True)
    parser.add_argument("--peer-address")
    parser.add_argument("--port", type=int, default=47200)
    parser.add_argument("--config", required=True)
    parser.add_argument("--result", required=True)
    parser.add_argument("--ready-file")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--base-timeout", type=float, default=0.25)
    parser.add_argument("--max-timeout", type=float, default=2.0)
    parser.add_argument("--max-retries", type=int, default=5)
    parser.add_argument("--overall-timeout", type=float, default=20.0)
    parser.add_argument("--transport-mode",
                        choices=("raw", "selective-fragment"), default="raw")
    parser.add_argument("--fragment-bytes", type=int, default=900)
    parser.add_argument("--max-wire-bytes", type=int, default=1400)
    parser.add_argument("--max-fragments", type=int, default=64)
    args = parser.parse_args()
    if args.role == "initiator" and not args.peer_address:
        parser.error("--peer-address is required for initiator")
    if args.role == "responder" and not args.ready_file:
        parser.error("--ready-file is required for responder")
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory(prefix=f"gtr-udp-{args.role}-") as temp:
        work = Path(temp)
        core.WORK = str(work)
        core.SEAL_PATH = str(work / "rot_seal.json")
        try:
            if args.transport_mode == "selective-fragment":
                result = (run_initiator_fragmented(args, config, work)
                          if args.role == "initiator"
                          else run_responder_fragmented(args, config, work))
            else:
                result = (run_initiator(args, config, work)
                          if args.role == "initiator"
                          else run_responder(args, config, work))
        except Exception as exc:
            result = {
                "schema": "gtr.udp.endpoint.v1", "role": args.role,
                "ok": False, "adopted": False,
                "error_type": type(exc).__name__, "error": str(exc),
            }
    base.atomic_json(Path(args.result), result)
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
