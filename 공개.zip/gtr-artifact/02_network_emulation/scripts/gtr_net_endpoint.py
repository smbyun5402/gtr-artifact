#!/usr/bin/env python3
"""One GT-R endpoint for Linux network-namespace experiments.

The endpoint reuses the OpenSSL ML-KEM-768 and HKDF/HMAC primitives from
``reauth_demo.py``.  Enrollment material is provisioned before a trial.  The
timed interval includes M1--M4 and the protected CONF_I/ACK_R adoption exchange
so that success means that both endpoints have committed matching state.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import resource
import secrets
import socket
import struct
import tempfile
import time
from pathlib import Path

import reauth_demo as core


MAX_FRAME = 16 * 1024 * 1024


class PolicyLimitExceeded(RuntimeError):
    """The authenticated reconnect state requires R2 rather than GT-R R1."""


def b64(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def unb64(value: str) -> bytes:
    return base64.b64decode(value.encode("ascii"), validate=True)


def require_execution_sid(value: object) -> str:
    """Validate the 128-bit hexadecimal execution identifier carried in M1."""
    if not isinstance(value, str) or len(value) != 32:
        raise RuntimeError("M1 execution identifier must encode 128 bits")
    try:
        bytes.fromhex(value)
    except ValueError as exc:
        raise RuntimeError("M1 execution identifier is not hexadecimal") from exc
    return value


def read_bytes(path: str) -> bytes:
    with open(path, "rb") as handle:
        return handle.read()


def write_bytes(path: Path, value: bytes) -> str:
    path.write_bytes(value)
    return str(path)


def send_frame(sock: socket.socket, value: dict) -> int:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    frame = struct.pack("!I", len(payload)) + payload
    sock.sendall(frame)
    return len(frame)


def recv_exact(sock: socket.socket, count: int) -> bytes:
    chunks = []
    remaining = count
    while remaining:
        chunk = sock.recv(remaining)
        if not chunk:
            raise ConnectionError("peer closed the TCP connection")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def recv_frame(sock: socket.socket) -> tuple[dict, int]:
    header = recv_exact(sock, 4)
    length = struct.unpack("!I", header)[0]
    if length > MAX_FRAME:
        raise ValueError(f"frame length {length} exceeds {MAX_FRAME}")
    payload = recv_exact(sock, length)
    return json.loads(payload.decode()), len(header) + len(payload)


def send_flight(sock: socket.socket, flight: str, value: dict,
                trace: dict) -> int:
    key = flight.lower()
    trace[f"{key}_send_started_ns"] = time.monotonic_ns()
    try:
        count = send_frame(sock, value)
    except socket.timeout as exc:
        raise TimeoutError(f"TIMEOUT_{flight}") from exc
    trace[f"{key}_send_completed_ns"] = time.monotonic_ns()
    return count


def recv_flight(sock: socket.socket, flight: str,
                trace: dict) -> tuple[dict, int]:
    try:
        value, count = recv_frame(sock)
    except socket.timeout as exc:
        raise TimeoutError(f"TIMEOUT_{flight}") from exc
    trace[f"{flight.lower()}_recv_completed_ns"] = time.monotonic_ns()
    return value, count


def pre_schedule(chain: bytes, ss_e: bytes, ss_sj: bytes, ss_si: bytes,
                 transcript: bytes, sid: str, epoch: int) -> bytes:
    return core.hkdf(
        core.H(chain, ss_e, ss_sj, ss_si, transcript,
               core._canon(("gt-r-pre", sid, epoch))),
        b"pre",
    )


def final_schedule(kpre: bytes, d_sj: bytes, d_si: bytes,
                   transcript: bytes, sid: str,
                   epoch: int) -> tuple[bytes, bytes, bytes]:
    master = core.hkdf(
        kpre,
        core.H(1, d_sj, d_si, transcript,
               core._canon(("gt-r-final", sid, epoch))),
        salt=b"qartz-final",
    )
    return (
        core.hkdf(master, b"session"),
        core.hkdf(master, b"chain"),
        core.hkdf(master, b"confirm-j"),
    )


def cpu_snapshot() -> tuple[float, float]:
    own = resource.getrusage(resource.RUSAGE_SELF)
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    return own.ru_utime + children.ru_utime, own.ru_stime + children.ru_stime


def tcp_info(sock: socket.socket) -> dict:
    """Return Linux TCP_INFO fields used by the experiment, when available."""
    try:
        raw = sock.getsockopt(socket.IPPROTO_TCP, socket.TCP_INFO, 104)
        if len(raw) < 104:
            return {"rtt_us": None, "total_retrans": None}
        return {
            "rtt_us": struct.unpack_from("I", raw, 68)[0],
            "total_retrans": struct.unpack_from("I", raw, 100)[0],
        }
    except (AttributeError, OSError, struct.error):
        return {"rtt_us": None, "total_retrans": None}


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:
            os.remove(temporary)
        except OSError:
            pass


def persist_next_state(path: str | None, role: str, config: dict,
                       epoch: int, chain: bytes, session: bytes,
                       transcript: bytes) -> None:
    """Persist the committed state for a later reconnect, when requested.

    The state file intentionally lives outside the public result record.  The
    reconnect-frequency runner keeps it in its excluded scratch directory and
    publishes only SHA-256 digests of the derived chain and session.
    """
    if not path:
        return
    atomic_json(Path(path), {
        "schema": "gtr.netns.private-state.v1",
        "role": role,
        "sid": config["sid"],
        "epoch": epoch,
        "chain_hex": chain.hex(),
        "chain_sha256": hashlib.sha256(chain).hexdigest(),
        "session_sha256": hashlib.sha256(session).hexdigest(),
        "transcript_sha256": hashlib.sha256(transcript).hexdigest(),
    })


def common_result(role: str, run_id: str, config: dict, started_ns: int,
                  ended_ns: int, user_start: float, system_start: float,
                  sent: int, received: int, info: dict,
                  trace: dict = None) -> dict:
    user_end, system_end = cpu_snapshot()
    return {
        "schema": "gtr.netns.endpoint.v1",
        "role": role,
        "run_id": run_id,
        "sid": config["sid"],
        "epochs": {
            "initiator": config["epoch_i"],
            "responder": config["epoch_j"],
            "converged": max(config["epoch_i"], config["epoch_j"]) + 1,
        },
        "started_monotonic_ns": started_ns,
        "ended_monotonic_ns": ended_ns,
        "elapsed_ms": (ended_ns - started_ns) / 1_000_000,
        "cpu_user_ms": (user_end - user_start) * 1000,
        "cpu_system_ms": (system_end - system_start) * 1000,
        "application_bytes_sent": sent,
        "application_bytes_received": received,
        "events_monotonic_ns": dict(trace or {}),
        "tcp": info,
    }


def run_responder(args: argparse.Namespace, config: dict, work: Path,
                  trace: dict) -> dict:
    sent = received = 0
    user_start, system_start = cpu_snapshot()
    started_ns = time.monotonic_ns()
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((args.address, args.port))
        listener.listen(1)
        listener.settimeout(args.timeout)
        Path(args.ready_file).write_text("ready\n", encoding="utf-8")
        conn, _ = listener.accept()
        with conn:
            conn.settimeout(args.timeout)
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            m1, count = recv_flight(conn, "M1", trace)
            received += count
            execution_sid = require_execution_sid(m1.get("sid"))
            if int(m1.get("e_i", -1)) != config["epoch_i"]:
                raise RuntimeError("M1 initiator epoch mismatch")

            n_i = unb64(m1["n_i"])
            if config.get("g_j", 0) > config.get("g_max", float("inf")):
                raise PolicyLimitExceeded(
                    f"R2: responder local gap {config['g_j']} exceeds "
                    f"G_max={config['g_max']}")
            eph_pk_bytes = unb64(m1["eph_pk"])
            eph_pk = write_bytes(work / "initiator-eph.pem", eph_pk_bytes)
            ct_sj = unb64(m1["ct_sj"])
            ss_sj = core.mlkem_decap(config["responder_static_sk"], ct_sj)
            ct_e, ss_e = core.mlkem_encap(eph_pk)
            ct_si, ss_si = core.mlkem_encap(config["initiator_static_pk"])
            d_si_ct, d_si = core.mlkem_encap(config["initiator_fs_pk"])
            n_j = secrets.token_bytes(16)
            e_prime = max(config["epoch_i"], config["epoch_j"]) + 1
            if "ck_j_hex" in config:
                chain_j = bytes.fromhex(config["ck_j_hex"])
            else:
                chain = bytes.fromhex(config["ck0_hex"])
                chain_j, _ = core.chain_fast_forward(
                    chain, 0, config["epoch_j"])
            ff_started_ns = time.process_time_ns()
            chain_ff, fast_forward_steps = core.chain_fast_forward(
                chain_j, config["epoch_j"], e_prime - 1)
            fast_forward_cpu_us = (
                time.process_time_ns() - ff_started_ns) / 1_000
            tr12 = core.H(
                "tr12", execution_sid, n_i, n_j, config["epoch_i"],
                config["epoch_j"], e_prime, eph_pk_bytes, ct_sj, ct_e,
                ct_si, d_si_ct,
            )
            kpre = pre_schedule(
                chain_ff, ss_e, ss_sj, ss_si, tr12, execution_sid, e_prime)
            tau_j = core.mac(core.hkdf(kpre, b"mac-j"),
                             core.H("tau_j", tr12))
            candidate_path = work / "responder-candidate.json"
            atomic_json(candidate_path, {
                "state": "C_pre",
                "run_id": args.run_id,
                "epoch": e_prime,
                "transcript_sha256": hashlib.sha256(tr12).hexdigest(),
            })
            sent += send_flight(conn, "M2", {
                "n_j": b64(n_j),
                "e_j": config["epoch_j"],
                "ct_e": b64(ct_e),
                "ct_si": b64(ct_si),
                "d_si": b64(d_si_ct),
                "tau_j": b64(tau_j),
            }, trace)

            m3, count = recv_flight(conn, "M3", trace)
            received += count
            d_sj_ct = unb64(m3["d_sj"])
            tau_i = unb64(m3["tau_i"])
            d_sj = core.mlkem_decap(config["responder_fs_sk"], d_sj_ct)
            tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
            expected_tau_i = core.mac(core.hkdf(kpre, b"mac-i"),
                                      core.H("tau_i", tr3))
            if not secrets.compare_digest(tau_i, expected_tau_i):
                raise RuntimeError("M3 authentication failed")
            transcript = core.H("tr-final", tr3, tau_i)
            session, next_chain, confirm = final_schedule(
                kpre, d_sj, d_si, transcript, execution_sid, e_prime)
            atomic_json(candidate_path, {
                "state": "C_fin",
                "run_id": args.run_id,
                "epoch": e_prime,
                "chain_sha256": hashlib.sha256(next_chain).hexdigest(),
                "session_sha256": hashlib.sha256(session).hexdigest(),
                "transcript_sha256": hashlib.sha256(transcript).hexdigest(),
            })
            gamma = core.mac(confirm, core.H("confirm", transcript))
            sent += send_flight(
                conn, "M4", {"gamma_j": b64(gamma)}, trace)

            conf_i, count = recv_flight(conn, "CONF_I", trace)
            received += count
            if conf_i.get("type") != "CONF_I":
                raise RuntimeError("expected protected initiator confirmation")
            expected_conf_i = core.mac(
                session,
                core.H("adopt-i", execution_sid, e_prime, transcript),
            )
            if not secrets.compare_digest(unb64(conf_i["tag"]),
                                          expected_conf_i):
                raise RuntimeError("protected initiator confirmation failed")
            responder_promoted_ns = time.monotonic_ns()
            persist_next_state(
                args.state_out, "responder", {**config, "sid": execution_sid},
                e_prime, next_chain,
                session, transcript)
            ack_r = core.mac(
                session,
                core.H("adopt-r", execution_sid, e_prime, transcript),
            )
            sent += send_flight(
                conn, "ACK_R", {"type": "ACK_R", "tag": b64(ack_r)}, trace)
            info = tcp_info(conn)
            candidate_path.unlink()
            candidate_cleanup_verified = not candidate_path.exists()

    ended_ns = time.monotonic_ns()
    result = common_result(
        "responder", args.run_id, {**config, "sid": execution_sid},
        started_ns, ended_ns,
        user_start, system_start, sent, received, info, trace)
    result.update({
        "ok": True,
        "policy_decision": "R1",
        "adopted": True,
        "exported_peer_id": "initiator",
        "fast_forward_steps": fast_forward_steps,
        "fast_forward_cpu_us": fast_forward_cpu_us,
        "next_chain_sha256": hashlib.sha256(next_chain).hexdigest(),
        "session_sha256": hashlib.sha256(session).hexdigest(),
        "transcript_sha256": hashlib.sha256(transcript).hexdigest(),
        "candidate_cleanup_verified": candidate_cleanup_verified,
        "adopted_monotonic_ns": responder_promoted_ns,
        "execution_sid_bits": 128,
        "protected_confirmation_verified": True,
        "adoption_ack_sent": True,
    })
    return result


def run_initiator(args: argparse.Namespace, config: dict, work: Path,
                  trace: dict) -> dict:
    sent = received = 0
    user_start, system_start = cpu_snapshot()
    started_ns = time.monotonic_ns()
    with socket.create_connection((args.address, args.port),
                                  timeout=args.timeout) as conn:
        conn.settimeout(args.timeout)
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        execution_sid = secrets.token_hex(16)
        n_i = secrets.token_bytes(16)
        eph_sk, eph_pk = core.mlkem_keygen(f"initiator-eph-{args.run_id}")
        eph_pk_bytes = read_bytes(eph_pk)
        ct_sj, ss_sj = core.mlkem_encap(config["responder_static_pk"])
        sent += send_flight(conn, "M1", {
            "sid": execution_sid,
            "n_i": b64(n_i),
            "e_i": config["epoch_i"],
            "eph_pk": b64(eph_pk_bytes),
            "ct_sj": b64(ct_sj),
        }, trace)

        m2, count = recv_flight(conn, "M2", trace)
        received += count
        if int(m2.get("e_j", -1)) != config["epoch_j"]:
            raise RuntimeError("M2 responder epoch mismatch")
        observed_delta = abs(config["epoch_i"] - config["epoch_j"])
        if config.get("g_i", 0) > config.get("g_max", float("inf")):
            raise PolicyLimitExceeded(
                f"R2: initiator local gap {config['g_i']} exceeds "
                f"G_max={config['g_max']}")
        n_j = unb64(m2["n_j"])
        ct_e = unb64(m2["ct_e"])
        ct_si = unb64(m2["ct_si"])
        d_si_ct = unb64(m2["d_si"])
        tau_j = unb64(m2["tau_j"])
        ss_e = core.mlkem_decap(eph_sk, ct_e)
        ss_si = core.mlkem_decap(config["initiator_static_sk"], ct_si)
        d_si = core.mlkem_decap(config["initiator_fs_sk"], d_si_ct)
        e_prime = max(config["epoch_i"], config["epoch_j"]) + 1
        if "ck_i_hex" in config:
            chain_i = bytes.fromhex(config["ck_i_hex"])
        else:
            chain = bytes.fromhex(config["ck0_hex"])
            chain_i, _ = core.chain_fast_forward(
                chain, 0, config["epoch_i"])
        ff_started_ns = time.process_time_ns()
        chain_ff, fast_forward_steps = core.chain_fast_forward(
            chain_i, config["epoch_i"], e_prime - 1)
        fast_forward_cpu_us = (
            time.process_time_ns() - ff_started_ns) / 1_000
        tr12 = core.H(
            "tr12", execution_sid, n_i, n_j, config["epoch_i"],
            config["epoch_j"], e_prime, eph_pk_bytes, ct_sj, ct_e,
            ct_si, d_si_ct,
        )
        kpre = pre_schedule(
            chain_ff, ss_e, ss_sj, ss_si, tr12, execution_sid, e_prime)
        expected_tau_j = core.mac(core.hkdf(kpre, b"mac-j"),
                                  core.H("tau_j", tr12))
        if not secrets.compare_digest(tau_j, expected_tau_j):
            raise RuntimeError("M2 authentication failed")
        if observed_delta > config.get("delta_max", float("inf")):
            raise PolicyLimitExceeded(
                f"R2: authenticated epoch drift {observed_delta} exceeds "
                f"Delta_max={config['delta_max']}")

        candidate_path = work / "initiator-candidate.json"
        atomic_json(candidate_path, {
            "state": "C_fin-pending-confirmation",
            "run_id": args.run_id,
            "epoch": e_prime,
            "transcript12_sha256": hashlib.sha256(tr12).hexdigest(),
        })
        d_sj_ct, d_sj = core.mlkem_encap(config["responder_fs_pk"])
        tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
        tau_i = core.mac(core.hkdf(kpre, b"mac-i"),
                         core.H("tau_i", tr3))
        sent += send_flight(
            conn, "M3", {"d_sj": b64(d_sj_ct), "tau_i": b64(tau_i)}, trace)
        transcript = core.H("tr-final", tr3, tau_i)
        session, next_chain, confirm = final_schedule(
            kpre, d_sj, d_si, transcript, execution_sid, e_prime)
        m4, count = recv_flight(conn, "M4", trace)
        received += count
        gamma = unb64(m4["gamma_j"])
        expected_gamma = core.mac(confirm, core.H("confirm", transcript))
        if not secrets.compare_digest(gamma, expected_gamma):
            raise RuntimeError("M4 confirmation failed")
        key_confirmed_ns = time.monotonic_ns()
        conf_i = core.mac(
            session,
            core.H("adopt-i", execution_sid, e_prime, transcript),
        )
        sent += send_flight(
            conn, "CONF_I", {"type": "CONF_I", "tag": b64(conf_i)}, trace)
        ack_r, count = recv_flight(conn, "ACK_R", trace)
        received += count
        if ack_r.get("type") != "ACK_R":
            raise RuntimeError("expected responder adoption acknowledgement")
        expected_ack_r = core.mac(
            session,
            core.H("adopt-r", execution_sid, e_prime, transcript),
        )
        if not secrets.compare_digest(unb64(ack_r["tag"]), expected_ack_r):
            raise RuntimeError("responder adoption acknowledgement failed")
        adopted_ns = time.monotonic_ns()
        persist_next_state(
            args.state_out, "initiator", {**config, "sid": execution_sid},
            e_prime, next_chain,
            session, transcript)
        candidate_path.unlink()
        candidate_cleanup_verified = not candidate_path.exists()
        info = tcp_info(conn)

    ended_ns = time.monotonic_ns()
    result = common_result(
        "initiator", args.run_id, {**config, "sid": execution_sid},
        started_ns, ended_ns,
        user_start, system_start, sent, received, info, trace)
    result.update({
        "ok": True,
        "policy_decision": "R1",
        "adopted": True,
        "exported_peer_id": "responder",
        "fast_forward_steps": fast_forward_steps,
        "fast_forward_cpu_us": fast_forward_cpu_us,
        "next_chain_sha256": hashlib.sha256(next_chain).hexdigest(),
        "session_sha256": hashlib.sha256(session).hexdigest(),
        "transcript_sha256": hashlib.sha256(transcript).hexdigest(),
        "candidate_cleanup_verified": candidate_cleanup_verified,
        "execution_sid_bits": 128,
        "key_confirmed_monotonic_ns": key_confirmed_ns,
        "adopted_monotonic_ns": adopted_ns,
        "initiator_key_confirmation_ms":
            (key_confirmed_ns - started_ns) / 1_000_000,
        "mutual_adoption_ttsc_ms": (adopted_ns - started_ns) / 1_000_000,
        "ttsc_ms": (adopted_ns - started_ns) / 1_000_000,
    })
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--role", choices=("initiator", "responder"), required=True)
    parser.add_argument("--address", required=True,
                        help="connect address for initiator; bind address for responder")
    parser.add_argument("--port", type=int, default=47000)
    parser.add_argument("--config", required=True)
    parser.add_argument("--result", required=True)
    parser.add_argument("--ready-file")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument("--state-out",
                        help="private committed-state output for a later reconnect")
    args = parser.parse_args()
    if args.role == "responder" and not args.ready_file:
        parser.error("--ready-file is required for responder")

    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    started_ns = time.monotonic_ns()
    user_start, system_start = cpu_snapshot()
    trace: dict = {}
    result: dict
    with tempfile.TemporaryDirectory(prefix=f"gtr-net-{args.role}-") as temporary:
        work = Path(temporary)
        core.WORK = str(work)
        core.SEAL_PATH = str(work / "rot_seal.json")
        try:
            if args.role == "responder":
                result = run_responder(args, config, work, trace)
            else:
                result = run_initiator(args, config, work, trace)
        except Exception as exc:
            ended_ns = time.monotonic_ns()
            result = common_result(
                args.role, args.run_id, config, started_ns, ended_ns,
                user_start, system_start, 0, 0,
                {"rtt_us": None, "total_retrans": None}, trace,
            )
            result.update({
                "ok": False,
                "adopted": False,
                "policy_decision": (
                    "R2" if isinstance(exc, PolicyLimitExceeded)
                    else "REJECT"
                ),
                "error_type": type(exc).__name__,
                "error": str(exc),
            })
    atomic_json(Path(args.result), result)
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
