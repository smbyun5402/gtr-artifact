#!/usr/bin/env python3
"""Restartable GT-R endpoint used by the event-triggered blackout campaign.

The cryptographic M1--M4 computations are the same OpenSSL-backed operations
used by ``gtr_net_endpoint.py``.  On a transport timeout the initiator opens a
new TCP connection with the same attempt identifier and byte-identical M1/M3.
The responder retains a bounded volatile pre-candidate and a final candidate
for that attempt and reuses the cached M2/M4 rather than recomputing either.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import secrets
import socket
import tempfile
import time
from pathlib import Path

import gtr_net_endpoint as base
import reauth_demo as core


def canonical(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def digest(value: dict) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def signal_event(args: argparse.Namespace, event: str, details: dict) -> None:
    if args.pause_event != event:
        return
    event_path = Path(args.event_file)
    release_path = Path(args.release_file)
    if event_path.exists():
        return
    base.atomic_json(event_path, {
        "schema": "gtr.blackout.event.v1",
        "run_id": args.run_id,
        "event": event,
        "monotonic_ns": time.monotonic_ns(),
        **details,
    })
    deadline = time.monotonic() + args.event_wait_timeout
    while not release_path.exists():
        if time.monotonic() >= deadline:
            raise TimeoutError(f"controller did not release {event}")
        time.sleep(0.002)


def retry_timeout(args: argparse.Namespace, attempt_index: int) -> float:
    return args.retry_base_timeout * (2 ** attempt_index)


def prepare_initiator(args: argparse.Namespace, config: dict,
                      work: Path) -> dict:
    n_i = secrets.token_bytes(16)
    attempt_id = n_i.hex()
    execution_sid = secrets.token_hex(16)
    eph_sk, eph_pk = core.mlkem_keygen(f"blackout-eph-{args.run_id}")
    eph_pk_bytes = base.read_bytes(eph_pk)
    ct_sj, ss_sj = core.mlkem_encap(config["responder_static_pk"])
    m1 = {
        "type": "M1", "attempt_id": attempt_id, "sid": execution_sid,
        "n_i": base.b64(n_i), "e_i": config["epoch_i"],
        "eph_pk": base.b64(eph_pk_bytes), "ct_sj": base.b64(ct_sj),
    }
    return {
        "n_i": n_i, "attempt_id": attempt_id, "sid": execution_sid,
        "eph_sk": eph_sk,
        "eph_pk_bytes": eph_pk_bytes, "ct_sj": ct_sj, "ss_sj": ss_sj,
        "m1": m1, "m2": None, "m3": None, "session": None,
        "transcript": None, "confirm": None, "e_prime": None,
        "m2_reuse_count": 0, "candidate_conflicts": 0,
    }


def accept_m2(state: dict, m2: dict, config: dict) -> None:
    if m2.get("type") != "M2" or m2.get("attempt_id") != state["attempt_id"]:
        raise RuntimeError("unexpected M2 attempt")
    if state["m2"] is not None:
        if not secrets.compare_digest(digest(m2), digest(state["m2"])):
            state["candidate_conflicts"] += 1
            raise RuntimeError("replayed M2 differs from cached candidate")
        state["m2_reuse_count"] += 1
        return

    if int(m2.get("e_j", -1)) != config["epoch_j"]:
        raise RuntimeError("M2 responder epoch mismatch")
    n_j = base.unb64(m2["n_j"])
    ct_e = base.unb64(m2["ct_e"])
    ct_si = base.unb64(m2["ct_si"])
    d_si_ct = base.unb64(m2["d_si"])
    tau_j = base.unb64(m2["tau_j"])
    ss_e = core.mlkem_decap(state["eph_sk"], ct_e)
    ss_si = core.mlkem_decap(config["initiator_static_sk"], ct_si)
    d_si = core.mlkem_decap(config["initiator_fs_sk"], d_si_ct)
    e_prime = max(config["epoch_i"], config["epoch_j"]) + 1
    chain = bytes.fromhex(config["ck0_hex"])
    chain_i, _ = core.chain_fast_forward(chain, 0, config["epoch_i"])
    chain_ff, _ = core.chain_fast_forward(
        chain_i, config["epoch_i"], e_prime - 1)
    tr12 = core.H(
        "tr12", state["sid"], state["n_i"], n_j, config["epoch_i"],
        config["epoch_j"], e_prime, state["eph_pk_bytes"], state["ct_sj"],
        ct_e, ct_si, d_si_ct,
    )
    kpre = base.pre_schedule(
        chain_ff, ss_e, state["ss_sj"], ss_si, tr12, state["sid"], e_prime)
    expected_tau_j = core.mac(core.hkdf(kpre, b"mac-j"),
                              core.H("tau_j", tr12))
    if not secrets.compare_digest(tau_j, expected_tau_j):
        raise RuntimeError("M2 authentication failed")

    d_sj_ct, d_sj = core.mlkem_encap(config["responder_fs_pk"])
    tr3 = core.H("tr123", tr12, d_sj_ct, tau_j)
    tau_i = core.mac(core.hkdf(kpre, b"mac-i"), core.H("tau_i", tr3))
    transcript = core.H("tr-final", tr3, tau_i)
    session, _, confirm = base.final_schedule(
        kpre, d_sj, d_si, transcript, state["sid"], e_prime)
    state.update({
        "m2": m2,
        "m3": {
            "type": "M3", "attempt_id": state["attempt_id"],
            "d_sj": base.b64(d_sj_ct), "tau_i": base.b64(tau_i),
        },
        "session": session, "transcript": transcript, "confirm": confirm,
        "e_prime": e_prime,
    })


def run_initiator(args: argparse.Namespace, config: dict, work: Path) -> dict:
    sent = received = 0
    user_start, system_start = base.cpu_snapshot()
    started_ns = time.monotonic_ns()
    state = prepare_initiator(args, config, work)
    errors: list[str] = []
    attempts = 0
    retrans_total = 0
    info = {"rtt_us": None, "total_retrans": 0}
    adopted_ns = None
    key_confirmed_ns = None

    for attempt_index in range(args.max_retries + 1):
        attempts += 1
        timeout = retry_timeout(args, attempt_index)
        try:
            with socket.create_connection((args.address, args.port),
                                          timeout=timeout) as conn:
                conn.settimeout(timeout)
                conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                sent += base.send_frame(conn, state["m1"])
                m2, count = base.recv_frame(conn)
                received += count
                accept_m2(state, m2, config)
                signal_event(args, "before_m3", {
                    "attempt_id": state["attempt_id"],
                    "candidate_sha256": digest(state["m3"]),
                })
                sent += base.send_frame(conn, state["m3"])
                m4, count = base.recv_frame(conn)
                received += count
                if m4.get("type") != "M4" or (
                        m4.get("attempt_id") != state["attempt_id"]):
                    raise RuntimeError("unexpected M4 attempt")
                gamma = base.unb64(m4["gamma_j"])
                expected_gamma = core.mac(
                    state["confirm"], core.H("confirm", state["transcript"]))
                if not secrets.compare_digest(gamma, expected_gamma):
                    raise RuntimeError("M4 confirmation failed")
                if key_confirmed_ns is None:
                    key_confirmed_ns = time.monotonic_ns()
                signal_event(args, "before_conf_i", {
                    "attempt_id": state["attempt_id"],
                    "transcript_sha256": hashlib.sha256(
                        state["transcript"]).hexdigest(),
                })
                sent += base.send_frame(conn, {
                    "type": "CONF_I",
                    "attempt_id": state["attempt_id"],
                    "tag": base.b64(core.mac(
                        state["session"],
                        core.H("adopt-i", state["sid"], state["e_prime"],
                               state["transcript"]))),
                })
                ack_r, count = base.recv_frame(conn)
                received += count
                if ack_r.get("type") != "ACK_R" or (
                        ack_r.get("attempt_id") != state["attempt_id"]):
                    raise RuntimeError("invalid responder adoption acknowledgement")
                expected_ack_r = core.mac(
                    state["session"],
                    core.H("adopt-r", state["sid"], state["e_prime"],
                           state["transcript"]))
                if not secrets.compare_digest(base.unb64(ack_r["tag"]),
                                              expected_ack_r):
                    raise RuntimeError("responder adoption acknowledgement failed")
                adopted_ns = time.monotonic_ns()
                sent += base.send_frame(conn, {
                    "type": "ACK_RECEIPT",
                    "attempt_id": state["attempt_id"],
                    "tag": base.b64(core.mac(
                        state["session"],
                        core.H("ack-receipt", state["sid"],
                               state["e_prime"], state["transcript"]))),
                })
                info = base.tcp_info(conn)
                retrans_total += info.get("total_retrans") or 0
                break
        except (TimeoutError, socket.timeout, ConnectionError, OSError) as exc:
            errors.append(f"attempt-{attempts}:{type(exc).__name__}:{exc}")
            if attempt_index == args.max_retries:
                raise RuntimeError("RETRY_EXHAUSTED: " + " | ".join(errors))
            continue

    ended_ns = time.monotonic_ns()
    result = base.common_result(
        "initiator", args.run_id, {**config, "sid": state["sid"]},
        started_ns, ended_ns,
        user_start, system_start, sent, received,
        {**info, "total_retrans": retrans_total},
    )
    result.update({
        "schema": "gtr.blackout.endpoint.v1", "ok": True, "adopted": True,
        "adopted_monotonic_ns": adopted_ns, "attempt_id": state["attempt_id"],
        "attempts": attempts, "application_retries": attempts - 1,
        "transport_errors": errors, "m2_candidate_reuse_count": state["m2_reuse_count"],
        "candidate_conflicts": state["candidate_conflicts"],
        "candidate_sha256": digest(state["m3"]),
        "session_sha256": hashlib.sha256(state["session"]).hexdigest(),
        "transcript_sha256": hashlib.sha256(state["transcript"]).hexdigest(),
        "key_confirmed_monotonic_ns": key_confirmed_ns,
        "initiator_key_confirmation_ms":
            (key_confirmed_ns - started_ns) / 1_000_000,
        "mutual_adoption_ttsc_ms": (adopted_ns - started_ns) / 1_000_000,
        "ttsc_ms": (adopted_ns - started_ns) / 1_000_000,
    })
    return result


def build_responder_candidate(m1: dict, config: dict, work: Path) -> dict:
    if m1.get("type") != "M1":
        raise RuntimeError("unexpected M1")
    execution_sid = base.require_execution_sid(m1.get("sid"))
    if int(m1.get("e_i", -1)) != config["epoch_i"]:
        raise RuntimeError("M1 initiator epoch mismatch")
    attempt_id = m1["attempt_id"]
    n_i = base.unb64(m1["n_i"])
    eph_pk_bytes = base.unb64(m1["eph_pk"])
    eph_pk = base.write_bytes(work / "initiator-eph.pem", eph_pk_bytes)
    ct_sj = base.unb64(m1["ct_sj"])
    ss_sj = core.mlkem_decap(config["responder_static_sk"], ct_sj)
    ct_e, ss_e = core.mlkem_encap(eph_pk)
    ct_si, ss_si = core.mlkem_encap(config["initiator_static_pk"])
    d_si_ct, d_si = core.mlkem_encap(config["initiator_fs_pk"])
    n_j = secrets.token_bytes(16)
    e_prime = max(config["epoch_i"], config["epoch_j"]) + 1
    chain = bytes.fromhex(config["ck0_hex"])
    chain_j, _ = core.chain_fast_forward(chain, 0, config["epoch_j"])
    chain_ff, _ = core.chain_fast_forward(
        chain_j, config["epoch_j"], e_prime - 1)
    tr12 = core.H(
        "tr12", execution_sid, n_i, n_j, config["epoch_i"],
        config["epoch_j"], e_prime, eph_pk_bytes, ct_sj, ct_e, ct_si, d_si_ct,
    )
    kpre = base.pre_schedule(
        chain_ff, ss_e, ss_sj, ss_si, tr12, execution_sid, e_prime)
    tau_j = core.mac(core.hkdf(kpre, b"mac-j"), core.H("tau_j", tr12))
    m2 = {
        "type": "M2", "attempt_id": attempt_id, "n_j": base.b64(n_j),
        "e_j": config["epoch_j"], "ct_e": base.b64(ct_e),
        "ct_si": base.b64(ct_si), "d_si": base.b64(d_si_ct),
        "tau_j": base.b64(tau_j),
    }
    return {
        "attempt_id": attempt_id, "sid": execution_sid,
        "m1_sha256": digest(m1), "m2": m2,
        "kpre": kpre, "d_si": d_si, "tau_j": tau_j, "tr12": tr12,
        "e_prime": e_prime, "m3": None, "m4": None, "session": None,
        "transcript": None, "m1_reuse_count": 0, "m3_reuse_count": 0,
        "candidate_conflicts": 0, "authenticated_monotonic_ns": None,
        "adopted_monotonic_ns": None,
    }


def accept_m3(candidate: dict, m3: dict, config: dict) -> None:
    if m3.get("type") != "M3" or m3.get("attempt_id") != candidate["attempt_id"]:
        raise RuntimeError("unexpected M3 attempt")
    if candidate["m3"] is not None:
        if not secrets.compare_digest(digest(m3), digest(candidate["m3"])):
            candidate["candidate_conflicts"] += 1
            raise RuntimeError("replayed M3 differs from cached candidate")
        candidate["m3_reuse_count"] += 1
        return

    d_sj_ct = base.unb64(m3["d_sj"])
    tau_i = base.unb64(m3["tau_i"])
    d_sj = core.mlkem_decap(config["responder_fs_sk"], d_sj_ct)
    tr3 = core.H("tr123", candidate["tr12"], d_sj_ct, candidate["tau_j"])
    expected_tau_i = core.mac(
        core.hkdf(candidate["kpre"], b"mac-i"), core.H("tau_i", tr3))
    if not secrets.compare_digest(tau_i, expected_tau_i):
        raise RuntimeError("M3 authentication failed")
    transcript = core.H("tr-final", tr3, tau_i)
    session, _, confirm = base.final_schedule(
        candidate["kpre"], d_sj, candidate["d_si"], transcript,
        candidate["sid"], candidate["e_prime"])
    gamma = core.mac(confirm, core.H("confirm", transcript))
    candidate.update({
        "m3": m3,
        "m4": {"type": "M4", "attempt_id": candidate["attempt_id"],
               "gamma_j": base.b64(gamma)},
        "session": session, "transcript": transcript,
        "authenticated_monotonic_ns": time.monotonic_ns(),
    })


def run_responder(args: argparse.Namespace, config: dict, work: Path) -> dict:
    sent = received = 0
    user_start, system_start = base.cpu_snapshot()
    started_ns = time.monotonic_ns()
    candidate = None
    errors: list[str] = []
    connections = 0
    completion_receipt_received = False
    promoted = False
    retrans_total = 0
    info = {"rtt_us": None, "total_retrans": 0}
    overall_deadline = time.monotonic() + args.event_wait_timeout

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((args.address, args.port))
        listener.listen(args.max_retries + 2)
        listener.settimeout(0.25)
        Path(args.ready_file).write_text("ready\n", encoding="utf-8")
        while (not completion_receipt_received
               and time.monotonic() < overall_deadline):
            try:
                conn, _ = listener.accept()
            except socket.timeout:
                continue
            connections += 1
            with conn:
                timeout = retry_timeout(
                    args, min(connections - 1, args.max_retries))
                conn.settimeout(timeout)
                conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                try:
                    m1, count = base.recv_frame(conn)
                    received += count
                    if candidate is None:
                        candidate = build_responder_candidate(m1, config, work)
                    elif not secrets.compare_digest(
                            digest(m1), candidate["m1_sha256"]):
                        candidate["candidate_conflicts"] += 1
                        raise RuntimeError("retry M1 differs from cached attempt")
                    else:
                        candidate["m1_reuse_count"] += 1
                    sent += base.send_frame(conn, candidate["m2"])
                    signal_event(args, "after_m2", {
                        "attempt_id": candidate["attempt_id"],
                        "candidate_sha256": digest(candidate["m2"]),
                    })
                    m3, count = base.recv_frame(conn)
                    received += count
                    accept_m3(candidate, m3, config)
                    signal_event(args, "before_m4", {
                        "attempt_id": candidate["attempt_id"],
                        "candidate_sha256": digest(candidate["m4"]),
                    })
                    sent += base.send_frame(conn, candidate["m4"])
                    conf_i, count = base.recv_frame(conn)
                    received += count
                    if conf_i.get("type") != "CONF_I" or (
                            conf_i.get("attempt_id") != candidate["attempt_id"]):
                        raise RuntimeError("invalid protected confirmation")
                    expected_conf_i = core.mac(
                        candidate["session"],
                        core.H("adopt-i", candidate["sid"],
                               candidate["e_prime"], candidate["transcript"]))
                    if not secrets.compare_digest(base.unb64(conf_i["tag"]),
                                                  expected_conf_i):
                        raise RuntimeError("protected confirmation key mismatch")
                    if not promoted:
                        candidate["adopted_monotonic_ns"] = time.monotonic_ns()
                        promoted = True
                    ack_r = core.mac(
                        candidate["session"],
                        core.H("adopt-r", candidate["sid"],
                               candidate["e_prime"], candidate["transcript"]))
                    signal_event(args, "before_ack_r", {
                        "attempt_id": candidate["attempt_id"],
                        "transcript_sha256": hashlib.sha256(
                            candidate["transcript"]).hexdigest(),
                    })
                    sent += base.send_frame(conn, {
                        "type": "ACK_R", "attempt_id": candidate["attempt_id"],
                        "tag": base.b64(ack_r),
                    })
                    receipt, count = base.recv_frame(conn)
                    received += count
                    if receipt.get("type") != "ACK_RECEIPT" or (
                            receipt.get("attempt_id") != candidate["attempt_id"]):
                        raise RuntimeError("invalid adoption acknowledgement receipt")
                    expected_receipt = core.mac(
                        candidate["session"],
                        core.H("ack-receipt", candidate["sid"],
                               candidate["e_prime"], candidate["transcript"]))
                    if not secrets.compare_digest(base.unb64(receipt["tag"]),
                                                  expected_receipt):
                        raise RuntimeError("adoption acknowledgement receipt failed")
                    completion_receipt_received = True
                    info = base.tcp_info(conn)
                    retrans_total += info.get("total_retrans") or 0
                except (TimeoutError, socket.timeout, ConnectionError, OSError) as exc:
                    info = base.tcp_info(conn)
                    retrans_total += info.get("total_retrans") or 0
                    errors.append(
                        f"connection-{connections}:{type(exc).__name__}:{exc}")
                    continue
    if (not completion_receipt_received or candidate is None
            or candidate["m4"] is None):
        raise RuntimeError("RETRY_EXHAUSTED: " + " | ".join(errors))

    ended_ns = time.monotonic_ns()
    result = base.common_result(
        "responder", args.run_id, {**config, "sid": candidate["sid"]},
        started_ns, ended_ns,
        user_start, system_start, sent, received,
        {**info, "total_retrans": retrans_total},
    )
    result.update({
        "schema": "gtr.blackout.endpoint.v1", "ok": True, "adopted": True,
        "adopted_monotonic_ns": candidate["adopted_monotonic_ns"],
        "attempt_id": candidate["attempt_id"], "connections": connections,
        "transport_errors": errors,
        "m1_candidate_reuse_count": candidate["m1_reuse_count"],
        "m3_candidate_reuse_count": candidate["m3_reuse_count"],
        "candidate_conflicts": candidate["candidate_conflicts"],
        "pre_candidate_sha256": digest(candidate["m2"]),
        "final_candidate_sha256": digest(candidate["m4"]),
        "session_sha256": hashlib.sha256(candidate["session"]).hexdigest(),
        "transcript_sha256": hashlib.sha256(candidate["transcript"]).hexdigest(),
        "protected_confirmation_received": True,
        "adoption_ack_sent": True,
        "completion_receipt_received": True,
    })
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--role", choices=("initiator", "responder"), required=True)
    parser.add_argument("--address", required=True)
    parser.add_argument("--port", type=int, default=47100)
    parser.add_argument("--config", required=True)
    parser.add_argument("--result", required=True)
    parser.add_argument("--ready-file")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--pause-event",
                        choices=("after_m2", "before_m3", "before_m4",
                                 "before_conf_i", "before_ack_r"),
                        required=True)
    parser.add_argument("--event-file", required=True)
    parser.add_argument("--release-file", required=True)
    parser.add_argument("--retry-base-timeout", type=float, default=0.5)
    parser.add_argument("--max-retries", type=int, default=3)
    parser.add_argument("--event-wait-timeout", type=float, default=20.0)
    args = parser.parse_args()
    if args.role == "responder" and not args.ready_file:
        parser.error("--ready-file is required for responder")

    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    started_ns = time.monotonic_ns()
    user_start, system_start = base.cpu_snapshot()
    with tempfile.TemporaryDirectory(prefix=f"gtr-blackout-{args.role}-") as temporary:
        work = Path(temporary)
        core.WORK = str(work)
        core.SEAL_PATH = str(work / "rot_seal.json")
        try:
            result = (run_responder(args, config, work)
                      if args.role == "responder"
                      else run_initiator(args, config, work))
        except Exception as exc:
            ended_ns = time.monotonic_ns()
            result = base.common_result(
                args.role, args.run_id, config, started_ns, ended_ns,
                user_start, system_start, 0, 0,
                {"rtt_us": None, "total_retrans": None},
            )
            result.update({
                "schema": "gtr.blackout.endpoint.v1", "ok": False,
                "adopted": False, "error_type": type(exc).__name__,
                "error": str(exc),
            })
    base.atomic_json(Path(args.result), result)
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
