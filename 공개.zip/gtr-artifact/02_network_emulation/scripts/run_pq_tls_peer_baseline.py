#!/usr/bin/env python3
"""Measure verifier-less mutual PQ TLS 1.3 under the GT-R netem topology."""

from __future__ import annotations

import argparse
import collections
import csv
import json
import os
import platform
import statistics
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import run_full_reattest_experiment as common


HERE = Path(__file__).resolve().parent


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * q
    lo = int(rank)
    hi = min(lo + 1, len(ordered) - 1)
    fraction = rank - lo
    return ordered[lo] * (1 - fraction) + ordered[hi] * fraction


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    os.replace(temporary, path)


def client_command(config: dict, environment: dict[str, str]) -> list[str]:
    args = [
        config["openssl"], "s_client",
        "-connect", f"{common.J_ADDR}:{common.TLS_PORT}",
        "-cert", config["client_cert"], "-key", config["client_key"],
        "-CAfile", config["ca_cert"], "-verify_return_error",
        "-groups", "MLKEM768", "-tls1_3", "-quiet",
    ]
    return common.ns_user_args(common.NS_I, args, environment)


def server_command(config: dict, environment: dict[str, str]) -> list[str]:
    """Serve one authenticated TLS connection and one protected HTTP reply."""
    args = [
        config["openssl"], "s_server", "-accept", str(common.TLS_PORT),
        "-cert", config["server_cert"], "-key", config["server_key"],
        "-CAfile", config["ca_cert"], "-Verify", "1",
        "-verify_return_error", "-groups", "MLKEM768", "-tls1_3",
        "-quiet", "-www", "-naccept", "1",
    ]
    return common.ns_user_args(common.NS_J, args, environment)


def run_trial(condition: dict, trial: int, config: dict,
              environment: dict[str, str], log_handle, timeout: float) -> dict:
    common.root_command([
        "ip", "netns", "exec", common.NS_J, "pkill", "-TERM", "-f",
        f"s_server.*{common.TLS_PORT}",
    ], check=False)
    server = subprocess.Popen(
        server_command(config, environment),
        stdout=log_handle, stderr=log_handle, text=True)
    client = None
    error = None
    client_rc = server_rc = None
    started = time.monotonic_ns()
    try:
        common.wait_for_tls_listener(server)
        started = time.monotonic_ns()
        client = subprocess.Popen(
            client_command(config, environment), stdin=subprocess.PIPE,
            stdout=log_handle, stderr=log_handle, text=True)
        try:
            client.communicate(input="GET / HTTP/1.0\r\n\r\n", timeout=timeout)
            client_rc = client.returncode
        except subprocess.TimeoutExpired:
            client.kill()
            client.wait(timeout=5)
            client_rc = client.returncode
            error = "client timeout"
        ended = time.monotonic_ns()
        try:
            server_rc = server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            common.root_command([
                "ip", "netns", "exec", common.NS_J, "pkill", "-TERM", "-f",
                f"s_server.*{common.TLS_PORT}",
            ], check=False)
            server.wait(timeout=5)
            server_rc = server.returncode
            if error is None:
                error = "server did not exit after one accepted connection"
    except Exception as exc:
        ended = time.monotonic_ns()
        error = f"{type(exc).__name__}: {exc}"
        if client is not None and client.poll() is None:
            client.kill()
            client.wait(timeout=5)
            client_rc = client.returncode
        if server.poll() is None:
            common.root_command([
                "ip", "netns", "exec", common.NS_J, "pkill", "-TERM", "-f",
                f"s_server.*{common.TLS_PORT}",
            ], check=False)
            server.wait(timeout=5)
        server_rc = server.returncode
    success = client_rc == 0 and server_rc == 0 and error is None
    return {
        "schema": "gtr.pq-tls-peer.trial.v1",
        "condition": condition,
        "trial": trial,
        "success": success,
        "ttsc_ms": (ended - started) / 1_000_000.0,
        "client_exit_code": client_rc,
        "server_exit_code": server_rc,
        "failure_reason": error,
    }


def summarize(condition: dict, rows: list[dict]) -> dict:
    successful = [row for row in rows if row["success"]]
    values = [row["ttsc_ms"] for row in successful]
    failures = collections.Counter(
        row["failure_reason"] or "non-zero exit"
        for row in rows if not row["success"])
    return {
        "condition": condition,
        "trials": len(rows),
        "successes": len(successful),
        "success_rate_percent": 100 * len(successful) / len(rows),
        "ttsc_ms": {
            "mean": statistics.mean(values) if values else None,
            "median": statistics.median(values) if values else None,
            "p95": percentile(values, 0.95),
            "p99": percentile(values, 0.99),
            "max": max(values) if values else None,
        },
        "failure_reasons": dict(failures),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=100)
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument("--output")
    args = parser.parse_args()
    if args.repetitions < 1:
        parser.error("--repetitions must be positive")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-pq-tls-peer-rtt")
    output.mkdir(parents=True, exist_ok=False)
    (output / "scratch").mkdir()
    log_path = output / "processes.log"

    openssl, version, environment = common.openssl_environment()
    credentials = common.provision_credentials(output, openssl, environment)
    config = {"openssl": openssl, **credentials}
    conditions = [
        {"id": f"pq-tls-rtt{rtt}-loss0", "rtt_ms": float(rtt),
         "loss_percent": 0.0, "jitter_ms": 0.0,
         "repetitions": args.repetitions}
        for rtt in (10, 50, 100, 200, 500, 1000)
    ]

    summaries: list[dict] = []
    common.setup_topology()
    try:
        common.apply_netem(0, 0, 0)
        common.verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            for condition in conditions:
                print(f"[{condition['id']}] n={args.repetitions}", flush=True)
                common.apply_netem(0, condition["rtt_ms"], 0)
                rows: list[dict] = []
                for trial in range(1, args.repetitions + 1):
                    row = run_trial(condition, trial, config, environment,
                                    log_handle, args.timeout)
                    rows.append(row)
                    with (output / "trials.jsonl").open(
                            "a", encoding="utf-8") as handle:
                        handle.write(json.dumps(row, sort_keys=True) + "\n")
                    if trial % 10 == 0 or not row["success"]:
                        print(f"  trial {trial}/{args.repetitions}: "
                              f"{'ok' if row['success'] else row['failure_reason']}",
                              flush=True)
                summary = summarize(condition, rows)
                summaries.append(summary)
                write_json(output / "summary.json", summaries)
                print(f"  success={summary['success_rate_percent']:.1f}% "
                      f"median={summary['ttsc_ms']['median']:.3f}ms "
                      f"p95={summary['ttsc_ms']['p95']:.3f}ms", flush=True)
    finally:
        common.cleanup_topology()

    with (output / "summary.csv").open("w", encoding="utf-8", newline="") as h:
        writer = csv.writer(h)
        writer.writerow(["condition", "rtt_ms", "trials", "successes",
                         "success_rate_percent", "median_ms", "p95_ms",
                         "p99_ms", "max_ms"])
        for row in summaries:
            writer.writerow([row["condition"]["id"], row["condition"]["rtt_ms"],
                             row["trials"], row["successes"],
                             row["success_rate_percent"], row["ttsc_ms"]["median"],
                             row["ttsc_ms"]["p95"], row["ttsc_ms"]["p99"],
                             row["ttsc_ms"]["max"]])
    write_json(output / "manifest.json", {
        "schema": "gtr.pq-tls-peer.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "baseline": "verifier-less mutually authenticated fresh PQ TLS 1.3",
        "timing_scope": (
            "client process launch through receipt of the server's first "
            "protected HTTP response and orderly close; server readiness and "
            "credential provisioning excluded"
        ),
        "cryptography": "TLS 1.3 MLKEM768 with ML-DSA-65 client and server certificates",
        "network": "the same Linux namespace/router topology and zero-loss RTT sweep used for GT-R",
        "openssl": version,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "conditions": conditions,
    })
    print(json.dumps({"output": str(output), "conditions": len(summaries)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
