#!/usr/bin/env python3
"""Run repeated stateful GT-R reconnects within a fixed logical mission window."""

from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import os
import platform
import secrets
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import reauth_demo as core
import run_netns_experiment as network


HERE = Path(__file__).resolve().parent
RECONNECT_COUNTS = (1, 2, 5, 10)


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def append_jsonl(path: Path, value: dict) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, sort_keys=True) + "\n")
        handle.flush()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * quantile
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = rank - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def describe(values: list[float]) -> dict:
    return {
        "mean": statistics.mean(values) if values else None,
        "median": statistics.median(values) if values else None,
        "p95": percentile(values, 0.95),
        "p99": percentile(values, 0.99),
        "max": max(values) if values else None,
    }


def read_private_state(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
        bytes.fromhex(state["chain_hex"])
        return state
    except (OSError, KeyError, ValueError, json.JSONDecodeError):
        return None


def cycle_config(base: dict, scratch: Path, condition_id: str,
                 mission: int, cycle: int, base_epoch: int,
                 base_chain: bytes, delta_max: int, g_max: int) -> Path:
    # Each simulated no-contact period advances i by one and j by five epochs.
    # A successful reconnect converges to base_epoch + 6 and that committed
    # chain becomes the common input to the next cycle.
    epoch_i = base_epoch + 1
    epoch_j = base_epoch + 5
    chain_i, _ = core.chain_fast_forward(base_chain, base_epoch, epoch_i)
    chain_j, _ = core.chain_fast_forward(base_chain, base_epoch, epoch_j)
    config = dict(base)
    config.update({
        "schema": "gtr.netns.frequency-cycle.v1",
        "sid": f"{condition_id}-mission{mission:04d}-cycle{cycle:02d}",
        "ck_i_hex": chain_i.hex(),
        "ck_j_hex": chain_j.hex(),
        "epoch_i": epoch_i,
        "epoch_j": epoch_j,
        "converged_epoch": epoch_j + 1,
        "g_i": 1,
        "g_j": 5,
        "g_max": g_max,
        "delta_max": delta_max,
    })
    path = scratch / f"{condition_id}-m{mission:04d}-c{cycle:02d}.config.json"
    write_json(path, config)
    return path


def run_cycle(condition: dict, mission: int, cycle: int, paths: dict,
              config: Path, expected_epoch: int, timeout: float,
              openssl: str, library_path: str, log_handle) -> tuple[dict, bytes | None]:
    run_id = f"{condition['id']}-m{mission:04d}-c{cycle:02d}"
    ready = paths["scratch"] / f"{run_id}.ready"
    initiator_result = paths["scratch"] / f"{run_id}.initiator.json"
    responder_result = paths["scratch"] / f"{run_id}.responder.json"
    initiator_state = paths["scratch"] / f"{run_id}.initiator-state.json"
    responder_state = paths["scratch"] / f"{run_id}.responder-state.json"
    for path in (ready, initiator_result, responder_result,
                 initiator_state, responder_state):
        path.unlink(missing_ok=True)

    responder_cmd = network.endpoint_command(
        network.NS_J, "responder", network.J_ADDR, config,
        responder_result, ready, run_id, timeout, openssl, library_path)
    responder_cmd.extend(["--state-out", str(responder_state)])
    initiator_cmd = network.endpoint_command(
        network.NS_I, "initiator", network.J_ADDR, config,
        initiator_result, ready, run_id, timeout, openssl, library_path)
    initiator_cmd.extend(["--state-out", str(initiator_state)])

    responder = subprocess.Popen(
        responder_cmd, stdout=log_handle, stderr=log_handle, text=True)
    client_rc = server_rc = None
    orchestration_error = None
    try:
        network.wait_for_ready(ready, responder)
        client = subprocess.Popen(
            initiator_cmd, stdout=log_handle, stderr=log_handle, text=True)
        try:
            client_rc = client.wait(timeout=timeout + 10)
        except subprocess.TimeoutExpired:
            client.kill()
            client_rc = client.wait(timeout=5)
            orchestration_error = "initiator orchestration timeout"
        try:
            server_rc = responder.wait(timeout=timeout + 10)
        except subprocess.TimeoutExpired:
            responder.kill()
            server_rc = responder.wait(timeout=5)
            orchestration_error = "responder orchestration timeout"
    except Exception as exc:
        orchestration_error = f"{type(exc).__name__}: {exc}"
        responder.kill()
        server_rc = responder.wait(timeout=5)

    left = network.load_result(initiator_result)
    right = network.load_result(responder_result)
    left_state = read_private_state(initiator_state)
    right_state = read_private_state(responder_state)
    both_ok = bool(left and right and left.get("ok") and right.get("ok"))
    endpoint_match = bool(
        both_ok
        and left["session_sha256"] == right["session_sha256"]
        and left["transcript_sha256"] == right["transcript_sha256"]
        and left.get("next_chain_sha256") == right.get("next_chain_sha256")
    )
    epoch_convergence = bool(
        both_ok
        and left["epochs"]["converged"] == expected_epoch
        and right["epochs"]["converged"] == expected_epoch
    )
    adopted = bool(both_ok and left.get("adopted") and right.get("adopted"))
    candidate_cleanup = bool(
        both_ok
        and left.get("candidate_cleanup_verified")
        and right.get("candidate_cleanup_verified")
    )
    private_state_match = bool(
        left_state and right_state
        and left_state["epoch"] == expected_epoch
        and right_state["epoch"] == expected_epoch
        and left_state["chain_sha256"] == right_state["chain_sha256"]
        and left_state["chain_sha256"] == left.get("next_chain_sha256")
    )
    success = bool(
        endpoint_match and epoch_convergence and adopted
        and candidate_cleanup and private_state_match
    )

    failure_reason = None
    if not success:
        if orchestration_error:
            failure_reason = orchestration_error
        elif left and not left.get("ok"):
            failure_reason = (
                f"initiator:{left.get('error_type')}:{left.get('error')}")
        elif right and not right.get("ok"):
            failure_reason = (
                f"responder:{right.get('error_type')}:{right.get('error')}")
        elif not left or not right:
            failure_reason = "missing endpoint result"
        elif not endpoint_match:
            failure_reason = "session/transcript/chain mismatch"
        elif not epoch_convergence:
            failure_reason = "epoch convergence mismatch"
        elif not adopted:
            failure_reason = "incomplete adoption"
        elif not candidate_cleanup:
            failure_reason = "candidate cleanup failed"
        else:
            failure_reason = "private committed-state mismatch"

    application_bytes = None
    retransmissions = None
    cpu_user_ms = cpu_system_ms = None
    ttsc_ms = left.get("ttsc_ms") if left else None
    if left and right:
        application_bytes = (
            left.get("application_bytes_sent", 0)
            + right.get("application_bytes_sent", 0))
        values = [
            value for value in (
                left.get("tcp", {}).get("total_retrans"),
                right.get("tcp", {}).get("total_retrans"))
            if value is not None
        ]
        retransmissions = sum(values) if values else None
        cpu_user_ms = left.get("cpu_user_ms", 0) + right.get("cpu_user_ms", 0)
        cpu_system_ms = (
            left.get("cpu_system_ms", 0) + right.get("cpu_system_ms", 0))

    row = {
        "schema": "gtr.netns.frequency-cycle-result.v1",
        "run_id": run_id,
        "condition": condition,
        "mission": mission,
        "cycle": cycle,
        "expected_converged_epoch": expected_epoch,
        "success": success,
        "failure_reason": failure_reason,
        "both_endpoints_adopted": adopted,
        "session_transcript_chain_match": endpoint_match,
        "epoch_convergence": epoch_convergence,
        "candidate_cleanup_verified": candidate_cleanup,
        "private_committed_state_match": private_state_match,
        "ttsc_ms": ttsc_ms,
        "application_protocol_bytes": application_bytes,
        "tcp_total_retransmissions": retransmissions,
        "cpu_user_ms": cpu_user_ms,
        "cpu_system_ms": cpu_system_ms,
        "initiator_exit_code": client_rc,
        "responder_exit_code": server_rc,
        "initiator": left,
        "responder": right,
    }
    next_chain = (
        bytes.fromhex(left_state["chain_hex"])
        if success and left_state else None)
    return row, next_chain


def summarize(condition: dict, missions: list[dict], cycles: list[dict]) -> dict:
    successful_missions = [row for row in missions if row["success"]]
    cumulative_ttsc = [
        row["cumulative_ttsc_ms"] for row in successful_missions]
    cumulative_bytes = [
        row["cumulative_application_protocol_bytes"]
        for row in successful_missions]
    cycle_ttsc = [
        row["ttsc_ms"] for row in cycles
        if row["success"] and row["ttsc_ms"] is not None]
    return {
        "condition": condition,
        "missions": len(missions),
        "successful_missions": len(successful_missions),
        "mission_success_rate_percent": (
            100 * len(successful_missions) / len(missions)),
        "executed_cycles": len(cycles),
        "successful_cycles": sum(row["success"] for row in cycles),
        "cycle_success_rate_percent": (
            100 * sum(row["success"] for row in cycles) / len(cycles)),
        "epoch_convergence_failures": sum(
            not row["epoch_convergence"] for row in cycles),
        "session_transcript_chain_mismatches": sum(
            not row["session_transcript_chain_match"] for row in cycles),
        "candidate_cleanup_failures": sum(
            not row["candidate_cleanup_verified"] for row in cycles),
        "private_state_mismatches": sum(
            not row["private_committed_state_match"] for row in cycles),
        "conflicting_adoptions": sum(
            row["both_endpoints_adopted"]
            and not row["session_transcript_chain_match"]
            for row in cycles),
        "cycle_ttsc_ms": describe(cycle_ttsc),
        "mission_cumulative_ttsc_ms": describe(cumulative_ttsc),
        "mission_cumulative_application_bytes": describe(cumulative_bytes),
        "failure_reasons": dict(collections.Counter(
            row["failure_reason"] for row in missions
            if row["failure_reason"])),
    }


def write_summary_csv(path: Path, summaries: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "reconnects_per_mission", "missions", "successful_missions",
            "mission_success_rate_percent", "executed_cycles",
            "successful_cycles", "cycle_success_rate_percent",
            "cycle_ttsc_median_ms", "cycle_ttsc_p95_ms",
            "cumulative_ttsc_median_ms", "cumulative_ttsc_p95_ms",
            "cumulative_bytes_median", "epoch_convergence_failures",
            "key_transcript_chain_mismatches", "candidate_cleanup_failures",
            "private_state_mismatches", "conflicting_adoptions",
        ])
        for row in summaries:
            writer.writerow([
                row["condition"]["reconnects_per_mission"], row["missions"],
                row["successful_missions"], row["mission_success_rate_percent"],
                row["executed_cycles"], row["successful_cycles"],
                row["cycle_success_rate_percent"],
                row["cycle_ttsc_ms"]["median"], row["cycle_ttsc_ms"]["p95"],
                row["mission_cumulative_ttsc_ms"]["median"],
                row["mission_cumulative_ttsc_ms"]["p95"],
                row["mission_cumulative_application_bytes"]["median"],
                row["epoch_convergence_failures"],
                row["session_transcript_chain_mismatches"],
                row["candidate_cleanup_failures"],
                row["private_state_mismatches"],
                row["conflicting_adoptions"],
            ])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=100,
                        help="missions per reconnect-count condition")
    parser.add_argument(
        "--counts", default=",".join(map(str, RECONNECT_COUNTS)),
        help="comma-separated reconnect counts per logical mission")
    parser.add_argument("--rtt-ms", type=float, default=100.0)
    parser.add_argument("--mission-window-seconds", type=int, default=600)
    parser.add_argument("--delta-max", type=int, default=8)
    parser.add_argument("--g-max", type=int, default=8)
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument("--output")
    parser.add_argument("--no-pcap", action="store_true")
    parser.add_argument("--keep-namespaces", action="store_true")
    args = parser.parse_args()
    try:
        reconnect_counts = tuple(
            int(value.strip()) for value in args.counts.split(",")
            if value.strip())
    except ValueError:
        parser.error("counts must be comma-separated positive integers")
    if (args.repetitions < 1 or args.rtt_ms < 0 or not reconnect_counts
            or any(count < 1 for count in reconnect_counts)):
        parser.error("repetitions must be positive and RTT non-negative")
    if args.mission_window_seconds < 1:
        parser.error("mission window must be positive")
    if args.delta_max < 4 or args.g_max < 5:
        parser.error("this campaign requires Delta_max >= 4 and G_max >= 5")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-reconnect-frequency")
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "scratch"
    scratch.mkdir()
    log_path = output / "processes.log"
    cycles_path = output / "cycles.jsonl"
    missions_path = output / "missions.jsonl"

    openssl, openssl_version = network.openssl_environment()
    library_path = os.environ.get("LD_LIBRARY_PATH", "")
    provision_path = network.provision(output, 0, 0)
    provision = json.loads(provision_path.read_text(encoding="utf-8"))
    root_chain = bytes.fromhex(provision["ck0_hex"])
    conditions = [{
        "id": f"reconnects{count}",
        "reconnects_per_mission": count,
        "missions": args.repetitions,
        "mission_window_seconds": args.mission_window_seconds,
        "logical_interval_seconds": args.mission_window_seconds / count,
        "rtt_ms": args.rtt_ms,
        "loss_percent_after_reconnect": 0.0,
        "epoch_increment_i_per_outage": 1,
        "epoch_increment_j_per_outage": 5,
        "delta_per_reconnect": 4,
        "delta_max": args.delta_max,
        "g_max": args.g_max,
    } for count in reconnect_counts]
    paths = {"output": output, "scratch": scratch}
    all_cycles: list[dict] = []
    all_missions: list[dict] = []
    summaries: list[dict] = []

    network.setup_topology()
    try:
        network.apply_netem(0.0, 0.0)
        network.verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            for condition in conditions:
                count = condition["reconnects_per_mission"]
                print(
                    f"[{condition['id']}] fixed-window="
                    f"{args.mission_window_seconds}s reconnects={count} "
                    f"missions={args.repetitions} RTT={args.rtt_ms:g}ms",
                    flush=True)
                capture = pcap = None
                if not args.no_pcap:
                    capture, pcap = network.start_capture(
                        condition, output, log_handle)
                condition_cycles: list[dict] = []
                condition_missions: list[dict] = []
                try:
                    for mission in range(1, args.repetitions + 1):
                        mission_chain = core.hkdf(
                            root_chain,
                            core._canon(("reconnect-frequency-mission",
                                         condition["id"], mission)))
                        base_epoch = 0
                        mission_rows = []
                        failure_reason = None
                        for cycle in range(1, count + 1):
                            # Exercise a real netem down/up transition. The
                            # logical mission interval is not wall-clock replayed.
                            network.apply_netem(100.0, 0.0)
                            time.sleep(0.005)
                            network.apply_netem(0.0, args.rtt_ms)
                            config = cycle_config(
                                provision, scratch, condition["id"], mission,
                                cycle, base_epoch, mission_chain,
                                args.delta_max, args.g_max)
                            expected_epoch = base_epoch + 6
                            row, next_chain = run_cycle(
                                condition, mission, cycle, paths, config,
                                expected_epoch, args.timeout, openssl,
                                library_path, log_handle)
                            condition_cycles.append(row)
                            all_cycles.append(row)
                            mission_rows.append(row)
                            append_jsonl(cycles_path, row)
                            if not row["success"] or next_chain is None:
                                failure_reason = row["failure_reason"]
                                break
                            base_epoch = expected_epoch
                            mission_chain = next_chain

                        success = len(mission_rows) == count and all(
                            row["success"] for row in mission_rows)
                        mission_row = {
                            "schema": "gtr.netns.frequency-mission-result.v1",
                            "condition": condition,
                            "mission": mission,
                            "success": success,
                            "completed_cycles": sum(
                                row["success"] for row in mission_rows),
                            "requested_cycles": count,
                            "final_converged_epoch": (
                                mission_rows[-1]["expected_converged_epoch"]
                                if success else None),
                            "cumulative_ttsc_ms": sum(
                                row["ttsc_ms"] or 0 for row in mission_rows),
                            "cumulative_application_protocol_bytes": sum(
                                row["application_protocol_bytes"] or 0
                                for row in mission_rows),
                            "candidate_cleanup_all_cycles": all(
                                row["candidate_cleanup_verified"]
                                for row in mission_rows),
                            "state_match_all_cycles": all(
                                row["private_committed_state_match"]
                                for row in mission_rows),
                            "failure_reason": failure_reason,
                        }
                        condition_missions.append(mission_row)
                        all_missions.append(mission_row)
                        append_jsonl(missions_path, mission_row)
                        if mission % 20 == 0 or not success:
                            print(
                                f"  mission {mission}/{args.repetitions}: "
                                f"{'ok' if success else failure_reason} "
                                f"cycles={mission_row['completed_cycles']}/{count}",
                                flush=True)
                finally:
                    if capture is not None and pcap is not None:
                        network.stop_capture(capture, pcap)
                summary = summarize(
                    condition, condition_missions, condition_cycles)
                summaries.append(summary)
                write_json(output / "summary.json", summaries)
                write_summary_csv(output / "summary.csv", summaries)
                print(
                    f"  missions={summary['successful_missions']}/"
                    f"{summary['missions']} cycles="
                    f"{summary['successful_cycles']}/"
                    f"{summary['executed_cycles']} cumulative-median="
                    f"{summary['mission_cumulative_ttsc_ms']['median']}ms",
                    flush=True)
    finally:
        if not args.keep_namespaces:
            network.cleanup_topology()

    manifest = {
        "schema": "gtr.netns.reconnect-frequency.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "experiment": "stateful reconnect frequency in a fixed logical mission window",
        "network_topology": (
            "gtr_eval_i(10.10.0.2) -- gtr_eval_r -- "
            "gtr_eval_j(10.20.0.2)"),
        "transport": "TCP through Linux netns and tc netem",
        "timing_scope": (
            "Per-cycle TTSC covers fresh TCP establishment through initiator "
            "M4 verification. Mission cumulative TTSC is the sum of successful "
            "cycle TTSC values and excludes modeled disconnected intervals."),
        "state_scope": (
            "Each successful cycle persists the derived next ratchet chain in "
            "an excluded private scratch file. The next cycle independently "
            "fast-forwards that common state by one and five epochs at i and j."),
        "mission_window": (
            "The 600-second default is a logical fixed observation window used "
            "to define reconnect frequency. It is not replayed in real time."),
        "blackout_transition": (
            "Before every reconnect, both router egress qdiscs are set to 100% "
            "loss and then restored to the configured clean RTT before M1."),
        "cryptography": (
            "OpenSSL ML-KEM-768 for ephemeral, static, and epoch-indexed FS-KEM; "
            "HKDF-SHA-256/HMAC-SHA-256 for ratchet and authentication"),
        "openssl": openssl_version,
        "python": sys.version,
        "platform": platform.platform(),
        "conditions": conditions,
        "expected_total_missions": len(conditions) * args.repetitions,
        "expected_total_cycles": sum(
            condition["reconnects_per_mission"] * args.repetitions
            for condition in conditions),
        "source_sha256": {
            Path(__file__).name: sha256(Path(__file__)),
            network.ENDPOINT.name: sha256(network.ENDPOINT),
            "run_netns_experiment.py": sha256(Path(network.__file__)),
            "reauth_demo.py": sha256(HERE / "reauth_demo.py"),
        },
        "outputs": {
            "summary_json": "summary.json",
            "summary_csv": "summary.csv",
            "cycles_jsonl": "cycles.jsonl",
            "missions_jsonl": "missions.jsonl",
            "pcap_directory": None if args.no_pcap else "pcap",
            "process_log": "processes.log",
        },
        "excluded_secret_paths": [
            "credentials/", "provision.json", "scratch/"],
        "limitations": [
            "The fixed mission window and no-contact intervals are modeled, not replayed in wall-clock time.",
            "The post-reconnect path is clean 100 ms RTT TCP, not a physical DDIL radio.",
            "The campaign tests successful sequential adoption; crash recovery and M4 loss were evaluated separately.",
            "Temporary candidate cleanup is validated in the software endpoint, not in physical RoT non-volatile storage.",
        ],
    }
    write_json(output / "manifest.json", manifest)
    conflicts = sum(
        row["both_endpoints_adopted"]
        and not row["session_transcript_chain_match"]
        for row in all_cycles)
    print(json.dumps({
        "output": str(output),
        "missions": len(all_missions),
        "successful_missions": sum(row["success"] for row in all_missions),
        "cycles": len(all_cycles),
        "successful_cycles": sum(row["success"] for row in all_cycles),
        "conflicting_adoptions": conflicts,
    }, indent=2))
    return 2 if conflicts else 0


if __name__ == "__main__":
    raise SystemExit(main())
