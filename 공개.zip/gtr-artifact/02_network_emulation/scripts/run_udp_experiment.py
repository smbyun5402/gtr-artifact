#!/usr/bin/env python3
"""Run GT-R over UDP with application retransmission under netem loss."""

from __future__ import annotations

import argparse
import collections
import csv
import getpass
import json
import os
import platform
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import run_netns_experiment as network


HERE = Path(__file__).resolve().parent
ENDPOINT = HERE / "gtr_udp_endpoint.py"
PORT = 47200


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    os.replace(temporary, path)


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    rank = (len(values) - 1) * q
    lo = int(rank)
    hi = min(lo + 1, len(values) - 1)
    f = rank - lo
    return values[lo] * (1 - f) + values[hi] * f


def endpoint_command(namespace: str, role: str, address: str, config: Path,
                     result: Path, ready: Path, run_id: str, openssl: str,
                     library_path: str, transport_mode: str,
                     fragment_bytes: int, max_retries: int) -> list[str]:
    args = [
        "sudo", "-n", "ip", "netns", "exec", namespace,
        "runuser", "-u", getpass.getuser(), "--", "env",
        f"OPENSSL={openssl}", f"LD_LIBRARY_PATH={library_path}",
        "OPENSSL_CONF=/dev/null", "PYTHONPYCACHEPREFIX=/tmp/gtr-udp-pycache",
        sys.executable, str(ENDPOINT), "--role", role, "--address", address,
        "--port", str(PORT), "--config", str(config), "--result", str(result),
        "--run-id", run_id, "--base-timeout", "0.15", "--max-timeout", "0.6",
        "--max-retries", str(max_retries), "--overall-timeout", "8.0",
        "--transport-mode", transport_mode,
        "--fragment-bytes", str(fragment_bytes),
    ]
    if role == "responder":
        args.extend(["--ready-file", str(ready)])
    else:
        args.extend(["--peer-address", network.J_ADDR])
    return args


def load(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def run_trial(condition: dict, trial: int, scratch: Path, config: Path,
              openssl: str, library_path: str, log_handle) -> dict:
    run_id = f"{condition['id']}-{trial:04d}"
    ready = scratch / f"{run_id}.ready"
    left_path = scratch / f"{run_id}.initiator.json"
    right_path = scratch / f"{run_id}.responder.json"
    for path in (ready, left_path, right_path):
        path.unlink(missing_ok=True)
    responder = subprocess.Popen(endpoint_command(
        network.NS_J, "responder", network.J_ADDR, config, right_path, ready,
        run_id, openssl, library_path, condition["transport_mode"],
        condition["fragment_bytes"], condition["max_retries"]),
        stdout=log_handle, stderr=log_handle,
        text=True)
    initiator = None
    orchestration_error = None
    try:
        deadline = time.monotonic() + 5
        while not ready.exists():
            if responder.poll() is not None:
                raise RuntimeError("responder exited before ready")
            if time.monotonic() >= deadline:
                raise TimeoutError("responder readiness timeout")
            time.sleep(0.01)
        initiator = subprocess.Popen(endpoint_command(
            network.NS_I, "initiator", network.I_ADDR, config, left_path, ready,
            run_id, openssl, library_path, condition["transport_mode"],
            condition["fragment_bytes"], condition["max_retries"]),
            stdout=log_handle, stderr=log_handle,
            text=True)
        initiator.wait(timeout=25)
        responder.wait(timeout=25)
    except Exception as exc:
        orchestration_error = f"{type(exc).__name__}: {exc}"
        for process in (initiator, responder):
            if process is not None and process.poll() is None:
                process.kill()
            if process is not None:
                process.wait(timeout=5)
    left = load(left_path)
    right = load(right_path)
    matching = bool(
        left and right and left.get("ok") and right.get("ok")
        and left["session_sha256"] == right["session_sha256"]
        and left["transcript_sha256"] == right["transcript_sha256"]
        and left["converged_epoch"] == right["converged_epoch"])
    success = bool(matching and left.get("adopted") and right.get("adopted"))
    reason = orchestration_error
    if not success and reason is None:
        reason = ((left or {}).get("error") or (right or {}).get("error")
                  or "state mismatch")
    return {
        "schema": "gtr.udp.trial.v1", "condition": condition,
        "trial": trial, "success": success, "failure_reason": reason,
        "ttsc_ms": (left or {}).get("ttsc_ms"),
        "completion_ms": (left or {}).get("completion_ms"),
        "application_retransmissions": (left or {}).get(
            "application_retransmissions"),
        "fragment_retransmissions": sum(
            (endpoint or {}).get("fragment_retransmissions", 0)
            for endpoint in (left, right)),
        "fragments_sent": sum(
            (endpoint or {}).get("fragments_sent", 0)
            for endpoint in (left, right)),
        "max_datagram_bytes": max(
            [(endpoint or {}).get("max_datagram_bytes", 0)
             for endpoint in (left, right)]),
        "matching_state": matching, "initiator": left, "responder": right,
    }


def summarize(condition: dict, rows: list[dict]) -> dict:
    success = [row for row in rows if row["success"]]
    latency = [row["ttsc_ms"] for row in success]
    retries = [row["application_retransmissions"] for row in rows
               if row["application_retransmissions"] is not None]
    return {
        "condition": condition, "trials": len(rows), "successes": len(success),
        "success_rate_percent": 100 * len(success) / len(rows),
        "conflicting_adoptions": sum(
            bool((row.get("initiator") or {}).get("adopted"))
            and bool((row.get("responder") or {}).get("adopted"))
            and not row["matching_state"] for row in rows),
        "ttsc_ms": {
            "median": statistics.median(latency) if latency else None,
            "p95": percentile(latency, 0.95),
            "max": max(latency) if latency else None,
        },
        "application_retransmissions": {
            "sum": sum(retries),
            "median": statistics.median(retries) if retries else None,
            "max": max(retries) if retries else None,
        },
        "fragment_retransmissions_sum": sum(
            row.get("fragment_retransmissions") or 0 for row in rows),
        "fragments_sent_sum": sum(
            row.get("fragments_sent") or 0 for row in rows),
        "max_datagram_bytes": max(
            [row.get("max_datagram_bytes") or 0 for row in rows], default=0),
        "failure_reasons": dict(collections.Counter(
            row["failure_reason"] for row in rows if row["failure_reason"])),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=100)
    parser.add_argument("--rtt-ms", type=float, default=100.0)
    parser.add_argument("--losses", default="0,5,10,20,30,40")
    parser.add_argument("--modes", default="raw,selective-fragment")
    parser.add_argument("--fragment-bytes", type=int, default=900)
    parser.add_argument("--max-retries", type=int, default=5)
    parser.add_argument("--output")
    args = parser.parse_args()
    losses = [float(item) for item in args.losses.split(",")]
    modes = [item.strip() for item in args.modes.split(",") if item.strip()]
    invalid_modes = set(modes) - {"raw", "selective-fragment"}
    if invalid_modes:
        parser.error(f"unsupported modes: {sorted(invalid_modes)}")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-udp-loss")
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "scratch"
    scratch.mkdir()
    log_path = output / "processes.log"
    openssl, version = network.openssl_environment()
    library_path = os.environ.get("LD_LIBRARY_PATH", "")
    config = network.provision(output, 0, 5)
    summaries: list[dict] = []
    network.setup_topology()
    try:
        network.apply_netem(0, args.rtt_ms, 0)
        network.verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            for mode in modes:
                for loss in losses:
                    condition = {
                        "id": f"udp-{mode}-loss{loss:g}-rtt{args.rtt_ms:g}",
                        "transport_mode": mode,
                        "loss_percent": loss, "rtt_ms": args.rtt_ms,
                        "jitter_ms": 0.0, "repetitions": args.repetitions,
                        "fragment_bytes": args.fragment_bytes,
                        "max_retries": args.max_retries,
                    }
                    network.apply_netem(loss, args.rtt_ms, 0)
                    rows: list[dict] = []
                    print(f"[{condition['id']}] n={args.repetitions}",
                          flush=True)
                    for trial in range(1, args.repetitions + 1):
                        row = run_trial(
                            condition, trial, scratch, config, openssl,
                            library_path, log_handle)
                        rows.append(row)
                        with (output / "trials.jsonl").open(
                                "a", encoding="utf-8") as handle:
                            handle.write(json.dumps(row, sort_keys=True) + "\n")
                        if trial % 10 == 0 or not row["success"]:
                            print(
                                f"  trial {trial}/{args.repetitions}: "
                                f"{'ok' if row['success'] else row['failure_reason']}",
                                flush=True)
                    summary = summarize(condition, rows)
                    summaries.append(summary)
                    write_json(output / "summary.json", summaries)
                    print(
                        f"  success={summary['success_rate_percent']:.1f}% "
                        f"median={summary['ttsc_ms']['median']}ms", flush=True)
    finally:
        network.apply_netem(0, args.rtt_ms, 0)
        network.cleanup_topology()

    with (output / "summary.csv").open("w", encoding="utf-8", newline="") as h:
        writer = csv.writer(h)
        writer.writerow(["condition", "transport_mode", "loss_percent", "rtt_ms", "trials",
                         "successes", "success_rate_percent", "median_ms",
                         "p95_ms", "retransmissions_sum",
                         "fragment_retransmissions_sum", "fragments_sent_sum",
                         "max_datagram_bytes", "conflicting_adoptions"])
        for row in summaries:
            writer.writerow([row["condition"]["id"],
                             row["condition"]["transport_mode"],
                             row["condition"]["loss_percent"],
                             row["condition"]["rtt_ms"], row["trials"],
                             row["successes"], row["success_rate_percent"],
                             row["ttsc_ms"]["median"], row["ttsc_ms"]["p95"],
                             row["application_retransmissions"]["sum"],
                             row["fragment_retransmissions_sum"],
                             row["fragments_sent_sum"],
                             row["max_datagram_bytes"],
                             row["conflicting_adoptions"]])
    write_json(output / "manifest.json", {
        "schema": "gtr.udp.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "transport": (
            "paired comparison of raw whole-message UDP retransmission and "
            "application-layer fragmentation with per-fragment acknowledgements; "
            "on timeout the selective mode retransmits only unacknowledged "
            "fragments"),
        "fragment_payload_bytes": args.fragment_bytes,
        "initial_plus_retries": args.max_retries + 1,
        "network": f"Linux namespaces; {args.rtt_ms} ms configured RTT; independent netem loss on router egress",
        "cryptography": "OpenSSL 4.0.2 ML-KEM-768 plus HKDF-SHA-256/HMAC-SHA-256",
        "openssl": version, "python": sys.version,
        "platform": platform.platform(),
        "conditions": [row["condition"] for row in summaries],
    })
    print(json.dumps({"output": str(output), "conditions": len(summaries)},
                     indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
