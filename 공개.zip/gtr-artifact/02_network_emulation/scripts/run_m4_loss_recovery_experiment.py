#!/usr/bin/env python3
"""Drop every M4 attempt, verify no adoption, then start a fresh reconnect."""

from __future__ import annotations

import argparse
import json
import os
import platform
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

import run_blackout_experiment as blackout
import run_netns_experiment as network


HERE = Path(__file__).resolve().parent


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    os.replace(temporary, path)


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    rank = (len(values) - 1) * q
    lo = int(rank)
    hi = min(lo + 1, len(values) - 1)
    f = rank - lo
    return values[lo] * (1 - f) + values[hi] * f


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=100)
    parser.add_argument("--rtt-ms", type=float, default=10.0)
    parser.add_argument("--output")
    args = parser.parse_args()
    if args.repetitions < 1:
        parser.error("--repetitions must be positive")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-m4-loss-recovery")
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "scratch"
    scratch.mkdir()
    log_path = output / "processes.log"

    openssl, version = network.openssl_environment()
    library_path = os.environ.get("LD_LIBRARY_PATH", "")
    config = network.provision(output, 0, 5)
    rows: list[dict] = []
    network.setup_topology()
    try:
        network.apply_netem(0, args.rtt_ms, 0)
        network.verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            for trial in range(1, args.repetitions + 1):
                network.apply_netem(0, args.rtt_ms, 0)
                loss_condition = {
                    "id": "permanent-m4-loss",
                    "trigger": "before_m4",
                    "blackout_seconds": 0.75,
                    "rtt_ms": args.rtt_ms,
                    "loss_percent": 100.0,
                    "retry_base_timeout": 0.02,
                    "max_retries": 3,
                    "event_wait_timeout": 0.80,
                }
                failed = blackout.run_trial(
                    loss_condition, trial, {"scratch": scratch}, config,
                    openssl, library_path, log_handle)
                no_adoption = bool(
                    not (failed.get("initiator") or {}).get("adopted", False)
                    and not (failed.get("responder") or {}).get("adopted", False))

                network.apply_netem(0, args.rtt_ms, 0)
                recovery_condition = {
                    "id": "fresh-after-m4-loss",
                    "loss_percent": 0.0,
                    "rtt_ms": args.rtt_ms,
                    "jitter_ms": 0.0,
                }
                recovered = network.run_trial(
                    recovery_condition, trial, {"scratch": scratch}, config,
                    5.0, openssl, library_path, log_handle)
                row = {
                    "schema": "gtr.m4-loss-recovery.trial.v1",
                    "trial": trial,
                    "all_m4_attempts_lost": not failed["success"],
                    "no_endpoint_adopted_failed_attempt": no_adoption,
                    "fresh_reconnect_success": recovered["success"],
                    "fresh_reconnect_ttsc_ms": recovered.get("ttsc_ms"),
                    "fresh_reconnect_matching_state": recovered.get(
                        "session_transcript_epoch_match", False),
                    "failed_attempt": failed,
                    "recovery_attempt": recovered,
                }
                rows.append(row)
                with (output / "trials.jsonl").open(
                        "a", encoding="utf-8") as handle:
                    handle.write(json.dumps(row, sort_keys=True) + "\n")
                if trial % 10 == 0 or not (
                        no_adoption and recovered["success"]):
                    print(f"trial {trial}/{args.repetitions}: "
                          f"no-adopt={no_adoption} recovery={recovered['success']}",
                          flush=True)
    finally:
        network.apply_netem(0, args.rtt_ms, 0)
        network.cleanup_topology()

    latencies = [row["fresh_reconnect_ttsc_ms"] for row in rows
                 if row["fresh_reconnect_success"]]
    summary = {
        "schema": "gtr.m4-loss-recovery.summary.v1",
        "trials": len(rows),
        "failed_attempts_with_all_m4_lost": sum(
            row["all_m4_attempts_lost"] for row in rows),
        "failed_attempts_with_zero_adoptions": sum(
            row["no_endpoint_adopted_failed_attempt"] for row in rows),
        "fresh_reconnect_successes": sum(
            row["fresh_reconnect_success"] for row in rows),
        "fresh_reconnect_state_matches": sum(
            row["fresh_reconnect_matching_state"] for row in rows),
        "fresh_reconnect_ttsc_ms": {
            "median": statistics.median(latencies) if latencies else None,
            "p95": percentile(latencies, 0.95),
            "max": max(latencies) if latencies else None,
        },
    }
    write_json(output / "summary.json", summary)
    write_json(output / "manifest.json", {
        "schema": "gtr.m4-loss-recovery.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "force loss of every M4 delivery through retry exhaustion, verify that neither endpoint promotes the candidate, restore the link, and run a fresh GT-R execution from the prior state",
        "network": f"Linux namespaces; {args.rtt_ms} ms RTT; 100% loss begins immediately before M4 for 0.75 s",
        "retry_policy": "initial delivery plus three retries with 0.02, 0.04, 0.08, and 0.16 s timeouts",
        "adoption_policy": "responder commits after authenticated CONF_I; initiator commits after authenticated ACK_R; M4 verification alone never adopts",
        "openssl": version,
        "python": sys.version,
        "platform": platform.platform(),
    })
    print(json.dumps(summary, indent=2))
    return 0 if (
        summary["failed_attempts_with_zero_adoptions"] == len(rows)
        and summary["fresh_reconnect_successes"] == len(rows)
        and summary["fresh_reconnect_state_matches"] == len(rows)) else 1


if __name__ == "__main__":
    raise SystemExit(main())
