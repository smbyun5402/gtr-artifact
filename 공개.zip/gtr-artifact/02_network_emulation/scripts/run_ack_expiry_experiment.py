#!/usr/bin/env python3
"""Exercise permanent ACK_R loss, candidate expiry, and fail-closed R2 policy.

The harness executes the OpenSSL-backed GT-R key schedule through CONF_I,
drops every authenticated ACK_R delivery, persists the initiator's pending
candidate and the responder's completion record, advances a simulated
monotonic clock beyond the configured retention bound, and verifies that a
stale acknowledgement cannot promote the expired initiator candidate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import secrets
import statistics
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import gtr_blackout_endpoint as protocol
import gtr_net_endpoint as base
import reauth_demo as core
import run_netns_experiment as network


HERE = Path(__file__).resolve().parent


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    rank = (len(ordered) - 1) * quantile
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = rank - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def execute_handshake(config: dict, run_id: str, work: Path) -> tuple[dict, dict]:
    args = SimpleNamespace(run_id=run_id)
    core.WORK = str(work)
    core.SEAL_PATH = str(work / "rot_seal.json")
    initiator = protocol.prepare_initiator(args, config, work)
    responder = protocol.build_responder_candidate(
        initiator["m1"], config, work)
    protocol.accept_m2(initiator, responder["m2"], config)
    protocol.accept_m3(responder, initiator["m3"], config)

    expected_gamma = core.mac(
        initiator["confirm"], core.H("confirm", initiator["transcript"]))
    if not secrets.compare_digest(
            base.unb64(responder["m4"]["gamma_j"]), expected_gamma):
        raise RuntimeError("M4 confirmation mismatch")
    if not secrets.compare_digest(initiator["session"], responder["session"]):
        raise RuntimeError("session mismatch before adoption")
    return initiator, responder


def run_trial(config: dict, trial: int, output: Path, retention_ms: int,
              retry_waits_ms: list[int]) -> dict:
    run_id = f"ack-expiry-{trial:05d}"
    with tempfile.TemporaryDirectory(prefix="gtr-ack-expiry-") as temporary:
        work = Path(temporary)
        initiator, responder = execute_handshake(config, run_id, work)
        sid = initiator["sid"]
        epoch = initiator["e_prime"]
        transcript_sha = hashlib.sha256(initiator["transcript"]).hexdigest()
        session_sha = hashlib.sha256(initiator["session"]).hexdigest()

        # M4 has been authenticated.  The initiator persists a version-bound
        # pending candidate but retains its old active epoch.
        now_ms = 0
        initiator_state = {
            "active_epoch": config["epoch_i"],
            "pending": {
                "sid": sid, "epoch": epoch, "transcript_sha256": transcript_sha,
                "session_sha256": session_sha, "expires_ms": retention_ms,
            },
            "outcome": "PENDING_ACK_R",
        }
        responder_state = {
            "active_epoch": config["epoch_j"], "completion_record": None,
            "commit_count": 0,
        }
        initiator_path = work / "initiator-state.json"
        responder_path = work / "responder-state.json"
        write_json(initiator_path, initiator_state)
        write_json(responder_path, responder_state)

        conf_i = core.mac(
            initiator["session"],
            core.H("adopt-i", sid, epoch, initiator["transcript"]))
        expected_conf_i = core.mac(
            responder["session"],
            core.H("adopt-i", responder["sid"], responder["e_prime"],
                   responder["transcript"]))
        if not secrets.compare_digest(conf_i, expected_conf_i):
            raise RuntimeError("CONF_I authentication mismatch")

        # The responder compare-and-commits exactly once, then creates the
        # acknowledgement that the experiment deliberately drops.
        responder_state["active_epoch"] = epoch
        responder_state["commit_count"] += 1
        responder_state["completion_record"] = {
            "sid": sid, "epoch": epoch,
            "transcript_sha256": transcript_sha,
            "session_sha256": session_sha, "expires_ms": retention_ms,
        }
        ack_r = core.mac(
            responder["session"],
            core.H("adopt-r", sid, epoch, responder["transcript"]))
        write_json(responder_path, responder_state)

        dropped_ack_count = 0
        for wait_ms in retry_waits_ms:
            now_ms += wait_ms
            dropped_ack_count += 1
            # A replayed CONF_I matches the completion record and therefore
            # reuses ACK_R without a second responder commit.
            reloaded_r = json.loads(responder_path.read_text(encoding="utf-8"))
            if reloaded_r["completion_record"]["session_sha256"] != session_sha:
                raise RuntimeError("completion record changed across retry")
            if reloaded_r["commit_count"] != 1:
                raise RuntimeError("duplicate responder commit")

        retry_exhausted_ms = now_ms
        now_ms = max(now_ms, retention_ms + 1)
        reloaded_i = json.loads(initiator_path.read_text(encoding="utf-8"))
        reloaded_r = json.loads(responder_path.read_text(encoding="utf-8"))
        if now_ms > reloaded_i["pending"]["expires_ms"]:
            reloaded_i["pending"] = None
            reloaded_i["outcome"] = "R2_REQUIRED"
        if (reloaded_r["completion_record"] is not None
                and now_ms > reloaded_r["completion_record"]["expires_ms"]):
            reloaded_r["completion_record"] = None
        write_json(initiator_path, reloaded_i)
        write_json(responder_path, reloaded_r)

        # A delayed, cryptographically valid ACK_R is not sufficient after the
        # version-bound candidate has expired: no candidate exists to promote.
        expected_ack = core.mac(
            initiator["session"],
            core.H("adopt-r", sid, epoch, initiator["transcript"]))
        delayed_ack_authentic = secrets.compare_digest(ack_r, expected_ack)
        delayed_ack_promoted = bool(
            delayed_ack_authentic and reloaded_i["pending"] is not None)
        r2_required = bool(
            reloaded_i["outcome"] == "R2_REQUIRED"
            and reloaded_i["active_epoch"] != reloaded_r["active_epoch"])
        success = bool(
            responder_state["commit_count"] == 1
            and reloaded_i["active_epoch"] == config["epoch_i"]
            and reloaded_r["active_epoch"] == epoch
            and reloaded_i["pending"] is None
            and reloaded_r["completion_record"] is None
            and delayed_ack_authentic and not delayed_ack_promoted
            and r2_required)
        return {
            "schema": "gtr.ack-expiry.trial.v1", "trial": trial,
            "success": success, "dropped_ack_r": dropped_ack_count,
            "retry_exhausted_ms": retry_exhausted_ms,
            "retention_ms": retention_ms, "expiry_observed_ms": now_ms,
            "responder_commit_count": responder_state["commit_count"],
            "initiator_active_epoch": reloaded_i["active_epoch"],
            "responder_active_epoch": reloaded_r["active_epoch"],
            "pending_candidate_after_expiry": reloaded_i["pending"] is not None,
            "completion_record_after_expiry":
                reloaded_r["completion_record"] is not None,
            "delayed_ack_authentic": delayed_ack_authentic,
            "delayed_ack_promoted": delayed_ack_promoted,
            "policy_outcome": reloaded_i["outcome"],
            "r2_required": r2_required,
            "session_sha256": session_sha,
            "transcript_sha256": transcript_sha,
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=1000)
    parser.add_argument("--retention-ms", type=int, default=5000)
    parser.add_argument("--retry-waits-ms", default="250,500,1000,2000")
    parser.add_argument("--output")
    args = parser.parse_args()
    if args.repetitions < 1 or args.retention_ms < 1:
        parser.error("repetitions and retention must be positive")
    waits = [int(item) for item in args.retry_waits_ms.split(",")]
    if any(item < 1 for item in waits):
        parser.error("retry waits must be positive")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-ack-expiry")
    output.mkdir(parents=True, exist_ok=False)
    openssl, version = network.openssl_environment()
    config_path = network.provision(output, 0, 5)
    config = json.loads(config_path.read_text(encoding="utf-8"))
    rows = []
    trials_path = output / "trials.jsonl"
    for trial in range(1, args.repetitions + 1):
        row = run_trial(config, trial, output, args.retention_ms, waits)
        rows.append(row)
        with trials_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
        if trial % 100 == 0 or not row["success"]:
            print(f"trial {trial}/{args.repetitions}: "
                  f"{'ok' if row['success'] else 'FAILED'}", flush=True)

    successes = sum(row["success"] for row in rows)
    retry_exhaustion = [row["retry_exhausted_ms"] for row in rows]
    summary = {
        "schema": "gtr.ack-expiry.summary.v1",
        "trials": len(rows), "successes": successes,
        "success_rate_percent": 100 * successes / len(rows),
        "single_responder_commit": sum(
            row["responder_commit_count"] == 1 for row in rows),
        "expired_candidates_rejected": sum(
            not row["delayed_ack_promoted"] for row in rows),
        "r2_required": sum(row["r2_required"] for row in rows),
        "retry_exhausted_ms": {
            "median": statistics.median(retry_exhaustion),
            "p95": percentile(retry_exhaustion, 0.95),
        },
    }
    write_json(output / "summary.json", summary)
    write_json(output / "manifest.json", {
        "schema": "gtr.ack-expiry.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": (
            "drop every protected ACK_R through retry exhaustion; expire the "
            "initiator pending candidate and responder completion record; "
            "verify a delayed authentic ACK_R cannot promote and policy returns "
            "R2_REQUIRED"),
        "retention_ms": args.retention_ms,
        "retry_waits_ms": waits,
        "cryptography": "OpenSSL-backed ML-KEM-768 GT-R key schedule and HMAC adoption tags",
        "openssl": version, "python": platform.python_version(),
        "platform": platform.platform(),
    })
    print(json.dumps({"output": str(output), **summary}, indent=2))
    return 0 if successes == len(rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
