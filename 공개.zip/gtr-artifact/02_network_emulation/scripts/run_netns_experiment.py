#!/usr/bin/env python3
"""Run the real GT-R M1--M4 flow through Linux netns and tc/netem."""

from __future__ import annotations

import argparse
import collections
import csv
import getpass
import hashlib
import json
import os
import platform
import secrets
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import reauth_demo as core


HERE = Path(__file__).resolve().parent
ENDPOINT = HERE / "gtr_net_endpoint.py"
NS_I = "gtr_eval_i"
NS_R = "gtr_eval_r"
NS_J = "gtr_eval_j"
I_ADDR = "10.10.0.2"
J_ADDR = "10.20.0.2"
PORT = 47000


def command(args: list[str], *, check: bool = True,
            capture: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(
        args,
        check=check,
        text=True,
        capture_output=capture,
    )


def root_command(args: list[str], *, check: bool = True,
                 capture: bool = False) -> subprocess.CompletedProcess:
    return command(["sudo", "-n"] + args, check=check, capture=capture)


def namespace_exists(name: str) -> bool:
    result = command(["ip", "netns", "list"], capture=True)
    return any(line.split()[0] == name for line in result.stdout.splitlines())


def cleanup_topology() -> None:
    for namespace in (NS_I, NS_R, NS_J):
        if namespace_exists(namespace):
            root_command(["ip", "netns", "delete", namespace], check=False)


def setup_topology() -> None:
    cleanup_topology()
    for namespace in (NS_I, NS_R, NS_J):
        root_command(["ip", "netns", "add", namespace])

    root_command(["ip", "link", "add", "vi0", "type", "veth",
                  "peer", "name", "vri0"])
    root_command(["ip", "link", "add", "vj0", "type", "veth",
                  "peer", "name", "vrj0"])
    root_command(["ip", "link", "set", "vi0", "netns", NS_I])
    root_command(["ip", "link", "set", "vri0", "netns", NS_R])
    root_command(["ip", "link", "set", "vj0", "netns", NS_J])
    root_command(["ip", "link", "set", "vrj0", "netns", NS_R])

    for namespace in (NS_I, NS_R, NS_J):
        root_command(["ip", "-n", namespace, "link", "set", "lo", "up"])

    root_command(["ip", "-n", NS_I, "addr", "add", "10.10.0.2/24",
                  "dev", "vi0"])
    root_command(["ip", "-n", NS_R, "addr", "add", "10.10.0.1/24",
                  "dev", "vri0"])
    root_command(["ip", "-n", NS_J, "addr", "add", "10.20.0.2/24",
                  "dev", "vj0"])
    root_command(["ip", "-n", NS_R, "addr", "add", "10.20.0.1/24",
                  "dev", "vrj0"])

    for namespace, device in (
        (NS_I, "vi0"), (NS_R, "vri0"), (NS_J, "vj0"), (NS_R, "vrj0")
    ):
        root_command(["ip", "-n", namespace, "link", "set", device, "up"])

    root_command(["ip", "-n", NS_I, "route", "add", "10.20.0.0/24",
                  "via", "10.10.0.1"])
    root_command(["ip", "-n", NS_J, "route", "add", "10.10.0.0/24",
                  "via", "10.20.0.1"])
    root_command(["ip", "netns", "exec", NS_R, "sysctl", "-q", "-w",
                  "net.ipv4.ip_forward=1"])


def apply_netem(loss_percent: float, rtt_ms: float,
                jitter_ms: float = 0.0) -> None:
    one_way = rtt_ms / 2.0
    for device in ("vri0", "vrj0"):
        netem = [
            "ip", "netns", "exec", NS_R,
            "tc", "qdisc", "replace", "dev", device, "root", "netem",
            "delay", f"{one_way:.3f}ms",
        ]
        if jitter_ms > 0:
            netem.extend([f"{jitter_ms / 2.0:.3f}ms", "distribution", "normal"])
        netem.extend(["loss", f"{loss_percent:.3f}%"])
        root_command(netem)


def verify_connectivity() -> None:
    root_command([
        "ip", "netns", "exec", NS_I,
        "ping", "-c", "1", "-W", "2", J_ADDR,
    ])


def openssl_environment() -> tuple[str, str]:
    openssl = os.environ.get("OPENSSL", "openssl")
    library_path = os.environ.get("LD_LIBRARY_PATH", "")
    available, version = core.openssl_ok()
    if not available:
        raise RuntimeError(f"OpenSSL is not runnable: {openssl}")
    algorithms = command([openssl, "list", "-kem-algorithms"], capture=True)
    if "ML-KEM-768" not in algorithms.stdout:
        raise RuntimeError("the selected OpenSSL build lacks ML-KEM-768")
    return openssl, version


def provision(output: Path, epoch_i: int, epoch_j: int) -> Path:
    credentials = output / "credentials"
    credentials.mkdir(parents=True, exist_ok=True)
    core.WORK = str(credentials)
    core.SEAL_PATH = str(credentials / "rot_seal.json")
    i_static_sk, i_static_pk = core.mlkem_keygen("initiator-static")
    j_static_sk, j_static_pk = core.mlkem_keygen("responder-static")
    i_fs_sk, i_fs_pk = core.mlkem_keygen("initiator-fs-epoch")
    j_fs_sk, j_fs_pk = core.mlkem_keygen("responder-fs-epoch")
    ck0 = secrets.token_bytes(32)
    ck_i, _ = core.chain_fast_forward(ck0, 0, epoch_i)
    ck_j, _ = core.chain_fast_forward(ck0, 0, epoch_j)
    config = {
        "schema": "gtr.netns.provision.v1",
        "sid": "gtr-netns-evaluation",
        "ck0_hex": ck0.hex(),
        "ck_i_hex": ck_i.hex(),
        "ck_j_hex": ck_j.hex(),
        "epoch_i": epoch_i,
        "epoch_j": epoch_j,
        "converged_epoch": max(epoch_i, epoch_j) + 1,
        "initiator_static_sk": str(Path(i_static_sk).resolve()),
        "initiator_static_pk": str(Path(i_static_pk).resolve()),
        "responder_static_sk": str(Path(j_static_sk).resolve()),
        "responder_static_pk": str(Path(j_static_pk).resolve()),
        "initiator_fs_sk": str(Path(i_fs_sk).resolve()),
        "initiator_fs_pk": str(Path(i_fs_pk).resolve()),
        "responder_fs_sk": str(Path(j_fs_sk).resolve()),
        "responder_fs_pk": str(Path(j_fs_pk).resolve()),
        "fs_kem_mode": "mandatory for this network experiment",
        "note": "The target-epoch FS-KEM keys are provisioned before timing.",
    }
    path = output / "provision.json"
    write_json(path, config)
    return path


def endpoint_command(namespace: str, role: str, address: str,
                     config: Path, result: Path, ready: Path,
                     run_id: str, timeout: float,
                     openssl: str, library_path: str) -> list[str]:
    username = getpass.getuser()
    args = [
        "sudo", "-n", "ip", "netns", "exec", namespace,
        "runuser", "-u", username, "--",
        "env", f"OPENSSL={openssl}",
        f"LD_LIBRARY_PATH={library_path}",
        "PYTHONPYCACHEPREFIX=/tmp/gtr-net-pycache",
        sys.executable, str(ENDPOINT),
        "--role", role,
        "--address", address,
        "--port", str(PORT),
        "--config", str(config),
        "--result", str(result),
        "--run-id", run_id,
        "--timeout", str(timeout),
    ]
    if role == "responder":
        args.extend(["--ready-file", str(ready)])
    return args


def wait_for_ready(path: Path, process: subprocess.Popen,
                   timeout: float = 10.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if path.exists():
            return
        if process.poll() is not None:
            raise RuntimeError(f"responder exited before listen (rc={process.returncode})")
        time.sleep(0.02)
    raise TimeoutError("responder readiness timeout")


def load_result(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def run_trial(condition: dict, trial_number: int, paths: dict,
              config: Path, timeout: float, openssl: str,
              library_path: str, log_handle) -> dict:
    run_id = f"{condition['id']}-{trial_number:04d}"
    ready = paths["scratch"] / f"{run_id}.ready"
    initiator_result = paths["scratch"] / f"{run_id}.initiator.json"
    responder_result = paths["scratch"] / f"{run_id}.responder.json"
    for path in (ready, initiator_result, responder_result):
        path.unlink(missing_ok=True)

    responder_cmd = endpoint_command(
        NS_J, "responder", J_ADDR, config, responder_result, ready,
        run_id, timeout, openssl, library_path)
    initiator_cmd = endpoint_command(
        NS_I, "initiator", J_ADDR, config, initiator_result, ready,
        run_id, timeout, openssl, library_path)
    responder = subprocess.Popen(
        responder_cmd, stdout=log_handle, stderr=log_handle, text=True)
    client_rc = server_rc = None
    orchestration_error = None
    measurement_started_ns = None
    try:
        wait_for_ready(ready, responder)
        measurement_started_ns = time.monotonic_ns()
        client = subprocess.Popen(
            initiator_cmd, stdout=log_handle, stderr=log_handle, text=True)
        try:
            client_rc = client.wait(timeout=timeout + 10)
        except subprocess.TimeoutExpired:
            client.kill()
            client_rc = client.wait(timeout=5)
            orchestration_error = "initiator orchestration timeout"
        try:
            server_rc = responder.wait(timeout=timeout + 10)
        except subprocess.TimeoutExpired:
            responder.kill()
            server_rc = responder.wait(timeout=5)
            orchestration_error = "responder orchestration timeout"
    except Exception as exc:
        orchestration_error = f"{type(exc).__name__}: {exc}"
        responder.kill()
        server_rc = responder.wait(timeout=5)

    left = load_result(initiator_result)
    right = load_result(responder_result)
    both_ok = bool(left and right and left.get("ok") and right.get("ok"))
    matching = bool(
        both_ok
        and left["session_sha256"] == right["session_sha256"]
        and left["transcript_sha256"] == right["transcript_sha256"]
        and left["epochs"]["converged"] == right["epochs"]["converged"]
    )
    adopted = bool(both_ok and left.get("adopted") and right.get("adopted"))
    success = both_ok and matching and adopted

    failure_reason = None
    if not success:
        if orchestration_error:
            failure_reason = orchestration_error
        elif left and not left.get("ok"):
            failure_reason = f"initiator:{left.get('error_type')}:{left.get('error')}"
        elif right and not right.get("ok"):
            failure_reason = f"responder:{right.get('error_type')}:{right.get('error')}"
        elif not left or not right:
            failure_reason = "missing endpoint result"
        elif not matching:
            failure_reason = "key/transcript/epoch mismatch"
        else:
            failure_reason = "incomplete adoption"

    retransmissions = None
    application_bytes = None
    ttsc_ms = None
    initiator_key_confirmation_ms = None
    cpu_user_ms = cpu_system_ms = None
    if left and right:
        retrans_values = [
            value for value in (
                left.get("tcp", {}).get("total_retrans"),
                right.get("tcp", {}).get("total_retrans"),
            ) if value is not None
        ]
        retransmissions = sum(retrans_values) if retrans_values else None
        application_bytes = (
            left.get("application_bytes_sent", 0)
            + right.get("application_bytes_sent", 0)
        )
        cpu_user_ms = left.get("cpu_user_ms", 0) + right.get("cpu_user_ms", 0)
        cpu_system_ms = (
            left.get("cpu_system_ms", 0) + right.get("cpu_system_ms", 0)
        )
    if left and measurement_started_ns is not None:
        key_ns = left.get("key_confirmed_monotonic_ns")
        left_adopted_ns = left.get("adopted_monotonic_ns")
        right_adopted_ns = right.get("adopted_monotonic_ns") if right else None
        if key_ns is not None:
            initiator_key_confirmation_ms = (
                key_ns - measurement_started_ns) / 1_000_000
        if left_adopted_ns is not None and right_adopted_ns is not None:
            ttsc_ms = (
                max(left_adopted_ns, right_adopted_ns)
                - measurement_started_ns
            ) / 1_000_000

    return {
        "schema": "gtr.netns.trial.v1",
        "run_id": run_id,
        "condition": condition,
        "trial": trial_number,
        "success": success,
        "failure_reason": failure_reason,
        "both_endpoints_adopted": adopted,
        "session_transcript_epoch_match": matching,
        "ttsc_ms": ttsc_ms,
        "initiator_key_confirmation_ms": initiator_key_confirmation_ms,
        "mutual_adoption_ttsc_ms": ttsc_ms,
        "application_protocol_bytes": application_bytes,
        "tcp_total_retransmissions": retransmissions,
        "cpu_user_ms": cpu_user_ms,
        "cpu_system_ms": cpu_system_ms,
        "initiator_exit_code": client_rc,
        "responder_exit_code": server_rc,
        "initiator": left,
        "responder": right,
    }


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * quantile
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = rank - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def summarize(condition: dict, rows: list[dict]) -> dict:
    successful = [row for row in rows if row["success"]]
    latencies = [
        row["ttsc_ms"] for row in successful if row["ttsc_ms"] is not None
    ]
    key_confirmation_latencies = [
        row["initiator_key_confirmation_ms"] for row in successful
        if row.get("initiator_key_confirmation_ms") is not None
    ]
    retransmissions = [
        row["tcp_total_retransmissions"] for row in rows
        if row["tcp_total_retransmissions"] is not None
    ]
    bytes_sent = [
        row["application_protocol_bytes"] for row in successful
        if row["application_protocol_bytes"] is not None
    ]
    failures = collections.Counter(
        row["failure_reason"] for row in rows if row["failure_reason"])
    return {
        "condition": condition,
        "trials": len(rows),
        "successes": len(successful),
        "success_rate_percent": 100 * len(successful) / len(rows),
        "conflicting_adoptions": sum(
            1 for row in rows
            if row["both_endpoints_adopted"]
            and not row["session_transcript_epoch_match"]
        ),
        "ttsc_ms": {
            "mean": statistics.mean(latencies) if latencies else None,
            "median": statistics.median(latencies) if latencies else None,
            "p95": percentile(latencies, 0.95),
            "p99": percentile(latencies, 0.99),
            "max": max(latencies) if latencies else None,
        },
        "initiator_key_confirmation_ms": {
            "mean": statistics.mean(key_confirmation_latencies)
            if key_confirmation_latencies else None,
            "median": statistics.median(key_confirmation_latencies)
            if key_confirmation_latencies else None,
            "p95": percentile(key_confirmation_latencies, 0.95),
            "p99": percentile(key_confirmation_latencies, 0.99),
            "max": max(key_confirmation_latencies)
            if key_confirmation_latencies else None,
        },
        "tcp_total_retransmissions": {
            "sum": sum(retransmissions) if retransmissions else 0,
            "median": statistics.median(retransmissions)
            if retransmissions else None,
            "max": max(retransmissions) if retransmissions else None,
        },
        "application_protocol_bytes_median": statistics.median(bytes_sent)
        if bytes_sent else None,
        "failure_reasons": dict(failures),
    }


def start_capture(condition: dict, output: Path, log_handle) -> tuple[subprocess.Popen, Path]:
    pcap = output / "pcap" / f"{condition['id']}.pcap"
    pcap.parent.mkdir(parents=True, exist_ok=True)
    capture = subprocess.Popen([
        "sudo", "-n", "ip", "netns", "exec", NS_R,
        "tcpdump", "--immediate-mode", "-i", "any", "-U", "-s", "0",
        "-w", str(pcap),
        "tcp", "port", str(PORT),
    ], stdout=log_handle, stderr=log_handle, text=True)
    # tcpdump needs a short startup interval before a fast clean handshake;
    # otherwise the first condition can finish before libpcap is attached.
    time.sleep(1.0)
    if capture.poll() is not None:
        raise RuntimeError(f"tcpdump failed to start (rc={capture.returncode})")
    return capture, pcap


def stop_capture(capture: subprocess.Popen, pcap: Path) -> None:
    # Give libpcap time to drain packets already accepted by the kernel.  Clean
    # handshakes can otherwise finish before tcpdump services its capture ring.
    time.sleep(0.5)
    root_command([
        "ip", "netns", "exec", NS_R, "pkill", "-INT", "-x", "tcpdump",
    ], check=False)
    try:
        capture.wait(timeout=5)
    except subprocess.TimeoutExpired:
        capture.kill()
        capture.wait(timeout=5)
    if pcap.exists():
        root_command([
            "chown", f"{os.getuid()}:{os.getgid()}", str(pcap),
        ], check=False)


def conditions_for(suite: str, repetitions: int | None,
                   fixed_rtt_ms: float) -> list[dict]:
    conditions: list[dict] = []
    if suite == "smoke":
        count = repetitions or 2
        return [
            {"id": "clean-rtt10", "loss_percent": 0.0,
             "rtt_ms": 10.0, "jitter_ms": 0.0, "repetitions": count},
            {"id": "loss20-rtt50", "loss_percent": 20.0,
             "rtt_ms": 50.0, "jitter_ms": 0.0, "repetitions": count},
        ]
    if suite in ("loss", "full"):
        count = repetitions or 100
        for loss in (0, 1, 5, 10, 20, 30, 40):
            conditions.append({
                "id": f"loss{loss}-rtt{fixed_rtt_ms:g}",
                "loss_percent": float(loss),
                "rtt_ms": fixed_rtt_ms,
                "jitter_ms": 0.0,
                "repetitions": count,
            })
    if suite in ("rtt", "full"):
        count = repetitions or 100
        for rtt in (10, 50, 100, 200, 500, 1000):
            conditions.append({
                "id": f"rtt{rtt}-loss0",
                "loss_percent": 0.0,
                "rtt_ms": float(rtt),
                "jitter_ms": 0.0,
                "repetitions": count,
            })
    if suite == "jitter":
        count = repetitions or 100
        for jitter in (0, 10, 25, 50, 100):
            conditions.append({
                "id": f"jitter{jitter}-rtt{fixed_rtt_ms:g}-loss0",
                "loss_percent": 0.0,
                "rtt_ms": fixed_rtt_ms,
                "jitter_ms": float(jitter),
                "repetitions": count,
            })
    return conditions


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_summary_csv(path: Path, summaries: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "condition", "loss_percent", "rtt_ms", "trials", "successes",
            "success_rate_percent", "mutual_ttsc_mean_ms",
            "mutual_ttsc_median_ms", "mutual_ttsc_p95_ms",
            "mutual_ttsc_p99_ms", "initiator_key_confirm_median_ms",
            "initiator_key_confirm_p95_ms", "tcp_retransmissions_sum",
            "application_protocol_bytes_median", "conflicting_adoptions",
        ])
        for row in summaries:
            condition = row["condition"]
            writer.writerow([
                condition["id"], condition["loss_percent"], condition["rtt_ms"],
                row["trials"], row["successes"], row["success_rate_percent"],
                row["ttsc_ms"]["mean"], row["ttsc_ms"]["median"],
                row["ttsc_ms"]["p95"], row["ttsc_ms"]["p99"],
                row["initiator_key_confirmation_ms"]["median"],
                row["initiator_key_confirmation_ms"]["p95"],
                row["tcp_total_retransmissions"]["sum"],
                row["application_protocol_bytes_median"],
                row["conflicting_adoptions"],
            ])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--suite",
                        choices=("smoke", "loss", "rtt", "jitter", "full"),
                        default="smoke")
    parser.add_argument("--repetitions", type=int)
    parser.add_argument("--fixed-rtt-ms", type=float, default=50.0)
    parser.add_argument("--initiator-epoch", type=int, default=0)
    parser.add_argument("--responder-epoch", type=int, default=5)
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument("--output")
    parser.add_argument("--no-pcap", action="store_true")
    parser.add_argument("--keep-namespaces", action="store_true")
    args = parser.parse_args()
    if args.repetitions is not None and args.repetitions < 1:
        parser.error("--repetitions must be positive")
    if min(args.initiator_epoch, args.responder_epoch) < 0:
        parser.error("epochs must be non-negative")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-{args.suite}")
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "scratch"
    scratch.mkdir()
    log_path = output / "processes.log"

    openssl, openssl_version = openssl_environment()
    library_path = os.environ.get("LD_LIBRARY_PATH", "")
    config = provision(output, args.initiator_epoch, args.responder_epoch)
    conditions = conditions_for(args.suite, args.repetitions, args.fixed_rtt_ms)
    paths = {"output": output, "scratch": scratch}
    all_rows: list[dict] = []
    summaries: list[dict] = []

    setup_topology()
    try:
        apply_netem(0, 0)
        verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            for condition in conditions:
                print(
                    f"[{condition['id']}] loss={condition['loss_percent']}% "
                    f"rtt={condition['rtt_ms']}ms "
                    f"jitter={condition['jitter_ms']}ms "
                    f"n={condition['repetitions']}",
                    flush=True,
                )
                apply_netem(
                    condition["loss_percent"], condition["rtt_ms"],
                    condition["jitter_ms"])
                capture = pcap = None
                if not args.no_pcap:
                    capture, pcap = start_capture(condition, output, log_handle)
                condition_rows = []
                try:
                    for trial_number in range(1, condition["repetitions"] + 1):
                        row = run_trial(
                            condition, trial_number, paths, config, args.timeout,
                            openssl, library_path, log_handle)
                        condition_rows.append(row)
                        all_rows.append(row)
                        with (output / "trials.jsonl").open(
                                "a", encoding="utf-8") as handle:
                            handle.write(json.dumps(row, sort_keys=True) + "\n")
                        if trial_number % 10 == 0 or not row["success"]:
                            print(
                                f"  trial {trial_number}/{condition['repetitions']}: "
                                f"{'ok' if row['success'] else row['failure_reason']}",
                                flush=True,
                            )
                finally:
                    if capture is not None and pcap is not None:
                        stop_capture(capture, pcap)
                summary = summarize(condition, condition_rows)
                summaries.append(summary)
                write_json(output / "summary.json", summaries)
                write_summary_csv(output / "summary.csv", summaries)
                print(
                    f"  success={summary['success_rate_percent']:.1f}% "
                    f"median={summary['ttsc_ms']['median']}ms "
                    f"p95={summary['ttsc_ms']['p95']}ms",
                    flush=True,
                )
    finally:
        if not args.keep_namespaces:
            cleanup_topology()

    manifest = {
        "schema": "gtr.netns.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "suite": args.suite,
        "network_topology": (
            "gtr_eval_i(10.10.0.2) -- gtr_eval_r -- "
            "gtr_eval_j(10.20.0.2)"
        ),
        "transport": "TCP; length-prefixed canonical JSON frames",
        "timing_scope": (
            "TCP connect through verified ACK_R after M1--M4 and protected "
            "CONF_I; both endpoints have committed matching state; enrollment excluded"
        ),
        "cryptography": (
            "OpenSSL ML-KEM-768 for ephemeral, static, and target-epoch FS-KEM; "
            "Python HKDF-SHA-256/HMAC-SHA-256 for the key schedule and tags"
        ),
        "openssl": openssl_version,
        "python": sys.version,
        "platform": platform.platform(),
        "conditions": conditions,
        "source_sha256": {
            ENDPOINT.name: sha256(ENDPOINT),
            Path(__file__).name: sha256(Path(__file__)),
            "reauth_demo.py": sha256(HERE / "reauth_demo.py"),
        },
        "outputs": {
            "summary_json": "summary.json",
            "summary_csv": "summary.csv",
            "trials_jsonl": "trials.jsonl",
            "pcap_directory": None if args.no_pcap else "pcap",
            "process_log": "processes.log",
        },
        "limitations": [
            "Network impairment is Linux netem emulation, not a physical DDIL radio.",
            "TCP provides transport retransmission; GT-R message-level retries are not added.",
            "The target-epoch FS-KEM keys are pre-provisioned and deletion is outside this network run.",
            "Application byte counts exclude TCP/IP link-layer overhead; pcaps retain wire evidence.",
        ],
    }
    write_json(output / "manifest.json", manifest)
    print(json.dumps({"output": str(output), "conditions": len(summaries)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
