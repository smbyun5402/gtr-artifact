#!/usr/bin/env python3
"""Endpoint and verifier roles for the measured FullReAttest baseline.

The responder produces a fresh TPM quote, the remote verifier checks it and
signs its decision with ML-DSA-65, and the initiator then performs a fresh
mutually authenticated TLS 1.3 handshake using MLKEM768 and ML-DSA-65.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import resource
import secrets
import socket
import struct
import subprocess
import tempfile
import time
from pathlib import Path


MAX_FRAME = 16 * 1024 * 1024


def b64(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def unb64(value: str) -> bytes:
    return base64.b64decode(value.encode("ascii"), validate=True)


def send_frame(sock: socket.socket, value: dict) -> int:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    frame = struct.pack("!I", len(payload)) + payload
    sock.sendall(frame)
    return len(frame)


def recv_exact(sock: socket.socket, count: int) -> bytes:
    chunks: list[bytes] = []
    remaining = count
    while remaining:
        chunk = sock.recv(remaining)
        if not chunk:
            raise ConnectionError("peer closed the TCP connection")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def recv_frame(sock: socket.socket) -> tuple[dict, int]:
    header = recv_exact(sock, 4)
    length = struct.unpack("!I", header)[0]
    if length > MAX_FRAME:
        raise ValueError(f"frame length {length} exceeds {MAX_FRAME}")
    payload = recv_exact(sock, length)
    return json.loads(payload.decode("utf-8")), len(header) + len(payload)


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:
            os.remove(temporary)
        except OSError:
            pass


def cpu_snapshot() -> tuple[float, float]:
    own = resource.getrusage(resource.RUSAGE_SELF)
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    return own.ru_utime + children.ru_utime, own.ru_stime + children.ru_stime


def common_result(role: str, run_id: str, started_ns: int, ended_ns: int,
                  user_start: float, system_start: float,
                  sent: int, received: int) -> dict:
    user_end, system_end = cpu_snapshot()
    return {
        "schema": "gtr.full-reattest.node.v1",
        "role": role,
        "run_id": run_id,
        "started_monotonic_ns": started_ns,
        "ended_monotonic_ns": ended_ns,
        "elapsed_ms": (ended_ns - started_ns) / 1_000_000,
        "cpu_user_ms": (user_end - user_start) * 1000,
        "cpu_system_ms": (system_end - system_start) * 1000,
        "control_bytes_sent": sent,
        "control_bytes_received": received,
    }


def command(args: list[str], *, env: dict | None = None,
            input_bytes: bytes | None = None, timeout: float | None = None
            ) -> subprocess.CompletedProcess:
    result = subprocess.run(
        args,
        input=input_bytes,
        capture_output=True,
        env=env,
        timeout=timeout,
    )
    if result.returncode:
        stderr = result.stderr.decode("utf-8", errors="replace")[-1500:]
        raise RuntimeError(f"{Path(args[0]).name} failed ({result.returncode}): {stderr}")
    return result


def openssl_env() -> dict:
    env = dict(os.environ)
    env.setdefault("OPENSSL_CONF", "/dev/null")
    return env


def signed_decision_bytes(nonce_hex: str, evidence_sha256: str) -> bytes:
    decision = {
        "evidence_sha256": evidence_sha256,
        "nonce_hex": nonce_hex,
        "verdict": "allow",
    }
    return json.dumps(decision, sort_keys=True, separators=(",", ":")).encode()


def run_verifier(args: argparse.Namespace, config: dict, work: Path) -> dict:
    sent = received = 0
    started_ns = time.monotonic_ns()
    user_start, system_start = cpu_snapshot()
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((args.address, args.port))
        listener.listen(1)
        listener.settimeout(args.timeout)
        Path(args.ready_file).write_text("ready\n", encoding="utf-8")
        conn, _ = listener.accept()
        with conn:
            conn.settimeout(args.timeout)
            request, count = recv_frame(conn)
            received += count
            nonce_hex = request["nonce_hex"]
            if len(bytes.fromhex(nonce_hex)) != 32:
                raise ValueError("attestation nonce is not 32 bytes")
            quote_msg = unb64(request["quote_msg"])
            quote_sig = unb64(request["quote_sig"])
            quote_pcr = unb64(request["quote_pcr"])
            msg_path = work / "quote.msg"
            sig_path = work / "quote.sig"
            pcr_path = work / "quote.pcr"
            msg_path.write_bytes(quote_msg)
            sig_path.write_bytes(quote_sig)
            pcr_path.write_bytes(quote_pcr)

            verify_start = time.monotonic_ns()
            command([
                "tpm2_checkquote", "-u", config["ak_pem_pub"],
                "-m", str(msg_path), "-s", str(sig_path),
                "-f", str(pcr_path), "-g", "sha256", "-q", nonce_hex,
            ], env={**os.environ, "TPM2TOOLS_TCTI": "none"}, timeout=args.timeout)
            verify_end = time.monotonic_ns()

            evidence_hash = hashlib.sha256(
                quote_msg + quote_sig + quote_pcr).hexdigest()
            decision = signed_decision_bytes(nonce_hex, evidence_hash)
            decision_path = work / "decision.json"
            signature_path = work / "decision.sig"
            decision_path.write_bytes(decision)
            sign_start = time.monotonic_ns()
            command([
                config["openssl"], "pkeyutl", "-sign", "-rawin",
                "-inkey", config["verifier_signing_key"],
                "-in", str(decision_path), "-out", str(signature_path),
            ], env=openssl_env(), timeout=args.timeout)
            sign_end = time.monotonic_ns()
            sent += send_frame(conn, {
                "decision": b64(decision),
                "signature": b64(signature_path.read_bytes()),
            })

    ended_ns = time.monotonic_ns()
    result = common_result(
        "verifier", args.run_id, started_ns, ended_ns,
        user_start, system_start, sent, received)
    result.update({
        "ok": True,
        "nonce_sha256": hashlib.sha256(bytes.fromhex(nonce_hex)).hexdigest(),
        "evidence_sha256": evidence_hash,
        "quote_verify_ms": (verify_end - verify_start) / 1_000_000,
        "decision_sign_ms": (sign_end - sign_start) / 1_000_000,
    })
    return result


def run_responder(args: argparse.Namespace, config: dict, work: Path) -> dict:
    sent = received = 0
    started_ns = time.monotonic_ns()
    user_start, system_start = cpu_snapshot()
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((args.address, args.port))
        listener.listen(1)
        listener.settimeout(args.timeout)
        Path(args.ready_file).write_text("ready\n", encoding="utf-8")
        conn, _ = listener.accept()
        with conn:
            conn.settimeout(args.timeout)
            challenge, count = recv_frame(conn)
            received += count
            nonce_hex = challenge["nonce_hex"]
            if len(bytes.fromhex(nonce_hex)) != 32:
                raise ValueError("attestation nonce is not 32 bytes")

            quote_msg = work / "quote.msg"
            quote_sig = work / "quote.sig"
            quote_pcr = work / "quote.pcr"
            quote_start = time.monotonic_ns()
            command([
                "tpm2_quote", "-c", config["ak_context"],
                "-l", "sha256:0,1,2", "-q", nonce_hex,
                "-m", str(quote_msg), "-s", str(quote_sig),
                "-o", str(quote_pcr), "-g", "sha256",
            ], env={**os.environ, "TPM2TOOLS_TCTI": config["tpm_tcti"]},
               timeout=args.timeout)
            quote_end = time.monotonic_ns()

            with socket.create_connection(
                    (config["verifier_address"], config["verifier_port"]),
                    timeout=args.timeout) as verifier:
                verifier.settimeout(args.timeout)
                sent += send_frame(verifier, {
                    "nonce_hex": nonce_hex,
                    "quote_msg": b64(quote_msg.read_bytes()),
                    "quote_sig": b64(quote_sig.read_bytes()),
                    "quote_pcr": b64(quote_pcr.read_bytes()),
                })
                verdict, count = recv_frame(verifier)
                received += count
            sent += send_frame(conn, verdict)

    decision = unb64(verdict["decision"])
    decision_object = json.loads(decision.decode("utf-8"))
    if decision_object.get("nonce_hex") != nonce_hex:
        raise RuntimeError("verifier decision nonce mismatch")
    ended_ns = time.monotonic_ns()
    result = common_result(
        "responder", args.run_id, started_ns, ended_ns,
        user_start, system_start, sent, received)
    result.update({
        "ok": decision_object.get("verdict") == "allow",
        "nonce_sha256": hashlib.sha256(bytes.fromhex(nonce_hex)).hexdigest(),
        "evidence_sha256": decision_object["evidence_sha256"],
        "quote_generation_ms": (quote_end - quote_start) / 1_000_000,
    })
    return result


def run_initiator(args: argparse.Namespace, config: dict, work: Path) -> dict:
    sent = received = 0
    user_start, system_start = cpu_snapshot()
    started_ns = time.monotonic_ns()
    nonce = secrets.token_bytes(32)
    nonce_hex = nonce.hex()
    with socket.create_connection(
            (config["responder_address"], config["responder_port"]),
            timeout=args.timeout) as responder:
        responder.settimeout(args.timeout)
        sent += send_frame(responder, {"nonce_hex": nonce_hex})
        verdict, count = recv_frame(responder)
        received += count

    decision = unb64(verdict["decision"])
    signature = unb64(verdict["signature"])
    decision_path = work / "decision.json"
    signature_path = work / "decision.sig"
    decision_path.write_bytes(decision)
    signature_path.write_bytes(signature)
    decision_object = json.loads(decision.decode("utf-8"))
    if decision_object.get("nonce_hex") != nonce_hex:
        raise RuntimeError("verifier decision is not bound to this challenge")
    if decision_object.get("verdict") != "allow":
        raise RuntimeError("verifier denied attestation")
    verify_start = time.monotonic_ns()
    command([
        config["openssl"], "pkeyutl", "-verify", "-rawin", "-pubin",
        "-inkey", config["verifier_signing_pub"],
        "-in", str(decision_path), "-sigfile", str(signature_path),
    ], env=openssl_env(), timeout=args.timeout)
    verify_end = time.monotonic_ns()
    attestation_end_ns = time.monotonic_ns()

    tls_start_ns = time.monotonic_ns()
    tls_result = command([
        config["openssl"], "s_client",
        "-connect", f"{config['responder_address']}:{config['tls_port']}",
        "-cert", config["client_cert"], "-key", config["client_key"],
        "-CAfile", config["ca_cert"], "-verify_return_error",
        "-groups", "MLKEM768", "-tls1_3", "-brief",
        "-keylogfile", args.tls_keylog,
    ], env=openssl_env(), input_bytes=b"Q\n", timeout=args.timeout)
    tls_end_ns = time.monotonic_ns()
    transcript = (tls_result.stdout + tls_result.stderr).decode(
        "utf-8", errors="replace")
    required = (
        "CONNECTION ESTABLISHED",
        "Verification: OK",
        "Negotiated TLS1.3 group: MLKEM768",
        "Signature type: mldsa65",
    )
    missing = [marker for marker in required if marker not in transcript]
    if missing:
        raise RuntimeError(f"TLS evidence missing: {missing}")

    ended_ns = time.monotonic_ns()
    result = common_result(
        "initiator", args.run_id, started_ns, ended_ns,
        user_start, system_start, sent, received)
    result.update({
        "ok": True,
        "nonce_sha256": hashlib.sha256(nonce).hexdigest(),
        "evidence_sha256": decision_object["evidence_sha256"],
        "verifier_signature_verify_ms": (verify_end - verify_start) / 1_000_000,
        "attestation_phase_ms": (attestation_end_ns - started_ns) / 1_000_000,
        "tls_phase_ms": (tls_end_ns - tls_start_ns) / 1_000_000,
        "ttsc_ms": (ended_ns - started_ns) / 1_000_000,
        "tls": {
            "version": "TLSv1.3",
            "group": "MLKEM768",
            "certificate_signature": "ML-DSA-65",
            "mutual_authentication": True,
        },
    })
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--role", choices=("initiator", "responder", "verifier"),
                        required=True)
    parser.add_argument("--address", required=True)
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--result", required=True)
    parser.add_argument("--ready-file")
    parser.add_argument("--tls-keylog")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--timeout", type=float, default=20.0)
    args = parser.parse_args()
    if args.role != "initiator" and not args.ready_file:
        parser.error("--ready-file is required for server roles")
    if args.role == "initiator" and not args.tls_keylog:
        parser.error("--tls-keylog is required for the initiator")

    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    initial_ns = time.monotonic_ns()
    initial_user, initial_system = cpu_snapshot()
    with tempfile.TemporaryDirectory(prefix=f"full-reattest-{args.role}-") as temporary:
        work = Path(temporary)
        try:
            if args.role == "verifier":
                result = run_verifier(args, config, work)
            elif args.role == "responder":
                result = run_responder(args, config, work)
            else:
                result = run_initiator(args, config, work)
        except Exception as exc:
            ended_ns = time.monotonic_ns()
            result = common_result(
                args.role, args.run_id, initial_ns, ended_ns,
                initial_user, initial_system, 0, 0)
            result.update({
                "ok": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
            })
    atomic_json(Path(args.result), result)
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
