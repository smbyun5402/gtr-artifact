#!/usr/bin/env python3
"""Measure fresh PQC TLS plus remote TPM attestation over Linux netem."""

from __future__ import annotations

import argparse
import collections
import csv
import getpass
import hashlib
import json
import os
import platform
import statistics
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path


HERE = Path(__file__).resolve().parent
NODE = HERE / "full_reattest_node.py"
NS_I = "gtr_cmp_i"
NS_R = "gtr_cmp_r"
NS_J = "gtr_cmp_j"
NS_V = "gtr_cmp_v"
I_ADDR = "10.10.0.2"
J_ADDR = "10.20.0.2"
V_ADDR = "10.30.0.2"
CONTROL_PORT = 48000
VERIFIER_PORT = 48001
TLS_PORT = 48443
TPM_PORT = 2321
TPM_CTRL_PORT = 2322


def command(args: list[str], *, check: bool = True,
            capture: bool = False, env: dict | None = None,
            cwd: Path | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        args, check=check, text=True, capture_output=capture, env=env, cwd=cwd)


def root_command(args: list[str], *, check: bool = True,
                 capture: bool = False) -> subprocess.CompletedProcess:
    return command(["sudo", "-n"] + args, check=check, capture=capture)


def ns_user_args(namespace: str, args: list[str], env: dict[str, str] | None = None
                 ) -> list[str]:
    result = [
        "sudo", "-n", "ip", "netns", "exec", namespace,
        "runuser", "-u", getpass.getuser(), "--",
    ]
    if env:
        result.extend(["env"] + [f"{key}={value}" for key, value in env.items()])
    result.extend(args)
    return result


def namespace_exists(name: str) -> bool:
    result = command(["ip", "netns", "list"], capture=True)
    return any(line.split()[0] == name for line in result.stdout.splitlines())


def cleanup_topology() -> None:
    for namespace in (NS_I, NS_R, NS_J, NS_V):
        if namespace_exists(namespace):
            root_command(["ip", "netns", "delete", namespace], check=False)


def setup_topology() -> None:
    cleanup_topology()
    for namespace in (NS_I, NS_R, NS_J, NS_V):
        root_command(["ip", "netns", "add", namespace])
    for endpoint, router_end in (("ci0", "cri0"), ("cj0", "crj0"), ("cv0", "crv0")):
        root_command(["ip", "link", "add", endpoint, "type", "veth",
                      "peer", "name", router_end])
    root_command(["ip", "link", "set", "ci0", "netns", NS_I])
    root_command(["ip", "link", "set", "cri0", "netns", NS_R])
    root_command(["ip", "link", "set", "cj0", "netns", NS_J])
    root_command(["ip", "link", "set", "crj0", "netns", NS_R])
    root_command(["ip", "link", "set", "cv0", "netns", NS_V])
    root_command(["ip", "link", "set", "crv0", "netns", NS_R])
    for namespace in (NS_I, NS_R, NS_J, NS_V):
        root_command(["ip", "-n", namespace, "link", "set", "lo", "up"])

    for namespace, address, device in (
        (NS_I, "10.10.0.2/24", "ci0"),
        (NS_R, "10.10.0.1/24", "cri0"),
        (NS_J, "10.20.0.2/24", "cj0"),
        (NS_R, "10.20.0.1/24", "crj0"),
        (NS_V, "10.30.0.2/24", "cv0"),
        (NS_R, "10.30.0.1/24", "crv0"),
    ):
        root_command(["ip", "-n", namespace, "addr", "add", address,
                      "dev", device])
        root_command(["ip", "-n", namespace, "link", "set", device, "up"])

    root_command(["ip", "-n", NS_I, "route", "add", "10.20.0.0/24",
                  "via", "10.10.0.1"])
    root_command(["ip", "-n", NS_I, "route", "add", "10.30.0.0/24",
                  "via", "10.10.0.1"])
    root_command(["ip", "-n", NS_J, "route", "add", "10.10.0.0/24",
                  "via", "10.20.0.1"])
    root_command(["ip", "-n", NS_J, "route", "add", "10.30.0.0/24",
                  "via", "10.20.0.1"])
    root_command(["ip", "-n", NS_V, "route", "add", "10.10.0.0/24",
                  "via", "10.30.0.1"])
    root_command(["ip", "-n", NS_V, "route", "add", "10.20.0.0/24",
                  "via", "10.30.0.1"])
    root_command(["ip", "netns", "exec", NS_R, "sysctl", "-q", "-w",
                  "net.ipv4.ip_forward=1"])


def apply_netem(loss_percent: float, rtt_ms: float, jitter_ms: float) -> None:
    one_way = rtt_ms / 2.0
    for device in ("cri0", "crj0", "crv0"):
        netem = [
            "ip", "netns", "exec", NS_R,
            "tc", "qdisc", "replace", "dev", device, "root", "netem",
            "delay", f"{one_way:.3f}ms",
        ]
        if jitter_ms:
            netem.extend([f"{jitter_ms / 2.0:.3f}ms", "distribution", "normal"])
        netem.extend(["loss", f"{loss_percent:.3f}%"])
        root_command(netem)


def verify_connectivity() -> None:
    for namespace, address in ((NS_I, J_ADDR), (NS_J, V_ADDR), (NS_V, I_ADDR)):
        root_command(["ip", "netns", "exec", namespace,
                      "ping", "-c", "1", "-W", "2", address])


def openssl_environment() -> tuple[str, str, dict[str, str]]:
    openssl = os.environ.get("OPENSSL", "openssl")
    environment = {
        "OPENSSL": openssl,
        "LD_LIBRARY_PATH": os.environ.get("LD_LIBRARY_PATH", ""),
        "OPENSSL_CONF": os.environ.get("OPENSSL_CONF", "/dev/null"),
        "PYTHONPYCACHEPREFIX": "/tmp/gtr-full-pycache",
    }
    result = command([openssl, "version"], capture=True, env={**os.environ, **environment})
    groups = command([openssl, "list", "-tls-groups"], capture=True,
                     env={**os.environ, **environment})
    signatures = command([openssl, "list", "-signature-algorithms"], capture=True,
                         env={**os.environ, **environment})
    if "MLKEM768" not in groups.stdout or "ML-DSA-65" not in signatures.stdout:
        raise RuntimeError("OpenSSL lacks MLKEM768 TLS or ML-DSA-65 support")
    return openssl, result.stdout.strip(), environment


def openssl_run(openssl: str, environment: dict[str, str], args: list[str],
                cwd: Path) -> None:
    command([openssl] + args, env={**os.environ, **environment}, cwd=cwd)


def provision_credentials(output: Path, openssl: str,
                          environment: dict[str, str]) -> dict:
    directory = output / "credentials" / "pqc-tls"
    directory.mkdir(parents=True)
    openssl_run(openssl, environment,
                ["genpkey", "-algorithm", "ML-DSA-65", "-out", "ca.key"], directory)
    openssl_run(openssl, environment, [
        "req", "-new", "-x509", "-key", "ca.key", "-out", "ca.crt",
        "-subj", "/CN=GT-R-Evaluation-CA", "-days", "2",
        "-addext", "basicConstraints=critical,CA:TRUE",
        "-addext", "keyUsage=critical,keyCertSign,cRLSign",
    ], directory)
    for name in ("server", "client"):
        openssl_run(openssl, environment,
                    ["genpkey", "-algorithm", "ML-DSA-65",
                     "-out", f"{name}.key"], directory)
        openssl_run(openssl, environment,
                    ["req", "-new", "-key", f"{name}.key",
                     "-out", f"{name}.csr", "-subj", f"/CN=gtr-{name}"], directory)
        openssl_run(openssl, environment,
                    ["x509", "-req", "-in", f"{name}.csr",
                     "-CA", "ca.crt", "-CAkey", "ca.key", "-CAcreateserial",
                     "-out", f"{name}.crt", "-days", "2"], directory)
    openssl_run(openssl, environment,
                ["genpkey", "-algorithm", "ML-DSA-65",
                 "-out", "verifier-decision.key"], directory)
    openssl_run(openssl, environment,
                ["pkey", "-in", "verifier-decision.key", "-pubout",
                 "-out", "verifier-decision.pub"], directory)
    return {
        "ca_cert": str((directory / "ca.crt").resolve()),
        "server_cert": str((directory / "server.crt").resolve()),
        "server_key": str((directory / "server.key").resolve()),
        "client_cert": str((directory / "client.crt").resolve()),
        "client_key": str((directory / "client.key").resolve()),
        "verifier_signing_key": str((directory / "verifier-decision.key").resolve()),
        "verifier_signing_pub": str((directory / "verifier-decision.pub").resolve()),
    }


def start_swtpm(output: Path, log_handle) -> tuple[subprocess.Popen, Path]:
    # swtpm requires POSIX advisory locking, which the Lima host-share mount
    # does not provide reliably.  Keep only emulator state on the guest-local
    # filesystem; all published measurements still go to ``output``.
    state = Path(tempfile.mkdtemp(prefix="gtr-full-swtpm-", dir="/tmp"))
    process = subprocess.Popen(ns_user_args(NS_J, [
        "swtpm", "socket", "--tpmstate", f"dir={state}", "--tpm2",
        "--server", f"type=tcp,port={TPM_PORT}",
        "--ctrl", f"type=tcp,port={TPM_CTRL_PORT}",
        "--flags", "not-need-init,startup-clear",
    ]), stdout=log_handle, stderr=log_handle, text=True)
    time.sleep(0.8)
    if process.poll() is not None:
        raise RuntimeError(f"swtpm failed to start (rc={process.returncode})")
    return process, state


def tpm_command(args: list[str], tcti: str) -> None:
    command(ns_user_args(NS_J, args, {"TPM2TOOLS_TCTI": tcti}), capture=True)


def provision_tpm(output: Path) -> dict:
    directory = output / "credentials" / "ak"
    directory.mkdir(parents=True)
    tcti = f"swtpm:port={TPM_PORT}"
    primary = str((directory / "primary.ctx").resolve())
    ak_pub = str((directory / "ak.pub").resolve())
    ak_priv = str((directory / "ak.priv").resolve())
    ak_context_file = str((directory / "ak.ctx").resolve())
    ak_persistent_handle = "0x81010002"
    ak_pem = str((directory / "ak-pem.pub").resolve())
    tpm_command(["tpm2_createprimary", "-C", "o", "-c", primary], tcti)
    tpm_command(["tpm2_flushcontext", "-t"], tcti)
    tpm_command([
        "tpm2_create", "-C", primary, "-G", "ecc256:ecdsa-sha256:null",
        "-u", ak_pub, "-r", ak_priv,
        "-a", "fixedtpm|fixedparent|sensitivedataorigin|userwithauth|restricted|sign",
    ], tcti)
    tpm_command(["tpm2_flushcontext", "-t"], tcti)
    tpm_command(["tpm2_load", "-C", primary, "-u", ak_pub,
                 "-r", ak_priv, "-c", ak_context_file], tcti)
    tpm_command(["tpm2_evictcontrol", "-C", "o", "-c", ak_context_file,
                 ak_persistent_handle], tcti)
    tpm_command(["tpm2_flushcontext", "-t"], tcti)
    tpm_command(["tpm2_readpublic", "-c", ak_persistent_handle, "-f", "pem",
                 "-o", ak_pem], tcti)
    return {"ak_context": ak_persistent_handle, "ak_pem_pub": ak_pem,
            "tpm_tcti": tcti}


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    os.replace(temporary, path)


def write_config(output: Path, openssl: str, credentials: dict,
                 tpm: dict) -> Path:
    config = {
        "schema": "gtr.full-reattest.provision.v1",
        "openssl": openssl,
        "responder_address": J_ADDR,
        "responder_port": CONTROL_PORT,
        "verifier_address": V_ADDR,
        "verifier_port": VERIFIER_PORT,
        "tls_port": TLS_PORT,
        **credentials,
        **tpm,
    }
    path = output / "provision.json"
    write_json(path, config)
    return path


def node_command(namespace: str, role: str, address: str, port: int,
                 config: Path, result: Path, run_id: str, timeout: float,
                 environment: dict[str, str], ready: Path | None = None,
                 keylog: Path | None = None) -> list[str]:
    args = [
        sys.executable, str(NODE), "--role", role, "--address", address,
        "--port", str(port), "--config", str(config), "--result", str(result),
        "--run-id", run_id, "--timeout", str(timeout),
    ]
    if ready is not None:
        args.extend(["--ready-file", str(ready)])
    if keylog is not None:
        args.extend(["--tls-keylog", str(keylog)])
    return ns_user_args(namespace, args, environment)


def tls_server_command(config: dict, keylog: Path,
                       environment: dict[str, str]) -> list[str]:
    args = [
        config["openssl"], "s_server", "-accept", str(TLS_PORT),
        "-cert", config["server_cert"], "-key", config["server_key"],
        "-CAfile", config["ca_cert"], "-Verify", "1", "-verify_return_error",
        "-groups", "MLKEM768", "-tls1_3", "-brief", "-naccept", "1",
        "-keylogfile", str(keylog),
    ]
    return ns_user_args(NS_J, args, environment)


def wait_for_ready(paths: list[Path], processes: list[subprocess.Popen],
                   timeout: float = 10.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if all(path.exists() for path in paths):
            return
        for process in processes:
            if process.poll() is not None:
                raise RuntimeError(f"server exited before ready (rc={process.returncode})")
        time.sleep(0.02)
    raise TimeoutError("server readiness timeout")


def wait_for_tls_listener(process: subprocess.Popen, timeout: float = 10.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"TLS server exited before listen (rc={process.returncode})")
        result = root_command(["ip", "netns", "exec", NS_J, "ss", "-ltn"],
                              capture=True)
        if f":{TLS_PORT}" in result.stdout:
            return
        time.sleep(0.02)
    raise TimeoutError("TLS listener readiness timeout")


def load_result(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def handshake_secrets(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return {
        line.strip() for line in path.read_text(encoding="utf-8").splitlines()
        if line.startswith("CLIENT_HANDSHAKE_TRAFFIC_SECRET ")
    }


def run_trial(condition: dict, number: int, paths: dict, config_path: Path,
              config: dict, timeout: float, environment: dict[str, str],
              log_handle) -> dict:
    run_id = f"{condition['id']}-{number:04d}"
    scratch = paths["scratch"]
    files = {
        "vready": scratch / f"{run_id}.verifier.ready",
        "jready": scratch / f"{run_id}.responder.ready",
        "vresult": scratch / f"{run_id}.verifier.json",
        "jresult": scratch / f"{run_id}.responder.json",
        "iresult": scratch / f"{run_id}.initiator.json",
        "ckeylog": scratch / f"{run_id}.client.keys",
        "skeylog": scratch / f"{run_id}.server.keys",
    }
    for path in files.values():
        path.unlink(missing_ok=True)

    root_command(["ip", "netns", "exec", NS_J, "pkill", "-TERM", "-f",
                  f"s_server.*{TLS_PORT}"], check=False)

    verifier = subprocess.Popen(node_command(
        NS_V, "verifier", V_ADDR, VERIFIER_PORT, config_path,
        files["vresult"], run_id, timeout, environment, ready=files["vready"]),
        stdout=log_handle, stderr=log_handle, text=True)
    responder = subprocess.Popen(node_command(
        NS_J, "responder", J_ADDR, CONTROL_PORT, config_path,
        files["jresult"], run_id, timeout, environment, ready=files["jready"]),
        stdout=log_handle, stderr=log_handle, text=True)
    tls_server = subprocess.Popen(
        tls_server_command(config, files["skeylog"], environment),
        stdout=log_handle, stderr=log_handle, text=True)
    orchestration_error = None
    client_rc = verifier_rc = responder_rc = tls_server_rc = None
    try:
        wait_for_ready([files["vready"], files["jready"]],
                       [verifier, responder])
        wait_for_tls_listener(tls_server)
        client = subprocess.Popen(node_command(
            NS_I, "initiator", I_ADDR, CONTROL_PORT, config_path,
            files["iresult"], run_id, timeout, environment,
            keylog=files["ckeylog"]),
            stdout=log_handle, stderr=log_handle, text=True)
        try:
            client_rc = client.wait(timeout=timeout * 3 + 10)
        except subprocess.TimeoutExpired:
            client.kill()
            client_rc = client.wait(timeout=5)
            orchestration_error = "initiator orchestration timeout"
        if client_rc != 0 and tls_server.poll() is None:
            root_command(["ip", "netns", "exec", NS_J, "pkill", "-TERM", "-f",
                          f"s_server.*{TLS_PORT}"], check=False)
        for name, process in (
            ("responder", responder), ("verifier", verifier),
            ("tls-server", tls_server),
        ):
            try:
                return_code = process.wait(timeout=timeout + 10)
            except subprocess.TimeoutExpired:
                if name == "tls-server":
                    root_command(["ip", "netns", "exec", NS_J,
                                  "pkill", "-TERM", "-f",
                                  f"s_server.*{TLS_PORT}"], check=False)
                process.kill()
                return_code = process.wait(timeout=5)
                orchestration_error = f"{name} orchestration timeout"
            if name == "responder":
                responder_rc = return_code
            elif name == "verifier":
                verifier_rc = return_code
            else:
                tls_server_rc = return_code
    except Exception as exc:
        orchestration_error = f"{type(exc).__name__}: {exc}"
        root_command(["ip", "netns", "exec", NS_J, "pkill", "-TERM", "-f",
                      f"s_server.*{TLS_PORT}"], check=False)
        for process in (verifier, responder, tls_server):
            if process.poll() is None:
                process.kill()
            process.wait(timeout=5)

    initiator_result = load_result(files["iresult"])
    responder_result = load_result(files["jresult"])
    verifier_result = load_result(files["vresult"])
    secrets_match = bool(
        handshake_secrets(files["ckeylog"])
        & handshake_secrets(files["skeylog"]))
    all_ok = bool(
        initiator_result and responder_result and verifier_result
        and initiator_result.get("ok") and responder_result.get("ok")
        and verifier_result.get("ok") and client_rc == 0
        and responder_rc == 0 and verifier_rc == 0 and tls_server_rc == 0)
    binding_match = bool(
        all_ok
        and initiator_result["nonce_sha256"] == responder_result["nonce_sha256"]
        == verifier_result["nonce_sha256"]
        and initiator_result["evidence_sha256"]
        == responder_result["evidence_sha256"]
        == verifier_result["evidence_sha256"])
    success = all_ok and binding_match and secrets_match

    failure_reason = None
    if not success:
        if orchestration_error:
            failure_reason = orchestration_error
        else:
            for name, result in (
                ("initiator", initiator_result),
                ("responder", responder_result),
                ("verifier", verifier_result),
            ):
                if result and not result.get("ok"):
                    failure_reason = f"{name}:{result.get('error_type')}:{result.get('error')}"
                    break
            if failure_reason is None and not all_ok:
                failure_reason = "missing result or non-zero process exit"
            elif failure_reason is None and not binding_match:
                failure_reason = "challenge/evidence binding mismatch"
            elif failure_reason is None:
                failure_reason = "TLS handshake-secret mismatch"

    return {
        "schema": "gtr.full-reattest.trial.v1",
        "run_id": run_id,
        "condition": condition,
        "trial": number,
        "success": success,
        "failure_reason": failure_reason,
        "ttsc_ms": initiator_result.get("ttsc_ms") if initiator_result else None,
        "attestation_phase_ms": (
            initiator_result.get("attestation_phase_ms") if initiator_result else None),
        "tls_phase_ms": initiator_result.get("tls_phase_ms") if initiator_result else None,
        "quote_generation_ms": (
            responder_result.get("quote_generation_ms") if responder_result else None),
        "quote_verify_ms": (
            verifier_result.get("quote_verify_ms") if verifier_result else None),
        "decision_sign_ms": (
            verifier_result.get("decision_sign_ms") if verifier_result else None),
        "challenge_evidence_binding_match": binding_match,
        "tls_handshake_secrets_match": secrets_match,
        "initiator_exit_code": client_rc,
        "responder_exit_code": responder_rc,
        "verifier_exit_code": verifier_rc,
        "tls_server_exit_code": tls_server_rc,
        "initiator": initiator_result,
        "responder": responder_result,
        "verifier": verifier_result,
    }


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    if len(values) == 1:
        return values[0]
    rank = (len(values) - 1) * quantile
    lower = int(rank)
    upper = min(lower + 1, len(values) - 1)
    fraction = rank - lower
    return values[lower] * (1 - fraction) + values[upper] * fraction


def distribution(rows: list[dict], key: str) -> dict:
    values = [row[key] for row in rows if row.get(key) is not None]
    return {
        "mean": statistics.mean(values) if values else None,
        "median": statistics.median(values) if values else None,
        "p95": percentile(values, 0.95),
        "p99": percentile(values, 0.99),
        "max": max(values) if values else None,
    }


def summarize(condition: dict, rows: list[dict]) -> dict:
    successful = [row for row in rows if row["success"]]
    return {
        "condition": condition,
        "trials": len(rows),
        "successes": len(successful),
        "success_rate_percent": 100 * len(successful) / len(rows),
        "ttsc_ms": distribution(successful, "ttsc_ms"),
        "attestation_phase_ms": distribution(successful, "attestation_phase_ms"),
        "tls_phase_ms": distribution(successful, "tls_phase_ms"),
        "quote_generation_ms": distribution(successful, "quote_generation_ms"),
        "quote_verify_ms": distribution(successful, "quote_verify_ms"),
        "decision_sign_ms": distribution(successful, "decision_sign_ms"),
        "binding_mismatches": sum(
            1 for row in rows if not row["challenge_evidence_binding_match"]),
        "tls_secret_mismatches": sum(
            1 for row in rows if not row["tls_handshake_secrets_match"]),
        "failure_reasons": dict(collections.Counter(
            row["failure_reason"] for row in rows if row["failure_reason"])),
    }


def write_summary_csv(path: Path, summaries: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "condition", "loss_percent", "rtt_ms", "trials", "successes",
            "success_rate_percent", "ttsc_median_ms", "ttsc_p95_ms",
            "ttsc_p99_ms", "attestation_median_ms", "tls_median_ms",
            "quote_generation_median_ms", "quote_verify_median_ms",
            "decision_sign_median_ms", "binding_mismatches",
            "tls_secret_mismatches",
        ])
        for row in summaries:
            writer.writerow([
                row["condition"]["id"], row["condition"]["loss_percent"],
                row["condition"]["rtt_ms"], row["trials"], row["successes"],
                row["success_rate_percent"], row["ttsc_ms"]["median"],
                row["ttsc_ms"]["p95"], row["ttsc_ms"]["p99"],
                row["attestation_phase_ms"]["median"],
                row["tls_phase_ms"]["median"],
                row["quote_generation_ms"]["median"],
                row["quote_verify_ms"]["median"],
                row["decision_sign_ms"]["median"],
                row["binding_mismatches"], row["tls_secret_mismatches"],
            ])


def start_capture(condition: dict, output: Path, log_handle
                  ) -> tuple[subprocess.Popen, Path]:
    pcap = output / "pcap" / f"{condition['id']}.pcap"
    pcap.parent.mkdir(parents=True, exist_ok=True)
    capture = subprocess.Popen([
        "sudo", "-n", "ip", "netns", "exec", NS_R,
        "tcpdump", "--immediate-mode", "-i", "any", "-U", "-s", "0",
        "-w", str(pcap), "tcp", "and", "(",
        "port", str(CONTROL_PORT), "or", "port", str(VERIFIER_PORT),
        "or", "port", str(TLS_PORT), ")",
    ], stdout=log_handle, stderr=log_handle, text=True)
    time.sleep(1.0)
    if capture.poll() is not None:
        raise RuntimeError(f"tcpdump failed to start (rc={capture.returncode})")
    return capture, pcap


def stop_capture(capture: subprocess.Popen, pcap: Path) -> None:
    time.sleep(0.5)
    root_command(["ip", "netns", "exec", NS_R,
                  "pkill", "-INT", "-x", "tcpdump"], check=False)
    try:
        capture.wait(timeout=5)
    except subprocess.TimeoutExpired:
        capture.kill()
        capture.wait(timeout=5)
    if pcap.exists():
        root_command(["chown", f"{os.getuid()}:{os.getgid()}", str(pcap)],
                     check=False)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def conditions(repetitions: int, loss_percent: float,
               jitter_ms: float) -> list[dict]:
    return [
        {
            "id": f"full-rtt{rtt}-loss{loss_percent:g}",
            "rtt_ms": float(rtt), "loss_percent": loss_percent,
            "jitter_ms": jitter_ms, "repetitions": repetitions,
        }
        for rtt in (10, 50, 100, 200, 500, 1000)
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=100)
    parser.add_argument("--loss-percent", type=float, default=0.0)
    parser.add_argument("--jitter-ms", type=float, default=0.0)
    parser.add_argument("--timeout", type=float, default=20.0)
    parser.add_argument("--output")
    parser.add_argument("--no-pcap", action="store_true")
    parser.add_argument("--keep-namespaces", action="store_true")
    args = parser.parse_args()
    if args.repetitions < 1:
        parser.error("--repetitions must be positive")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-fullreattest-rtt")
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "scratch"
    scratch.mkdir()
    log_path = output / "processes.log"
    openssl, openssl_version, environment = openssl_environment()
    credential_config = provision_credentials(output, openssl, environment)

    setup_topology()
    swtpm = None
    all_rows: list[dict] = []
    summaries: list[dict] = []
    try:
        apply_netem(0, 0, 0)
        verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            swtpm, _ = start_swtpm(output, log_handle)
            tpm_config = provision_tpm(output)
            config_path = write_config(
                output, openssl, credential_config, tpm_config)
            config = json.loads(config_path.read_text(encoding="utf-8"))
            for condition in conditions(
                    args.repetitions, args.loss_percent, args.jitter_ms):
                print(
                    f"[{condition['id']}] loss={condition['loss_percent']}% "
                    f"rtt={condition['rtt_ms']}ms n={condition['repetitions']}",
                    flush=True)
                apply_netem(condition["loss_percent"], condition["rtt_ms"],
                            condition["jitter_ms"])
                capture = pcap = None
                if not args.no_pcap:
                    capture, pcap = start_capture(condition, output, log_handle)
                condition_rows: list[dict] = []
                try:
                    for number in range(1, condition["repetitions"] + 1):
                        row = run_trial(
                            condition, number, {"scratch": scratch},
                            config_path, config, args.timeout, environment,
                            log_handle)
                        condition_rows.append(row)
                        all_rows.append(row)
                        with (output / "trials.jsonl").open(
                                "a", encoding="utf-8") as handle:
                            handle.write(json.dumps(row, sort_keys=True) + "\n")
                        if number % 10 == 0 or not row["success"]:
                            print(
                                f"  trial {number}/{condition['repetitions']}: "
                                f"{'ok' if row['success'] else row['failure_reason']}",
                                flush=True)
                finally:
                    if capture is not None and pcap is not None:
                        stop_capture(capture, pcap)
                summary = summarize(condition, condition_rows)
                summaries.append(summary)
                write_json(output / "summary.json", summaries)
                write_summary_csv(output / "summary.csv", summaries)
                print(
                    f"  success={summary['success_rate_percent']:.1f}% "
                    f"median={summary['ttsc_ms']['median']}ms "
                    f"p95={summary['ttsc_ms']['p95']}ms", flush=True)
    finally:
        if swtpm is not None and swtpm.poll() is None:
            swtpm.terminate()
            try:
                swtpm.wait(timeout=5)
            except subprocess.TimeoutExpired:
                swtpm.kill()
                swtpm.wait(timeout=5)
        if not args.keep_namespaces:
            cleanup_topology()

    manifest = {
        "schema": "gtr.full-reattest.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "baseline": "fresh mutual PQC TLS plus online TPM quote verification",
        "network_topology": (
            "gtr_cmp_i(10.10.0.2) -- gtr_cmp_r -- gtr_cmp_j(10.20.0.2); "
            "gtr_cmp_j -- gtr_cmp_r -- gtr_cmp_v(10.30.0.2)"),
        "timing_scope": (
            "initiator TCP challenge through verifier-signed TPM verdict and "
            "completion of fresh mutually authenticated TLS 1.3"),
        "cryptography": (
            "swtpm ECC attestation key; tpm2_quote/tpm2_checkquote; "
            "ML-DSA-65-signed verifier decision; TLS 1.3 MLKEM768 with "
            "ML-DSA-65 client and server certificates"),
        "openssl": openssl_version,
        "swtpm": command(["swtpm", "--version"], capture=True).stdout.splitlines()[0],
        "tpm2_tools": command(["tpm2_quote", "--version"], capture=True).stdout.strip(),
        "python": sys.version,
        "platform": platform.platform(),
        "conditions": conditions(args.repetitions, args.loss_percent, args.jitter_ms),
        "source_sha256": {
            NODE.name: sha256(NODE),
            Path(__file__).name: sha256(Path(__file__)),
        },
        "limitations": [
            "The TPM is swtpm, not the Windows hardware TPM.",
            "The network is Linux netem emulation, not a physical DDIL radio.",
            "Credential and AK provisioning are outside TTSC.",
            "The verifier is reachable through a path with the same configured impairment.",
        ],
    }
    write_json(output / "manifest.json", manifest)
    print(json.dumps({"output": str(output), "conditions": len(summaries)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
