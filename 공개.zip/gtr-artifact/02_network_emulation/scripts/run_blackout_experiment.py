#!/usr/bin/env python3
"""Run event-triggered GT-R link-blackout and candidate-reuse experiments."""

from __future__ import annotations

import argparse
import collections
import csv
import getpass
import hashlib
import json
import os
import platform
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import run_netns_experiment as network


HERE = Path(__file__).resolve().parent
ENDPOINT = HERE / "gtr_blackout_endpoint.py"
PORT = 47100
TRIGGERS = ("after_m2", "before_m3", "before_m4",
            "before_conf_i", "before_ack_r")
DEFAULT_DURATIONS = (0.2, 0.5, 1.0, 2.0, 5.0)


def command(args: list[str], *, check: bool = True,
            capture: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(args, check=check, text=True, capture_output=capture)


def root_command(args: list[str], *, check: bool = True) -> subprocess.CompletedProcess:
    return command(["sudo", "-n"] + args, check=check)


def endpoint_command(namespace: str, role: str, address: str, config: Path,
                     result: Path, ready: Path, event: Path, release: Path,
                     run_id: str, trigger: str, openssl: str,
                     library_path: str, retry_base_timeout: float = 0.5,
                     max_retries: int = 3,
                     event_wait_timeout: float = 20.0) -> list[str]:
    args = [
        "sudo", "-n", "ip", "netns", "exec", namespace,
        "runuser", "-u", getpass.getuser(), "--", "env",
        f"OPENSSL={openssl}", f"LD_LIBRARY_PATH={library_path}",
        "OPENSSL_CONF=/dev/null", "PYTHONPYCACHEPREFIX=/tmp/gtr-blackout-pycache",
        sys.executable, str(ENDPOINT), "--role", role, "--address", address,
        "--port", str(PORT), "--config", str(config), "--result", str(result),
        "--run-id", run_id, "--pause-event", trigger,
        "--event-file", str(event), "--release-file", str(release),
        "--retry-base-timeout", str(retry_base_timeout),
        "--max-retries", str(max_retries),
        "--event-wait-timeout", str(event_wait_timeout),
    ]
    if role == "responder":
        args.extend(["--ready-file", str(ready)])
    return args


def wait_path(path: Path, processes: list[subprocess.Popen], timeout: float) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if path.exists():
            return
        for process in processes:
            if process.poll() is not None:
                raise RuntimeError(
                    f"endpoint exited before {path.name} (rc={process.returncode})")
        time.sleep(0.005)
    raise TimeoutError(f"timed out waiting for {path.name}")


def load_result(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def start_capture(condition: dict, output: Path, log_handle
                  ) -> tuple[subprocess.Popen, Path]:
    pcap = output / "pcap" / f"{condition['id']}.pcap"
    pcap.parent.mkdir(parents=True, exist_ok=True)
    process = subprocess.Popen([
        "sudo", "-n", "ip", "netns", "exec", network.NS_R,
        "tcpdump", "--immediate-mode", "-i", "any", "-U", "-s", "0",
        "-w", str(pcap), "tcp", "port", str(PORT),
    ], stdout=log_handle, stderr=log_handle, text=True)
    time.sleep(0.5)
    if process.poll() is not None:
        raise RuntimeError(f"tcpdump failed to start (rc={process.returncode})")
    return process, pcap


def stop_capture(process: subprocess.Popen, pcap: Path) -> None:
    time.sleep(0.25)
    root_command(["ip", "netns", "exec", network.NS_R,
                  "pkill", "-INT", "-x", "tcpdump"], check=False)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
    if pcap.exists():
        root_command(["chown", f"{os.getuid()}:{os.getgid()}", str(pcap)],
                     check=False)


def run_trial(condition: dict, number: int, paths: dict, config: Path,
              openssl: str, library_path: str, log_handle) -> dict:
    run_id = f"{condition['id']}-{number:04d}"
    files = {
        "ready": paths["scratch"] / f"{run_id}.ready",
        "event": paths["scratch"] / f"{run_id}.event.json",
        "release": paths["scratch"] / f"{run_id}.release",
        "initiator": paths["scratch"] / f"{run_id}.initiator.json",
        "responder": paths["scratch"] / f"{run_id}.responder.json",
    }
    for path in files.values():
        path.unlink(missing_ok=True)

    responder = subprocess.Popen(endpoint_command(
        network.NS_J, "responder", network.J_ADDR, config, files["responder"],
        files["ready"], files["event"], files["release"], run_id,
        condition["trigger"], openssl, library_path,
        condition.get("retry_base_timeout", 0.5),
        condition.get("max_retries", 3),
        condition.get("event_wait_timeout", 20.0)),
        stdout=log_handle, stderr=log_handle, text=True)
    initiator = None
    orchestration_error = None
    client_rc = server_rc = None
    event_data = None
    blackout_start_ns = restore_ns = None
    try:
        wait_path(files["ready"], [responder], 10)
        initiator = subprocess.Popen(endpoint_command(
            network.NS_I, "initiator", network.J_ADDR, config,
            files["initiator"], files["ready"], files["event"],
            files["release"], run_id, condition["trigger"], openssl,
            library_path, condition.get("retry_base_timeout", 0.5),
            condition.get("max_retries", 3),
            condition.get("event_wait_timeout", 20.0)),
            stdout=log_handle, stderr=log_handle, text=True)
        wait_path(files["event"], [initiator, responder], 10)
        event_data = load_result(files["event"])
        network.apply_netem(100.0, condition["rtt_ms"], 0.0)
        blackout_start_ns = time.monotonic_ns()
        files["release"].write_text("blackout-active\n", encoding="utf-8")
        time.sleep(condition["blackout_seconds"])
        network.apply_netem(0.0, condition["rtt_ms"], 0.0)
        restore_ns = time.monotonic_ns()
        client_rc = initiator.wait(timeout=15)
        server_rc = responder.wait(timeout=15)
    except Exception as exc:
        orchestration_error = f"{type(exc).__name__}: {exc}"
        network.apply_netem(0.0, condition["rtt_ms"], 0.0)
        restore_ns = restore_ns or time.monotonic_ns()
        for process in (initiator, responder):
            if process is not None and process.poll() is None:
                process.kill()
            if process is not None:
                process.wait(timeout=5)
        client_rc = initiator.returncode if initiator is not None else None
        server_rc = responder.returncode

    left = load_result(files["initiator"])
    right = load_result(files["responder"])
    both_ok = bool(left and right and left.get("ok") and right.get("ok"))
    matching = bool(
        both_ok
        and left["session_sha256"] == right["session_sha256"]
        and left["transcript_sha256"] == right["transcript_sha256"]
        and left["epochs"]["converged"] == right["epochs"]["converged"])
    adopted = bool(both_ok and left.get("adopted") and right.get("adopted"))
    candidate_conflicts = sum(
        endpoint.get("candidate_conflicts", 0)
        for endpoint in (left or {}, right or {}))
    success = bool(
        both_ok and matching and adopted and candidate_conflicts == 0
        and client_rc == 0 and server_rc == 0)

    failure_reason = None
    if not success:
        if orchestration_error:
            failure_reason = orchestration_error
        elif left and not left.get("ok"):
            failure_reason = f"initiator:{left.get('error_type')}:{left.get('error')}"
        elif right and not right.get("ok"):
            failure_reason = f"responder:{right.get('error_type')}:{right.get('error')}"
        elif not matching:
            failure_reason = "CONFLICTING_ADOPTION"
        elif candidate_conflicts:
            failure_reason = "CANDIDATE_CONFLICT"
        else:
            failure_reason = "INCOMPLETE_ADOPTION"

    export_ns = max(
        [endpoint.get("adopted_monotonic_ns", 0)
         for endpoint in (left or {}, right or {})])
    recovery_ms = (
        (export_ns - restore_ns) / 1_000_000
        if success and restore_ns is not None else None)
    total_ms = (
        (export_ns - min(left["started_monotonic_ns"],
                         right["started_monotonic_ns"])) / 1_000_000
        if success else None)
    retransmissions = sum(
        endpoint.get("tcp", {}).get("total_retrans") or 0
        for endpoint in (left or {}, right or {}))
    candidate_reuse = (
        (left or {}).get("m2_candidate_reuse_count", 0)
        + (right or {}).get("m1_candidate_reuse_count", 0)
        + (right or {}).get("m3_candidate_reuse_count", 0))

    return {
        "schema": "gtr.blackout.trial.v1", "run_id": run_id,
        "condition": condition, "trial": number, "success": success,
        "failure_reason": failure_reason, "event": event_data,
        "blackout_start_monotonic_ns": blackout_start_ns,
        "link_restored_monotonic_ns": restore_ns,
        "actual_blackout_ms": (
            (restore_ns - blackout_start_ns) / 1_000_000
            if blackout_start_ns and restore_ns else None),
        "recovery_after_restore_ms": recovery_ms,
        "handshake_total_ms": total_ms,
        "attempts": (left or {}).get("attempts"),
        "application_retries": (left or {}).get("application_retries"),
        "tcp_total_retransmissions": retransmissions,
        "candidate_reuse_count": candidate_reuse,
        "candidate_conflicts": candidate_conflicts,
        "candidate_survived_blackout": bool(
            left and left.get("candidate_sha256") and right
            and right.get("pre_candidate_sha256")
            and right.get("final_candidate_sha256")),
        "both_endpoints_adopted": adopted,
        "session_transcript_epoch_match": matching,
        "application_protocol_bytes": sum(
            endpoint.get("application_bytes_sent", 0)
            for endpoint in (left or {}, right or {})),
        "cpu_user_ms": sum(endpoint.get("cpu_user_ms", 0)
                           for endpoint in (left or {}, right or {})),
        "cpu_system_ms": sum(endpoint.get("cpu_system_ms", 0)
                             for endpoint in (left or {}, right or {})),
        "initiator_exit_code": client_rc, "responder_exit_code": server_rc,
        "initiator": left, "responder": right,
    }


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * quantile
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = rank - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def distribution(rows: list[dict], key: str) -> dict:
    values = [row[key] for row in rows if row.get(key) is not None]
    return {
        "median": statistics.median(values) if values else None,
        "p95": percentile(values, 0.95), "p99": percentile(values, 0.99),
        "max": max(values) if values else None,
    }


def summarize(condition: dict, rows: list[dict]) -> dict:
    successful = [row for row in rows if row["success"]]
    return {
        "condition": condition, "trials": len(rows),
        "successes": len(successful),
        "success_rate_percent": 100 * len(successful) / len(rows),
        "recovery_after_restore_ms": distribution(
            successful, "recovery_after_restore_ms"),
        "handshake_total_ms": distribution(successful, "handshake_total_ms"),
        "actual_blackout_ms": distribution(rows, "actual_blackout_ms"),
        "attempts": distribution(successful, "attempts"),
        "application_retries_sum": sum(
            row.get("application_retries") or 0 for row in rows),
        "tcp_retransmissions_sum": sum(
            row.get("tcp_total_retransmissions") or 0 for row in rows),
        "candidate_reuse_sum": sum(
            row.get("candidate_reuse_count") or 0 for row in rows),
        "candidate_survival_failures": sum(
            not row["candidate_survived_blackout"] for row in rows),
        "conflicting_adoptions": sum(
            row["both_endpoints_adopted"]
            and not row["session_transcript_epoch_match"] for row in rows),
        "candidate_conflicts": sum(row["candidate_conflicts"] for row in rows),
        "failure_reasons": dict(collections.Counter(
            row["failure_reason"] for row in rows if row["failure_reason"])),
    }


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    os.replace(temporary, path)


def write_csv(path: Path, summaries: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "condition", "trigger", "blackout_seconds", "trials", "successes",
            "success_rate_percent", "recovery_median_ms", "recovery_p95_ms",
            "total_median_ms", "attempts_median", "application_retries_sum",
            "tcp_retransmissions_sum", "candidate_reuse_sum",
            "candidate_survival_failures", "candidate_conflicts",
            "conflicting_adoptions",
        ])
        for row in summaries:
            writer.writerow([
                row["condition"]["id"], row["condition"]["trigger"],
                row["condition"]["blackout_seconds"], row["trials"],
                row["successes"], row["success_rate_percent"],
                row["recovery_after_restore_ms"]["median"],
                row["recovery_after_restore_ms"]["p95"],
                row["handshake_total_ms"]["median"], row["attempts"]["median"],
                row["application_retries_sum"], row["tcp_retransmissions_sum"],
                row["candidate_reuse_sum"], row["candidate_survival_failures"],
                row["candidate_conflicts"], row["conflicting_adoptions"],
            ])


def parse_csv_floats(value: str) -> tuple[float, ...]:
    return tuple(float(item.strip()) for item in value.split(",") if item.strip())


def parse_csv_strings(value: str) -> tuple[str, ...]:
    return tuple(item.strip() for item in value.split(",") if item.strip())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=100)
    parser.add_argument("--rtt-ms", type=float, default=100.0)
    parser.add_argument("--durations", default="0.2,0.5,1,2,5")
    parser.add_argument("--triggers", default=",".join(TRIGGERS))
    parser.add_argument("--initiator-epoch", type=int, default=0)
    parser.add_argument("--responder-epoch", type=int, default=4)
    parser.add_argument("--output")
    parser.add_argument("--no-pcap", action="store_true")
    args = parser.parse_args()
    durations = parse_csv_floats(args.durations)
    triggers = parse_csv_strings(args.triggers)
    if args.repetitions < 1 or not durations or any(value <= 0 for value in durations):
        parser.error("repetitions and blackout durations must be positive")
    if not triggers or any(value not in TRIGGERS for value in triggers):
        parser.error(f"triggers must be selected from {TRIGGERS}")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-blackout")
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "scratch"
    scratch.mkdir()
    log_path = output / "processes.log"
    openssl, openssl_version = network.openssl_environment()
    library_path = os.environ.get("LD_LIBRARY_PATH", "")
    config = network.provision(
        output, args.initiator_epoch, args.responder_epoch)
    conditions = [
        {"id": f"blackout-{trigger}-{duration:g}s".replace(".", "p"),
         "trigger": trigger, "blackout_seconds": duration,
         "rtt_ms": args.rtt_ms, "loss_percent": 100.0,
         "repetitions": args.repetitions}
        for trigger in triggers for duration in durations
    ]
    summaries: list[dict] = []
    all_rows: list[dict] = []

    network.setup_topology()
    try:
        network.apply_netem(0.0, args.rtt_ms, 0.0)
        network.verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            for condition in conditions:
                print(
                    f"[{condition['id']}] trigger={condition['trigger']} "
                    f"blackout={condition['blackout_seconds']}s "
                    f"n={condition['repetitions']}", flush=True)
                capture = pcap = None
                if not args.no_pcap:
                    capture, pcap = start_capture(condition, output, log_handle)
                condition_rows: list[dict] = []
                try:
                    for number in range(1, args.repetitions + 1):
                        network.apply_netem(0.0, args.rtt_ms, 0.0)
                        row = run_trial(
                            condition, number, {"scratch": scratch}, config,
                            openssl, library_path, log_handle)
                        condition_rows.append(row)
                        all_rows.append(row)
                        with (output / "trials.jsonl").open(
                                "a", encoding="utf-8") as handle:
                            handle.write(json.dumps(row, sort_keys=True) + "\n")
                        if number % 10 == 0 or not row["success"]:
                            print(
                                f"  trial {number}/{args.repetitions}: "
                                f"{'ok' if row['success'] else row['failure_reason']}",
                                flush=True)
                finally:
                    network.apply_netem(0.0, args.rtt_ms, 0.0)
                    if capture is not None and pcap is not None:
                        stop_capture(capture, pcap)
                summary = summarize(condition, condition_rows)
                summaries.append(summary)
                write_json(output / "summary.json", summaries)
                write_csv(output / "summary.csv", summaries)
                print(
                    f"  success={summary['success_rate_percent']:.1f}% "
                    f"recovery_median={summary['recovery_after_restore_ms']['median']}ms "
                    f"retries={summary['application_retries_sum']} "
                    f"reuse={summary['candidate_reuse_sum']}", flush=True)
    finally:
        network.cleanup_topology()

    manifest = {
        "schema": "gtr.blackout.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "network_topology": (
            "gtr_eval_i(10.10.0.2) -- gtr_eval_r -- gtr_eval_j(10.20.0.2)"),
        "baseline_network": f"{args.rtt_ms} ms RTT, zero loss, zero jitter",
        "blackout": "100% netem loss on both router egress directions",
        "retry_policy": (
            "same attempt and byte-identical M1/M3/CONF_I; initial attempt plus "
            "at most three retries with 0.5, 1, 2, and 4 second socket timeouts"),
        "candidate_policy": (
            "bounded responder pre-candidate, authenticated final candidate, and "
            "completion record cached for the process lifetime; identical retries "
            "reuse cached M2/M4 and ACK_R"),
        "cryptography": (
            "OpenSSL 4.0.2 ML-KEM-768 for ephemeral, static, and target-epoch "
            "FS-KEM; HKDF-SHA-256/HMAC-SHA-256 transcript authentication"),
        "openssl": openssl_version, "python": sys.version,
        "platform": platform.platform(), "conditions": conditions,
        "source_sha256": {
            ENDPOINT.name: network.sha256(ENDPOINT),
            Path(__file__).name: network.sha256(Path(__file__)),
            "gtr_net_endpoint.py": network.sha256(HERE / "gtr_net_endpoint.py"),
            "reauth_demo.py": network.sha256(HERE / "reauth_demo.py"),
        },
        "limitations": [
            "Blackout is controlled netem loss, not a physical radio outage.",
            "The endpoint processes remain alive; crash recovery is not tested.",
            "The pre-candidate is volatile and survives only the link blackout.",
            "TTSC includes the protected CONF_I/ACK_R adoption exchange; the final "
            "ACK receipt only terminates the responder test process and changes no state.",
        ],
    }
    write_json(output / "manifest.json", manifest)
    print(json.dumps({
        "output": str(output), "conditions": len(summaries),
        "trials": len(all_rows), "successes": sum(row["success"] for row in all_rows),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
