#!/usr/bin/env python3
"""Validate and plot the stateful GT-R reconnect-frequency campaign."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


EXPECTED_COUNTS = (1, 2, 5, 10)


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fmt(value: float | None, digits: int = 1) -> str:
    return "-" if value is None else f"{value:.{digits}f}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    summaries = load(args.input / "summary.json")
    cycles = load_jsonl(args.input / "cycles.jsonl")
    missions = load_jsonl(args.input / "missions.jsonl")
    counts = tuple(
        row["condition"]["reconnects_per_mission"] for row in summaries)
    if counts != EXPECTED_COUNTS:
        raise ValueError(f"unexpected reconnect-count conditions: {counts}")
    if len(missions) != 400:
        raise ValueError(f"expected 400 missions, found {len(missions)}")
    if len(cycles) != 1800:
        raise ValueError(f"expected 1800 reconnect cycles, found {len(cycles)}")
    if any(row["conflicting_adoptions"] for row in summaries):
        raise ValueError("a condition contains conflicting adopted state")
    for row in cycles:
        if row["success"]:
            if not all((
                row["session_transcript_chain_match"],
                row["epoch_convergence"],
                row["candidate_cleanup_verified"],
                row["private_committed_state_match"],
            )):
                raise ValueError("successful cycle lacks a required invariant")

    x = np.arange(len(counts))
    success_rate = [row["mission_success_rate_percent"] for row in summaries]
    ttsc_median = [
        row["mission_cumulative_ttsc_ms"]["median"] for row in summaries]
    ttsc_p95 = [
        row["mission_cumulative_ttsc_ms"]["p95"] for row in summaries]
    bytes_median = [
        row["mission_cumulative_application_bytes"]["median"] / 1024
        for row in summaries]
    validations = {
        "Epoch convergence": [
            100 * (row["executed_cycles"] - row["epoch_convergence_failures"])
            / row["executed_cycles"] for row in summaries],
        "Key/transcript/chain match": [
            100 * (row["executed_cycles"]
                   - row["session_transcript_chain_mismatches"])
            / row["executed_cycles"] for row in summaries],
        "Candidate cleanup": [
            100 * (row["executed_cycles"] - row["candidate_cleanup_failures"])
            / row["executed_cycles"] for row in summaries],
        "Committed-state match": [
            100 * (row["executed_cycles"] - row["private_state_mismatches"])
            / row["executed_cycles"] for row in summaries],
    }

    fig, axes = plt.subplots(2, 2, figsize=(11.2, 7.5))
    bars = axes[0, 0].bar(x, success_rate, color="#2878b5", width=0.62)
    axes[0, 0].set_xticks(x, labels=counts)
    axes[0, 0].set_ylim(0, 105)
    axes[0, 0].set_xlabel("Reconnects per 600-s logical mission")
    axes[0, 0].set_ylabel("Mission success rate (%)")
    axes[0, 0].set_title("End-to-end mission completion")
    axes[0, 0].grid(True, axis="y", alpha=0.3)
    axes[0, 0].bar_label(bars, fmt="%.1f%%", padding=3, fontsize=9)

    axes[0, 1].plot(counts, ttsc_median, "o-", linewidth=1.8,
                    label="median", color="#2878b5")
    axes[0, 1].plot(counts, ttsc_p95, "s--", linewidth=1.5,
                    label="p95", color="#d95f02")
    axes[0, 1].set_xlabel("Reconnects per 600-s logical mission")
    axes[0, 1].set_ylabel("Cumulative TTSC (ms)")
    axes[0, 1].set_title("Cumulative secure-completion time")
    axes[0, 1].grid(True, alpha=0.3)
    axes[0, 1].legend(frameon=False)

    axes[1, 0].plot(counts, bytes_median, "o-", linewidth=1.8,
                    color="#5a9f68")
    for count, value in zip(counts, bytes_median):
        axes[1, 0].annotate(
            f"{value:.1f}", (count, value), xytext=(0, 6),
            textcoords="offset points", ha="center", fontsize=8)
    axes[1, 0].set_xlabel("Reconnects per 600-s logical mission")
    axes[1, 0].set_ylabel("Cumulative framed JSON bytes (KiB)")
    axes[1, 0].set_title("Cumulative reconnect traffic")
    axes[1, 0].grid(True, alpha=0.3)

    markers = ("o", "s", "^", "D")
    for (label, values), marker in zip(validations.items(), markers):
        axes[1, 1].plot(counts, values, marker=marker, linewidth=1.5,
                        label=label)
    axes[1, 1].set_ylim(95, 100.25)
    axes[1, 1].set_xlabel("Reconnects per 600-s logical mission")
    axes[1, 1].set_ylabel("Validated cycles (%)")
    axes[1, 1].set_title("Per-cycle state invariants")
    axes[1, 1].grid(True, alpha=0.3)
    axes[1, 1].legend(frameon=False, fontsize=8, loc="lower left")

    fig.suptitle(
        "GT-R reconnect frequency (100 missions per condition, RTT = 100 ms)")
    fig.tight_layout()
    stem = args.output / "gt_r_reconnect_frequency_n100"
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)

    report = [
        "# GT-R reconnect-frequency experiment",
        "",
        "The campaign executed 100 missions at each of 1, 2, 5, and 10 "
        "reconnects within a fixed 600-second logical mission window. Before "
        "each reconnect, both Linux router egress paths were changed to 100% "
        "loss and restored to a clean 100 ms RTT before M1. Every cycle used "
        "a fresh TCP connection and the real OpenSSL ML-KEM M1-M4 path.",
        "",
        "Unlike the independent-trial campaigns, the session ratchet state is "
        "stateful here: after a successful cycle, the two endpoints must derive "
        "the same next-chain digest, persist matching committed state, and use "
        "that chain as the input to the following outage. During each outage, "
        "i advances by one epoch and j by five; reconnection therefore tests "
        "delta = 4 and converges to max(e_i,e_j)+1 on every cycle.",
        "",
        "| Reconnects / mission | Missions completed | Cycles completed | "
        "Cumulative TTSC median / p95 | Cumulative bytes median | "
        "Invariant failures | Conflicts |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summaries:
        invariant_failures = (
            row["epoch_convergence_failures"]
            + row["session_transcript_chain_mismatches"]
            + row["candidate_cleanup_failures"]
            + row["private_state_mismatches"])
        report.append(
            f"| {row['condition']['reconnects_per_mission']} | "
            f"{row['successful_missions']}/{row['missions']} | "
            f"{row['successful_cycles']}/{row['executed_cycles']} | "
            f"{fmt(row['mission_cumulative_ttsc_ms']['median'])} / "
            f"{fmt(row['mission_cumulative_ttsc_ms']['p95'])} ms | "
            f"{fmt(row['mission_cumulative_application_bytes']['median'], 0)} B | "
            f"{invariant_failures} | {row['conflicting_adoptions']} |")
    report.extend([
        "",
        "## Interpretation",
        "",
        f"Across {len(missions)} missions and {len(cycles)} sequential "
        "reconnect cycles, the result measures whether repeated adoption causes "
        "state divergence or cumulative failure. Mission success requires every "
        "requested cycle to complete; it is therefore stricter than per-cycle "
        "success. Cumulative TTSC and bytes are sums over the reconnects and do "
        "not include the modeled disconnected interval.",
        "",
        "## Interpretation boundary",
        "",
        "The 600-second window is logical and is not replayed in real time. "
        "Link down/up transitions are applied with netem, but the restored path "
        "is clean TCP at 100 ms RTT rather than a physical DDIL radio. Candidate "
        "cleanup and committed-state matching are validated in the software "
        "endpoints; physical root-of-trust persistence is outside this campaign. "
        "The byte counter covers length-prefixed JSON with base64 fields, so it "
        "is an implementation-transport measurement rather than the protocol's "
        "compact binary wire-size estimate. "
        "Crash recovery, candidate reuse after packet loss, and asymmetric loss "
        "were evaluated in separate campaigns.",
        "",
    ])
    (args.output / "RESULTS.md").write_text(
        "\n".join(report), encoding="utf-8")

    targets = [
        args.input / "cycles.jsonl",
        args.input / "missions.jsonl",
        args.input / "summary.json",
        args.input / "summary.csv",
        args.input / "manifest.json",
        Path(__file__).resolve(),
    ]
    targets.extend(sorted((args.input / "pcap").glob("*.pcap")))
    (args.output / "artifact_checksums.json").write_text(
        json.dumps(
            {str(path.resolve()): sha256(path) for path in targets},
            indent=2, sort_keys=True) + "\n",
        encoding="utf-8")
    print(json.dumps({
        "missions": len(missions),
        "successful_missions": sum(row["success"] for row in missions),
        "cycles": len(cycles),
        "successful_cycles": sum(row["success"] for row in cycles),
        "conflicting_adoptions": sum(
            row["conflicting_adoptions"] for row in summaries),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
