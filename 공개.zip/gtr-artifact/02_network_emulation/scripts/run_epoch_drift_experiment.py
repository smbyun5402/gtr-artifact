#!/usr/bin/env python3
"""Evaluate GT-R after a controlled partition and independent epoch drift."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

import run_netns_experiment as network


HERE = Path(__file__).resolve().parent
DEFAULT_DELTAS = (0, 1, 2, 4, 6, 8, 9, 10, 12)


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * quantile
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = rank - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def provision_condition(output: Path, condition: dict) -> Path:
    root = output / "provision" / condition["id"]
    config_path = network.provision(
        root, condition["epoch_i"], condition["epoch_j"])
    config = json.loads(config_path.read_text(encoding="utf-8"))
    config.update({
        "sid": f"gtr-partition-{condition['id']}",
        "pre_partition_epoch_i": condition["base_epoch"],
        "pre_partition_epoch_j": condition["base_epoch"],
        "lce_i": condition["base_epoch"],
        "lce_j": condition["base_epoch"],
        "g_i": condition["g_i"],
        "g_j": condition["g_j"],
        "delta_max": condition["delta_max"],
        "g_max": condition["g_max"],
        "policy_expected": condition["expected_decision"],
        "note": (
            "Static and epoch-indexed KEM credentials plus the independently "
            "advanced ratchet states are provisioned before reconnect timing."
        ),
    })
    write_json(config_path, config)
    return config_path


def partition_probe() -> bool:
    probe = network.root_command([
        "ip", "netns", "exec", network.NS_I,
        "ping", "-c", "1", "-W", "1", network.J_ADDR,
    ], check=False, capture=True)
    return probe.returncode != 0


def classify(row: dict, condition: dict) -> dict:
    expected = condition["expected_decision"]
    left = row.get("initiator") or {}
    right = row.get("responder") or {}
    any_adoption = bool(left.get("adopted") or right.get("adopted"))
    any_key_export = bool(
        left.get("session_sha256") or right.get("session_sha256")
        or left.get("exported_peer_id") or right.get("exported_peer_id")
    )

    if row.get("success") and left.get("policy_decision") == "R1" \
            and right.get("policy_decision") == "R1":
        actual = "R1"
    elif (left.get("policy_decision") == "R2"
          and left.get("error_type") == "PolicyLimitExceeded"
          and not any_adoption and not any_key_export):
        actual = "R2"
    else:
        actual = "ERROR"

    expected_epoch = max(condition["epoch_i"], condition["epoch_j"]) + 1
    epoch_converged = bool(
        actual == "R1"
        and left.get("epochs", {}).get("converged") == expected_epoch
        and right.get("epochs", {}).get("converged") == expected_epoch
        and row.get("session_transcript_epoch_match")
    )
    result = dict(row)
    result.update({
        "expected_policy_decision": expected,
        "actual_policy_decision": actual,
        "policy_outcome_correct": actual == expected,
        "expected_converged_epoch": expected_epoch,
        "epoch_converged": epoch_converged,
        "unexpected_adoption": expected == "R2" and any_adoption,
        "unexpected_key_export": expected == "R2" and any_key_export,
        "fast_forward": {
            "initiator_steps": left.get("fast_forward_steps"),
            "initiator_cpu_us": left.get("fast_forward_cpu_us"),
            "responder_steps": right.get("fast_forward_steps"),
            "responder_cpu_us": right.get("fast_forward_cpu_us"),
        },
    })
    return result


def summarize(condition: dict, rows: list[dict], probe_blocked: bool) -> dict:
    r1 = [row for row in rows if row["actual_policy_decision"] == "R1"]
    latencies = [row["ttsc_ms"] for row in r1 if row.get("ttsc_ms") is not None]
    ff_i = [
        row["fast_forward"]["initiator_cpu_us"] for row in r1
        if row["fast_forward"]["initiator_cpu_us"] is not None
    ]
    ff_j = [
        row["fast_forward"]["responder_cpu_us"] for row in r1
        if row["fast_forward"]["responder_cpu_us"] is not None
    ]
    return {
        "condition": condition,
        "partition_probe_blocked": probe_blocked,
        "trials": len(rows),
        "policy_correct": sum(row["policy_outcome_correct"] for row in rows),
        "policy_correct_percent": 100 * sum(
            row["policy_outcome_correct"] for row in rows) / len(rows),
        "r1_completions": len(r1),
        "epoch_convergences": sum(row["epoch_converged"] for row in rows),
        "unexpected_adoptions": sum(row["unexpected_adoption"] for row in rows),
        "unexpected_key_exports": sum(row["unexpected_key_export"] for row in rows),
        "ttsc_ms": {
            "median": statistics.median(latencies) if latencies else None,
            "p95": percentile(latencies, 0.95),
            "p99": percentile(latencies, 0.99),
            "max": max(latencies) if latencies else None,
        },
        "fast_forward_cpu_us": {
            "initiator_median": statistics.median(ff_i) if ff_i else None,
            "initiator_p95": percentile(ff_i, 0.95),
            "responder_median": statistics.median(ff_j) if ff_j else None,
            "responder_p95": percentile(ff_j, 0.95),
        },
    }


def write_summary_csv(path: Path, summaries: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "delta", "epoch_i", "epoch_j", "expected_decision", "trials",
            "policy_correct", "r1_completions", "epoch_convergences",
            "unexpected_adoptions", "unexpected_key_exports",
            "ttsc_median_ms", "ttsc_p95_ms", "initiator_ff_steps",
            "initiator_ff_cpu_median_us", "responder_ff_steps",
            "responder_ff_cpu_median_us", "partition_probe_blocked",
        ])
        for row in summaries:
            condition = row["condition"]
            writer.writerow([
                condition["delta"], condition["epoch_i"], condition["epoch_j"],
                condition["expected_decision"], row["trials"],
                row["policy_correct"], row["r1_completions"],
                row["epoch_convergences"], row["unexpected_adoptions"],
                row["unexpected_key_exports"], row["ttsc_ms"]["median"],
                row["ttsc_ms"]["p95"], condition["delta"],
                row["fast_forward_cpu_us"]["initiator_median"], 0,
                row["fast_forward_cpu_us"]["responder_median"],
                row["partition_probe_blocked"],
            ])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=100)
    parser.add_argument("--deltas", default=",".join(map(str, DEFAULT_DELTAS)))
    parser.add_argument("--delta-max", type=int, default=8)
    parser.add_argument("--g-max", type=int, default=16)
    parser.add_argument("--base-epoch", type=int, default=2)
    parser.add_argument("--rtt-ms", type=float, default=100.0)
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument("--output")
    parser.add_argument("--no-pcap", action="store_true")
    parser.add_argument("--keep-namespaces", action="store_true")
    args = parser.parse_args()
    deltas = tuple(int(value.strip()) for value in args.deltas.split(","))
    if args.repetitions < 1 or any(delta < 0 for delta in deltas):
        parser.error("repetitions must be positive and deltas non-negative")
    if args.g_max < max(deltas) + 1:
        parser.error(
            "g-max must be at least max(delta)+1 so this suite isolates delta")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(args.output).resolve() if args.output else (
        HERE / "results" / f"{stamp}-epoch-drift")
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "scratch"
    scratch.mkdir()
    log_path = output / "processes.log"
    openssl, openssl_version = network.openssl_environment()
    library_path = os.environ.get("LD_LIBRARY_PATH", "")

    epoch_i = args.base_epoch + 1
    conditions = []
    for delta in deltas:
        epoch_j = epoch_i + delta
        conditions.append({
            "id": f"delta{delta}",
            "delta": delta,
            "delta_max": args.delta_max,
            "g_max": args.g_max,
            "base_epoch": args.base_epoch,
            "epoch_i": epoch_i,
            "epoch_j": epoch_j,
            "g_i": epoch_i - args.base_epoch,
            "g_j": epoch_j - args.base_epoch,
            "expected_decision": "R1" if delta <= args.delta_max else "R2",
            "rtt_ms": args.rtt_ms,
            "loss_percent": 0.0,
            "jitter_ms": 0.0,
            "repetitions": args.repetitions,
        })

    paths = {"output": output, "scratch": scratch}
    summaries = []
    all_rows = []
    network.setup_topology()
    try:
        network.apply_netem(0, 0)
        network.verify_connectivity()
        with log_path.open("a", encoding="utf-8") as log_handle:
            for condition in conditions:
                config = provision_condition(output, condition)
                print(
                    f"[{condition['id']}] epochs=({condition['epoch_i']},"
                    f"{condition['epoch_j']}) expected={condition['expected_decision']} "
                    f"n={condition['repetitions']}", flush=True)

                network.apply_netem(100.0, 0.0)
                probe_blocked = partition_probe()
                network.apply_netem(0.0, args.rtt_ms)
                network.verify_connectivity()

                capture = pcap = None
                if not args.no_pcap:
                    capture, pcap = network.start_capture(
                        condition, output, log_handle)
                condition_rows = []
                try:
                    for trial_number in range(1, args.repetitions + 1):
                        raw = network.run_trial(
                            condition, trial_number, paths, config,
                            args.timeout, openssl, library_path, log_handle)
                        row = classify(raw, condition)
                        condition_rows.append(row)
                        all_rows.append(row)
                        with (output / "trials.jsonl").open(
                                "a", encoding="utf-8") as handle:
                            handle.write(json.dumps(row, sort_keys=True) + "\n")
                        if trial_number % 20 == 0 or not row["policy_outcome_correct"]:
                            print(
                                f"  trial {trial_number}/{args.repetitions}: "
                                f"{row['actual_policy_decision']} "
                                f"({'correct' if row['policy_outcome_correct'] else 'ERROR'})",
                                flush=True)
                finally:
                    if capture is not None and pcap is not None:
                        network.stop_capture(capture, pcap)

                summary = summarize(condition, condition_rows, probe_blocked)
                summaries.append(summary)
                write_json(output / "summary.json", summaries)
                write_summary_csv(output / "summary.csv", summaries)
                print(
                    f"  policy={summary['policy_correct_percent']:.1f}% "
                    f"R1={summary['r1_completions']} "
                    f"unexpected-export={summary['unexpected_key_exports']}",
                    flush=True)
    finally:
        if not args.keep_namespaces:
            network.cleanup_topology()

    manifest = {
        "schema": "gtr.netns.epoch-drift.manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "experiment": "controlled partition, independent epoch drift, reconnect",
        "network_topology": (
            "gtr_eval_i(10.10.0.2) -- gtr_eval_r -- "
            "gtr_eval_j(10.20.0.2)"
        ),
        "partition_validation": (
            "100% bidirectional netem loss and failed ICMP probe before link restore"
        ),
        "reconnect_network": {
            "rtt_ms": args.rtt_ms,
            "loss_percent": 0.0,
            "jitter_ms": 0.0,
        },
        "bounds": {"delta_max": args.delta_max, "g_max": args.g_max},
        "isolation_note": (
            "G_max is held above every local gap so only Delta_max changes the "
            "R1/R2 decision; local-gap sensitivity is a separate experiment."
        ),
        "timing_scope": (
            "GT-R TTSC covers fresh TCP establishment through initiator M4 "
            "verification; enrollment, offline ticks, partition, and ICMP probes "
            "are excluded. Fast-forward CPU timing covers only chain advancement "
            "from each retained local epoch to e'-1."
        ),
        "cryptography": (
            "OpenSSL ML-KEM-768 for ephemeral, static, and epoch-indexed FS-KEM; "
            "HKDF-SHA-256/HMAC-SHA-256 for ratchet and authentication"
        ),
        "openssl": openssl_version,
        "python": sys.version,
        "platform": platform.platform(),
        "conditions": conditions,
        "source_sha256": {
            Path(__file__).name: sha256(Path(__file__)),
            network.ENDPOINT.name: sha256(network.ENDPOINT),
            "run_netns_experiment.py": sha256(Path(network.__file__)),
            "reauth_demo.py": sha256(HERE / "reauth_demo.py"),
        },
        "outputs": {
            "summary_json": "summary.json",
            "summary_csv": "summary.csv",
            "trials_jsonl": "trials.jsonl",
            "pcap_directory": None if args.no_pcap else "pcap",
            "process_log": "processes.log",
        },
        "limitations": [
            "The partition and reconnect path use Linux netem, not a physical radio.",
            "The suite isolates inter-peer drift by configuring G_max above every local gap.",
            "R2 means fail-closed policy selection; the verifier-assisted exchange is not run.",
            "The rejected path authenticates M2 before selecting R2 and never adopts or exports a key.",
        ],
    }
    write_json(output / "manifest.json", manifest)
    if not all(row["policy_outcome_correct"] for row in all_rows):
        return 2
    print(json.dumps({
        "output": str(output),
        "trials": len(all_rows),
        "policy_correct": sum(row["policy_outcome_correct"] for row in all_rows),
        "unexpected_key_exports": sum(row["unexpected_key_export"] for row in all_rows),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
