#!/usr/bin/env python3
"""Validate, summarize, and plot the GT-R epoch-drift campaign."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


EXPECTED_DELTAS = (0, 1, 2, 4, 6, 8, 9, 10, 12)
DELTA_MAX = 8


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fmt(value: float | None, digits: int = 2) -> str:
    return "-" if value is None else f"{value:.{digits}f}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    summaries = sorted(
        load(args.input / "summary.json"),
        key=lambda row: row["condition"]["delta"],
    )
    trials = load_jsonl(args.input / "trials.jsonl")
    deltas = tuple(row["condition"]["delta"] for row in summaries)
    if deltas != EXPECTED_DELTAS:
        raise ValueError(f"unexpected drift conditions: {deltas}")
    if len(trials) != 900:
        raise ValueError(f"expected 900 raw trials, got {len(trials)}")
    if any(row["trials"] != 100 for row in summaries):
        raise ValueError("each drift condition must contain 100 trials")
    if any(not row["partition_probe_blocked"] for row in summaries):
        raise ValueError("at least one 100% loss partition probe was not blocked")
    if any(not row["policy_outcome_correct"] for row in trials):
        raise ValueError("at least one trial made the wrong R1/R2 decision")
    if any(row["unexpected_adoption"] or row["unexpected_key_export"]
           for row in trials):
        raise ValueError("an out-of-bound trial adopted or exported a key")
    for row in summaries:
        delta = row["condition"]["delta"]
        if delta <= DELTA_MAX:
            if row["r1_completions"] != 100 or row["epoch_convergences"] != 100:
                raise ValueError(f"delta={delta} did not complete and converge 100/100")
        elif row["r1_completions"] != 0 or row["epoch_convergences"] != 0:
            raise ValueError(f"delta={delta} unexpectedly completed R1")

    x = np.asarray(deltas, dtype=float)
    correct = np.asarray([row["policy_correct_percent"] for row in summaries])
    colors = ["#2878b5" if delta <= DELTA_MAX else "#d95f02" for delta in deltas]

    accepted = [row for row in summaries if row["condition"]["delta"] <= DELTA_MAX]
    xa = np.asarray([row["condition"]["delta"] for row in accepted], dtype=float)
    median = np.asarray([row["ttsc_ms"]["median"] for row in accepted])
    p95 = np.asarray([row["ttsc_ms"]["p95"] for row in accepted])
    ff_median = np.asarray([
        row["fast_forward_cpu_us"]["initiator_median"] for row in accepted
    ])
    ff_p95 = np.asarray([
        row["fast_forward_cpu_us"]["initiator_p95"] for row in accepted
    ])

    fig, axes = plt.subplots(1, 3, figsize=(12.0, 3.65))
    positions = np.arange(len(x))
    axes[0].bar(positions, correct, color=colors)
    axes[0].set_xticks(positions, labels=[str(int(value)) for value in x])
    axes[0].set_ylim(0, 112)
    axes[0].set_xlabel("Epoch drift, delta")
    axes[0].set_ylabel("Correct policy outcome (%)")
    axes[0].grid(True, axis="y", alpha=0.3)
    for index, delta in enumerate(deltas):
        decision = "R1" if delta <= DELTA_MAX else "R2"
        axes[0].text(index, 101.5, decision, ha="center", va="bottom", fontsize=8)

    axes[1].plot(xa, median, "o-", linewidth=1.8, label="median")
    axes[1].plot(xa, p95, "s--", linewidth=1.5, label="p95")
    axes[1].set_xlabel("Accepted epoch drift, delta")
    axes[1].set_ylabel("TTSC (ms)")
    axes[1].grid(True, alpha=0.3)
    axes[1].legend(frameon=False)

    axes[2].plot(xa, ff_median, "o-", linewidth=1.8, label="median")
    axes[2].plot(xa, ff_p95, "s--", linewidth=1.5, label="p95")
    axes[2].set_xlabel("Accepted epoch drift, delta")
    axes[2].set_ylabel("Initiator fast-forward CPU (us)")
    axes[2].grid(True, alpha=0.3)
    axes[2].legend(frameon=False)

    fig.suptitle(
        "GT-R controlled-partition epoch convergence "
        "(drift limit = 8, RTT = 100 ms, n = 100)"
    )
    fig.tight_layout()
    stem = args.output / "gt_r_epoch_drift_n100"
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)

    report = [
        "# GT-R controlled-partition and epoch-drift experiment",
        "",
        "Each condition began from a common committed epoch 2. During a verified "
        "100% loss partition, the initiator advanced to epoch 3 and the responder "
        "advanced to epoch 3 + delta. After link restoration, the real OpenSSL "
        "ML-KEM M1-M4 path ran at 100 ms configured RTT. Delta_max was 8. G_max "
        "was fixed at 16 so local-gap rejection could not confound the drift sweep.",
        "",
        "| delta | Reconnect epochs | Expected | Correct policy | R1 completed | "
        "Converged | Median TTSC | p95 TTSC | Initiator FF median | Unexpected export |",
        "|---:|:---:|:---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summaries:
        c = row["condition"]
        report.append(
            f"| {c['delta']} | ({c['epoch_i']}, {c['epoch_j']}) | "
            f"{c['expected_decision']} | {row['policy_correct']}/{row['trials']} | "
            f"{row['r1_completions']}/{row['trials']} | "
            f"{row['epoch_convergences']}/{row['trials']} | "
            f"{fmt(row['ttsc_ms']['median'])} ms | "
            f"{fmt(row['ttsc_ms']['p95'])} ms | "
            f"{fmt(row['fast_forward_cpu_us']['initiator_median'], 3)} us | "
            f"{row['unexpected_key_exports']} |"
        )
    report.extend([
        "",
        "## Result",
        "",
        "All 600 in-bound executions (delta 0 through 8) completed M1-M4, "
        "produced equal session-key and transcript hashes at both endpoints, and "
        "adopted e' = max(e_i, e_j) + 1. All 300 out-of-bound executions "
        "(delta 9, 10, and 12) authenticated M2 and selected R2 without any state "
        "adoption or session-key export. Thus all 900 policy outcomes matched the "
        "configured Delta_max = 8 decision rule.",
        "",
        "## Interpretation boundary",
        "",
        "This is a controlled Linux netem/TCP experiment, not a physical DDIL "
        "radio trial. R2 denotes fail-closed policy selection; an online verifier "
        "was intentionally not contacted. The G_max value was raised only to "
        "isolate inter-peer epoch drift, so local no-contact-gap sensitivity must "
        "be reported separately.",
        "",
    ])
    (args.output / "RESULTS.md").write_text("\n".join(report), encoding="utf-8")

    targets = [
        args.input / "trials.jsonl",
        args.input / "summary.json",
        args.input / "summary.csv",
        args.input / "manifest.json",
        Path(__file__).resolve(),
    ]
    targets.extend(sorted((args.input / "pcap").glob("*.pcap")))
    (args.output / "artifact_checksums.json").write_text(
        json.dumps(
            {str(path.resolve()): sha256(path) for path in targets},
            indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "trials": len(trials),
        "policy_correct": sum(row["policy_outcome_correct"] for row in trials),
        "r1_completions": sum(row["actual_policy_decision"] == "R1" for row in trials),
        "r2_fail_closed": sum(row["actual_policy_decision"] == "R2" for row in trials),
        "unexpected_key_exports": sum(row["unexpected_key_export"] for row in trials),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
