# Rights and external dependencies

## Release authorization

The input experimental ZIP did not contain a repository-level LICENSE or COPYRIGHT file. This preparation step does not assign copyright ownership, grant an open-source/data license, or establish permission from coauthors, an institution, a funder, or third-party rights holders.

The authors selected GitHub for dissemination. No project-wide reuse license was selected when this package was prepared on 2026-10-16. See `LICENSE_NOTICE.txt`. Code and data may need separate license decisions. Until a license is actually chosen by the responsible rights holders, this package must not be described as MIT-, Apache-, GPL-, or CC-licensed, or as unrestricted open source. Before uploading, the authors remain responsible for confirming permission to distribute the included source/data and compliance with institutional, funder, and upstream obligations.

No third-party source tree, compiler, cryptographic library binary, prover binary, VM disk, or manuscript artwork is included. Existing source comments and citations were retained. The absence of a third-party copyright header does not by itself prove that every included line is independently owned; authors should review provenance, especially the fTPM integration harness.

## Dependencies to obtain separately

| Component | Role | Source |
|---|---|---|
| Python | Simulation, result inspection, experiment harnesses | https://www.python.org/ |
| NumPy / Matplotlib | Numerical simulation and plotting | https://numpy.org/ ; https://matplotlib.org/ |
| cryptography / OpenSSL | Software cryptographic backends | https://cryptography.io/ ; https://openssl.org/ |
| wolfSSL / wolfTPM | Software-fTPM integration | https://github.com/wolfSSL/wolfssl ; https://github.com/wolfSSL/wolfTPM |
| Linux iproute2/netem | Namespace/network emulation | https://www.kernel.org/ ; distribution packages |
| QEMU / swtpm / TPM2 tools | Virtual-TPM lab | https://www.qemu.org/ ; https://github.com/stefanberger/swtpm ; https://github.com/tpm2-software/tpm2-tools |
| Tamarin / ProVerif | Model-specific formal analysis | https://tamarin-prover.com/ ; https://bblanche.gitlabpages.inria.fr/proverif/ |
| Microsoft Visual C++ / Windows SDK / TPM Base Services | Native physical-TPM helper build | Microsoft official tooling |

These components retain their own licenses. The table is an inventory, not a license-compatibility determination. Consult the actual upstream licenses for the exact versions used. Pinned fTPM commits and recorded backend versions remain in the relevant README/manifests.

The reconstructed D2D-MAP, PAF-IoD, and KEMTLS reference flows must not be represented as original-author implementations. Their limitations and literature provenance remain in `05_external_protocol_comparison/`.
