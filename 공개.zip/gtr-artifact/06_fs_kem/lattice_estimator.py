#!/usr/bin/env python3
# Core-SVP lattice-security estimator for the DR-KEM module-LWE parameters.
# Implements the standard primal-uSVP (2016) and dual attack estimates with the
# GSA + BKZ root-Hermite factor and the core-SVP cost model used by the NIST
# ML-KEM/ML-DSA submissions (classical 0.292*beta, quantum 0.265*beta bits).
# NOT the full Albrecht et al. lattice-estimator (Sage); a self-contained core-SVP
# approximation, calibrated against ML-KEM-768 (should reproduce ~181-bit classical
# core-SVP). Used to fix DR-cons / DR-chal and to size the modulus q that a
# depth-d binary-tree-encryption leaf needs for correct decapsulation.
#
# Run:  python lattice_estimator.py   -> calibration + DR-cons/DR-chal + macros

import os
import math
import sys
import json
import hashlib
import platform
from datetime import datetime, timezone


def delta_bkz(beta):
    """Root-Hermite factor delta_0 for BKZ with block size beta (Chen 2013)."""
    if beta < 50:
        beta = 50
    return (((math.pi * beta) ** (1.0 / beta)) * beta / (2 * math.pi * math.e)) ** (
        1.0 / (2.0 * (beta - 1)))


def primal_coresvp(n, q, sigma, max_samples=None):
    """Smallest BKZ block size beta for which the primal-uSVP attack recovers the
    LWE secret, via the 2016 estimate, minimized over the number of samples m.
    Returns (beta, m). core-SVP bit costs are 0.292*beta / 0.265*beta."""
    if max_samples is None:
        max_samples = 2 * n
    best = None
    for m in range(n, max_samples + 1, 8):
        d = m + n + 1                       # embedding lattice dimension
        for beta in range(50, 1200):
            dlt = delta_bkz(beta)
            # projected norm of the unique short vector vs. GSA length at position d-beta
            lhs = math.sqrt(beta) * sigma
            rhs = (dlt ** (2 * beta - d - 1)) * (q ** (float(m) / d))
            if lhs <= rhs:
                if best is None or beta < best[0]:
                    best = (beta, m)
                break
    return best


def dual_coresvp(n, q, sigma, max_samples=None):
    """Dual-attack block size (distinguishing) via the standard core-SVP estimate."""
    if max_samples is None:
        max_samples = 2 * n
    best = None
    for m in range(n, max_samples + 1, 8):
        d = m + n
        for beta in range(50, 1200):
            dlt = delta_bkz(beta)
            # dual vector length; distinguishing advantage ~ exp(-pi*(tau)^2), tau=len*sigma/q
            length = (dlt ** (d - 1)) * (q ** (float(n) / d))
            tau = length * sigma / q
            # advantage per sample ~ exp(-pi tau^2); require it not negligible for the
            # attacker (>= 2^-... ) while cost stays below the SVP oracle count.
            if tau <= 1.0:                  # distinguishable regime
                adv = math.exp(-math.pi * tau * tau)
                # attack repeats ~1/adv^2 times; fold into cost as +2*log2(1/adv)
                rep = 0.0 if adv >= 1 else 2 * math.log2(1.0 / adv)
                cost = 0.292 * beta + rep
                if best is None or cost < best[2]:
                    best = (beta, m, cost)
                break
    return best


def coresvp_bits(beta):
    return 0.292 * beta, 0.265 * beta       # classical, quantum


def report(name, N, k, log2q, sigma):
    n = k * N
    q = 2 ** log2q
    pb, pm = primal_coresvp(n, q, sigma)
    pc, pq = coresvp_bits(pb)
    d = dual_coresvp(n, q, sigma)
    dc = d[2] if d else float('inf')
    print(f"{name:16s} N={N} k={k} n={n} log2q={log2q:.1f} sigma={sigma:.2f} "
          f"-> primal beta={pb} classical={pc:.0f} quantum={pq:.0f} | dual~{dc:.0f}")
    return dict(name=name, N=N, k=k, n=n, log2q=log2q, sigma=sigma,
                beta=pb, classical=pc, quantum=pq, dual=dc)


# ---- decryption-failure / correctness for a depth-d BTE leaf --------------------
def leaf_logq_needed(N, k, sigma, depth, base_gauss=4.0):
    """Modulus (log2 q) a depth-`depth` ABB leaf needs for correct dual-Regev
    decapsulation. Each SampleLeft/SampleRight delegation inflates the trapdoor
    Gaussian width by ~ C*sqrt(N*k*log q); after `depth` levels the leaf width is
    s_d ~ base * (C*sqrt(N*k*log q))^depth. Correctness needs q > s_d * sqrt((d+1)kN)
    * omega(sqrt(log n)). We solve the implicit relation by iteration."""
    C = 1.0                                  # smoothing constant (conservative ~1)
    logq = 20.0
    for _ in range(200):
        width_factor = C * math.sqrt(N * k * logq)
        s_d = base_gauss * (width_factor ** depth)
        need = s_d * math.sqrt((depth + 1) * k * N) * 6.0   # omega(sqrt(log n)) ~ 6
        new_logq = math.log2(max(need * 8, 2 ** 20))        # 8x margin for low DFR
        if abs(new_logq - logq) < 0.01:
            logq = new_logq
            break
        logq = 0.5 * logq + 0.5 * new_logq
    return logq


def dfr_estimate(N, k, log2q, sigma, depth):
    """Rough decryption-failure-rate exponent (log2 DFR) for the leaf dual-Regev
    decode: failure if accumulated noise exceeds q/4. With per-coordinate noise
    stddev s_eff and (d+1)kN-ish accumulation, DFR ~ (d+1)kN * erfc(q/4 / (sqrt2 s))."""
    q = 2 ** log2q
    C = 1.0
    width = 4.0 * (C * math.sqrt(N * k * log2q)) ** depth
    s_eff = width * math.sqrt((depth + 1) * k * N) * sigma
    x = (q / 4.0) / (math.sqrt(2.0) * max(s_eff, 1e-9))
    # erfc tail ~ exp(-x^2)/(x sqrt(pi)); log2
    if x <= 0:
        return 0.0
    log2_tail = (-x * x) / math.log(2) - math.log2(max(x, 1e-9) * math.sqrt(math.pi))
    coords = (depth + 1) * k * N
    return math.log2(coords) + log2_tail


def ct_pk_bytes(N, k, log2q, depth):
    """Wire sizes: dual-Regev ct carries c0 over the (d+1)-block leaf matrix
    ((d+1)k ring elts) + c1 (k ring elts); pk is seed-compact (u in R_q^k + 32B seed)."""
    ring_bytes = N * log2q / 8.0
    ct = ((depth + 1) * k + k) * ring_bytes
    pk = k * ring_bytes + 32
    return int(ct), int(pk)


if __name__ == "__main__":
    print("=== calibration (should reproduce published ~core-SVP) ===")
    report("ML-KEM-512", 256, 2, math.log2(3329), 1.0)     # published ~118 classical
    report("ML-KEM-768", 256, 3, math.log2(3329), 1.0)     # published ~182 classical
    report("ML-KEM-1024", 256, 4, math.log2(3329), 1.0)    # published ~256 classical

    print("\n=== DR-KEM depth analysis (N=256, sigma base) ===")
    for depth in (8, 10, 12):
        lq = leaf_logq_needed(256, 3, 3.2, depth)
        print(f"  depth={depth}: leaf needs log2 q >= {lq:.1f}")

    print("\n=== DR-cons / DR-chal search (hold >=192 classical at the needed q) ===")
    DEPTH_CONS, DEPTH_CHAL = 10, 8
    lq_cons = leaf_logq_needed(256, 4, 3.2, DEPTH_CONS)
    lq_chal = leaf_logq_needed(256, 3, 3.2, DEPTH_CHAL)
    results = []
    # DR-cons: raise module rank until >=192-bit classical core-SVP at the required q
    for k in (3, 4, 5, 6):
        lq = leaf_logq_needed(256, k, 3.2, DEPTH_CONS)
        r = report(f"DR-cons k={k}", 256, k, lq, 3.2)
        r.update(depth=DEPTH_CONS)
        results.append(r)
    print()
    for k in (2, 3):
        lq = leaf_logq_needed(256, k, 3.2, DEPTH_CHAL)
        r = report(f"DR-chal k={k}", 256, k, lq, 3.2)
        r.update(depth=DEPTH_CHAL)
        results.append(r)

    # the naive lattice-BTE is infeasible: at the depth-10 modulus, security and
    # correctness both collapse.  Quantify it as the negative result.
    bte = report("BTE-naive k=2", 256, 2, leaf_logq_needed(256, 2, 3.2, 10), 3.2)
    bte_ct, bte_pk = ct_pk_bytes(256, 2, bte["log2q"], 10)
    bte_dfr = dfr_estimate(256, 2, bte["log2q"], 3.2, 10)
    print(f"\n=== NAIVE LATTICE-BTE (infeasible): log2q={bte['log2q']:.0f} "
          f"classical={bte['classical']:.0f}-bit ct={bte_ct//1024}KB log2(DFR)~{bte_dfr:.0f} ===")

    # ML-KEM-768 is the sound instantiation's base (estimator-verified)
    mlkem = report("ML-KEM-768(base)", 256, 3, math.log2(3329), 1.0)

    # emit macros for the paper
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "lattice_estimator_macros.tex"), "w") as f:
        f.write("% auto-generated by drkem/lattice_estimator.py (core-SVP, calibrated vs ML-KEM) -- do not edit\n")
        f.write(f"\\newcommand{{\\RaEstMlkemClassical}}{{{mlkem['classical']:.0f}}}\n")
        f.write(f"\\newcommand{{\\RaEstMlkemQuantum}}{{{mlkem['quantum']:.0f}}}\n")
        f.write(f"\\newcommand{{\\RaEstBteLogq}}{{{bte['log2q']:.0f}}}\n")
        f.write(f"\\newcommand{{\\RaEstBteBits}}{{{bte['classical']:.0f}}}\n")
        f.write(f"\\newcommand{{\\RaEstBteCtKB}}{{{bte_ct//1024}}}\n")
        f.write(f"\\newcommand{{\\RaEstBteDepth}}{{10}}\n")
    manifest = {
        "schema": "gtr.lattice-core-svp-estimate.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "method": {
            "type": "self-contained-core-svp-approximation",
            "primal_cost_bits": "0.292 * beta",
            "quantum_cost_bits": "0.265 * beta",
            "full_sage_lattice_estimator": False,
        },
        "dr_search": results,
        "naive_bte": {
            **bte,
            "ciphertext_bytes": bte_ct,
            "public_key_bytes": bte_pk,
            "log2_dfr_estimate": bte_dfr,
            "depth": 10,
        },
        "mlkem_768_calibration": mlkem,
        "source_sha256": hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
    }
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "lattice_estimator_result.json"), "w",
              encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write("\n")
    print("[macros] drkem/lattice_estimator_macros.tex")
    print("[manifest] drkem/lattice_estimator_result.json")
