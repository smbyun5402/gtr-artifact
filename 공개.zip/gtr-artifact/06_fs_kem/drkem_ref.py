#!/usr/bin/env python3
# DR-KEM reference prototype: an epoch-indexed forward-secure KEM built GENERICALLY
# from a real KEM (ML-KEM-768 via OpenSSL 4.0).  The independent-per-epoch
# implementation is the concrete reference; lattice_estimator.py records why the
# explored custom binary-tree-encryption route is not used.
#
# Construction (sound, post-quantum, implementable):
#   - Enrollment (verifier reachable): the node generates one ML-KEM keypair per
#     epoch e in [0, T_max), (pk_e, sk_e); it PUBLISHES/certifies {pk_e} and keeps
#     all not-yet-expired secret keys in a RoT-sealed store. This flat reference
#     deliberately makes no compact GGM-key-generation claim: both enrollment
#     public material and initial secret storage are O(T_max).
#   - Encapsulate to epoch e: standard ML-KEM.Encap(pk_e) -> (ct, D). ct = 1088 B.
#   - Decapsulate: ML-KEM.Decap(sk_e, ct) if sk_e still retained, else bottom.
#   - Tick to e: DELETE sk_{<e} (forward secrecy). ExtractRoT at epoch e reveals only
#     the retained {sk_{>=e}}, so a recorded ct to epoch e' < e is unrecoverable.
#
# Security: reduces to ML-KEM IND-CCA because each epoch is an independent
# instance. It adds no new lattice hardness assumption and inherits ML-KEM-768's
# ~182-bit classical core-SVP (lattice_estimator.py). This is the honest, reviewer-
# demanded concrete/implementable instantiation.
#
# Run: python drkem_ref.py   -> correctness + record-now-extract-later + sizes/timing

import os
import time
import hmac
import hashlib
import secrets
import subprocess
import json
import math
import platform
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(HERE, "_drkem_work")
os.makedirs(WORK, exist_ok=True)
OPENSSL = os.environ.get("OPENSSL", "openssl")
CRYPTO_BACKEND = None

T_MAX_DEMO = 16          # small horizon for a fast runnable demo (real T_max: 256-1024)
B_MLKEM_CT = 1088        # ML-KEM-768 ciphertext
B_MLKEM_PK = 1184        # ML-KEM-768 raw public key
B_MLKEM_SK = 2400        # ML-KEM-768 raw decapsulation key
T_MAX_LOW_RATE_EXAMPLE = 256  # 12 h / 5 min profile; not a universal default
MISSION_PROFILES = (
    ("TwoHFiveS", 2 * 3600, 5),
    ("TwelveHFiveS", 12 * 3600, 5),
    ("TwelveHSixtyS", 12 * 3600, 60),
    ("TwelveHFiveMin", 12 * 3600, 5 * 60),
)


def mission_sizing(duration_s, epoch_s):
    """Sizing for b=0 event ticks and r=1 completed reconnect adoption."""
    n_time = math.ceil(duration_s / epoch_s)
    n_nv = n_time + 1
    t_req = n_nv + 1              # e' < T_max
    t_cfg = 1 << (t_req - 1).bit_length()
    return n_nv, t_req, t_cfg


def _run(args, check=True):
    result = subprocess.run([OPENSSL] + args, capture_output=True)
    if check and result.returncode != 0:
        detail = result.stderr.decode(errors="replace").strip()
        raise RuntimeError(f"OpenSSL failed ({' '.join(args)}): {detail}")
    return result


def crypto_ok():
    global CRYPTO_BACKEND
    try:
        result = _run(["version"], check=False)
        if result.returncode == 0:
            CRYPTO_BACKEND = "openssl-cli"
            return True, result.stdout.decode(errors="replace").strip()
    except OSError:
        pass

    try:
        import cryptography
        from cryptography.hazmat.backends.openssl.backend import backend
        from cryptography.hazmat.primitives.asymmetric import mlkem

        _ = mlkem.MLKEM768PrivateKey
        CRYPTO_BACKEND = "cryptography-openssl-inprocess"
        return True, (f"{backend.openssl_version_text()} via cryptography "
                      f"{cryptography.__version__}")
    except (ImportError, AttributeError) as exc:
        return False, f"OpenSSL CLI and cryptography ML-KEM unavailable: {exc}"


def _p(name):
    return os.path.join(WORK, name)


def mlkem_keygen(e):
    sk = _p(f"e{e}_sk.pem"); pk = _p(f"e{e}_pk.pem")
    if CRYPTO_BACKEND == "openssl-cli":
        _run(["genpkey", "-algorithm", "ML-KEM-768", "-out", sk])
        _run(["pkey", "-in", sk, "-pubout", "-out", pk])
    else:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import mlkem

        key = mlkem.MLKEM768PrivateKey.generate()
        with open(sk, "wb") as f:
            f.write(key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            ))
        with open(pk, "wb") as f:
            f.write(key.public_key().public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ))
    return sk, pk


def mlkem_encap(pk):
    if CRYPTO_BACKEND != "openssl-cli":
        from cryptography.hazmat.primitives import serialization

        with open(pk, "rb") as f:
            key = serialization.load_pem_public_key(f.read())
        shared_secret, ciphertext = key.encapsulate()
        return ciphertext, shared_secret

    ct = _p("ct.bin"); ss = _p("ss_e.bin")
    _run(["pkeyutl", "-encap", "-inkey", pk, "-pubin", "-out", ct, "-secret", ss])
    with open(ct, "rb") as f:
        ct_bytes = f.read()
    with open(ss, "rb") as f:
        ss_bytes = f.read()
    return ct_bytes, ss_bytes


def mlkem_decap(sk, ct_bytes):
    if CRYPTO_BACKEND != "openssl-cli":
        from cryptography.hazmat.primitives import serialization

        with open(sk, "rb") as f:
            key = serialization.load_pem_private_key(f.read(), password=None)
        return key.decapsulate(ct_bytes)

    ct = _p("ct_in.bin"); ss = _p("ss_d.bin")
    with open(ct, "wb") as f:
        f.write(ct_bytes)
    r = _run(["pkeyutl", "-decap", "-inkey", sk, "-in", ct, "-secret", ss])
    if r.returncode != 0 or not os.path.exists(ss):
        return None
    with open(ss, "rb") as f:
        return f.read()


class DrKem:
    """Epoch-indexed forward-secure KEM (generic, ML-KEM-instantiated)."""

    def __init__(self, t_max):
        self.t_max = t_max
        self.pk = {}                  # published per-epoch public keys (paths)
        self._sk = {}                 # RoT-sealed retained secret keys (paths)
        self.cur = 0
        # enrollment: generate all epochs' keypairs (verifier reachable)
        for e in range(t_max):
            sk, pk = mlkem_keygen(e)
            self.pk[e] = pk
            self._sk[e] = sk

    def enroll_pk_bytes(self):
        """Total published public-key material at enrollment."""
        return self.t_max * B_MLKEM_PK

    def initial_sk_bytes(self):
        """Raw decapsulation-key material in the initial secret state."""
        return self.t_max * B_MLKEM_SK

    def encap(self, e):
        """Sender-side: needs only the published pk_e. Returns (ct, D)."""
        return mlkem_encap(self.pk[e])

    def decap(self, e, ct):
        """Receiver-side: succeeds iff sk_e is still retained (e >= cur)."""
        if e not in self._sk:
            return None
        return mlkem_decap(self._sk[e], ct)

    def tick_to(self, e):
        """Forward secrecy: delete all secret keys for epochs < e."""
        for ep in list(self._sk):
            if ep < e:
                try:
                    os.remove(self._sk[ep])
                except OSError:
                    pass
                del self._sk[ep]
        self.cur = e

    def extract_rot(self):
        """Model ExtractRoT: the adversary learns the CURRENTLY retained sk set."""
        return set(self._sk)          # epochs >= cur only


def main():
    ok, openssl_version = crypto_ok()
    if not ok:
        raise SystemExit(openssl_version)
    print("OpenSSL:", openssl_version, "\n")

    t0 = time.time()
    print(f"[enroll] generating {T_MAX_DEMO} real ML-KEM-768 epoch keypairs ...")
    dk = DrKem(T_MAX_DEMO)
    t_enroll = time.time() - t0
    print(f"[enroll] done in {t_enroll:.1f}s; published pk material = "
          f"{dk.enroll_pk_bytes()} B ({dk.enroll_pk_bytes()/1024:.1f} KB) for "
          f"T_max={T_MAX_DEMO}; initial secret material = "
          f"{dk.initial_sk_bytes()} B ({dk.initial_sk_bytes()/1024:.1f} KB)\n")

    cases = []

    def rec(name, ok, expect, detail=""):
        good = (ok == expect)
        cases.append((name, good))
        print(f"[{'PASS' if good else 'FAIL'}] {name}: got={ok} expect={expect} {detail}")

    # 1. correctness: encap to epoch 3, decap agrees
    ct3, D_enc = dk.encap(3)
    D_dec = dk.decap(3, ct3)
    rec("correctness_encap_decap", D_dec == D_enc, True,
        f"ct={len(ct3)}B ss={len(D_enc)}B")

    # 2. record a transcript at epoch 3, then tick past it (delete sk_3)
    recorded_ct = ct3
    dk.tick_to(10)                     # mission advances; epochs <10 deleted
    retained = dk.extract_rot()
    rec("forward_secrecy_sk_deleted", (3 in retained), False,
        f"retained epochs = {sorted(retained)}")

    # 3. record-now-extract-later: adversary has the full retained store (ExtractRoT)
    #    but cannot decap the epoch-3 transcript (sk_3 deleted)
    D_retro = dk.decap(3, recorded_ct)
    rec("record_now_extract_later_blocked", D_retro is None, True,
        "sk_3 deleted -> recorded epoch-3 ct unrecoverable post-extraction")

    # 4. future epoch still works (encap/decap at a retained epoch)
    ct12, D12e = dk.encap(12)
    D12d = dk.decap(12, ct12)
    rec("future_epoch_ok", D12d == D12e, True, "epoch 12 retained")

    # ---- timing microbench (median of a few, minus process spawn) ----
    if CRYPTO_BACKEND == "openssl-cli":
        base = []
        for _ in range(5):
            s = time.perf_counter(); _run(["version"]); base.append(time.perf_counter() - s)
        baseline = sorted(base)[len(base) // 2]
    else:
        baseline = 0.0

    def timed(fn, reps=8):
        ts = []
        for _ in range(reps):
            s = time.perf_counter(); fn(); ts.append(time.perf_counter() - s)
        return max(0.0, sorted(ts)[len(ts) // 2] - baseline) * 1000.0

    enc_ms = timed(lambda: dk.encap(12))
    ct_t, _ = dk.encap(12)
    dec_ms = timed(lambda: dk.decap(12, ct_t))
    kg_ms = timed(lambda: mlkem_keygen(99), reps=5)

    n_ok = sum(1 for _, g in cases if g)
    timing_scope = ("CLI, process floor subtracted, file I/O included"
                    if CRYPTO_BACKEND == "openssl-cli" else
                    "in-process OpenSSL-backed cryptography, PEM load/store included")
    print(f"\n[timing] keygen={kg_ms:.1f}ms encap={enc_ms:.1f}ms "
          f"decap={dec_ms:.1f}ms ({timing_scope})")
    print(f"[sizes]  reconnect DR ct = {B_MLKEM_CT} B (one ML-KEM ct); "
          f"enrollment pk = T_max x {B_MLKEM_PK} B; "
          f"initial sk = T_max x {B_MLKEM_SK} B")
    print(f"         T_max={T_MAX_LOW_RATE_EXAMPLE} low-rate example -> "
          f"{T_MAX_LOW_RATE_EXAMPLE*B_MLKEM_PK/1024:.0f} KiB public + "
          f"{T_MAX_LOW_RATE_EXAMPLE*B_MLKEM_SK/1024:.0f} KiB secret; "
          f"projected key generation = {T_MAX_LOW_RATE_EXAMPLE*kg_ms/1000:.2f} s")
    print(f"[cases]  {n_ok}/{len(cases)} passed")
    print(f"total {time.time()-t0:.1f}s")

    # emit macros for the paper (real, ML-KEM-instantiated DR-KEM)
    with open(os.path.join(HERE, "drkem_ref_macros.tex"), "w") as f:
        f.write("% auto-generated by drkem/drkem_ref.py (real ML-KEM-768) -- do not edit\n")
        f.write(f"\\newcommand{{\\RaDrRefCt}}{{{B_MLKEM_CT}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefPk}}{{{B_MLKEM_PK}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefCases}}{{{len(cases)}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefCasesOk}}{{{n_ok}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefEnrollKB}}{{{T_MAX_LOW_RATE_EXAMPLE*B_MLKEM_PK//1024}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefSk}}{{{B_MLKEM_SK}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefSecretKB}}{{{T_MAX_LOW_RATE_EXAMPLE*B_MLKEM_SK//1024}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefTotalKB}}{{{T_MAX_LOW_RATE_EXAMPLE*(B_MLKEM_PK+B_MLKEM_SK)//1024}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefKeygenMs}}{{{kg_ms:.2f}}}\n")
        f.write(f"\\newcommand{{\\RaDrRefEnrollKeygenSec}}{{{T_MAX_LOW_RATE_EXAMPLE*kg_ms/1000:.2f}}}\n")
        for label, duration_s, epoch_s in MISSION_PROFILES:
            n_nv, t_req, t_cfg = mission_sizing(duration_s, epoch_s)
            f.write(f"\\newcommand{{\\RaFs{label}Nv}}{{{n_nv}}}\n")
            f.write(f"\\newcommand{{\\RaFs{label}Req}}{{{t_req}}}\n")
            f.write(f"\\newcommand{{\\RaFs{label}Cfg}}{{{t_cfg}}}\n")
            f.write(f"\\newcommand{{\\RaFs{label}PubKB}}{{{t_cfg*B_MLKEM_PK//1024}}}\n")
            f.write(f"\\newcommand{{\\RaFs{label}SecKB}}{{{t_cfg*B_MLKEM_SK//1024}}}\n")
            f.write(f"\\newcommand{{\\RaFs{label}KeygenSec}}{{{t_cfg*kg_ms/1000:.1f}}}\n")
    manifest = {
        "schema": "gtr.drkem.reference-manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "openssl": openssl_version,
        "crypto_backend": CRYPTO_BACKEND,
        "python": sys.version,
        "platform": platform.platform(),
        "construction": "independent-per-epoch-ML-KEM-768",
        "demo_t_max": T_MAX_DEMO,
        "cases": [{"name": name, "pass": good} for name, good in cases],
        "timing_cli_ms": {"keygen": kg_ms, "encap": enc_ms, "decap": dec_ms},
        "timing_scope": timing_scope,
        "sizes": {"ciphertext_bytes": B_MLKEM_CT,
                  "public_key_bytes_per_epoch": B_MLKEM_PK,
                  "secret_key_bytes_per_epoch": B_MLKEM_SK,
                  "public_enrollment_bytes_demo": dk.enroll_pk_bytes(),
                  "initial_secret_bytes_demo": dk.initial_sk_bytes()},
        "reported_horizon": {
            "t_max": T_MAX_LOW_RATE_EXAMPLE,
            "public_key_bytes": T_MAX_LOW_RATE_EXAMPLE * B_MLKEM_PK,
            "initial_secret_bytes": T_MAX_LOW_RATE_EXAMPLE * B_MLKEM_SK,
            "projected_keygen_ms": T_MAX_LOW_RATE_EXAMPLE * kg_ms,
            "projection_excludes": ["certification", "RoT sealing", "process launch"],
        },
        "limitations": {
            "compact_seed_tree_construction_claimed": False,
            "rot_sealing_implemented": False,
            "physical_secure_deletion_verified": False,
        },
        "source_sha256": hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
    }
    with open(os.path.join(HERE, "drkem_ref_result.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write("\n")
    print("[macros] drkem/drkem_ref_macros.tex")
    print("[manifest] drkem/drkem_ref_result.json")


if __name__ == "__main__":
    main()
