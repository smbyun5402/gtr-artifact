# Q-ARTZ-Reauth randomized trace-conformance runner over scenarios RA1..RA9,
# baselines + full protocol P_Qartz + ablations, independent local no-contact-gap
# and inter-peer epoch-drift frontiers, the record-now-extract-later contrast,
# the hybrid-floor equality
# check, seal-batch and robustness sweeps.  Emits IEEE-column figures (fig_ra_*.pdf)
# and LaTeX macros (prefix Ra) to results/reauth_macros.tex.
#
# Single-command rerun:  python run_reauth_experiments.py
# Never touches resync/control macro files.

import os
import csv
import gzip
import json
import sys
import time
import hashlib
import platform
from datetime import datetime, timezone
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import reauth_sim as R
from reauth_sim import (POLICIES, CFGS, PolCfg, ReauthPolicy, make_trace,
                        run_policy, metrics, CONDS, LINK, TLS_PQC,
                        QUOTE_MS, QUOTE_VERIFY_MS, CLEAN, DISR, HEAVY)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
FIG = os.path.join(HERE, "figures")
os.makedirs(OUT, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

T = 40
RUNS = 100

plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "figure.dpi": 200,
    "pdf.fonttype": 42,
})
W = 3.45

ALL_POLS = list(POLICIES.keys())
SCENARIOS = ["RA1", "RA2", "RA3", "RA4", "RA5", "RA6", "RA7", "RA8", "RA9"]

TRACE_SEED_BASE = 1000
LINK_SEED_BASE = 7000

# LaTeX control sequences cannot contain digits -> letters-only policy suffixes
POLNAME = {
    "P_Qartz": "Qartz", "P_QartzSig": "QartzSig", "B_MacTicket": "MacTicket",
    "B_FullOnly": "FullOnly", "B_SigOnly": "SigOnly", "B_NoSeal": "NoSeal",
    "B_DriftWin": "DriftWin", "B_SakeLike": "SakeLike",
    "A_noEphemeral": "AblNoEph", "A_noStaticAuth": "AblNoStatic",
    "A_unboundedDelta": "AblUnbDelta", "A_noTranscriptBind": "AblNoTrBind",
    "A_noLse": "AblNoLse", "A_noDrkem": "AblNoDr",
}
CONDNAME = {CLEAN: "Clean", DISR: "Disr", HEAVY: "Heavy"}
DISPLAY = {
    "P_Qartz": "GT-R", "P_QartzSig": "GT-R\nsig", "B_MacTicket": "MAC\nticket",
    "B_FullOnly": "Full\nonly", "B_SigOnly": "Sig\nonly", "B_NoSeal": "$-$seal",
    "B_DriftWin": "$\\delta{\\le}1$", "B_SakeLike": "SAKE\nlike",
    "A_noEphemeral": "$-$eph", "A_noStaticAuth": "$-$auth",
    "A_unboundedDelta": "$-$bound", "A_noTranscriptBind": "$-$trbind",
    "A_noLse": "$-$lse", "A_noDrkem": "No-FS",
}
REASON_LABEL = {
    "freshness": "nonce/freshness", "healed": "PCS healed", "auth-fail": "entity auth",
    "seal-counter": "RoT counter", "lse": "epoch-regression", "delta-bound": "drift bound",
    "dr-forward-secure": "DR forward-secrecy", "r2": "re-attest", "r2-noverify": "no verifier",
    "resume": "resumed", "accept": "accepted",
}


# ------------------------------------------------------------------ aggregate
def aggregate():
    rows, raw = [], {}
    episode_fields = [
        "scenario", "policy", "run", "episode", "trace_seed", "link_seed",
        "condition", "attack", "gap_epochs", "delta", "verifier_reachable",
        "captured_chain", "extracted_rot", "cur_epoch", "peer_epoch", "lse",
        "path", "accepted", "impersonation", "pcs_leak", "retro_decrypt",
        "success", "latency_ms", "bytes", "r2_forced", "audit",
    ]
    episode_path = os.path.join(OUT, "episode_outcomes.csv.gz")
    with gzip.open(episode_path, "wt", newline="", encoding="utf-8") as ef:
        ew = csv.DictWriter(ef, fieldnames=episode_fields)
        ew.writeheader()
        for scen in SCENARIOS:
            for run in range(RUNS):
                trace_seed = TRACE_SEED_BASE + run
                link_seed = LINK_SEED_BASE + run
                tr = make_trace(scen, T, seed=trace_seed)
                for pol in ALL_POLS:
                    rng = np.random.default_rng(link_seed)
                    policy = POLICIES[pol](rng, tr.base_secret)
                    outs = run_policy(policy, tr)
                    for ep, out in zip(tr.episodes, outs):
                        ew.writerow({
                            "scenario": scen, "policy": pol, "run": run,
                            "episode": ep.idx, "trace_seed": trace_seed,
                            "link_seed": link_seed, "condition": ep.cond,
                            "attack": ep.attack or "benign",
                            "gap_epochs": ep.gap_epochs, "delta": ep.delta,
                            "verifier_reachable": ep.verifier_reachable,
                            "captured_chain": ep.captured_chain,
                            "extracted_rot": ep.extracted_rot,
                            "cur_epoch": ep.cur_e, "peer_epoch": ep.peer_e,
                            "lse": ep.lse, "path": out["path"],
                            "accepted": out["accepted"],
                            "impersonation": out["imperson"],
                            "pcs_leak": out["pcs_leak"],
                            "retro_decrypt": out["retro"],
                            "success": out["success"],
                            "latency_ms": out["latency"], "bytes": out["bytes"],
                            "r2_forced": out["r2_forced"],
                            "audit": json.dumps(out["audit"], separators=(",", ":")),
                        })
                    m = metrics(tr, outs)
                    m.update(scenario=scen, policy=pol, run=run,
                             trace_seed=trace_seed, link_seed=link_seed)
                    rows.append({k: v for k, v in m.items() if k != "guard_audit"})
                    raw.setdefault((scen, pol), []).append(m)
            print(f"[done] {scen}", flush=True)
    with open(os.path.join(OUT, "raw_metrics.csv"), "w", newline="") as f:
        keys = sorted({k for r in rows for k in r})
        wtr = csv.DictWriter(f, fieldnames=keys)
        wtr.writeheader()
        wtr.writerows(rows)
    print(f"[raw] episode outcomes -> {episode_path}")
    return raw


def mstat(raw, scen, pol, key):
    vals = [r[key] for r in raw.get((scen, pol), [])
            if key in r and not (isinstance(r[key], float) and np.isnan(r[key]))]
    if not vals:
        return np.nan, np.nan
    v = np.asarray(vals, float)
    ci = 1.96 * v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0.0
    return float(v.mean()), float(ci)


# -------------------------------------------------------- gap and drift frontiers
GAPS = list(range(1, 13))
DRIFTS = list(range(0, 13))
FRONTIER_RUNS = 60


def _frontier_trace(seed, gap, delta, label):
    """Benign reconnects with independently fixed local gap and epoch drift."""
    rng = np.random.default_rng(seed)
    eps = []
    e_i = 100
    for i in range(T):
        cond = rng.choice(CONDS, p=[0.5, 0.3, 0.2])
        peer_e = e_i + delta
        eps.append(R.Episode(idx=i, cond=cond, attack=None, gap_epochs=gap,
                             delta=delta, verifier_reachable=False,
                             captured_chain=False, extracted_rot=False,
                             cur_e=e_i, peer_e=peer_e,
                             lse=e_i - gap, adv={}))
        e_i = peer_e + max(gap, 1) + 1
    return R.Trace(T, label, eps, b"\x00" * 32)


def frontier():
    """Sweep each resume guard while holding the other strictly in range."""
    res = {"gap": GAPS, "drift": DRIFTS}
    run_rows = []
    pols = ("P_Qartz", "B_DriftWin", "B_SakeLike", "B_FullOnly")
    for pol in pols:
        res[pol] = {"gap_avail": [], "drift_avail": []}
    sweeps = (
        ("gap", GAPS, "gap_avail", lambda v: (v, 0)),
        ("drift", DRIFTS, "drift_avail", lambda v: (1, v)),
    )
    for sweep, values, key, params in sweeps:
        for value in values:
            gap, delta = params(value)
            acc = {pol: [] for pol in pols}
            for run in range(FRONTIER_RUNS):
                tr = _frontier_trace(TRACE_SEED_BASE + run, gap, delta,
                                     sweep.upper())
                for pol in pols:
                    policy = POLICIES[pol](
                        np.random.default_rng(LINK_SEED_BASE + run),
                        tr.base_secret)
                    m = metrics(tr, run_policy(policy, tr))
                    acc[pol].append(m["availability"])
                    run_rows.append({"sweep": sweep, "value": value,
                                     "gap": gap, "delta": delta, "run": run,
                                     "policy": pol,
                                     "availability": m["availability"]})
            for pol in pols:
                res[pol][key].append(float(np.mean(acc[pol])))
            print(f"[frontier:{sweep}] value={value} "
                  f"GT-R={res['P_Qartz'][key][-1]:.2f} "
                  f"d<=1={res['B_DriftWin'][key][-1]:.2f}", flush=True)
    np.save(os.path.join(OUT, "frontier.npy"), res, allow_pickle=True)
    with open(os.path.join(OUT, "frontier_runs.csv"), "w", newline="") as f:
        w = csv.DictWriter(
            f, fieldnames=["sweep", "value", "gap", "delta", "run",
                           "policy", "availability"])
        w.writeheader(); w.writerows(run_rows)
    return res


# ------------------------------------------------------------------ seal batch
BATCHES = [1, 2, 4, 8, 16]


def seal_sweep():
    """Rollback exposure window vs seal batch size k (window = k-1 epochs)."""
    res = {"batch": BATCHES, "roll_acc": []}
    run_rows = []
    for k in BATCHES:
        vals = []
        for run in range(FRONTIER_RUNS):
            tr = make_trace("RA5", T, seed=TRACE_SEED_BASE + run)
            cfg = PolCfg(**{**CFGS["P_Qartz"].__dict__}); cfg.seal_batch = k
            policy = ReauthPolicy(cfg, tr.base_secret)
            policy._rng = np.random.default_rng(LINK_SEED_BASE + run)
            m = metrics(tr, run_policy(policy, tr))
            vals.append(m.get("acc_rollback", np.nan))
            run_rows.append({"seal_batch": k, "run": run,
                             "rollback_acceptance": m.get("acc_rollback", np.nan)})
        res["roll_acc"].append(float(np.nanmean(vals)))
        print(f"[seal] k={k} rollAcc={res['roll_acc'][-1]:.3f}", flush=True)
    with open(os.path.join(OUT, "seal_sweep.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["seal_batch", "run", "rollback_acceptance"])
        w.writeheader(); w.writerows(run_rows)
    return res


# ------------------------------------------------------------------ robustness
ROB_PARAMS = [
    ("Dmax", "d_max", [4, 6, 8, 10, 12]),
    ("Gmax", "g_max", [4, 6, 8, 10]),
]
ROB_RUNS = 30


def robustness():
    rows = {}
    run_rows = []
    for tag, key, vals in ROB_PARAMS:
        acc, av = [], []
        for v in vals:
            for run in range(ROB_RUNS):
                cfg = PolCfg(**{**CFGS["P_Qartz"].__dict__}); setattr(cfg, key, v)
                # attack acceptance must stay 0 across the attack scenarios
                for scen in ("RA2", "RA4", "RA5", "RA6", "RA8", "RA9"):
                    tr = make_trace(scen, T, seed=TRACE_SEED_BASE + run)
                    policy = ReauthPolicy(cfg, tr.base_secret)
                    policy._rng = np.random.default_rng(LINK_SEED_BASE + run)
                    m = metrics(tr, run_policy(policy, tr))
                    scenario_acc = []
                    for kk in ("acc_replay", "acc_imperson", "acc_rollback",
                               "acc_regression", "acc_ffdos", "acc_retro"):
                        vv = m.get(kk, np.nan)
                        if not np.isnan(vv):
                            acc.append(vv)
                            scenario_acc.append(vv)
                    run_rows.append({"parameter": tag, "value": v, "run": run,
                                     "scenario": scen, "metric": "attack_acceptance",
                                     "result": max(scenario_acc) if scenario_acc else np.nan})
                # availability measured on benign gap traffic (RA1), where a low
                # resume ratio would be a real regression -- attack scenarios route
                # to R2 by design, so their resume ratio is not a robustness signal
                tb = make_trace("RA1", T, seed=TRACE_SEED_BASE + run)
                pb = ReauthPolicy(cfg, tb.base_secret)
                pb._rng = np.random.default_rng(LINK_SEED_BASE + run)
                availability = metrics(tb, run_policy(pb, tb))["availability"]
                av.append(availability)
                run_rows.append({"parameter": tag, "value": v, "run": run,
                                 "scenario": "RA1", "metric": "availability",
                                 "result": availability})
        rows[tag] = dict(rng=f"{vals[0]}--{vals[-1]}",
                         acc=100 * max(acc) if acc else 0.0,
                         av=100 * min(av))
        print(f"[rob] {tag}: accMax={rows[tag]['acc']:.1f} "
              f"availMin={rows[tag]['av']:.1f}", flush=True)
    with open(os.path.join(OUT, "robustness_runs.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["parameter", "value", "run", "scenario",
                                         "metric", "result"])
        w.writeheader(); w.writerows(run_rows)
    return rows


# ------------------------------------------------------------------ figures
def _bar(ax, names, means, errs, ylabel, ymax=115):
    xs = np.arange(len(names))
    values = 100 * np.asarray(means, dtype=float)
    errors = 100 * np.asarray(errs, dtype=float)
    policy_colors = {
        "P_Qartz": "#2ca02c",
        "A_noDrkem": "#888888",
        "B_SigOnly": "#4477AA",
        "B_MacTicket": "#EE9944",
    }
    ax.bar(xs, values, yerr=errors, capsize=2, width=0.62,
           color=[policy_colors[n] for n in names])
    for x, v in zip(xs, values):
        if not np.isnan(v):
            ax.text(x, v + 0.02 * ymax, f"{v:.0f}", ha="center", fontsize=5.0)
    ax.set_ylim(0, ymax)
    ax.set_xticks(xs)
    ax.set_xticklabels([DISPLAY.get(n, n) for n in names], fontsize=5.0)
    ax.set_ylabel(ylabel)


def _fig_ra_frontier(fr, sweep, values, key, bound, xlabel, filename):
    """Plot one resume guard while the other guard is fixed in range."""
    fig, ax = plt.subplots(figsize=(W, 2.2))
    styles = {"P_Qartz": ("GT-R", "-o", "#2ca02c"),
              "B_DriftWin": (r"$\delta\leq1$ window", "-s", "#CC6677"),
              "B_SakeLike": (r"SAKE-like ($\delta\leq2$)", "-^", "#EE9944"),
              "B_FullOnly": ("FullOnly (needs verifier)", "--x", "#888888")}
    marker_sizes = {"P_Qartz": 3.2, "B_DriftWin": 4.2,
                    "B_SakeLike": 5.0, "B_FullOnly": 3.2}
    zorders = {"P_Qartz": 5, "B_DriftWin": 4,
               "B_SakeLike": 3, "B_FullOnly": 2}
    for pol, (lab, mk, col) in styles.items():
        hollow = pol in {"B_DriftWin", "B_SakeLike"}
        ax.plot(values, fr[pol][key], mk, color=col,
                markerfacecolor="none" if hollow else col,
                markeredgewidth=0.8, ms=marker_sizes[pol], lw=1,
                zorder=zorders[pol], label=lab)
    ax.axvline(bound, color="#2ca02c", ls=":", lw=0.8)
    bound_label = r"$G_{\max}$" if sweep == "gap" else r"$\Delta_{\max}$"
    ax.annotate(bound_label, xy=(bound, 0.16), xytext=(-3, 0),
                textcoords="offset points", ha="right", va="center",
                fontsize=6, color="#2ca02c",
                bbox=dict(facecolor="white", edgecolor="none", alpha=0.85,
                          pad=0.2))
    ax.set_xlabel(xlabel)
    ax.set_ylabel("R1 selected")
    ax.set_ylim(-0.03, 1.05)
    ax.legend(frameon=False, fontsize=5.8, ncol=2, columnspacing=0.9,
              handletextpad=0.4, loc="lower right",
              bbox_to_anchor=(1.0, 1.01))
    fig.tight_layout(pad=0.4)
    fig.savefig(os.path.join(FIG, filename))
    plt.close(fig)


def fig_ra_frontiers(fr):
    _fig_ra_frontier(fr, "gap", GAPS, "gap_avail", R.G_MAX,
                     r"local no-contact gap $g_x$ (epochs)",
                     "fig_ra_gap_frontier.pdf")
    _fig_ra_frontier(fr, "drift", DRIFTS, "drift_avail", R.D_MAX,
                     r"inter-peer epoch drift $\delta$ (epochs)",
                     "fig_ra_drift_frontier.pdf")

    # Publication layout: one full-width asset with a shared legend. Keeping
    # the legend outside both axes prevents it from hiding the y=1 traces.
    styles = {"P_Qartz": ("GT-R", "-o", "#2ca02c"),
              "B_DriftWin": (r"$\delta\leq1$ window", "-s", "#CC6677"),
              "B_SakeLike": (r"SAKE-like ($\delta\leq2$)", "-^", "#EE9944"),
              "B_FullOnly": ("FullOnly (needs verifier)", "--x", "#888888")}
    marker_sizes = {"P_Qartz": 3.2, "B_DriftWin": 4.2,
                    "B_SakeLike": 5.0, "B_FullOnly": 3.2}
    zorders = {"P_Qartz": 5, "B_DriftWin": 4,
               "B_SakeLike": 3, "B_FullOnly": 2}
    specs = [
        (GAPS, "gap_avail", R.G_MAX,
         r"local no-contact gap $g_x$ (epochs)", r"$G_{\max}$"),
        (DRIFTS, "drift_avail", R.D_MAX,
         r"inter-peer epoch drift $\delta$ (epochs)", r"$\Delta_{\max}$"),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.2), sharey=True)
    for ax, (values, key, bound, xlabel, bound_label) in zip(axes, specs):
        for pol, (label, marker, color) in styles.items():
            hollow = pol in {"B_DriftWin", "B_SakeLike"}
            ax.plot(values, fr[pol][key], marker, color=color,
                    markerfacecolor="none" if hollow else color,
                    markeredgewidth=0.8, ms=marker_sizes[pol], lw=1,
                    zorder=zorders[pol], label=label)
        ax.axvline(bound, color="#2ca02c", ls=":", lw=0.8)
        ax.annotate(bound_label, xy=(bound, 0.16), xytext=(-3, 0),
                    textcoords="offset points", ha="right", va="center",
                    fontsize=7, color="#2ca02c",
                    bbox=dict(facecolor="white", edgecolor="none",
                              alpha=0.85, pad=0.2))
        ax.set_xlabel(xlabel)
        ax.set_ylim(-0.03, 1.05)
    axes[0].set_ylabel("R1 selected")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, frameon=False, fontsize=7, ncol=2,
               columnspacing=1.1, handletextpad=0.45, loc="upper right",
               bbox_to_anchor=(0.99, 0.995))
    fig.text(0.275, 0.025, "(a)", ha="center", fontsize=8)
    fig.text(0.755, 0.025, "(b)", ha="center", fontsize=8)
    fig.subplots_adjust(left=0.085, right=0.99, bottom=0.27, top=0.76,
                        wspace=0.18)
    fig.savefig(os.path.join(FIG, "fig_ra_boundaries.pdf"))
    plt.close(fig)


def fig_ra_attacks(raw):
    # Preserve the original attack-by-attack 2x3 structure, but replace the
    # repeated tiny policy names under every subplot with one shared legend.
    classes = [("acc_replay", "RA2", "replay/reflect"),
               ("acc_imperson", "RA4", "active impersonation"),
               ("acc_pcs", "RA3", "post-gap read"),
               ("acc_rollback", "RA5", "rollback"),
               ("acc_regression", "RA6", "epoch regression"),
               ("acc_retro", "RA9", "record-now-extract")]
    pols = ["P_Qartz", "B_MacTicket", "B_SigOnly", "B_NoSeal",
            "A_noTranscriptBind", "A_noStaticAuth", "A_noLse", "A_noDrkem"]
    labels = ["GT-R", "MAC ticket", "Sig-only", "No-seal",
              "No-bind", "No-auth", "No-lse", "No-FS"]
    colors = ["#2ca02c", "#EE9944", "#4477AA", "#CC6677",
              "#332288", "#AA4499", "#44AA99", "#888888"]
    fig, axes = plt.subplots(2, 3, figsize=(W, 2.05), sharey=True)
    legend_handles = None
    for ax, (key, scen, title) in zip(axes.ravel(), classes):
        means = [mstat(raw, scen, pol, key)[0] for pol in pols]
        bars = ax.bar(np.arange(len(pols)), means, width=0.68, color=colors)
        if legend_handles is None:
            legend_handles = list(bars)
        ax.set_title(title, fontsize=6.2, pad=1.5)
        ax.set_ylim(0, 1.08)
        ax.set_xticks([])
        ax.text(0, 0.025, "0", color=colors[0], ha="center", va="bottom",
                fontsize=5.0)
    fig.text(0.035, 0.58, "adverse outcome", rotation=90,
             ha="center", va="center", fontsize=7)
    fig.legend(legend_handles, labels, frameon=False, fontsize=6.0, ncol=4,
               handlelength=1.2, handletextpad=0.3, columnspacing=0.65,
               loc="lower center", bbox_to_anchor=(0.5, 0.005))
    fig.subplots_adjust(left=0.15, right=0.99, bottom=0.20, top=0.96,
                        wspace=0.12, hspace=0.42)
    fig.savefig(os.path.join(FIG, "fig_ra_attacks.pdf"))
    plt.close(fig)


def fig_ra_latency(raw):
    """Reconnect latency by condition: GT-R resume vs FullReAttest anchor."""
    fig, ax = plt.subplots(figsize=(W, 2.0))
    conds = [CLEAN, DISR, HEAVY]
    x = np.arange(len(conds))
    wbar = 0.35
    gt = [mstat(raw, "RA1", "P_Qartz", f"lat_{c}_resume")[0] for c in conds]
    gte = [mstat(raw, "RA1", "P_Qartz", f"lat_{c}_resume")[1] for c in conds]
    fu = [TLS_PQC[c] + QUOTE_MS + QUOTE_VERIFY_MS for c in conds]
    ax.bar(x - wbar / 2, gt, wbar, yerr=gte, capsize=2, label="GT-R resume",
           color="#4477AA")
    ax.bar(x + wbar / 2, fu, wbar, label="FullReAttest anchor", color="#CC6677")
    ax.set_yscale("log")
    ax.set_xticks(x)
    ax.set_xticklabels(["clean", "disrupted", "heavy"])
    ax.set_ylabel("reconnect latency (ms, log)")
    ax.legend(frameon=False, fontsize=6, loc="upper left")
    fig.tight_layout(pad=0.4)
    fig.savefig(os.path.join(FIG, "fig_ra_latency.pdf"))
    plt.close(fig)


def fig_ra_retro(raw):
    """Record-now-extract-later: retro-decrypt success of pre-extraction stage
    keys.  GT-R (FS-KEM) = 0; A_noDrkem / statics-only = 1."""
    fig, ax = plt.subplots(figsize=(W, 2.05))
    pols = ["P_Qartz", "A_noDrkem", "B_SigOnly", "B_MacTicket"]
    ms = [mstat(raw, "RA9", p, "retro_rate")[0] for p in pols]
    es = [mstat(raw, "RA9", p, "retro_rate")[1] for p in pols]
    _bar(ax, pols, ms, es, "retro-decrypt success (%)")
    fig.tight_layout(pad=0.4)
    fig.savefig(os.path.join(FIG, "fig_ra_retro.pdf"))
    plt.close(fig)


# ------------------------------------------------------------------ macros
def macros(raw, fr, seal, rob, runtime_s):
    def pct(x):
        return "--" if x is None or (isinstance(x, float) and np.isnan(x)) \
            else f"{100*x:.1f}"

    def num(x, d=1):
        return "--" if x is None or (isinstance(x, float) and np.isnan(x)) \
            else f"{x:.{d}f}"

    lines = []

    def M(name, val):
        lines.append(f"\\newcommand{{\\{name}}}{{{val}}}")

    # step time (per-episode wall time of the GT-R handler)
    trs = make_trace("RA4", T, seed=1)
    pol = POLICIES["P_Qartz"](np.random.default_rng(1), trs.base_secret)
    run_policy(pol, trs)
    M("RaStepMicros", num(float(np.mean(pol.step_time_us)), 1))

    # ---- attack acceptance per class x policy
    acc_table = [("acc_replay", "RA2", "Replay"),
                 ("acc_pcs", "RA3", "Pcs"),
                 ("acc_imperson", "RA4", "Imp"),
                 ("acc_rollback", "RA5", "Roll"),
                 ("acc_regression", "RA6", "Reg"),
                 ("acc_ffdos", "RA8", "FfDos"),
                 ("acc_retro", "RA9", "Retro")]
    for key, scen, tag in acc_table:
        for pol_id in ALL_POLS:
            m, e = mstat(raw, scen, pol_id, key)
            sh = POLNAME[pol_id]
            M(f"Ra{tag}Acc{sh}", pct(m))
            M(f"Ra{tag}Acc{sh}Err", pct(e))

    # ---- headline security rates
    for pol_id in ALL_POLS:
        sh = POLNAME[pol_id]
        M(f"RaImp{sh}", pct(mstat(raw, "RA4", pol_id, "imperson_rate")[0]))
        M(f"RaPcsLeak{sh}", pct(mstat(raw, "RA3", pol_id, "pcs_leak_rate")[0]))
        M(f"RaRetro{sh}", pct(mstat(raw, "RA9", pol_id, "retro_rate")[0]))
        M(f"RaHquar{sh}", pct(mstat(raw, "RA1", pol_id, "hquar")[0]))
        M(f"RaAvail{sh}", pct(mstat(raw, "RA1", pol_id, "availability")[0]))
        M(f"RaAvailLong{sh}", pct(mstat(raw, "RA7", pol_id, "availability")[0]))

    # ---- aggregate targeted-class acceptance (worst case over the 5 named attack
    #      classes for P_Qartz) so ONE macro provably covers all classes cited in
    #      the abstract (finding 3/8): replaces aliasing RaImpAccQartz for all.
    _allcls = [mstat(raw, "RA2", "P_Qartz", "acc_replay")[0],
               mstat(raw, "RA4", "P_Qartz", "acc_imperson")[0],
               mstat(raw, "RA5", "P_Qartz", "acc_rollback")[0],
               mstat(raw, "RA6", "P_Qartz", "acc_regression")[0],
               mstat(raw, "RA9", "P_Qartz", "acc_retro")[0]]
    _allcls = [v for v in _allcls if not np.isnan(v)]
    M("RaAllClassAccQartz", pct(max(_allcls)) if _allcls else "0.0")

    # ---- hybrid-floor equality check: A_noDrkem must equal P_Qartz on every
    #      non-RA9 security/availability metric (Lemma H implementation witness).
    #      Count real (non-both-NaN) comparisons and fail loud if coverage collapses.
    floor_ok = True
    n_cmp = 0
    for scen in ("RA1", "RA2", "RA3", "RA4", "RA5", "RA6", "RA7", "RA8"):
        for key in ("availability", "imperson_rate", "pcs_leak_rate",
                    "acc_replay", "acc_imperson", "acc_rollback", "acc_regression"):
            a = mstat(raw, scen, "P_Qartz", key)[0]
            b = mstat(raw, scen, "A_noDrkem", key)[0]
            if np.isnan(a) and np.isnan(b):
                continue
            n_cmp += 1
            if np.isnan(a) or np.isnan(b) or abs(a - b) > 1e-9:
                floor_ok = False
    MIN_CMP = 14                        # degeneracy guard: fail if coverage drops
    floor_ok = floor_ok and n_cmp >= MIN_CMP
    M("RaHybridFloorHolds", "yes" if floor_ok else "NO")
    M("RaHybridFloorN", str(n_cmp))
    M("RaRetroQartzVsNoDr",
      f"{pct(mstat(raw, 'RA9', 'P_Qartz', 'retro_rate')[0])}"
      f"/{pct(mstat(raw, 'RA9', 'A_noDrkem', 'retro_rate')[0])}")

    # ---- latency by condition (GT-R resume vs FullReAttest anchor)
    for cond in CONDS:
        cn = CONDNAME[cond]
        m, e = mstat(raw, "RA1", "P_Qartz", f"lat_{cond}_resume")
        M(f"RaLat{cn}Resume", num(m, 1)); M(f"RaLat{cn}ResumeErr", num(e, 1))
        M(f"RaFullAnchor{cn}", num(TLS_PQC[cond] + QUOTE_MS + QUOTE_VERIFY_MS, 1))

    # ---- bytes per mode (from the byte model)
    p_std = R.ReauthPolicy(PolCfg("std", drkem=False), b"\x00" * 32)
    p_hyb = R.ReauthPolicy(CFGS["P_Qartz"], b"\x00" * 32)
    p_sig = R.ReauthPolicy(CFGS["P_QartzSig"], b"\x00" * 32)
    p_mac = R.ReauthPolicy(CFGS["B_MacTicket"], b"\x00" * 32)
    M("RaBytesStd", num(p_std._bytes("resume"), 0))
    M("RaBytesHybrid", num(p_hyb._bytes("resume"), 0))
    M("RaBytesSig", num(p_sig._bytes("resume"), 0))
    M("RaBytesMac", num(p_mac._bytes("resume"), 0))
    M("RaBytesFull", num(p_hyb._bytes("fullreattest"), 0))

    # ---- independent local-gap and drift frontiers (availability >= 50%)
    def last_value(pol, key, values):
        av = np.asarray(fr[pol][key])
        idx = np.where(av >= 0.5)[0]
        return values[idx[-1]] if len(idx) else 0
    M("RaGapFrontierQartzLimit",
      str(last_value("P_Qartz", "gap_avail", GAPS)))
    M("RaDriftFrontierQartzLimit",
      str(last_value("P_Qartz", "drift_avail", DRIFTS)))
    M("RaDriftFrontierWindowLimit",
      str(last_value("B_DriftWin", "drift_avail", DRIFTS)))
    M("RaDriftFrontierQartzAvailAtFive",
      pct(fr["P_Qartz"]["drift_avail"][DRIFTS.index(5)]))
    M("RaDriftFrontierWindowAvailAtFive",
      pct(fr["B_DriftWin"]["drift_avail"][DRIFTS.index(5)]))

    # ---- seal batch sweep
    M("RaSealRollAtOne", pct(seal["roll_acc"][0]))
    M("RaSealRollAtSixteen", pct(seal["roll_acc"][-1]))

    # ---- robustness worst case
    for tag, row in rob.items():
        M(f"RaRob{tag}Rng", str(row["rng"]))
        M(f"RaRob{tag}Acc", num(row["acc"], 1))
        M(f"RaRob{tag}Avail", num(row["av"], 1))
    M("RaRobAccMax", num(max(r["acc"] for r in rob.values()), 1))
    M("RaRobAvailMin", num(min(r["av"] for r in rob.values()), 1))

    # ---- guard audit (P_Qartz), aggregated per attack kind
    agg = {}
    for scen in SCENARIOS:
        for r in raw.get((scen, "P_Qartz"), []):
            for kind, a in r.get("guard_audit", {}).items():
                g = agg.setdefault(kind, {"n": 0, "acc": 0, "reasons": {}})
                g["n"] += a["n"]; g["acc"] += a["acc"]
                for why, c in a["reasons"].items():
                    g["reasons"][why] = g["reasons"].get(why, 0) + c
    # benign omitted: the guard audit is attack-rejection accounting; a "benign
    # acceptance rate" is counted 0 by construction (accepted= is attack-only) and
    # would mislead (finding 11).
    AUDIT = [("replay", "Replay"), ("impersonate_active", "Imp"),
             ("rollback", "Roll"), ("regression", "Reg"), ("retro", "Retro"),
             ("fastforward_dos", "FfDos")]
    for kind, K in AUDIT:
        g = agg.get(kind, {"n": 0, "acc": 0, "reasons": {}})
        M(f"RaAuditN{K}", str(g["n"]))
        M(f"RaAuditAcc{K}", pct(g["acc"] / g["n"]) if g["n"] else "--")
        if g["reasons"]:
            top = sorted(g["reasons"].items(), key=lambda kv: -kv[1])[0][0]
            M(f"RaAuditWhy{K}", REASON_LABEL.get(top, top))
        else:
            M(f"RaAuditWhy{K}", "accepted" if g["acc"] else "--")

    # ---- Epoch-indexed FS-KEM (from ML-KEM-768) sizes + enrollment cost
    M("RaDrCtBytes", str(R.DR_CT_BYTES))            # reconnect ct = one ML-KEM ct
    M("RaDrPkBytes", str(R.DR_PK_BYTES))            # one epoch pk
    M("RaDrEncapsMs", num(R.DR_ENCAPS_MS, 2))
    M("RaDrDecapsMs", num(R.DR_DECAPS_MS, 2))
    M("RaDrFfPerEpochUs", num(R.DR_FF_PER_EPOCH_US, 1))

    # ---- misc
    M("RaNumRuns", str(RUNS))
    M("RaSimT", str(T))
    M("RaNumPol", str(len(ALL_POLS)))
    M("RaNumScen", str(len(SCENARIOS)))
    M("RaDmax", str(R.D_MAX))
    M("RaGmax", str(R.G_MAX))
    M("RaHandshakeRetries", str(R.N_RETRY_HS))
    M("RaMldsaBytes", str(R.B_SIG))
    M("RaKemCtBytes", str(R.B_KEMCT))
    M("RaKemPkBytes", str(R.B_KEMPK))
    M("RaPayloadBytes", str(R.B_PAY))
    M("RaMacTagBytes", str(R.B_MACTAG))
    M("RaSimSecs", num(runtime_s, 0))

    with open(os.path.join(OUT, "reauth_macros.tex"), "w") as f:
        f.write("% auto-generated by run_reauth_experiments.py -- do not edit\n")
        f.write("\n".join(lines) + "\n")
    print(f"[macros] {len(lines)} written to results/reauth_macros.tex")
    return len(lines)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_manifest(runtime_s, macro_count):
    """Record enough environment and provenance data to audit a rerun."""
    output_names = [
        "raw_metrics.csv", "episode_outcomes.csv.gz", "frontier.npy",
        "frontier_runs.csv", "seal_sweep.csv", "robustness_runs.csv",
        "reauth_macros.tex",
    ]
    figure_names = [
        "fig_ra_gap_frontier.pdf", "fig_ra_drift_frontier.pdf",
        "fig_ra_boundaries.pdf",
        "fig_ra_attacks.pdf",
        "fig_ra_latency.pdf", "fig_ra_retro.pdf",
    ]
    manifest = {
        "schema": "gtr.reauth.simulation-manifest.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "entrypoint": os.path.basename(__file__),
        "python": sys.version,
        "platform": platform.platform(),
        "dependencies": {
            "numpy": np.__version__,
            "matplotlib": matplotlib.__version__,
        },
        "parameters": {
            "trace_seed_base": TRACE_SEED_BASE,
            "link_seed_base": LINK_SEED_BASE,
            "runs": RUNS,
            "episodes_per_trace": T,
            "scenarios": SCENARIOS,
            "policies": ALL_POLS,
            "d_max": R.D_MAX,
            "g_max": R.G_MAX,
            "frontier_runs": FRONTIER_RUNS,
            "robustness_runs": ROB_RUNS,
        },
        "counts": {
            "policy_episode_evaluations": len(SCENARIOS) * RUNS * T * len(ALL_POLS),
            "summary_rows": len(SCENARIOS) * RUNS * len(ALL_POLS),
            "latex_macros": macro_count,
        },
        "runtime_seconds": runtime_s,
        "source_sha256": {
            "reauth_sim.py": _sha256(os.path.join(HERE, "reauth_sim.py")),
            "run_reauth_experiments.py": _sha256(__file__),
        },
        "outputs_sha256": {},
    }
    for name in output_names:
        path = os.path.join(OUT, name)
        if os.path.exists(path):
            manifest["outputs_sha256"][f"results/{name}"] = _sha256(path)
    for name in figure_names:
        path = os.path.join(FIG, name)
        if os.path.exists(path):
            manifest["outputs_sha256"][f"figures/{name}"] = _sha256(path)
    path = os.path.join(OUT, "reauth_manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write("\n")
    print(f"[manifest] {path}")
    return path


# ------------------------------------------------------------------ main
if __name__ == "__main__":
    t0 = time.time()
    raw = aggregate()
    fr = frontier()
    seal = seal_sweep()
    rob = robustness()
    fig_ra_frontiers(fr)
    fig_ra_attacks(raw)
    fig_ra_latency(raw)
    fig_ra_retro(raw)
    runtime = time.time() - t0
    n = macros(raw, fr, seal, rob, runtime)
    write_manifest(runtime, n)
    print(f"total {runtime:.1f}s  ({n} macros)")
