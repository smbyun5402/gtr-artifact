import unittest

import numpy as np

from reauth_sim import Episode, PolCfg, ReauthPolicy


def episode(*, gap, delta, attack=None, verifier=True, adv=None):
    return Episode(
        idx=0,
        cond="clean",
        attack=attack,
        gap_epochs=gap,
        delta=delta,
        verifier_reachable=verifier,
        captured_chain=False,
        extracted_rot=False,
        cur_e=10,
        peer_e=10 + delta,
        lse=10,
        adv=adv or {},
    )


class DecisionGuardTests(unittest.TestCase):
    def policy(self, **overrides):
        cfg = PolCfg("test", **overrides)
        value = ReauthPolicy(cfg, b"x" * 32)
        value._rng = np.random.default_rng(7)
        return value

    def test_gap_and_drift_limits_are_independent(self):
        policy = self.policy(d_max=8, g_max=4)
        outcome = policy.run_episode(episode(gap=5, delta=1), policy._rng)
        self.assertEqual(outcome["path"], "fullreattest")

    def test_gap_boundary_resumes(self):
        policy = self.policy(d_max=8, g_max=4)
        outcome = policy.run_episode(episode(gap=4, delta=1), policy._rng)
        self.assertEqual(outcome["path"], "resume")

    def test_drift_boundary_is_independent_of_gap(self):
        policy = self.policy(d_max=2, g_max=8)
        outcome = policy.run_episode(episode(gap=2, delta=3), policy._rng)
        self.assertEqual(outcome["path"], "fullreattest")

    def test_replay_does_not_reach_accepting_state(self):
        policy = self.policy()
        outcome = policy.run_episode(episode(gap=1, delta=0, attack="replay"),
                                     policy._rng)
        self.assertFalse(outcome["accepted"])


if __name__ == "__main__":
    unittest.main()
