# Q-ARTZ-Control simulation core.
# Implements the security-state estimator (Alg. 1), the constrained PQC-hybrid
# mode controller (Alg. 2), the E0-E5 profile resolver, baselines and the
# ablations defined in the paper. All policies consume the same pre-generated
# evidence trace per seed so comparisons are paired.
#
# Cryptography is modeled symbolically (Dolev-Yao): signature validity is an
# oracle bit (the EUF-CMA reduction covers forgery), but state binding and
# monotonic-counter arithmetic are COMPUTED from node-side state, so replay
# and rollback rejection are exercised mechanically, not assumed.

import time
import numpy as np
from dataclasses import dataclass

# ---------------------------------------------------------------- constants
PQC, HYBRID, LEGACY_EXC, SUSPEND = "PQC", "HYBRID", "LEGACY_EXC", "SUSPEND"
E0, E1, E2, E3, E4, E5 = range(6)
DIMS = ["integrity", "runtime", "provenance"]

RC_PSI_HI = {0: 0.70, 1: 0.65, 2: 0.50, 3: 0.35}   # Table II
RC_PSI_MID = {0: 0.50, 1: 0.45, 2: 0.30, 3: 0.20}

# Prop(mode, RC) matrix (appendix)
PROP = {
    PQC:        {0: 1, 1: 1, 2: 1, 3: 1},
    HYBRID:     {0: 1, 1: 1, 2: 1, 3: 0},
    LEGACY_EXC: {0: 1, 1: 1, 2: 0, 3: 0},
    SUSPEND:    {0: 1, 1: 1, 2: 1, 3: 1},
}


@dataclass
class Params:
    gamma: float = 0.995        # long-timescale EWMA
    beta_max: float = 0.90      # short-timescale EWMA, calm
    beta_min: float = 0.30      # short-timescale EWMA, shock
    lam: float = 0.60           # short/long blend
    delta: float = 0.25         # shock threshold
    tau_fresh: float = 250.0    # freshness decay constant (steps)
    rho_zero: float = 1e-3      # numerical zero for unavailable evidence
    eta_hi: float = 0.50
    eta_hi_exit: float = 0.40
    eta_lo: float = 0.20
    chi_min: float = 0.60
    a_min: float = 0.30
    rho_patch: float = 0.35
    rho_exc: float = 0.50
    rho_att_min: float = 0.40
    lam_u: float = 0.30         # risk weight for missing confidence
    lam_eta: float = 0.60
    lam_chi: float = 0.50
    trust_theta: float = 0.50   # scalar-baseline deny threshold
    rc_dwell: int = 120
    ttl_exc: int = 300
    ddil_budget_steps: int = 2400  # consecutive benign low-availability cap
    ddil_recovery_steps: int = 30  # healthy/confident steps before budget reset


# ---------------------------------------------------------------- traces
@dataclass
class Trace:
    T: int
    a_true: np.ndarray            # link quality [0,1]
    outage: np.ndarray            # bool
    compromised: np.ndarray       # bool ground truth
    misuse: np.ndarray            # behavior-detector output [0,1]
    ev_arrive: dict               # dim -> bool array (fresh evidence this step)
    ev_q: dict                    # dim -> score array
    ev_assure: dict               # dim -> assurance constant
    chi_soft: np.ndarray
    hardfail: np.ndarray          # 0 none, 1 typed hard fail
    res_reported: np.ndarray      # reported resource level [0,1]
    res_true: np.ndarray
    peer_legacy_only: np.ndarray  # bool
    pa_reachable: np.ndarray      # bool
    waiver_kind: list             # None | valid/replay/forged/rollback/expired/rebased
    secrecy_critical: bool
    attack_window: tuple          # (t0,t1) ground-truth attack interval or None


def _outage_mask(T, rng, n_out, lo=150, hi=300):
    mask = np.zeros(T, bool)
    for _ in range(n_out):
        L = rng.integers(lo, hi)
        s = rng.integers(0, max(1, T - L))
        mask[s:s + L] = True
    return mask


def make_trace(scenario, T, seed):
    """Generate one ground-truth + evidence trace for a scenario."""
    rng = np.random.default_rng(seed)
    a_true = np.clip(0.88 + 0.05 * rng.standard_normal(T), 0, 1)
    outage = np.zeros(T, bool)
    compromised = np.zeros(T, bool)
    misuse = np.clip(0.03 + 0.03 * np.abs(rng.standard_normal(T)), 0, 1)  # FP floor
    chi_soft = np.clip(0.95 + 0.03 * rng.standard_normal(T), 0, 1)
    hardfail = np.zeros(T, int)
    res_true = np.clip(0.8 - 0.15 * rng.random(T), 0, 1)
    res_reported = res_true.copy()
    peer_legacy_only = np.zeros(T, bool)
    pa_reachable = np.ones(T, bool)
    waiver_kind = [None] * T
    attack_window = None
    secrecy_critical = False

    outage_link = 0.10            # disrupted/intermittent: residual trickle
    if scenario == "S1":          # benign DDIL: long link blackouts
        outage = _outage_mask(T, rng, 3, lo=250, hi=600)
    elif scenario == "S1L":       # benign DDIL: long *denied* phases (no link)
        outage = _outage_mask(T, rng, 2, lo=900, hi=1300)
        outage_link = 0.0
    elif scenario in ("S2", "S5"):  # downgrade adversary (RC1: real interop loss)
        t0 = T // 3
        attack_window = (t0, T)
        peer_legacy_only[t0:] = True            # interop pressure (A3 lure)
        res_reported[t0:] *= 0.15               # spoofed resource exhaustion
        if scenario == "S5":
            pa_reachable[t0:] = False           # full policy partition (A5)
        else:
            pa_reachable[t0:t0 + (T - t0) // 2] = False
        kinds = ["replay", "forged", "rollback", "expired", "rebased"]
        for i, t in enumerate(range(t0, T, max(1, (T - t0) // 32))):
            waiver_kind[t] = kinds[i % 5]       # adversarial attempts
        for t in range(t0 + 10, T, 200):        # PA issues valid waivers when up
            if pa_reachable[t] and waiver_kind[t] is None:
                waiver_kind[t] = "valid"
    elif scenario == "S2b":       # benign control: real interop loss, PA up
        t0 = T // 3
        peer_legacy_only[t0:] = True
        for t in range(t0, T, 200):
            waiver_kind[t] = "valid"
    elif scenario == "S3":        # compromised-but-authorized
        tc = int(0.3 * T)
        compromised[tc:] = True
        attack_window = (tc, T)
        ramp = np.clip((np.arange(T) - tc) / 400.0, 0, 1)
        misuse = np.clip(misuse + compromised * (0.35 + 0.45 * ramp)
                         * (rng.random(T) < 0.8), 0, 1)
    elif scenario == "S4":        # confused DDIL: jamming + stealthy misuse + drift
        s, e = int(0.3 * T), int(0.65 * T)
        outage[s:e] = True
        tc = s + 100
        compromised[tc:] = True
        attack_window = (tc, T)
        ramp = np.clip((np.arange(T) - tc) / 400.0, 0, 1)
        misuse = np.clip(misuse + compromised * (0.35 + 0.45 * ramp)
                         * (rng.random(T) < 0.8), 0, 1)
        # soft consistency drift (epoch/manifest skew) observed at the first
        # sync exchange after onset -- injection latency is explicit, not zero
        d_sync = int(rng.integers(20, 60))
        chi_soft[tc + d_sync:] = np.clip(chi_soft[tc + d_sync:] - 0.40, 0, 1)
        for t in range(tc + 150, e, 300):       # occasional typed hard fail
            if rng.random() < 0.5:
                hardfail[t] = 1

    a_true = np.where(outage,
                      np.clip(outage_link + 0.06 * rng.standard_normal(T)
                              * (outage_link > 0), 0, 1),
                      a_true)

    # evidence arrival: probability scales with link quality
    ev_arrive, ev_q, ev_assure = {}, {}, {}
    base_rate = {"integrity": 1 / 50.0, "runtime": 1 / 5.0, "provenance": 1 / 80.0}
    assure = {"integrity": 0.95, "runtime": 0.70, "provenance": 0.85}
    for d in DIMS:
        arr = rng.random(T) < base_rate[d] * np.clip(a_true / 0.8, 0, 1)
        q = np.clip(0.92 + 0.04 * rng.standard_normal(T), 0, 1)
        if d == "runtime":
            q = np.where(compromised, np.clip(0.45 + 0.1 * rng.standard_normal(T), 0, 1), q)
        if d == "integrity":
            # fresh attestation reveals compromise with prob 0.6
            reveal = compromised & (rng.random(T) < 0.6)
            q = np.where(reveal, np.clip(0.25 + 0.1 * rng.standard_normal(T), 0, 1), q)
        ev_arrive[d], ev_q[d], ev_assure[d] = arr, q, assure[d]

    return Trace(T, a_true, outage, compromised, misuse, ev_arrive, ev_q,
                 ev_assure, chi_soft, hardfail, res_reported, res_true,
                 peer_legacy_only, pa_reachable, waiver_kind, secrecy_critical,
                 attack_window)


# ---------------------------------------------------------------- Q-ARTZ policy
class QARTZ:
    """Full Q-ARTZ-Control node-local loop. Ablations via flags."""

    def __init__(self, p=None, no_conf=False, no_sep=False, no_chi=False,
                 no_guard=False, atomic=False, no_c1c2=False,
                 guard_variant="full", rng=None):
        self.p = p or Params()
        self.no_conf, self.no_sep, self.no_chi = no_conf, no_sep, no_chi
        self.no_guard, self.atomic, self.no_c1c2 = no_guard, atomic, no_c1c2
        # guard conjunct reductions (reviewer-style deployable baselines):
        #   "full"    -- Eq. (17) as designed
        #   "sigttl"  -- signature + expiry only ("signed fallback")
        #   "sigctr"  -- + counter equation (ticket-style single use)
        #   "nogates" -- all cryptographic conjuncts, no estimator gates
        self.guard_variant = guard_variant
        self.rng = rng or np.random.default_rng(0)
        self.TL = {d: 0.9 for d in DIMS}
        self.TS = {d: 0.9 for d in DIMS}
        self.That_prev = {d: 0.9 for d in DIMS}
        self.age = {d: 0.0 for d in DIMS}
        self.eta = 0.0
        self.rc = 0
        self.rc_last_up = -10**9
        self.mode = HYBRID
        # RoT-protected node state consumed by the waiver guard
        self.trans_ctr = 0
        self.sec_epoch = 0
        self.key_epoch = 0
        # provisioning-time core state: the base a "rebased" token binds to
        self.digest_init = (0, HYBRID, 0, 0)
        self.last_valid_token = None   # captured by the replay adversary
        self.exc_until = -1
        self.exc_binding = None        # (RC, secEpoch, keyEpoch) at entry
        self.ddil_low_steps = 0
        self.ddil_recovery_streak = 0
        self.risk_high_since = None
        self.step_time_us = []

    # ---- estimator (Alg. 1)
    def _estimate(self, tr, t):
        p = self.p
        That, rho = {}, {}
        for d in DIMS:
            if tr.ev_arrive[d][t]:
                self.age[d] = 0.0
                q = tr.ev_q[d][t]
            else:
                self.age[d] += 1.0
                q = None
            rho_fresh = np.exp(-self.age[d] / p.tau_fresh)
            rho_d = rho_fresh * tr.ev_assure[d]
            if self.no_conf:
                # ablation: no confidence channel; missing evidence scored as 0
                That[d] = q if q is not None else 0.0
                rho[d] = 1.0
            else:
                # Missing samples are held; only confidence decays.  rho_zero
                # makes the mathematical absence rule executable at finite t.
                That[d] = q if q is not None else self.That_prev[d]
                rho[d] = 0.0 if q is None and rho_d < p.rho_zero else rho_d
            self.That_prev[d] = That[d]

        hard = tr.hardfail[t] == 1
        if hard:
            # typed hard fail: early return, timescale state frozen (Alg. 1)
            a = tr.a_true[t]
            self.eta = 0.9 * self.eta + 0.1 * tr.misuse[t]
            T = {d: self.p.lam * self.TS[d] + (1 - self.p.lam) * self.TL[d]
                 for d in DIMS}
            return T, rho, a, 0.0, self.eta, 1.0, True

        # A fast-timescale shock requires at least two concurrently active
        # dimensions/sources to deviate; one low score alone is not a shock.
        deviating = {d: rho[d] > 0.0 and
                     abs(That[d] - self.TS[d]) > p.delta for d in DIMS}
        corroborated = sum(deviating.values()) >= 2
        for d in DIMS:
            beta = p.beta_min if corroborated and deviating[d] else p.beta_max
            self.TL[d] = p.gamma * self.TL[d] + (1 - p.gamma) * That[d]
            self.TS[d] = beta * self.TS[d] + (1 - beta) * That[d]
        T = {d: p.lam * self.TS[d] + (1 - p.lam) * self.TL[d] for d in DIMS}

        a = tr.a_true[t]
        self.eta = 0.9 * self.eta + 0.1 * tr.misuse[t]
        eta = self.eta
        if self.no_sep:
            eta = max(eta, 1.0 - a)                  # ablation: mix link into eta
        chi = 1.0 if self.no_chi else tr.chi_soft[t]
        psi = sum((1 / 3) * (rho[d] * (1 - T[d]) + p.lam_u * (1 - rho[d]))
                  for d in DIMS)
        psi += p.lam_eta * eta + p.lam_chi * (1 - chi)
        psi = min(1.0, psi)
        return T, rho, a, chi, eta, psi, False

    # ---- symbolic waiver handling: state binding and counters are computed
    def _make_token(self, kind, t, tr):
        """Materialize the token the adversary/PA presents at step t."""
        digest = (self.rc, self.mode, self.sec_epoch, self.key_epoch)
        exp = t + self.p.ttl_exc
        if kind == "valid":
            if not tr.pa_reachable[t]:
                return None                      # PA cannot issue while down
            return dict(sig=True, digest=digest, to_ctr=self.trans_ctr + 1,
                        exp=exp)
        if kind == "forged":
            return dict(sig=False, digest=digest, to_ctr=self.trans_ctr + 1,
                        exp=exp)
        if kind == "rollback":
            return dict(sig=True, digest=digest, to_ctr=self.trans_ctr,
                        exp=exp)
        if kind == "expired":                    # PA-signed but past its exp
            return dict(sig=True, digest=digest, to_ctr=self.trans_ctr + 1,
                        exp=t - 1)
        if kind == "replay":
            if self.last_valid_token is not None:
                return dict(self.last_valid_token)   # verbatim reuse
            return dict(sig=True, digest=(0, HYBRID, -1, -1), to_ctr=0,
                        exp=exp)
        if kind == "rebased":
            # PA-signed for an older base state of this node (solicited or
            # captured before the state transition); the counter target is
            # chosen unspent and the expiry fresh, so the state digest is the
            # ONLY conjunct separating it from a valid token -- this isolates
            # what exact-state binding contributes over counter-only designs.
            return dict(sig=True, digest=self.digest_init,
                        to_ctr=self.trans_ctr + 1, exp=exp)
        return None

    def _guard(self, tok, t, chi, eta, rho):
        """Returns (ok, rejecting-conjunct). guard_variant truncates the
        conjunct sequence to model deployable weaker guards; an acceptance
        that the full guard's estimator gates would have refused is tagged
        "acceptthin" (thin-evidence entry).

        The policyHash/capDigest and epoch-/mode-/scope-target conjuncts
        of Eq. (17) are not modeled: no policy churn, epoch churn, or
        scope mismatch is injected within an episode (reconnect-time
        deltas are the companion protocol's domain), so they hold
        trivially -- disclosed in the paper's fidelity paragraph."""
        p = self.p
        digest_now = (self.rc, self.mode, self.sec_epoch, self.key_epoch)
        if tok is None:
            return False, "none"
        if not tok["sig"]:
            return False, "sig"
        if tok["exp"] < t:
            return False, "fresh"
        if self.guard_variant == "sigttl":
            return True, "accept"        # signed fallback: no state binding
        if tok["to_ctr"] != self.trans_ctr + 1:
            return False, "ctr"
        if self.guard_variant == "sigctr":
            return True, "accept"        # single-use ticket: no state binding
        if tok["digest"] != digest_now:
            return False, "digest"
        gates_ok = (chi > p.chi_min and eta < p.eta_lo
                    and min(rho.values()) >= p.rho_exc
                    and rho["integrity"] >= p.rho_att_min
                    and bool(PROP[LEGACY_EXC][self.rc]))
        if self.guard_variant == "nogates":
            return True, ("accept" if gates_ok else "acceptthin")
        if not (chi > p.chi_min and eta < p.eta_lo):
            return False, "estimator"
        if not (min(rho.values()) >= p.rho_exc
                and rho["integrity"] >= p.rho_att_min):
            return False, "confidence"
        if not PROP[LEGACY_EXC][self.rc]:
            return False, "prop"
        return True, "accept"

    # ---- mode objective J(m,t), Eq. (15): mission-weighted cost
    def _J(self, m, tr, t):
        res, a = tr.res_reported[t], tr.a_true[t]
        c_sec = {PQC: 0.05, HYBRID: 0.15}[m]
        c_perf = {PQC: 0.50, HYBRID: 0.30}[m] * (1 - res)
        c_link = {PQC: 0.30, HYBRID: 0.15}[m] * (1 - a)
        c_int = {PQC: 0.30, HYBRID: 0.10}[m]
        c_sw = 1.0 if m != self.mode else 0.0
        raw = ((0.60, 0.20, 0.15, 0.05, 0.15) if self.rc >= 2 else
               (0.25, 0.20, 0.15, 0.25, 0.15))
        z = sum(raw)
        w_sec, w_perf, w_link, w_int, w_sw = (w / z for w in raw)
        return (w_sec * c_sec + w_perf * c_perf + w_link * c_link
                + w_int * c_int + w_sw * c_sw)

    # ---- controller (Alg. 2) + resolver
    def step(self, tr, t):
        t0 = time.perf_counter()
        p = self.p
        T, rho, a, chi, eta, psi, hard = self._estimate(tr, t)

        # reqClass (Eq. 20) with hysteresis
        rc_target = 0
        if tr.peer_legacy_only[t]:
            rc_target = max(rc_target, 1)
        if tr.secrecy_critical:
            rc_target = max(rc_target, 2)
        if eta >= p.eta_hi or chi < p.chi_min:
            rc_target = 3
        if rc_target > self.rc:
            self.rc, self.rc_last_up = rc_target, t
        elif rc_target < self.rc and t - self.rc_last_up > p.rc_dwell and \
                eta < p.eta_hi_exit:
            self.rc = rc_target

        # Rule C2: risk-driven promotion
        if not self.no_c1c2 and psi >= RC_PSI_HI[self.rc]:
            self.rc, self.rc_last_up = 3, t

        conf_low = min(rho.values()) < p.rho_patch
        benign_low_avail = (a < p.a_min and eta < p.eta_lo and
                            chi >= p.chi_min)
        if benign_low_avail:
            self.ddil_low_steps += 1
            self.ddil_recovery_streak = 0
        elif (a >= p.a_min and min(rho.values()) >= p.rho_patch and
              eta < p.eta_lo and chi >= p.chi_min):
            # A brief link flicker cannot renew the whole DDIL allowance.
            self.ddil_recovery_streak += 1
            if self.ddil_recovery_streak >= p.ddil_recovery_steps:
                self.ddil_low_steps = 0
        else:
            self.ddil_recovery_streak = 0
        ddil_budget_exhausted = \
            self.ddil_low_steps >= p.ddil_budget_steps

        # profile candidates
        cand = []
        if hard:
            cand.append(E5 if chi <= 0 else E4)
        if eta >= p.eta_hi:
            cand.append(E4 if chi < p.chi_min else E3)
        if chi < p.chi_min and a >= p.a_min:
            cand.append(E4)
        if psi >= RC_PSI_HI[self.rc]:
            cand.append(E3)
            # sustained high risk that re-auth did not clear -> full re-attest
            if self.risk_high_since is None:
                self.risk_high_since = t
            elif t - self.risk_high_since >= 100:
                cand.append(E4)
        else:
            self.risk_high_since = None
            if psi >= RC_PSI_MID[self.rc]:
                cand.append(E2)
        if conf_low and eta < p.eta_hi and not hard and not self.no_c1c2:
            cand.append(E1)                     # Rule C1: short TTL + re-attest
        if benign_low_avail:
            # Degraded DDIL operation is finite even if low availability
            # persists; reset requires sustained healthy, confident recovery.
            if ddil_budget_exhausted:
                cand.append(E4)
            else:
                cand.append(E1 if self.rc <= 1 else E4)
        if a < p.a_min and eta >= p.eta_hi:
            cand.append(E4)
        if not cand:
            cand.append(E0)

        conflict = len(set(cand)) > 1
        if self.atomic:
            # ablation: single-source arbitration (uniform among proposers)
            profile = cand[int(self.rng.integers(len(cand)))]
        else:
            profile = max(cand)
        weak = conflict and profile < max(cand)

        # The ordinary objective may select secure modes only. Legacy-exc is
        # reachable solely through the waiver transition below; Suspend is
        # the explicit fail-closed transition when neither path is available.
        adm = []
        for m in (PQC, HYBRID):
            if not PROP[m][self.rc]:
                continue
            if tr.peer_legacy_only[t]:
                continue                        # Comp fails
            need = 0.25 if m == PQC else 0.15
            if tr.res_reported[t] < need:
                continue                        # Res fails
            adm.append(m)

        # Rule C1 gates the exception path BEFORE any selection (cf. Alg. 2);
        # the guard-conjunct reductions model estimator-decoupled baselines,
        # so the estimator-coupled Rule C1 forbid does not apply to them
        exc_allowed = (self.no_c1c2 or not conf_low or
                       self.guard_variant != "full")

        exc_taken, exc_invalid = False, False
        guard_event = None
        if profile >= E4:
            mode = SUSPEND
        elif adm:
            mode = min(adm, key=lambda m: self._J(m, tr, t))
        else:
            kind = tr.waiver_kind[t]
            tok = self._make_token(kind, t, tr) if kind else None
            ok, reason = False, None
            if tok is not None:
                if not exc_allowed:
                    reason = "ruleCone"
                elif self.no_guard:
                    ok, reason = True, "accept"
                else:
                    ok, reason = self._guard(tok, t, chi, eta, rho)
                guard_event = (kind, ok, reason)
            if ok:
                mode = LEGACY_EXC
                self.trans_ctr += 1             # single-use: counter consumed
                self.last_valid_token = tok if kind == "valid" else \
                    self.last_valid_token
                self.exc_until = t + p.ttl_exc
                self.exc_binding = (self.rc, self.sec_epoch, self.key_epoch)
                exc_taken, exc_invalid = True, kind != "valid"
            elif (self.mode == LEGACY_EXC and t < self.exc_until and
                  self.exc_binding == (self.rc, self.sec_epoch,
                                       self.key_epoch) and
                  bool(PROP[LEGACY_EXC][self.rc]) and exc_allowed and
                  eta < p.eta_lo and chi > p.chi_min and
                  min(rho.values()) >= p.rho_exc and
                  rho["integrity"] >= p.rho_att_min and profile < E3):
                # TTL continuation revalidates live policy class, the
                # entry-bound epochs/class, and every live estimator gate.
                mode = LEGACY_EXC
            else:
                mode = SUSPEND

        mode_changed = mode != self.mode
        if mode == SUSPEND and profile < E4:
            # Suspend is a fail-closed E4 transition, never an E0/E2 action.
            profile = E4
        if mode_changed and profile < E2:
            # Every mode change is an atomic ModeSwitch+Rekey bundle. E4/E5
            # already contain a stronger key/recovery action.
            profile = E2
        if mode_changed:
            # Model the committed RotateKey target, not only its action flag.
            self.key_epoch += 1
        if exc_taken:
            # The waiver binds the issuance base state; continuation pins the
            # post-transition epoch produced by the mandatory rekey.
            self.exc_binding = (self.rc, self.sec_epoch, self.key_epoch)
        if mode != LEGACY_EXC:
            self.exc_until = -1
            self.exc_binding = None
        self.mode = mode
        allow = profile <= E3 and mode != SUSPEND
        self.step_time_us.append((time.perf_counter() - t0) * 1e6)
        return dict(profile=profile, mode=mode, allow=allow, psi=psi, eta=eta,
                    chi=chi, rc=self.rc, exc=exc_taken, exc_invalid=exc_invalid,
                    rekey=profile >= E2, conflict=conflict, weak=weak,
                    reattest=(profile == E1 or profile >= E4),
                    guard_event=guard_event,
                    T=dict(T), rho=dict(rho))


# ---------------------------------------------------------------- baselines
class ScalarTrust:
    """B1/B2/B3: single scalar trust score in the absence-as-distrust style:
    per-source values are held and decayed with staleness (same tau as Q-ARTZ
    uses for confidence), then fused into ONE score -- i.e., staleness is
    folded into trust instead of confidence. join-time-only variants (B1/B2)
    evaluate at admission and never afterwards. B1/B3 model capability-driven
    fallback (follow peer capability claims; no waiver requirement) -- this
    rule is what the absence of an authorization guard means operationally."""

    def __init__(self, mode, continuous=True, theta=0.5, tau=250.0):
        self.mode0, self.continuous, self.theta = mode, continuous, theta
        self.tau = tau
        self.v = {d: 0.92 for d in DIMS}
        self.age = {d: 0.0 for d in DIMS}
        self.eta = 0.0

    def step(self, tr, t):
        if self.continuous:
            for d in DIMS:
                if tr.ev_arrive[d][t]:
                    self.v[d], self.age[d] = tr.ev_q[d][t], 0.0
                else:
                    self.age[d] += 1.0
            self.eta = 0.9 * self.eta + 0.1 * tr.misuse[t]
            dims = np.mean([self.v[d] * np.exp(-self.age[d] / self.tau)
                            for d in DIMS])
            s = 0.75 * dims + 0.25 * (1.0 - self.eta)
            allow = s >= self.theta
        else:
            allow = True
        profile = E0 if allow else E5
        # capability-driven fallback (no waiver guard); static-PQC (B2) cannot
        # fall back and simply loses the legacy peer
        mode = self.mode0
        exc = False
        if tr.peer_legacy_only[t] and self.mode0 == HYBRID:
            mode, exc = LEGACY_EXC, True
        return dict(profile=profile, mode=mode, allow=allow, exc=exc,
                    exc_invalid=exc, rekey=False)


class GraceScalar:
    """G1: reviewer-style strongest scalar variant. Trust is fused from the
    most recent evidence per source WITHOUT staleness decay; when evidence
    goes stale the node enters a grace state that requests re-attestation
    (short-TTL allow) instead of denying. Deny requires the fused score to
    fall below theta on evidence that is actually fresh. This embeds the
    absence-of-evidence principle (our Rule C1 idea) into a single fused
    channel -- everything else (typed channels, waiver guard, mode control)
    is absent: fixed Hybrid with capability fallback."""

    def __init__(self, mode=HYBRID, theta=0.5, tau_grace=250.0):
        self.mode0, self.theta, self.tau_grace = mode, theta, tau_grace
        self.v = {d: 0.92 for d in DIMS}
        self.age = {d: 0.0 for d in DIMS}
        self.eta = 0.0

    def step(self, tr, t):
        for d in DIMS:
            if tr.ev_arrive[d][t]:
                self.v[d], self.age[d] = tr.ev_q[d][t], 0.0
            else:
                self.age[d] += 1.0
        self.eta = 0.9 * self.eta + 0.1 * tr.misuse[t]
        s = 0.75 * float(np.mean(list(self.v.values()))) \
            + 0.25 * (1.0 - self.eta)
        stale = min(self.age.values()) > self.tau_grace
        if s < self.theta and not stale:
            allow, profile = False, E5          # fresh negative evidence
        elif stale:
            allow, profile = True, E1           # grace: re-attest request
        else:
            allow, profile = True, E0
        mode, exc = self.mode0, False
        if tr.peer_legacy_only[t] and self.mode0 == HYBRID:
            mode, exc = LEGACY_EXC, True        # capability fallback, no guard
        return dict(profile=profile, mode=mode, allow=allow, exc=exc,
                    exc_invalid=exc, rekey=False)


class _EvidenceOpinion:
    """Shared evidence accumulator for the literature-grounded baselines:
    positive/negative evidence mass from the same streams Q-ARTZ sees
    (behavior every step, integrity/provenance on arrival), aged with the
    same staleness constant tau as our confidence channel."""

    def __init__(self, tau=250.0):
        self.decay = np.exp(-1.0 / tau)
        self.r, self.s = 5.0, 0.3          # warm start near benign steady state

    def update(self, tr, t):
        self.r *= self.decay
        self.s *= self.decay
        v = 1.0 - tr.misuse[t]
        self.r += 0.1 * v
        self.s += 0.1 * (1.0 - v)
        for d, wgt in (("integrity", 1.0), ("provenance", 0.5)):
            if tr.ev_arrive[d][t]:
                q = tr.ev_q[d][t]
                self.r += wgt * q
                self.s += wgt * (1.0 - q)


class SubjectiveLogicZT:
    """L1: subjective-logic zero trust (Josang-style opinions).
    Opinion (b,d,u) with uncertainty mass u = W/(r+s+W); absence of
    evidence raises u rather than disbelief -- the strongest prior-art
    treatment of the DDIL blackout problem. Decision on projected
    probability E = b + a*u. No attestation-typed channels, no mode
    control (fixed Hybrid, capability fallback), no waiver guard."""

    W, A, THETA = 2.0, 0.5, 0.5    # same operating point as L2/B3

    def __init__(self, rng=None):
        self.op = _EvidenceOpinion()

    def step(self, tr, t):
        self.op.update(tr, t)
        r, s = self.op.r, self.op.s
        b = r / (r + s + self.W)
        u = self.W / (r + s + self.W)
        allow = (b + self.A * u) >= self.THETA
        profile = E0 if allow else E5
        mode, exc = HYBRID, False
        if tr.peer_legacy_only[t]:
            mode, exc = LEGACY_EXC, True    # capability fallback, no guard
        return dict(profile=profile, mode=mode, allow=allow, exc=exc,
                    exc_invalid=exc, rekey=False)


class BetaReputation:
    """L2: beta-reputation trust (Ganeriwal et al.-style) with aging.
    Trust = expectation of Beta(r+1, s+1); deny below theta. Same
    evidence streams and aging as L1."""

    THETA = 0.5

    def __init__(self, rng=None):
        self.op = _EvidenceOpinion()

    def step(self, tr, t):
        self.op.update(tr, t)
        r, s = self.op.r, self.op.s
        trust = (r + 1.0) / (r + s + 2.0)
        allow = trust >= self.THETA
        profile = E0 if allow else E5
        mode, exc = HYBRID, False
        if tr.peer_legacy_only[t]:
            mode, exc = LEGACY_EXC, True    # capability fallback, no guard
        return dict(profile=profile, mode=mode, allow=allow, exc=exc,
                    exc_invalid=exc, rekey=False)


class ContextOnly:
    """B4: crypto-agile by context only; no trust, no waiver guard."""

    def step(self, tr, t):
        if tr.peer_legacy_only[t] or tr.res_reported[t] < 0.2:
            mode, exc = LEGACY_EXC, True
        elif tr.a_true[t] < 0.3:
            mode, exc = HYBRID, False
        else:
            mode, exc = PQC, False
        return dict(profile=E0, mode=mode, allow=True, exc=exc,
                    exc_invalid=exc, rekey=False)


class Oracle:
    """B6: sees ground truth; perfect separation upper bound."""

    def step(self, tr, t):
        comp = tr.compromised[t]
        profile = E4 if comp else E0
        mode = SUSPEND if comp else (PQC if tr.secrecy_critical else HYBRID)
        if not comp and tr.peer_legacy_only[t]:
            mode = LEGACY_EXC if tr.waiver_kind[t] == "valid" else SUSPEND
        return dict(profile=profile, mode=mode, allow=not comp, exc=False,
                    exc_invalid=False, rekey=comp)


# ---------------------------------------------------------------- run + metrics
def run_policy(policy, tr):
    keys = ("profile", "mode", "allow", "exc_invalid", "rekey",
            "reattest", "conflict", "weak")
    out = {k: [] for k in keys}
    events = []
    for t in range(tr.T):
        d = policy.step(tr, t)
        for k in keys:
            default = (d.get("profile", E0) == E1 or
                       d.get("profile", E0) >= E4) if k == "reattest" else False
            out[k].append(d.get(k, default))
        if d.get("guard_event"):
            events.append(d["guard_event"])
    res = {k: np.asarray(v) for k, v in out.items()}
    res["guard_events"] = events
    return res


def metrics(tr, out):
    m = {}
    prof, mode, allow = out["profile"], out["mode"], out["allow"]
    benign = ~tr.compromised
    # false isolation: E4+/deny raised while benign (per-run indicator)
    m["false_isolation"] = float(np.any(((prof >= E4) | ~allow) & benign))
    # unnecessary escalation: fraction of benign time at E3+ (forced re-auth)
    m["unnecessary_esc"] = float(np.mean((prof >= E3)[benign])) \
        if benign.any() else np.nan
    if tr.outage.any():
        m["avail_outage"] = float(np.mean(allow[tr.outage & benign])) \
            if (tr.outage & benign).any() else np.nan
    # Downgrade is attributed to the token accepted on this exact step.  A
    # later exception cannot be credited to an earlier, overlapping attempt.
    att_ts = [t for t, k in enumerate(tr.waiver_kind)
              if k in ("replay", "forged", "rollback", "expired", "rebased")]
    n_succ = sum(1 for t in att_ts
                 if mode[t] == LEGACY_EXC and out["exc_invalid"][t])
    m["downgrade_attempts"] = len(att_ts)
    m["downgrade_success"] = n_succ / len(att_ts) if att_ts else np.nan
    # detection / containment: censored runs report detected=0 and NaN times
    if tr.attack_window and tr.compromised.any():
        tc = int(np.argmax(tr.compromised))
        det = np.where(prof[tc:] >= E3)[0]
        con = np.where(prof[tc:] >= E4)[0]
        m["detected"] = float(len(det) > 0)
        m["mttd"] = float(det[0]) if len(det) else np.nan
        m["mttc"] = float(con[0]) if len(con) else np.nan
    m["mode_switches_ph"] = float(np.sum(mode[1:] != mode[:-1]) / (tr.T / 3600.0))
    m["avail_benign"] = float(np.mean(allow[benign])) if benign.any() else np.nan
    # resolver conflicts: how often a weaker-than-strongest action executed
    n_conf = int(np.sum(out["conflict"]))
    m["weak_action_rate"] = float(np.sum(out["weak"])) / n_conf if n_conf else np.nan
    # guard decision audit: per token kind, acceptances and rejecting conjunct
    audit = {}
    for kind, ok, reason in out.get("guard_events", []):
        a = audit.setdefault(kind, {"n": 0, "acc": 0, "thin": 0, "reasons": {}})
        a["n"] += 1
        if ok:
            a["acc"] += 1
            if reason == "acceptthin":   # entry the estimator gates would refuse
                a["thin"] += 1
        else:
            a["reasons"][reason] = a["reasons"].get(reason, 0) + 1
    m["guard_audit"] = audit
    # legitimate exception utilisation, over the constrained window if any
    if tr.peer_legacy_only.any():
        w = tr.peer_legacy_only
        m["time_legacy"] = float(np.mean((mode == LEGACY_EXC)[w]))
        m["time_suspend"] = float(np.mean((mode == SUSPEND)[w]))
    else:
        m["time_legacy"] = float(np.mean(mode == LEGACY_EXC))
        m["time_suspend"] = float(np.mean(mode == SUSPEND))
    return m


POLICIES = {
    "B1_StaticHybrid": lambda rng: ScalarTrust(HYBRID, continuous=False),
    "B2_StaticPQC": lambda rng: ScalarTrust(PQC, continuous=False),
    "B3_TrustAuth": lambda rng: ScalarTrust(HYBRID, continuous=True),
    "B3lo_TrustAuth": lambda rng: ScalarTrust(HYBRID, continuous=True, theta=0.25),
    "B4_ContextOnly": lambda rng: ContextOnly(),
    "L1_SLogic": lambda rng: SubjectiveLogicZT(),
    "L2_BetaRep": lambda rng: BetaReputation(),
    "G1_Grace": lambda rng: GraceScalar(),
    "B5_QARTZ": lambda rng: QARTZ(rng=rng),
    "B6_Oracle": lambda rng: Oracle(),
    "A_noConf": lambda rng: QARTZ(no_conf=True, rng=rng),
    "A_noSep": lambda rng: QARTZ(no_sep=True, rng=rng),
    "A_noChi": lambda rng: QARTZ(no_chi=True, rng=rng),
    "A_noGuard": lambda rng: QARTZ(no_guard=True, rng=rng),
    "A_atomic": lambda rng: QARTZ(atomic=True, rng=rng),
    "A_noC1C2": lambda rng: QARTZ(no_c1c2=True, rng=rng),
    # guard-conjunct reductions (deployable weaker-guard baselines)
    "A_guardSigTtl": lambda rng: QARTZ(guard_variant="sigttl", rng=rng),
    "A_guardSigCtr": lambda rng: QARTZ(guard_variant="sigctr", rng=rng),
    "A_guardNoGates": lambda rng: QARTZ(guard_variant="nogates", rng=rng),
}
