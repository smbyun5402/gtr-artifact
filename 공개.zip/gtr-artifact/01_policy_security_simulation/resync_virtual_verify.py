"""Deterministic virtual verification for the Q-ARTZ-Resync simulator.

This is a negative/property test harness, not another protocol model.  It
constructs valid M2/M3/M4 transcripts with :mod:`resync_sim`, mutates their
canonical JSON representation, and submits them to the production schema,
SST, bundle, ticket, classifier, and commit validators.  Expected verdicts
come from mutation-independent semantic oracles documented in ``ORACLES``.

The harness also runs state-carrying seeded traces and crash/restart checkpoint
properties.  It writes a machine-readable, reproducible result and exits
non-zero on any false accept, false reject, invariant violation, or exception.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import platform
import sys
import time
from collections import defaultdict
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Callable, Optional

import numpy as np

import resync_sim as R


DEFAULT_OUTPUT = Path(__file__).resolve().parent / "results" / "resync" / \
    "virtual_verify_result.json"
DEFAULT_MACROS_OUTPUT = Path(__file__).resolve().parent / "results" / \
    "resync_virtual_verify_macros.tex"

ORACLES = {
    "schema": "exact message/state field sets and declared JSON types",
    "authentication": "any unsigned change to a signed SST/object must reject",
    "freshness": "stored session nonces and roles must match",
    "state_binding": "SST stateDigest and duplicated state fields must match Sigma",
    "scope": "same domain and delta capabilities subset of waiver capabilities",
    "bundle": "PA objects share the issue core, are unexpired, and match the base",
    "commit": "decision, candidate, ticket, transcript, and role are MAC-bound",
    "counter": "a committed or aborted-reserved transition counter is never reused",
    "agreement": "two OPEN endpoints have the same state and decision",
    "crash": "restart recovers an atomic checkpoint or reaches a closed fallback",
}


@dataclass
class Fixture:
    seed: int
    policy: R.ResyncPolicy
    ep: R.Episode
    issue_i: dict[str, Any]
    m2: dict[str, Any]
    m3: dict[str, Any]
    m4: dict[str, Any]
    result_i: R.DecisionResult
    ctx_i: str
    key_i: bytes
    ticket: dict[str, Any]


class Recorder:
    def __init__(self) -> None:
        self.coverage: dict[str, dict[str, Any]] = defaultdict(
            lambda: {"executed": 0, "expected_accept": 0,
                     "observed_accept": 0, "false_accept": 0,
                     "false_reject": 0, "exceptions": 0,
                     "reasons": {}})
        self.failures: list[dict[str, Any]] = []
        self.first_failing_seed: Optional[int] = None

    def check(self, category: str, case: str, seed: int,
              expected_accept: bool,
              operation: Callable[[], tuple[bool, str]]) -> None:
        item = self.coverage[category]
        item["executed"] += 1
        item["expected_accept"] += int(expected_accept)
        try:
            observed, reason = operation()
            observed = bool(observed)
            reason = str(reason)
        except Exception as exc:  # captured as a verification failure
            observed, reason = False, f"exception:{type(exc).__name__}:{exc}"
            item["exceptions"] += 1
            self._failure(category, case, seed, expected_accept, None, reason)
            return
        item["observed_accept"] += int(observed)
        reasons = item["reasons"]
        reasons[reason] = reasons.get(reason, 0) + 1
        if observed and not expected_accept:
            item["false_accept"] += 1
            self._failure(category, case, seed, expected_accept, observed, reason)
        elif expected_accept and not observed:
            item["false_reject"] += 1
            self._failure(category, case, seed, expected_accept, observed, reason)

    def invariant(self, category: str, case: str, seed: int,
                  predicate: Callable[[], bool], detail: str) -> None:
        def evaluate() -> tuple[bool, str]:
            value = bool(predicate())
            return value, "satisfied" if value else detail
        self.check(category, case, seed, True, evaluate)

    def _failure(self, category: str, case: str, seed: int,
                 expected: bool, observed: Optional[bool], reason: str) -> None:
        if self.first_failing_seed is None or seed < self.first_failing_seed:
            self.first_failing_seed = seed
        if len(self.failures) < 50:
            self.failures.append({
                "category": category, "case": case, "seed": seed,
                "expected_accept": expected, "observed_accept": observed,
                "reason": reason,
            })

    def summary(self) -> dict[str, int]:
        values = list(self.coverage.values())
        return {
            "checks": sum(x["executed"] for x in values),
            "expected_accept": sum(x["expected_accept"] for x in values),
            "observed_accept": sum(x["observed_accept"] for x in values),
            "false_accept": sum(x["false_accept"] for x in values),
            "false_reject": sum(x["false_reject"] for x in values),
            "exceptions": sum(x["exceptions"] for x in values),
            "failures": len(self.failures),
        }


def _flip_hex(value: str) -> str:
    if not value:
        return "0"
    return ("0" if value[0] != "0" else "1") + value[1:]


def _set_path(obj: dict[str, Any], path: tuple[str, ...], value: Any) \
        -> dict[str, Any]:
    out = copy.deepcopy(obj)
    cursor: Any = out
    for key in path[:-1]:
        cursor = cursor[key]
    cursor[path[-1]] = value
    return out


def make_fixture(seed: int) -> Fixture:
    # RS3 episode 3 is an honest one-step policy patch with clean delivery.
    trace = R.make_trace("RS3", 4, seed)
    ep = trace.episodes[3]
    assert ep.attack is None and ep.delta_pol == 1
    policy = R.ResyncPolicy(R.CFGS["R_QARTZ"], trace.base_secret)
    policy.start(trace)
    i, j = policy.endpoints
    issue_i, _ = policy._apply_partition(ep)
    bundle = policy._legitimate_bundle(ep, issue_i)
    assert isinstance(bundle, dict) and bundle.get("delta") is not None

    sigma_j = copy.deepcopy(j.sigma)
    sst_j = R.build_sst(sigma_j, ep.nonce_i, ep.nonce_j, "resp",
                        j.node_id, ep.wall_time)
    m2 = R.wire_roundtrip({"kind": "ReConnState", "nonceJ": ep.nonce_j,
                           "sigmaJ": sigma_j, "sstJ": sst_j})
    ok, why = policy._validate_m2_message(i, m2, j.node_id, ep.nonce_i, ep)
    if not ok:
        raise AssertionError(f"fixture M2 rejected: {why}")

    result_i = policy._classify(ep, i.sigma, m2["sigmaJ"], bundle)
    if result_i.decision != "DeltaPatch" or result_i.candidate is None:
        raise AssertionError(f"fixture classify failed: {result_i.reason}")
    sst_i = R.build_sst(i.sigma, m2["nonceJ"], ep.nonce_i, "init",
                        i.node_id, ep.wall_time)
    ticket = R.issue_ticket(
        result_i.candidate, ep.idx,
        R.H("virtual-ticket", seed, R.state_digest(result_i.candidate)))
    fields = {"nonceI": ep.nonce_i, "sigmaI": copy.deepcopy(i.sigma),
              "sstI": sst_i, "bundle": copy.deepcopy(bundle),
              "decision": result_i.decision}
    ctx_i = policy._ctx_digest(m2, fields, result_i.decision, result_i)
    key_i = policy._resume_key(i.sigma, m2["sigmaJ"], i.sigma["sid"], ctx_i)
    commit_i = policy._commit_tag(key_i, "i", result_i.candidate, ticket, ctx_i)
    m3 = R.wire_roundtrip({"kind": "ReConnCommit", **fields,
                           "commitI": commit_i, "ticketPrime": ticket})

    # Persist-before-send is part of the real M3 path and is needed for the
    # state-aware M4 phase check.
    policy._persist_candidate(i, result_i.candidate, ticket,
                              result_i.decision, "candidate")
    valid, why, result_j, ctx_j, key_j, decision_j = \
        policy._validate_m3_message(j, m2, m3, ep)
    if not valid or result_j is None or key_j is None or ctx_j is None:
        raise AssertionError(f"fixture M3 rejected: {why}")
    assert decision_j is not None and result_j.candidate is not None
    m4 = R.wire_roundtrip({
        "kind": "ReConnConfirm", "decision": decision_j,
        "commitJ": policy._commit_tag(key_j, "j", result_j.candidate,
                                       ticket, ctx_j),
    })
    return Fixture(seed, policy, ep, issue_i, m2, m3, m4, result_i,
                   ctx_i, key_i, ticket)


def _m2_check(f: Fixture, message: Any) -> tuple[bool, str]:
    return f.policy._validate_m2_message(
        f.policy.i, message, "node-j", f.ep.nonce_i, f.ep)


def _m3_check(f: Fixture, message: Any) -> tuple[bool, str]:
    ok, why, *_ = f.policy._validate_m3_message(
        f.policy.j, f.m2, message, f.ep)
    return ok, why


def _m4_check(f: Fixture, message: Any,
              receiver: Optional[R.Endpoint] = None) -> tuple[bool, str]:
    return f.policy._validate_m4_message(
        message, f.result_i.decision, f.key_i, f.result_i.candidate,
        f.ticket, f.ctx_i, receiver=f.policy.i if receiver is None else receiver)


def exercise_m2(rec: Recorder, f: Fixture, rng: np.random.Generator) -> None:
    seed = f.seed
    rec.check("m2_honest", "canonical_roundtrip", seed, True,
              lambda: _m2_check(f, f.m2))

    for field in tuple(f.m2):
        msg = copy.deepcopy(f.m2)
        del msg[field]
        rec.check("m2_missing_field", field, seed, False,
                  lambda msg=msg: _m2_check(f, msg))
    rec.check("m2_extra_field", "unknown", seed, False,
              lambda: _m2_check(f, {**copy.deepcopy(f.m2), "extra": 1}))
    for field, value in (("nonceJ", 7), ("sigmaJ", []), ("sstJ", [])):
        msg = copy.deepcopy(f.m2)
        msg[field] = value
        rec.check("m2_type_confusion", field, seed, False,
                  lambda msg=msg: _m2_check(f, msg))
    rec.check("m2_kind", "wrong_kind", seed, False,
              lambda: _m2_check(f, _set_path(f.m2, ("kind",), "ReConnCommit")))

    sigma_cases = {
        "missing": lambda s: s.pop("seqNo"),
        "extra": lambda s: s.update(extra=1),
        "float_counter": lambda s: s.update(transCtr=float(s["transCtr"])),
        "bool_epoch": lambda s: s.update(polEpoch=True),
        "negative_seq": lambda s: s.update(seqNo=-1),
        "string_epoch": lambda s: s.update(keyEpoch="2"),
    }
    for name, mutate in sigma_cases.items():
        msg = copy.deepcopy(f.m2)
        mutate(msg["sigmaJ"])
        rec.check("m2_sigma_schema", name, seed, False,
                  lambda msg=msg: _m2_check(f, msg))

    changed = copy.deepcopy(f.m2)
    changed["sigmaJ"]["manifestDigest"] = R.H("mutated-manifest", seed)
    rec.check("m2_state_binding", "manifest_change", seed, False,
              lambda: _m2_check(f, changed))
    changed = copy.deepcopy(f.m2)
    changed["sigmaJ"]["polEpoch"] += 1
    rec.check("m2_state_binding", "core_epoch_change", seed, False,
              lambda: _m2_check(f, changed))
    bad_sig = copy.deepcopy(f.m2)
    bad_sig["sstJ"]["sig"] = _flip_hex(bad_sig["sstJ"]["sig"])
    rec.check("m2_authentication", "sst_signature_bit", seed, False,
              lambda: _m2_check(f, bad_sig))

    stale = copy.deepcopy(f.m2)
    stale["sstJ"] = R.build_sst(stale["sigmaJ"], "old-nonce",
                                 stale["nonceJ"], "resp", "node-j",
                                 f.ep.wall_time)
    rec.check("m2_freshness", "stale_initiator_nonce", seed, False,
              lambda: _m2_check(f, stale))
    wrong_role = copy.deepcopy(f.m2)
    wrong_role["sstJ"] = R.build_sst(wrong_role["sigmaJ"], f.ep.nonce_i,
                                      wrong_role["nonceJ"], "init", "node-j",
                                      f.ep.wall_time)
    rec.check("m2_role", "signed_role_reflection", seed, False,
              lambda: _m2_check(f, wrong_role))
    reflected = copy.deepcopy(f.m2)
    reflected["sstJ"] = R.build_sst(reflected["sigmaJ"], f.ep.nonce_i,
                                     reflected["nonceJ"], "resp", "node-i",
                                     f.ep.wall_time)
    rec.check("m2_role", "signer_reflection", seed, False,
              lambda: _m2_check(f, reflected))
    extra_body = copy.deepcopy(f.m2)
    body = copy.deepcopy(extra_body["sstJ"]["body"])
    body["ignored"] = "ambiguity"
    extra_body["sstJ"] = R.sign_object("node-j", body)
    rec.check("m2_sst_schema", "signed_extra_body_field", seed, False,
              lambda: _m2_check(f, extra_body))

    raw = R._canon(f.m2)
    duplicate = b'{"kind":"Bogus",' + raw[1:]
    raw_cases: list[tuple[str, bytes]] = [
        ("duplicate_key", duplicate),
        ("noncanonical_whitespace",
         json.dumps(f.m2, sort_keys=True).encode("utf-8")),
        ("noncanonical_key_order",
         json.dumps({key: f.m2[key] for key in reversed(tuple(f.m2))},
                    sort_keys=False,
                    separators=(",", ":")).encode("utf-8")),
        ("invalid_utf8", raw[:8] + b"\xff" + raw[8:]),
        ("truncated", raw[:-1]),
        ("nan_integer", raw.replace(
            f'"transCtr":{f.m2["sigmaJ"]["transCtr"]}'.encode(),
            b'"transCtr":NaN', 1)),
        ("float_integer", raw.replace(
            f'"transCtr":{f.m2["sigmaJ"]["transCtr"]}'.encode(),
            f'"transCtr":{f.m2["sigmaJ"]["transCtr"]}.0'.encode(), 1)),
        ("unpaired_unicode", raw.replace(
            f'"nonceJ":"{f.m2["nonceJ"]}"'.encode(),
            b'"nonceJ":"\\ud800"', 1)),
    ]
    for index in range(4):
        mutated = bytearray(raw)
        pos = int(rng.integers(1, len(mutated) - 1))
        mutated[pos] = ord("Z") if mutated[pos] != ord("Z") else ord("Y")
        raw_cases.append((f"single_byte_{index}", bytes(mutated)))
    for name, payload in raw_cases:
        def parse_and_check(payload: bytes = payload) -> tuple[bool, str]:
            try:
                parsed = R.strict_wire_decode(payload)
            except (UnicodeError, ValueError, TypeError, json.JSONDecodeError) as exc:
                return False, f"parse:{type(exc).__name__}"
            return _m2_check(f, parsed)
        rec.check("raw_json", name, seed, False, parse_and_check)


def exercise_bundle(rec: Recorder, f: Fixture) -> None:
    seed, p, ep = f.seed, f.policy, f.ep
    sigma_i, sigma_j = f.m3["sigmaI"], f.m2["sigmaJ"]
    normal = copy.deepcopy(f.m3["bundle"])
    rec.check("bundle_honest", "valid_delta", seed, True,
              lambda: p._validate_bundle(ep, sigma_i, sigma_j, normal))

    wrong = p._wrongbase_bundle(ep)
    rec.check("bundle_base", "wrong_base", seed, False,
              lambda: p._validate_bundle(ep, sigma_i, sigma_j, wrong))
    no_bind = copy.deepcopy(p)
    no_bind.cfg = copy.deepcopy(R.CFGS["B3_NoBind"])
    rec.check("bundle_base_ablation", "wrong_base_without_binding", seed,
              True,
              lambda: no_bind._validate_bundle(
                  ep, sigma_i, sigma_j, wrong))
    spliced = p._splice_bundle(ep)
    rec.check("bundle_scope", "disjoint_splice", seed, False,
              lambda: p._validate_bundle(ep, sigma_i, sigma_j, spliced))
    rec.check("bundle_schema", "extra_bundle_field", seed, False,
              lambda: p._validate_bundle(
                  ep, sigma_i, sigma_j, {**normal, "unknown": {}}))
    missing = {}
    rec.check("bundle_classifier", "missing_required_delta", seed, False,
              lambda: (p._classify(ep, sigma_i, sigma_j, missing).decision
                       != "FullReAttest", "classifier"))

    target_ctr = p._next_counter(sigma_i, sigma_j)
    target = copy.deepcopy(sigma_j)
    # Independent oracle: delta capabilities must be a subset of waiver caps.
    waiver_full = R.build_waiver(
        sigma_i, target_ctr, ("dom0", ("authn", "session")),
        f"cover-{seed}", ep.idx + 20)
    delta_subset = R.build_delta(
        sigma_i, target, ("dom0", ("authn",)),
        f"subset-{seed}", ep.idx + 20, relax_bits=1)
    rec.check("bundle_scope", "full_containment", seed, True,
              lambda: p._validate_bundle(
                  ep, sigma_i, sigma_j,
                  {"waiver": waiver_full, "delta": delta_subset}))
    waiver_partial = R.build_waiver(
        sigma_i, target_ctr, ("dom0", ("authn",)),
        f"partial-{seed}", ep.idx + 20)
    delta_broader = R.build_delta(
        sigma_i, target, ("dom0", ("authn", "session")),
        f"broader-{seed}", ep.idx + 20, relax_bits=1)
    rec.check("bundle_scope", "partial_overlap_authn_vs_authn_session",
              seed, False,
              lambda: p._validate_bundle(
                  ep, sigma_i, sigma_j,
                  {"waiver": waiver_partial, "delta": delta_broader}))
    waiver_domain = R.build_waiver(
        sigma_i, target_ctr, ("other-domain", ("authn", "session")),
        f"domain-{seed}", ep.idx + 20)
    rec.check("bundle_scope", "domain_mismatch", seed, False,
              lambda: p._validate_bundle(
                  ep, sigma_i, sigma_j,
                  {"waiver": waiver_domain, "delta": delta_broader}))

    unsigned_change = copy.deepcopy(normal)
    unsigned_change["delta"]["body"]["toPolEpoch"] += 1
    rec.check("bundle_authentication", "unsigned_target_change", seed, False,
              lambda: p._validate_bundle(ep, sigma_i, sigma_j,
                                         unsigned_change))

    replay_policy = copy.deepcopy(p)
    waiver_id = waiver_full["body"]["waiverID"]
    replay_policy.i.consumed_waivers.add(waiver_id)
    replay_policy.j.consumed_waivers.add(waiver_id)
    rec.check("bundle_replay", "consumed_waiver", seed, False,
              lambda: replay_policy._validate_bundle(
                  ep, sigma_i, sigma_j,
                  {"waiver": waiver_full, "delta": delta_subset}))

    # Exact DeltaOK: a PA signature is necessary but cannot authorize a
    # malformed lineage transition.
    base_delta = copy.deepcopy(normal["delta"]["body"])

    def signed_delta(**changes: Any) -> dict[str, Any]:
        body = copy.deepcopy(base_delta)
        body.update(changes)
        return R.sign_object("PA", body)

    delta_cases = {
        "multi_step": signed_delta(
            toPolEpoch=base_delta["fromPolEpoch"] + 7,
            toPolicyHash=R.H("jump", seed)),
        "wrong_from_hash": signed_delta(
            fromPolicyHash=R.H("wrong-from-policy", seed)),
        "wrong_from_class": signed_delta(
            fromReqClass=base_delta["fromReqClass"] + 9),
        "class_downgrade": signed_delta(
            toReqClass=max(0, base_delta["fromReqClass"] - 1)),
        "class_out_of_range": signed_delta(toReqClass=4),
        "relax_bits_out_of_range": signed_delta(relaxBits=256),
    }
    for name, delta_bad in delta_cases.items():
        rec.check("bundle_delta_rules", name, seed, False,
                  lambda delta_bad=delta_bad: p._validate_bundle(
                      ep, sigma_i, sigma_j, {"delta": delta_bad}))
    wrong_target_peer = copy.deepcopy(sigma_j)
    wrong_target_peer["policyHash"] = R.H("unauthorized-target", seed)
    rec.check("bundle_delta_rules", "peer_not_base_or_target", seed, False,
              lambda: p._validate_bundle(
                  ep, sigma_i, wrong_target_peer,
                  {"delta": copy.deepcopy(normal["delta"])}))

    # With no authority object, all core fields must agree. Differences only
    # in counters/sequence are deliberately outside the authority-bound core.
    for field, value in (
        ("policyHash", R.H("unissued-policy", seed)),
        ("reqClass", sigma_i["reqClass"] + 1),
        ("mode", "LEGACY" if sigma_i["mode"] != "LEGACY" else "HYBRID"),
    ):
        peer = copy.deepcopy(sigma_i)
        peer[field] = value
        rec.check("bundle_core_rules", f"no_object_{field}", seed, False,
                  lambda peer=peer: p._validate_bundle(
                      ep, sigma_i, peer, {}))
    noncore_peer = copy.deepcopy(sigma_i)
    noncore_peer["transCtr"] += 1
    noncore_peer["seqNo"] += 1
    noncore_peer["chainDigest"] = R.H("noncore-chain", seed)
    rec.check("bundle_core_rules", "noncore_only", seed, True,
              lambda: p._validate_bundle(ep, sigma_i, noncore_peer, {}))

    # Exact KeyOK: a present update advances exactly one epoch and its target
    # is no lower than either authenticated endpoint.
    key_peer = copy.deepcopy(sigma_i)
    key_peer["keyEpoch"] += 1
    key_good = R.build_key_update(
        sigma_i, key_peer, f"key-good-{seed}", ep.idx + 20)
    rec.check("bundle_key_rules", "one_step", seed, True,
              lambda: p._validate_bundle(
                  ep, sigma_i, key_peer, {"keyupd": key_good}))
    key_body = copy.deepcopy(key_good["body"])
    key_body["toKeyEpoch"] = key_body["fromKeyEpoch"]
    key_noop = R.sign_object("PA", key_body)
    rec.check("bundle_key_rules", "no_op", seed, False,
              lambda: p._validate_bundle(
                  ep, sigma_i, key_peer, {"keyupd": key_noop}))
    key_body = copy.deepcopy(key_good["body"])
    key_body["toKeyEpoch"] = key_body["fromKeyEpoch"] + 2
    key_jump = R.sign_object("PA", key_body)
    rec.check("bundle_key_rules", "multi_step", seed, False,
              lambda: p._validate_bundle(
                  ep, sigma_i, key_peer, {"keyupd": key_jump}))

    # Definition 6 permits either role-labelled endpoint to be the directed
    # base.  Reverse the normal fixture: responder j is the signed base and
    # initiator i already advertises the authorized target.
    reverse_i = copy.deepcopy(sigma_j)
    reverse_j = copy.deepcopy(sigma_i)
    reverse_i["attEpoch"] = reverse_j["attEpoch"] + 1
    reverse_i["EARdigest"] = R.H("reverse-higher-ear", seed)
    rec.check("base_select", "responder_is_base", seed, True,
              lambda: p._validate_bundle(
                  ep, reverse_i, reverse_j, copy.deepcopy(normal)))

    def reverse_classify() -> tuple[bool, str]:
        result = p._classify(
            ep, reverse_i, reverse_j, copy.deepcopy(normal))
        ok = (result.decision == "DeltaPatch" and
              result.candidate is not None and
              R.core_digest(result.candidate) == R.core_digest(reverse_i) and
              result.candidate["attEpoch"] == reverse_i["attEpoch"] and
              result.candidate["EARdigest"] == reverse_i["EARdigest"])
        return ok, result.reason

    rec.check("base_select", "reverse_candidate", seed, True,
              reverse_classify)


def exercise_m3_m4(rec: Recorder, f: Fixture) -> None:
    seed = f.seed
    rec.check("m3_honest", "canonical_roundtrip", seed, True,
              lambda: _m3_check(f, f.m3))
    for field in tuple(f.m3):
        msg = copy.deepcopy(f.m3)
        del msg[field]
        rec.check("m3_missing_field", field, seed, False,
                  lambda msg=msg: _m3_check(f, msg))
    rec.check("m3_extra_field", "unknown", seed, False,
              lambda: _m3_check(f, {**copy.deepcopy(f.m3), "extra": 1}))
    for field, value in (("nonceI", 1), ("sigmaI", []), ("sstI", []),
                         ("bundle", []), ("decision", 1), ("commitI", 1),
                         ("ticketPrime", [])):
        msg = copy.deepcopy(f.m3)
        msg[field] = value
        rec.check("m3_type_confusion", field, seed, False,
                  lambda msg=msg: _m3_check(f, msg))

    mutations: list[tuple[str, dict[str, Any]]] = []
    msg = copy.deepcopy(f.m3); msg["nonceI"] = "stale-nonce"
    mutations.append(("stale_nonce", msg))
    msg = copy.deepcopy(f.m3); msg["decision"] = "Resume"
    mutations.append(("decision_substitution", msg))
    msg = copy.deepcopy(f.m3); msg["commitI"] = _flip_hex(msg["commitI"])
    mutations.append(("commit_bit", msg))
    msg = copy.deepcopy(f.m3); msg["sstI"]["sig"] = _flip_hex(msg["sstI"]["sig"])
    mutations.append(("sst_signature_bit", msg))
    msg = copy.deepcopy(f.m3); msg["sigmaI"]["seqNo"] += 1
    mutations.append(("sigma_change", msg))
    msg = copy.deepcopy(f.m3); msg["bundle"] = {}
    mutations.append(("bundle_drop", msg))
    msg = copy.deepcopy(f.m3); msg["bundle"]["extra"] = {}
    mutations.append(("bundle_extra", msg))
    msg = copy.deepcopy(f.m3); msg["ticketPrime"]["sig"] = \
        _flip_hex(msg["ticketPrime"]["sig"])
    mutations.append(("ticket_signature_bit", msg))
    msg = copy.deepcopy(f.m3)
    ticket_body = copy.deepcopy(msg["ticketPrime"]["body"])
    ticket_body["stateDigest"] = R.H("other-state", seed)
    msg["ticketPrime"] = R.sign_object("TA", ticket_body)
    mutations.append(("signed_ticket_wrong_state", msg))
    for name, message in mutations:
        rec.check("m3_mutation", name, seed, False,
                  lambda message=message: _m3_check(f, message))

    replay = copy.deepcopy(f)
    replay.policy.j.invalidated_tickets.add(R.ticket_digest(replay.ticket))
    rec.check("m3_replay", "invalidated_ticket", seed, False,
              lambda: _m3_check(replay, replay.m3))

    # Duplicate validation before state transition is idempotent: both accepts
    # are permitted, but the validator itself must not mutate endpoint state.
    before = (R.state_digest(f.policy.j.sigma), f.policy.j.phase,
              copy.deepcopy(f.policy.j.candidate_record))
    first = _m3_check(f, f.m3)
    second = _m3_check(f, f.m3)
    after = (R.state_digest(f.policy.j.sigma), f.policy.j.phase,
             copy.deepcopy(f.policy.j.candidate_record))
    rec.check("m3_duplicate", "idempotent_precommit", seed, True,
              lambda: (first[0] and second[0] and before == after,
                       "idempotent" if before == after else "state-mutated"))

    rec.check("m4_honest", "canonical_roundtrip", seed, True,
              lambda: _m4_check(f, f.m4))
    for field in tuple(f.m4):
        msg = copy.deepcopy(f.m4)
        del msg[field]
        rec.check("m4_missing_field", field, seed, False,
                  lambda msg=msg: _m4_check(f, msg))
    rec.check("m4_extra_field", "unknown", seed, False,
              lambda: _m4_check(f, {**copy.deepcopy(f.m4), "extra": 1}))
    msg = copy.deepcopy(f.m4); msg["decision"] = "Resume"
    rec.check("m4_mutation", "decision_substitution", seed, False,
              lambda: _m4_check(f, msg))
    msg = copy.deepcopy(f.m4); msg["commitJ"] = _flip_hex(msg["commitJ"])
    rec.check("m4_mutation", "commit_bit", seed, False,
              lambda: _m4_check(f, msg))
    msg = copy.deepcopy(f.m4); msg["commitJ"] = 1
    rec.check("m4_type_confusion", "integer_commit", seed, False,
              lambda: _m4_check(f, msg))

    reordered_receiver = copy.deepcopy(f.policy.i)
    reordered_receiver.phase = "open"
    reordered_receiver.candidate_record = None
    rec.check("m4_reordering", "m4_before_candidate", seed, False,
              lambda: _m4_check(f, f.m4, receiver=reordered_receiver))


def exercise_crash_and_counter(rec: Recorder, seed: int) -> None:
    f = make_fixture(seed)
    p, i, j = f.policy, f.policy.i, f.policy.j
    assert i is not None and j is not None and f.result_i.candidate is not None
    reserved = f.result_i.candidate["transCtr"]
    old_state = R.state_digest(i.sigma)

    restarted_i = copy.deepcopy(i)
    rec.invariant("crash_checkpoint", "candidate_survives_restart", seed,
                  lambda: (restarted_i.phase == "candidate" and
                           restarted_i.candidate_record is not None and
                           reserved in restarted_i.reserved_counters),
                  "candidate checkpoint lost")
    p.i = restarted_i
    p._abort_candidate(restarted_i)
    rec.invariant("crash_checkpoint", "abort_keeps_counter_tombstone", seed,
                  lambda: (restarted_i.candidate_record is None and
                           restarted_i.phase == "closed" and
                           reserved in restarted_i.reserved_counters and
                           R.state_digest(restarted_i.sigma) == old_state),
                  "abort reused or partially adopted candidate")
    next_counter = p._next_counter(restarted_i.sigma, j.sigma)
    rec.invariant("counter_reservation", "aborted_counter_not_reissued", seed,
                  lambda: next_counter > reserved,
                  f"next counter {next_counter} reused reservation {reserved}")

    # Recover a responder HALF-OPEN checkpoint and finish the same candidate.
    f = make_fixture(seed + 1_000_000)
    p, i, j = f.policy, f.policy.i, f.policy.j
    valid, why, result_j, ctx_j, key_j, decision_j = \
        p._validate_m3_message(j, f.m2, f.m3, f.ep)
    if not valid or result_j is None or result_j.candidate is None:
        rec.check("crash_checkpoint", "prepare_half_open", seed, True,
                  lambda: (False, why))
        return
    p._persist_candidate(j, result_j.candidate, f.ticket,
                         decision_j or result_j.decision, "half-open")
    restarted_j = copy.deepcopy(j)
    p.j = restarted_j
    rec.invariant("crash_checkpoint", "half_open_survives_restart", seed,
                  lambda: (restarted_j.phase == "half-open" and
                           restarted_j.candidate_record is not None),
                  "half-open checkpoint lost")
    m4_ok, m4_why = p._validate_m4_message(
        f.m4, f.result_i.decision, f.key_i, f.result_i.candidate,
        f.ticket, f.ctx_i, receiver=i)
    if m4_ok:
        p._commit_candidate(i)
        p._commit_candidate(restarted_j)
    rec.check("crash_checkpoint", "restart_then_commit_agreement", seed, True,
              lambda: (m4_ok and i.phase == restarted_j.phase == "open" and
                       R.state_digest(i.sigma) == R.state_digest(restarted_j.sigma),
                       m4_why if not m4_ok else "agreement"))


def exercise_stateful_traces(rec: Recorder, trace_seeds: int,
                             episodes: int) -> dict[str, int]:
    scenarios = ("RS1", "RS2", "RS3", "RS4", "RS5", "RS6", "RS7")
    counts = {"traces": 0, "episodes": 0, "attack_episodes": 0,
              "forced_drop_cases": 0}
    for scenario_index, scenario in enumerate(scenarios):
        for offset in range(trace_seeds):
            seed = 50_000 + scenario_index * 10_000 + offset
            trace = R.make_trace(scenario, episodes, seed)
            p = R.ResyncPolicy(R.CFGS["R_QARTZ"], trace.base_secret)
            p.start(trace)
            counts["traces"] += 1
            previous_ctr = p.i.sigma["transCtr"]
            previous_seq = p.i.sigma["seqNo"]
            for ep in trace.episodes:
                out = p.run_episode(ep)
                counts["episodes"] += 1
                if ep.attack is not None:
                    counts["attack_episodes"] += 1
                both_open = p.i.phase == p.j.phase == "open"
                rec.invariant("trace_agreement", f"{scenario}:open_agreement",
                              seed,
                              lambda p=p, both_open=both_open:
                              (not both_open or
                               (R.state_digest(p.i.sigma) ==
                                R.state_digest(p.j.sigma) and
                                p.i.last_decision == p.j.last_decision)),
                              "different OPEN states or decisions")
                rec.invariant("trace_atomicity", f"{scenario}:terminal_record",
                              seed,
                              lambda p=p: (p.i.candidate_record is None and
                                           p.j.candidate_record is None),
                              "episode returned with live candidate")
                rec.invariant("trace_attack", f"{scenario}:no_attack_accept",
                              seed,
                              lambda out=out: not (out["attack_tested"] and
                                                   out["accepted"]),
                              f"accepted attack {out['attack']}")
                rec.invariant("trace_counter", f"{scenario}:monotone_counter",
                              seed,
                              lambda p=p, previous_ctr=previous_ctr:
                              (p.i.sigma["transCtr"] >= previous_ctr and
                               p.j.sigma["transCtr"] >= previous_ctr),
                              "transition counter decreased")
                if (out["commit_executed"] and
                        out["decision_i"] == "Resume"):
                    rec.invariant("resume_transition",
                                  f"{scenario}:resume_consumes_state", seed,
                                  lambda p=p, pc=previous_ctr, ps=previous_seq:
                                  (p.i.sigma["transCtr"] > pc and
                                   p.i.sigma["seqNo"] > ps),
                                  "successful Resume did not advance counter/chain")
                previous_ctr = p.i.sigma["transCtr"]
                previous_seq = p.i.sigma["seqNo"]

    # Deterministic all-retries-dropped M3/M4 cases, with verifier unavailable.
    for stage_index, stage in enumerate(("M3", "M4")):
        for offset in range(trace_seeds):
            seed = 900_000 + stage_index * 10_000 + offset
            trace = R.make_trace("RS3", 4, seed)
            ep = replace(trace.episodes[3], force_drop_stage=stage,
                         verifier_reachable=False)
            p = R.ResyncPolicy(R.CFGS["R_QARTZ"], trace.base_secret)
            p.start(trace)
            out = p.run_episode(ep)
            counts["forced_drop_cases"] += 1
            rec.invariant("drop_retry", f"{stage}:safe_terminal", seed,
                          lambda p=p: (p.i.phase == p.j.phase == "closed" and
                                       p.i.candidate_record is None and
                                       p.j.candidate_record is None),
                          "drop left an OPEN split or live candidate")
            rec.invariant("drop_retry", f"{stage}:not_accepted", seed,
                          lambda out=out: not out["accepted"],
                          "dropped commit was accepted")
            rec.invariant("drop_retry", f"{stage}:counter_reserved", seed,
                          lambda p=p: bool(p.i.reserved_counters),
                          "aborted initiator counter was not tombstoned")
    return counts


def write_macros(path: Path, result: dict[str, Any]) -> None:
    summary = result["summary"]
    workload = result["stateful_workload"]
    raw_json = result["coverage_by_class"].get("raw_json", {})
    values = {
        "RsVvChecks": summary["checks"],
        "RsVvFalseAccept": summary["false_accept"],
        "RsVvFalseReject": summary["false_reject"],
        "RsVvExceptions": summary["exceptions"],
        "RsVvTraces": workload["traces"],
        "RsVvEpisodes": workload["episodes"],
        "RsVvAttackEpisodes": workload["attack_episodes"],
        "RsVvForcedDrops": workload["forced_drop_cases"],
        "RsVvRawFrames": raw_json.get("executed", 0),
        "RsVvFuzzSeeds": result["configuration"]["fuzz_seeds"],
        "RsVvRuntimeSec": f'{result["runtime_seconds"]:.1f}',
    }
    lines = [
        "% auto-generated by sim/resync_virtual_verify.py -- do not edit",
        "% virtual_verify_result.json is the authoritative detailed record",
    ]
    lines.extend(f"\\newcommand{{\\{name}}}{{{value}}}"
                 for name, value in values.items())
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(fuzz_seeds: int, trace_seeds: int, episodes: int,
        output: Path, macros_output: Optional[Path] = None) -> dict[str, Any]:
    started = time.perf_counter()
    recorder = Recorder()
    for seed in range(fuzz_seeds):
        fixture_seed = 10_000 + seed
        rng = np.random.default_rng(fixture_seed)
        fixture = make_fixture(fixture_seed)
        exercise_m2(recorder, fixture, rng)
        exercise_bundle(recorder, fixture)
        exercise_m3_m4(recorder, fixture)
    for seed in range(min(fuzz_seeds, 64)):
        exercise_crash_and_counter(recorder, 700_000 + seed)
    trace_counts = exercise_stateful_traces(recorder, trace_seeds, episodes)
    elapsed = time.perf_counter() - started

    summary = recorder.summary()
    result: dict[str, Any] = {
        "schema_version": 1,
        "status": "PASS" if summary["failures"] == 0 else "FAIL",
        "command": (f"{Path(sys.executable).name} sim/resync_virtual_verify.py "
                    f"--fuzz-seeds {fuzz_seeds} --trace-seeds {trace_seeds} "
                    f"--episodes {episodes}"),
        "configuration": {"fuzz_seeds": fuzz_seeds,
                          "trace_seeds_per_scenario": trace_seeds,
                          "episodes_per_trace": episodes,
                          "seed_schedule": "documented deterministic offsets"},
        "oracles": ORACLES,
        "summary": summary,
        "stateful_workload": trace_counts,
        "coverage_by_class": dict(sorted(recorder.coverage.items())),
        "minimal_failing_seed": recorder.first_failing_seed,
        "failure_examples": recorder.failures,
        "runtime_seconds": round(elapsed, 6),
        "environment": {"python": platform.python_version(),
                        "platform": platform.platform(),
                        "numpy": np.__version__},
        "limitations": [
            "Randomized deterministic property testing is not exhaustive model checking.",
            "Signatures use the simulator's deterministic Dolev-Yao oracle; real-crypto timing is out of scope.",
            "Crash persistence is an atomic deep-copy checkpoint model, not filesystem fault injection.",
            "The harness calls production private validators because the simulator has no public wire API.",
        ],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n",
                      encoding="utf-8")
    if macros_output is not None:
        write_macros(macros_output, result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fuzz-seeds", type=int, default=128)
    parser.add_argument("--trace-seeds", type=int, default=32)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--macros-output", type=Path,
                        default=DEFAULT_MACROS_OUTPUT)
    args = parser.parse_args()
    if args.fuzz_seeds <= 0 or args.trace_seeds <= 0 or args.episodes <= 0:
        parser.error("seed and episode counts must be positive")
    result = run(args.fuzz_seeds, args.trace_seeds, args.episodes,
                 args.output.resolve(), args.macros_output.resolve())
    summary = result["summary"]
    print(json.dumps({"status": result["status"], **summary,
                      "runtime_seconds": result["runtime_seconds"],
                      "output": str(args.output.resolve())}, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
