#!/usr/bin/env python3
"""Reproducible experiment runner for the stateful Q-ARTZ-Resync model.

All raw outputs are namespaced under ``sim/results/resync/``.  The only
compatibility output outside that directory is ``results/resync_macros.tex``,
which is the paper's existing include path.  No generic ``raw_metrics.csv`` or
``frontier.npy`` file is touched.
"""

from __future__ import annotations

import copy
import csv
import gzip
import json
import math
import os
import platform
import re
import sys
import time
from collections import defaultdict
from typing import Any, Dict, Iterable, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import resync_sim as R
from resync_sim import (CFGS, POLICIES, CLEAN, CONDS, DISR, HEAVY,
                        LINK, PATHS, PolCfg, ResyncPolicy, make_trace,
                        metrics, run_policy)


HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(HERE, "results")
RESYNC_OUT = os.path.join(RESULTS, "resync")
FIG = os.path.join(HERE, "figures")
MACRO_PATH = os.path.join(RESULTS, "resync_macros.tex")

T = 40
RUNS = 100
FRONTIER_RUNS = 60
LOSS_RUNS = 60
ROB_RUNS = 30

SCENARIOS = ["RS1", "RS1L", "RS2", "RS3", "RS4", "RS5", "RS6", "RS7"]
ALL_POLS = list(POLICIES.keys())

POLNAME = {
    "B1_ReAuth": "ReAuth", "B2_FullOnly": "FullOnly",
    "B3_NoBind": "NoBind", "B4_NoCommit": "NoCommit",
    "B5_NoBundle": "NoBundle", "B6_Ticket": "Ticket",
    "R_QARTZ": "Qartz", "R_Oracle": "Oracle",
    "A_noFresh": "AblNoFresh", "A_fullDigestBind": "AblFullBind",
    "A_noCtrConsume": "AblNoCtr", "A_noDecisionBind": "AblNoDec",
    "A_timeTTL": "AblTimeTtl",
}
CONDNAME = {CLEAN: "Clean", DISR: "Disr", HEAVY: "Heavy"}
PATHNAME = {"resume": "Resume", "deltapatch": "Patch",
            "fullreattest": "Full"}
DISPLAY = {
    "B1_ReAuth": "B1\nReAuth", "B2_FullOnly": "B2\nFullOnly",
    "B3_NoBind": "B3\n-bind", "B4_NoCommit": "B4\n-commit",
    "B5_NoBundle": "B5\n-bundle", "B6_Ticket": "B6\nTicket",
    "R_QARTZ": "Q-ARTZ", "R_Oracle": "Oracle",
    "A_noFresh": "-fresh", "A_fullDigestBind": "full-\ndigest",
    "A_noCtrConsume": "-ctr", "A_noDecisionBind": "-decision",
    "A_timeTTL": "time-\nTTL",
}
REASON_LABEL = {
    "signature": "signature", "fresh": "nonce/freshness",
    "time-ttl": "time TTL", "role": "role", "state-digest": "state digest",
    "bind": "core binding", "cross-core": "cross-object core",
    "scope": "scope compat", "polepoch": "pol-epoch",
    "counter": "counter", "chain": "chain/rollback",
    "ticket-invalidated": "ticket invalidated", "decision": "decision bind",
    "commit-mac": "commit MAC", "commit-m3-loss": "M3 loss",
    "commit-m4-loss": "M4 loss", "accepted": "accepted",
    "rejected": "rejected", "budget": "lag budget",
    "confidence": "confidence", "missing-delta": "missing delta",
    "missing-keyupd": "missing key update", "oracle-reject": "oracle",
}

plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "figure.dpi": 200,
    "pdf.fonttype": 42,
})
W = 3.45


def _ensure_dirs() -> None:
    os.makedirs(RESYNC_OUT, exist_ok=True)
    os.makedirs(FIG, exist_ok=True)


def _safe_scalar(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    return value


def nearest_rank(values: Iterable[float], quantile: float) -> float:
    """Nearest-rank percentile (ceil(q*n)-1), including q=.95 at n=30."""
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return float("nan")
    index = max(0, min(len(ordered) - 1,
                       math.ceil(quantile * len(ordered)) - 1))
    return ordered[index]


def _cluster_ratio_stat(records: list[Dict[str, Any]], key: str) \
        -> Tuple[float, float]:
    usable = [record for record in records
              if record.get(f"{key}_den", 0) > 0]
    if not usable:
        return float("nan"), float("nan")
    numerator = sum(float(record[f"{key}_num"]) for record in usable)
    denominator = sum(float(record[f"{key}_den"]) for record in usable)
    point = numerator / denominator
    cluster_rates = np.asarray([
        float(record[f"{key}_num"]) / float(record[f"{key}_den"])
        for record in usable
    ])
    if point in (0.0, 1.0):
        # The run is the independent cluster.  This matches the manuscript's
        # run-level rule-of-three while raw attempt denominators remain explicit.
        half = min(1.0, 3.0 / len(usable))
    elif len(cluster_rates) > 1:
        half = 1.96 * float(cluster_rates.std(ddof=1)) / math.sqrt(len(cluster_rates))
    else:
        half = 0.0
    return point, half


def mstat(raw: Dict[Tuple[str, str], list[Dict[str, Any]]],
          scenario: str, policy: str, key: str) -> Tuple[float, float]:
    records = raw.get((scenario, policy), [])
    if records and f"{key}_num" in records[0] and f"{key}_den" in records[0]:
        return _cluster_ratio_stat(records, key)
    values = [float(record[key]) for record in records
              if key in record and not np.isnan(float(record[key]))]
    if not values:
        return float("nan"), float("nan")
    array = np.asarray(values)
    half = (1.96 * float(array.std(ddof=1)) / math.sqrt(len(array))
            if len(array) > 1 else 0.0)
    return float(array.mean()), half


def poolstat(latpool: Dict[Tuple[str, str, str], list[Tuple[str, int, float]]],
             policy: str, cond: str, path: str) -> Tuple[float, float]:
    values = latpool.get((policy, cond, path), [])
    if not values:
        return float("nan"), float("nan")
    by_cluster: Dict[Tuple[str, int], list[float]] = defaultdict(list)
    for scenario, run, value in values:
        by_cluster[(scenario, run)].append(float(value))
    means = np.asarray([np.mean(cluster) for cluster in by_cluster.values()])
    point = float(np.mean([value for _, _, value in values]))
    half = (1.96 * float(means.std(ddof=1)) / math.sqrt(len(means))
            if len(means) > 1 else 0.0)
    return point, half


def aggregate():
    _ensure_dirs()
    rows: list[Dict[str, Any]] = []
    raw: Dict[Tuple[str, str], list[Dict[str, Any]]] = {}
    latpool: Dict[Tuple[str, str, str], list[Tuple[str, int, float]]] = {}

    episode_fields = [
        "scenario", "policy", "run", "episode", "attack", "attack_tested",
        "accepted", "path", "success", "divergent", "hquar",
        "hquar_tested", "patch_intended", "patch_accepted", "condition",
        "latency_ms", "bytes", "mission_s", "operable_s", "decision_i",
        "decision_j", "phase_i", "phase_j", "state_i", "state_j",
        "pa_reachable", "verifier_reachable", "cached_bundle",
    ]
    episode_path = os.path.join(RESYNC_OUT, "episode_outcomes.csv.gz")
    with gzip.open(episode_path, "wt", newline="", encoding="utf-8") as stream:
        episode_writer = csv.DictWriter(stream, fieldnames=episode_fields)
        episode_writer.writeheader()
        for scenario in SCENARIOS:
            for run in range(RUNS):
                trace = make_trace(scenario, T, seed=1000 + run)
                for policy_name in ALL_POLS:
                    policy = POLICIES[policy_name](
                        np.random.default_rng(7000 + run), trace.base_secret)
                    outcomes = run_policy(policy, trace)
                    measured = metrics(trace, outcomes)
                    measured.update(scenario=scenario, policy=policy_name, run=run,
                                    commit_calls=policy.commit_count,
                                    mean_step_us=float(np.mean(policy.step_time_us)))
                    rows.append({key: _safe_scalar(value)
                                 for key, value in measured.items()
                                 if key != "guard_audit"})
                    raw.setdefault((scenario, policy_name), []).append(measured)
                    for episode, outcome in zip(trace.episodes, outcomes):
                        if outcome["success"] and outcome["path"] in PATHS:
                            latpool.setdefault((policy_name, outcome["cond"],
                                                outcome["path"]), []).append(
                                (scenario, run, outcome["latency"]))
                        episode_writer.writerow({
                            "scenario": scenario, "policy": policy_name,
                            "run": run, "episode": episode.idx,
                            "attack": episode.attack or "",
                            "attack_tested": int(outcome["attack_tested"]),
                            "accepted": int(outcome["accepted"]),
                            "path": outcome["path"],
                            "success": int(outcome["success"]),
                            "divergent": int(outcome["divergent"]),
                            "hquar": int(outcome["hquar"]),
                            "hquar_tested": int(outcome["hquar_tested"]),
                            "patch_intended": int(outcome["patch_intended"]),
                            "patch_accepted": int(outcome["patch_accepted"]),
                            "condition": outcome["cond"],
                            "latency_ms": f"{outcome['latency']:.6f}",
                            "bytes": outcome["bytes"],
                            "mission_s": f"{outcome['mission_s']:.6f}",
                            "operable_s": f"{outcome['operable_s']:.6f}",
                            "decision_i": outcome["decision_i"] or "",
                            "decision_j": outcome["decision_j"] or "",
                            "phase_i": outcome["phase_i"],
                            "phase_j": outcome["phase_j"],
                            "state_i": outcome["state_i"],
                            "state_j": outcome["state_j"],
                            "pa_reachable": int(episode.pa_reachable),
                            "verifier_reachable": int(episode.verifier_reachable),
                            "cached_bundle": int(episode.cached_bundle),
                        })
            print(f"[aggregate] {scenario}", flush=True)

    raw_path = os.path.join(RESYNC_OUT, "raw_metrics.csv")
    fields = sorted({key for row in rows for key in row})
    with open(raw_path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    latency_path = os.path.join(RESYNC_OUT, "latency_summary.csv")
    with open(latency_path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["policy", "condition", "path", "n", "mean_ms",
                         "ci95_cluster_ms", "p95_nearest_rank_ms"])
        for (policy, cond, path), samples in sorted(latpool.items()):
            values = [value for _, _, value in samples]
            mean, ci = poolstat(latpool, policy, cond, path)
            writer.writerow([policy, cond, path, len(values), f"{mean:.6f}",
                             f"{ci:.6f}", f"{nearest_rank(values, .95):.6f}"])
    return raw, latpool


# ---------------------------------------------------------------------------
# Focused stateful sweeps

FRONTIER_BUDGETS = list(range(0, 6))


def frontier():
    _ensure_dirs()
    policies = ("R_QARTZ", "B3_NoBind", "B6_Ticket")
    result: Dict[str, Any] = {"budget": FRONTIER_BUDGETS}
    for policy in policies:
        result[policy] = {"avail": [], "patch": [], "wrong": []}
    raw_rows = []
    for budget in FRONTIER_BUDGETS:
        collected = {policy: {"avail_num": 0.0, "avail_den": 0.0,
                              "patch_num": 0, "patch_den": 0,
                              "wrong_num": 0, "wrong_den": 0}
                     for policy in policies}
        for run in range(FRONTIER_RUNS):
            trace = make_trace("FRONTIER", T, 1000 + run)
            for policy_name in policies:
                cfg = copy.deepcopy(CFGS[policy_name])
                cfg.lag_pol = cfg.lag_key = cfg.L_att = budget
                policy = ResyncPolicy(cfg, trace.base_secret)
                policy._rng = np.random.default_rng(7000 + run)
                measured = metrics(trace, run_policy(policy, trace))
                row = {
                    "budget": budget, "run": run, "policy": policy_name,
                    "availability": measured["availability"],
                    "availability_num": measured["availability_num"],
                    "availability_den": measured["availability_den"],
                    "patch": measured["ratio_deltapatch"],
                    "patch_num": measured["ratio_deltapatch_num"],
                    "patch_den": measured["ratio_deltapatch_den"],
                    "wrong": measured["acc_wrong"],
                    "wrong_num": measured["acc_wrong_num"],
                    "wrong_den": measured["acc_wrong_den"],
                }
                raw_rows.append(row)
                acc = collected[policy_name]
                for key in ("availability_num", "availability_den"):
                    acc[key.replace("availability", "avail")] += row[key]
                acc["patch_num"] += row["patch_num"]
                acc["patch_den"] += row["patch_den"]
                acc["wrong_num"] += row["wrong_num"]
                acc["wrong_den"] += row["wrong_den"]
        for policy_name in policies:
            acc = collected[policy_name]
            result[policy_name]["avail"].append(
                acc["avail_num"] / acc["avail_den"])
            result[policy_name]["patch"].append(
                acc["patch_num"] / acc["patch_den"])
            result[policy_name]["wrong"].append(
                acc["wrong_num"] / acc["wrong_den"] if acc["wrong_den"] else 0.0)
        print(f"[frontier] budget={budget} patch={result['R_QARTZ']['patch'][-1]:.3f} "
              f"wrong={result['R_QARTZ']['wrong'][-1]:.3f}", flush=True)
    np.save(os.path.join(RESYNC_OUT, "frontier.npy"), result, allow_pickle=True)
    _write_rows(os.path.join(RESYNC_OUT, "frontier_raw.csv"), raw_rows)
    return result


LOSSES = np.round(np.arange(0.0, 0.41, 0.05), 3)


def loss_sweep():
    _ensure_dirs()
    result = {"loss": LOSSES, "B4_div": [], "R_div": [],
              "B4_complete": [], "R_complete": []}
    raw_rows = []
    original = LINK[DISR]["loss"]
    try:
        for loss in LOSSES:
            LINK[DISR]["loss"] = float(loss)
            totals = {"B4_NoCommit": [0, 0, 0, 0],
                      "R_QARTZ": [0, 0, 0, 0]}
            for run in range(LOSS_RUNS):
                trace = make_trace("LOSS", T, 1000 + run)
                for policy_name in totals:
                    policy = POLICIES[policy_name](
                        np.random.default_rng(7000 + run), trace.base_secret)
                    measured = metrics(trace, run_policy(policy, trace))
                    totals[policy_name][0] += measured["divergent_num"]
                    totals[policy_name][1] += measured["divergent_den"]
                    totals[policy_name][2] += measured["ratio_deltapatch_num"]
                    totals[policy_name][3] += measured["ratio_deltapatch_den"]
                    raw_rows.append({
                        "loss": loss, "run": run, "policy": policy_name,
                        "divergent_num": measured["divergent_num"],
                        "divergent_den": measured["divergent_den"],
                        "complete_num": measured["ratio_deltapatch_num"],
                        "complete_den": measured["ratio_deltapatch_den"],
                    })
            b4, rq = totals["B4_NoCommit"], totals["R_QARTZ"]
            result["B4_div"].append(b4[0] / b4[1])
            result["R_div"].append(rq[0] / rq[1])
            result["B4_complete"].append(b4[2] / b4[3])
            result["R_complete"].append(rq[2] / rq[3])
            print(f"[loss] {loss:.2f} B4div={result['B4_div'][-1]:.3f} "
                  f"Rdiv={result['R_div'][-1]:.3f} "
                  f"Rcommit={result['R_complete'][-1]:.3f}", flush=True)
    finally:
        LINK[DISR]["loss"] = original
    np.save(os.path.join(RESYNC_OUT, "loss.npy"), result, allow_pickle=True)
    _write_rows(os.path.join(RESYNC_OUT, "loss_raw.csv"), raw_rows)
    return result


LATTS = list(range(0, 6))


def latt_sweep():
    result = {"latt": LATTS, "patch": [], "avail": []}
    raw_rows = []
    for limit in LATTS:
        patch_num = patch_den = 0
        avail_num = avail_den = 0.0
        for run in range(FRONTIER_RUNS):
            trace = make_trace("LATT", T, 1000 + run)
            cfg = copy.deepcopy(CFGS["R_QARTZ"])
            cfg.L_att = limit
            policy = ResyncPolicy(cfg, trace.base_secret)
            policy._rng = np.random.default_rng(7000 + run)
            measured = metrics(trace, run_policy(policy, trace))
            patch_num += measured["ratio_deltapatch_num"]
            patch_den += measured["ratio_deltapatch_den"]
            avail_num += measured["availability_num"]
            avail_den += measured["availability_den"]
            raw_rows.append({
                "L_att": limit, "run": run,
                "patch_num": measured["ratio_deltapatch_num"],
                "patch_den": measured["ratio_deltapatch_den"],
                "availability_num": measured["availability_num"],
                "availability_den": measured["availability_den"],
            })
        result["patch"].append(patch_num / patch_den)
        result["avail"].append(avail_num / avail_den)
    np.save(os.path.join(RESYNC_OUT, "latt.npy"), result, allow_pickle=True)
    _write_rows(os.path.join(RESYNC_OUT, "latt_raw.csv"), raw_rows)
    return result


ROB_PARAMS = [
    ("RhoPatch", "rho_patch", [0.25, 0.30, 0.35, 0.40, 0.45]),
    ("RhoAtt", "rho_att_min", [0.30, 0.35, 0.40, 0.45, 0.50]),
    ("Latt", "L_att", [1, 2, 3, 4]),
    ("LagPol", "lag_pol", [1, 2, 3]),
    ("LagKey", "lag_key", [1, 2, 3]),
]


def robustness():
    summaries: Dict[str, Dict[str, Any]] = {}
    rows = []
    safety_scenarios = ("RS2", "RS3", "RS4", "RS5", "RS6")
    for tag, attr, values in ROB_PARAMS:
        per_value = []
        for value in values:
            attack_num = attack_den = div_num = div_den = hq_num = hq_den = 0
            avail_num = avail_den = 0.0
            for run in range(ROB_RUNS):
                cfg = copy.deepcopy(CFGS["R_QARTZ"])
                setattr(cfg, attr, value)
                for scenario in safety_scenarios:
                    trace = make_trace(scenario, T, 1000 + run)
                    policy = ResyncPolicy(cfg, trace.base_secret)
                    policy._rng = np.random.default_rng(7000 + run)
                    measured = metrics(trace, run_policy(policy, trace))
                    for attack_key in ("acc_stale", "acc_roll", "acc_wrong",
                                       "acc_waiv", "acc_splice", "acc_ticket"):
                        attack_num += measured[f"{attack_key}_num"]
                        attack_den += measured[f"{attack_key}_den"]
                    div_num += measured["divergent_num"]
                    div_den += measured["divergent_den"]
                    hq_num += measured["hquar_num"]
                    hq_den += measured["hquar_den"]
                trace = make_trace("RS1", T, 1000 + run)
                policy = ResyncPolicy(cfg, trace.base_secret)
                policy._rng = np.random.default_rng(7000 + run)
                measured = metrics(trace, run_policy(policy, trace))
                avail_num += measured["availability_num"]
                avail_den += measured["availability_den"]
            row = {
                "tag": tag, "parameter": attr, "value": value,
                "attack": attack_num / attack_den if attack_den else 0.0,
                "divergence": div_num / div_den if div_den else 0.0,
                "hquar": hq_num / hq_den if hq_den else 0.0,
                "availability": avail_num / avail_den,
                "attack_num": attack_num, "attack_den": attack_den,
                "divergent_num": div_num, "divergent_den": div_den,
                "hquar_num": hq_num, "hquar_den": hq_den,
                "availability_num": avail_num, "availability_den": avail_den,
            }
            rows.append(row)
            per_value.append(row)
        summaries[tag] = {
            "rng": f"{values[0]}--{values[-1]}",
            "acc": 100 * max(row["attack"] for row in per_value),
            "dv": 100 * max(row["divergence"] for row in per_value),
            "hq": 100 * max(row["hquar"] for row in per_value),
            "av": 100 * min(row["availability"] for row in per_value),
        }
        print(f"[robust] {tag} acc={summaries[tag]['acc']:.1f} "
              f"div={summaries[tag]['dv']:.1f} "
              f"avail={summaries[tag]['av']:.1f}", flush=True)
    _write_rows(os.path.join(RESYNC_OUT, "robustness.csv"), rows)
    return summaries


def _write_rows(path: str, rows: list[Dict[str, Any]]) -> None:
    if not rows:
        return
    fields = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


# ---------------------------------------------------------------------------
# Figures

def fig_rs_latency(latpool):
    fig, ax = plt.subplots(figsize=(W, 2.15))
    x = np.arange(len(CONDS))
    width = 0.25
    series = [("resume", "R_QARTZ", "Resume", "#4477AA"),
              ("deltapatch", "R_QARTZ", "DeltaPatch", "#228833"),
              ("fullreattest", "B2_FullOnly", "FullReAttest", "#CC6677")]
    for offset, (path, policy, label, color) in enumerate(series):
        means, errors = [], []
        for cond in CONDS:
            mean, error = poolstat(latpool, policy, cond, path)
            means.append(mean)
            errors.append(error)
        ax.bar(x + (offset - 1) * width, means, width, yerr=errors,
               label=label, color=color, capsize=2)
    ax.set_yscale("log")
    ax.set_ylabel("successful latency (ms, log)")
    ax.set_xticks(x, ["clean", "disrupted", "heavy"])
    ax.legend(frameon=False, ncol=3, loc="upper left")
    fig.tight_layout(pad=.4)
    fig.savefig(os.path.join(FIG, "fig_rs_latency.pdf"), bbox_inches="tight")
    plt.close(fig)


def fig_rs_attacks(raw):
    policies = ["B1_ReAuth", "B3_NoBind", "B5_NoBundle", "B6_Ticket",
                "A_noFresh", "A_noCtrConsume", "R_QARTZ"]
    attack_specs = [("acc_stale", "RS2"), ("acc_roll", "RS4"),
                    ("acc_wrong", "RS3"), ("acc_waiv", "RS3"),
                    ("acc_splice", "RS5"), ("acc_ticket", "RS4")]
    values = []
    for policy in policies:
        observed = [mstat(raw, scenario, policy, key)[0]
                    for key, scenario in attack_specs]
        values.append(max(value for value in observed if not np.isnan(value)))
    fig, ax = plt.subplots(figsize=(W, 2.05))
    colors = ["#CC6677" if policy != "R_QARTZ" else "#228833"
              for policy in policies]
    ax.bar(np.arange(len(policies)), 100 * np.asarray(values), color=colors)
    ax.set_ylabel("worst attack acceptance (%)")
    ax.set_xticks(np.arange(len(policies)), [DISPLAY[p] for p in policies])
    ax.set_ylim(0, 108)
    fig.tight_layout(pad=.4)
    fig.savefig(os.path.join(FIG, "fig_rs_attacks.pdf"), bbox_inches="tight")
    plt.close(fig)


def fig_rs_frontier(result):
    fig, ax1 = plt.subplots(figsize=(W, 2.1))
    budgets = result["budget"]
    ax1.plot(budgets, 100 * np.asarray(result["R_QARTZ"]["patch"]),
             marker="o", label="Q-ARTZ patch", color="#228833")
    ax1.set_xlabel("policy/key lag budget (epochs)")
    ax1.set_ylabel("DeltaPatch ratio (%)")
    ax2 = ax1.twinx()
    ax2.plot(budgets, 100 * np.asarray(result["B3_NoBind"]["wrong"]),
             marker="s", linestyle="--", label="NoBind wrong-base",
             color="#CC6677")
    ax2.plot(budgets, 100 * np.asarray(result["R_QARTZ"]["wrong"]),
             linestyle=":", label="Q-ARTZ wrong-base", color="#4477AA")
    ax2.set_ylabel("wrong-base acceptance (%)")
    lines = ax1.lines + ax2.lines
    ax1.legend(lines, [line.get_label() for line in lines], frameon=False,
               loc="upper left")
    fig.tight_layout(pad=.4)
    fig.savefig(os.path.join(FIG, "fig_rs_frontier.pdf"), bbox_inches="tight")
    plt.close(fig)


def fig_rs_divergence(result):
    fig, ax = plt.subplots(figsize=(W, 2.0))
    ax.plot(100 * np.asarray(result["loss"]),
            100 * np.asarray(result["B4_div"]), marker="s",
            label="NoCommit", color="#CC6677")
    ax.plot(100 * np.asarray(result["loss"]),
            100 * np.asarray(result["R_div"]), marker="o",
            label="Q-ARTZ", color="#228833")
    ax.set_xlabel("per-attempt link loss (%)")
    ax.set_ylabel("divergent reconnects (%)")
    ax.legend(frameon=False)
    fig.tight_layout(pad=.4)
    fig.savefig(os.path.join(FIG, "fig_rs_divergence.pdf"), bbox_inches="tight")
    plt.close(fig)


def fig_rs_timeline():
    trace = make_trace("RS1", T, seed=1042)
    policy = POLICIES["R_QARTZ"](np.random.default_rng(7042), trace.base_secret)
    outcomes = run_policy(policy, trace)
    mapping = {"abort": -1, "resume": 0, "deltapatch": 1,
               "fullreattest": 2}
    y = [mapping.get(outcome["path"], -1) for outcome in outcomes]
    colors = {CLEAN: "#D9F0D3", DISR: "#FEE8C8", HEAVY: "#F4A6A6"}
    fig, ax = plt.subplots(figsize=(W, 1.95))
    for episode, outcome in zip(trace.episodes, outcomes):
        ax.axvspan(episode.idx - .5, episode.idx + .5,
                   color=colors[outcome["cond"]], alpha=.35, linewidth=0)
    ax.step(range(T), y, where="mid", color="#225588")
    ax.set_yticks([-1, 0, 1, 2], ["abort", "resume", "patch", "full"])
    ax.set_xlabel("reconnect episode")
    ax.set_title("State-carrying Q-ARTZ mission trace (RS1)", fontsize=8)
    fig.tight_layout(pad=.4)
    fig.savefig(os.path.join(FIG, "fig_rs_timeline.pdf"), bbox_inches="tight")
    plt.close(fig)


def fig_rs_sensitivity(frontier_result, latt_result):
    fig, axes = plt.subplots(1, 2, figsize=(2 * W, 2.05))
    axes[0].plot(frontier_result["budget"],
                 100 * np.asarray(frontier_result["R_QARTZ"]["patch"]),
                 marker="o", color="#228833")
    axes[0].set_xlabel("lag budget")
    axes[0].set_ylabel("DeltaPatch ratio (%)")
    axes[1].plot(latt_result["latt"],
                 100 * np.asarray(latt_result["patch"]),
                 marker="s", color="#4477AA")
    axes[1].set_xlabel("soft-stale budget $L_{att}$")
    axes[1].set_ylabel("DeltaPatch ratio (%)")
    fig.tight_layout(pad=.5)
    fig.savefig(os.path.join(FIG, "fig_rs_sensitivity.pdf"), bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Paper-compatible macro generation

def macros(raw, latpool, frontier_result, loss_result, latt_result,
           robustness_result, runtime_s):
    def pct(value):
        return "--" if np.isnan(value) else f"{100 * value:.1f}"

    def num(value, digits=1):
        return "--" if np.isnan(value) else f"{value:.{digits}f}"

    lines = []
    names = set()

    def M(name, value):
        if name in names:
            raise AssertionError(f"duplicate macro {name}")
        if not re.fullmatch(r"[A-Za-z]+", name):
            raise AssertionError(f"non-letter macro name {name}")
        text = str(value)
        if text.lower() in ("nan", "inf", "-inf"):
            raise AssertionError(f"invalid macro value {name}={text}")
        names.add(name)
        lines.append(f"\\newcommand{{\\{name}}}{{{text}}}")

    attack_table = [("acc_stale", "RS2", "Stale"),
                    ("acc_roll", "RS4", "Roll"),
                    ("acc_wrong", "RS3", "Wrong"),
                    ("acc_waiv", "RS3", "Waiv"),
                    ("acc_splice", "RS5", "Splice"),
                    ("acc_ticket", "RS4", "Tick")]
    for key, scenario, tag in attack_table:
        for policy in ALL_POLS:
            mean, error = mstat(raw, scenario, policy, key)
            suffix = POLNAME[policy]
            M(f"Rs{tag}Acc{suffix}", pct(mean))
            M(f"Rs{tag}Acc{suffix}Err", pct(error))

    for policy in ALL_POLS:
        suffix = POLNAME[policy]
        hq, hqe = mstat(raw, "RS6", policy, "hquar")
        div, dive = mstat(raw, "RS5", policy, "divergent")
        div7, _ = mstat(raw, "RS7", policy, "divergent")
        avail, availe = mstat(raw, "RS1", policy, "availability")
        avail_long, _ = mstat(raw, "RS1L", policy, "availability")
        honest, honeste = mstat(raw, "RS1", policy, "honest_patch_acc")
        M(f"RsHquar{suffix}", pct(hq)); M(f"RsHquar{suffix}Err", pct(hqe))
        M(f"RsDiv{suffix}", pct(div)); M(f"RsDiv{suffix}Err", pct(dive))
        M(f"RsDivKey{suffix}", pct(div7))
        M(f"RsAvail{suffix}", pct(avail)); M(f"RsAvail{suffix}Err", pct(availe))
        M(f"RsAvailLong{suffix}", pct(avail_long))
        M(f"RsHonAcc{suffix}", pct(honest)); M(f"RsHonAcc{suffix}Err", pct(honeste))

    for scenario, suffix in (("RS1", ""), ("RS1L", "Long")):
        for path, tag in (("resume", "Resume"), ("deltapatch", "Patch"),
                          ("fullreattest", "Full")):
            mean, _ = mstat(raw, scenario, "R_QARTZ", f"ratio_{path}")
            M(f"Rs{tag}Ratio{suffix}", pct(mean))

    for cond in CONDS:
        cname = CONDNAME[cond]
        for path, policy, tag in (("resume", "R_QARTZ", "Resume"),
                                  ("deltapatch", "R_QARTZ", "Patch"),
                                  ("fullreattest", "B2_FullOnly", "Full")):
            mean, error = poolstat(latpool, policy, cond, path)
            M(f"RsLat{cname}{tag}", num(mean))
            M(f"RsLat{cname}{tag}Err", num(error))
        interrupt_q, _ = mstat(raw, "RS1", "R_QARTZ", f"interrupt_{cond}")
        interrupt_b, _ = mstat(raw, "RS1", "B2_FullOnly", f"interrupt_{cond}")
        M(f"RsInterrupt{cname}Qartz", num(interrupt_q, 2))
        M(f"RsInterrupt{cname}FullOnly", num(interrupt_b, 2))

    for path, policy, tag, scenario in (
            ("resume", "R_QARTZ", "Resume", "RS1"),
            ("deltapatch", "R_QARTZ", "Patch", "RS1"),
            ("fullreattest", "B2_FullOnly", "Full", "RS1L")):
        values = [record[f"bytes_{path}"] for record in raw[(scenario, policy)]
                  if not np.isnan(record[f"bytes_{path}"])]
        M(f"RsBytes{tag}", num(float(np.mean(values)), 0))

    for cond in CONDS:
        anchor = R.TLS_PQC[cond] + R.QUOTE_MS + R.QUOTE_VERIFY_MS
        M(f"RsFullAnchor{CONDNAME[cond]}", num(anchor))

    aggregate_audit: Dict[str, Dict[str, Any]] = {}
    for scenario in SCENARIOS:
        for record in raw[(scenario, "R_QARTZ")]:
            for kind, item in record["guard_audit"].items():
                target = aggregate_audit.setdefault(
                    kind, {"n": 0, "acc": 0, "reasons": {}})
                target["n"] += item["n"]
                target["acc"] += item["acc"]
                for reason, count in item["reasons"].items():
                    target["reasons"][reason] = \
                        target["reasons"].get(reason, 0) + count
    audit_kinds = [("stale", "Stale"), ("wrongbase", "Wrong"),
                   ("waiv", "Waiv"), ("splice", "Splice"),
                   ("roll", "Roll"), ("ticket", "Tick"),
                   ("quar", "Quar"), ("honest", "Honest")]
    for kind, tag in audit_kinds:
        item = aggregate_audit.get(kind, {"n": 0, "acc": 0, "reasons": {}})
        M(f"RsAuditN{tag}", item["n"])
        rate = item["acc"] / item["n"] if item["n"] else float("nan")
        M(f"RsAuditAcc{tag}", pct(rate))
        if item["reasons"]:
            reason = max(item["reasons"].items(), key=lambda pair: pair[1])[0]
            M(f"RsAuditWhy{tag}", REASON_LABEL.get(reason, reason))
        else:
            M(f"RsAuditWhy{tag}", "accepted" if item["acc"] else "--")

    qpatch = np.asarray(frontier_result["R_QARTZ"]["patch"])
    qwrong = frontier_result["R_QARTZ"]["wrong"]
    b3wrong = np.asarray(frontier_result["B3_NoBind"]["wrong"])
    M("RsFrontierQartzWrongMax", pct(max(qwrong)))
    M("RsFrontierBThreeWrongMax", pct(float(max(b3wrong))))
    M("RsFrontierQartzPatchLo", pct(float(qpatch[0])))
    M("RsFrontierQartzPatchHi", pct(float(qpatch[-1])))
    indices = np.where(b3wrong >= .5)[0]
    M("RsFrontierBThreeHalfBudget",
      frontier_result["budget"][indices[0]] if len(indices) else "--")

    M("RsLossDivBFourMax", pct(max(loss_result["B4_div"])))
    M("RsLossDivQartzMax", pct(max(loss_result["R_div"])))
    M("RsLossCompleteQartzLo", pct(min(loss_result["R_complete"])))
    heavy_index = int(np.argmin(np.abs(np.asarray(loss_result["loss"]) - .15)))
    M("RsLossDivBFourAtHeavy", pct(loss_result["B4_div"][heavy_index]))
    M("RsLossDivQartzAtHeavy", pct(loss_result["R_div"][heavy_index]))

    M("RsLattPatchLo", pct(latt_result["patch"][0]))
    M("RsLattPatchHi", pct(latt_result["patch"][-1]))
    for tag, row in robustness_result.items():
        M(f"RsRob{tag}Rng", row["rng"])
        M(f"RsRob{tag}Acc", num(row["acc"]))
        M(f"RsRob{tag}Div", num(row["dv"]))
        M(f"RsRob{tag}Hquar", num(row["hq"]))
        M(f"RsRob{tag}Avail", num(row["av"]))
    M("RsRobAccMax", num(max(row["acc"] for row in robustness_result.values())))
    M("RsRobDivMax", num(max(row["dv"] for row in robustness_result.values())))
    M("RsRobHquarMax", num(max(row["hq"] for row in robustness_result.values())))
    M("RsRobAvailMin", num(min(row["av"] for row in robustness_result.values())))

    timing_trace = make_trace("RS1", T, 1)
    timing_policy = POLICIES["R_QARTZ"](np.random.default_rng(1),
                                         timing_trace.base_secret)
    run_policy(timing_policy, timing_trace)
    if not timing_policy.commit_step_time_us:
        raise AssertionError("normal RS1 timing trace did not execute commit")
    step_us = float(np.mean(timing_policy.commit_step_time_us))
    M("RsNumRuns", RUNS); M("RsSimT", T); M("RsNumPol", len(ALL_POLS))
    M("RsNumScen", len(SCENARIOS)); M("RsFrontierRuns", FRONTIER_RUNS)
    M("RsStepMicros", num(step_us)); M("RsSimSecs", num(runtime_s, 0))
    M("RsMldsaBytes", R.B_SIG); M("RsHmacBytes", R.B_HMAC)
    M("RsTokenVerifyMs", num(R.TOKEN_VERIFY_MS))

    with open(MACRO_PATH, "w", encoding="utf-8") as stream:
        stream.write("% auto-generated by run_resync_experiments.py -- do not edit\n")
        stream.write("\n".join(lines) + "\n")
    _validate_paper_macro_abi(names)
    print(f"[macros] {len(lines)} definitions -> {MACRO_PATH}", flush=True)
    return names


def _validate_paper_macro_abi(generated_names: set[str]) -> None:
    paper = os.path.join(os.path.dirname(HERE), "paper", "QARTZ_Resync_en.tex")
    text = open(paper, encoding="utf-8").read()
    required = {name for name in re.findall(r"\\(Rs[A-Za-z]+)", text)
                if not name.startswith("RsTb")}
    missing = sorted(required - generated_names)
    if missing:
        raise AssertionError(f"paper macro ABI missing: {missing}")


def _write_manifest(runtime_s: float, macro_names: set[str]) -> None:
    manifest = {
        "schema": "qartz-resync-stateful-v2", "generated_utc": time.time(),
        "python": sys.version, "platform": platform.platform(),
        "numpy": np.__version__, "runs": RUNS, "events_per_run": T,
        "scenarios": SCENARIOS, "policies": ALL_POLS,
        "seeds": {"trace": "1000..1099", "policy": "7000..7099"},
        "n_retry": R.N_RETRY, "link": LINK,
        "runtime_s": runtime_s, "macro_count": len(macro_names),
        "raw_outputs": [
            "raw_metrics.csv", "episode_outcomes.csv.gz", "latency_summary.csv",
            "frontier.npy", "frontier_raw.csv", "loss.npy", "loss_raw.csv",
            "latt.npy", "latt_raw.csv", "robustness.csv",
        ],
    }
    with open(os.path.join(RESYNC_OUT, "manifest.json"), "w",
              encoding="utf-8") as stream:
        json.dump(manifest, stream, indent=2, sort_keys=True)


def main():
    _ensure_dirs()
    started = time.time()
    raw, latpool = aggregate()
    frontier_result = frontier()
    loss_result = loss_sweep()
    latt_result = latt_sweep()
    robustness_result = robustness()
    fig_rs_latency(latpool)
    fig_rs_attacks(raw)
    fig_rs_frontier(frontier_result)
    fig_rs_divergence(loss_result)
    fig_rs_timeline()
    fig_rs_sensitivity(frontier_result, latt_result)
    runtime_s = time.time() - started
    macro_names = macros(raw, latpool, frontier_result, loss_result,
                         latt_result, robustness_result, runtime_s)
    _write_manifest(runtime_s, macro_names)
    print(f"total {runtime_s:.1f}s", flush=True)


if __name__ == "__main__":
    main()

