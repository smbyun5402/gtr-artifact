"""Stateful two-endpoint simulator for Q-ARTZ-Resync.

The simulator intentionally separates three concerns:

* :class:`Episode` is an immutable exogenous trace (partition drift,
  infrastructure reachability, adversary delivery, and common network draws).
* :class:`ResyncPolicy` owns two persistent endpoints.  Their Sigma, ticket,
  counter, peer checkpoint, and commit phase survive all reconnects in a run.
* Attack labels select captured wire material, but protocol outcomes are
  produced only by the same signature/digest/bundle/commit validators used for
  honest traffic.  No validator branches on the expected verdict.

Cryptographic signatures are a deterministic Dolev--Yao signing oracle.  Hash,
HKDF, HMAC, transcript construction, state transitions, and counter checks are
real computations over canonical length-prefixed encodings.  The real-crypto
testbed remains the performance anchor.
"""

from __future__ import annotations

import copy
import hashlib
import hmac
import json
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Optional, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Canonical encoding and cryptographic computations

def _canon(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def H(*parts: Any) -> str:
    h = hashlib.sha256()
    for part in parts:
        encoded = _canon(part)
        h.update(len(encoded).to_bytes(4, "big"))
        h.update(encoded)
    return h.hexdigest()


def _hkdf(secret: bytes, info: bytes, salt: bytes = b"qartz-resync",
          length: int = 32) -> bytes:
    prk = hmac.new(salt, secret, hashlib.sha256).digest()
    okm, block, counter = b"", b"", 1
    while len(okm) < length:
        block = hmac.new(prk, block + info + bytes([counter]),
                         hashlib.sha256).digest()
        okm += block
        counter += 1
    return okm[:length]


def _mac(key: bytes, obj: Any) -> str:
    return hmac.new(key, _canon(obj), hashlib.sha256).hexdigest()


def _signing_key(signer: str) -> bytes:
    return hashlib.sha256(("qartz-signing-key|" + signer).encode()).digest()


def sign_object(signer: str, body: Dict[str, Any]) -> Dict[str, Any]:
    body_copy = copy.deepcopy(body)
    return {"signer": signer, "body": body_copy,
            "sig": _mac(_signing_key(signer), body_copy)}


def verify_object(obj: Any, signer: str) -> bool:
    if not isinstance(obj, dict) or obj.get("signer") != signer:
        return False
    body, sig = obj.get("body"), obj.get("sig")
    if not isinstance(body, dict) or not isinstance(sig, str):
        return False
    return hmac.compare_digest(sig, _mac(_signing_key(signer), body))


def wire_bytes(obj: Any) -> int:
    """Application-wire bytes, including the four-byte frame prefix."""
    return 4 + len(_canon(obj))


def strict_wire_decode(data: bytes | str) -> Any:
    """Decode the canonical integer-only JSON profile used on the wire.

    JSON's default decoder silently keeps the last duplicate key and accepts
    NaN/Infinity.  This decoder also rejects finite floats, invalid Unicode,
    and non-canonical whitespace/key ordering before transcript validation.
    """
    if isinstance(data, bytes):
        text = data.decode("utf-8", errors="strict")
    elif isinstance(data, str):
        text = data
    else:
        raise TypeError("wire input must be bytes or str")

    def no_duplicates(pairs: list[Tuple[str, Any]]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for key, value in pairs:
            if key in out:
                raise ValueError(f"duplicate JSON key: {key}")
            out[key] = value
        return out

    def reject_constant(value: str) -> Any:
        raise ValueError(f"non-finite JSON number: {value}")

    def reject_float(value: str) -> Any:
        raise ValueError(f"floating-point JSON number: {value}")

    parsed = json.loads(text, object_pairs_hook=no_duplicates,
                        parse_constant=reject_constant,
                        parse_float=reject_float)

    def reject_surrogates(value: Any) -> None:
        if isinstance(value, str):
            if any(0xD800 <= ord(ch) <= 0xDFFF for ch in value):
                raise ValueError("unpaired Unicode surrogate")
        elif isinstance(value, dict):
            for key, item in value.items():
                reject_surrogates(key)
                reject_surrogates(item)
        elif isinstance(value, list):
            for item in value:
                reject_surrogates(item)

    reject_surrogates(parsed)
    if _canon(parsed).decode("utf-8") != text:
        raise ValueError("non-canonical JSON encoding")
    return parsed


def wire_roundtrip(obj: Any) -> Any:
    """Serialize and parse an application message before peer validation."""
    return strict_wire_decode(_canon(obj))


# ---------------------------------------------------------------------------
# Constants shared with the paper/testbed

CLEAN, DISR, HEAVY = "clean", "disrupted", "heavy"
CONDS = (CLEAN, DISR, HEAVY)
PATHS = ("resume", "deltapatch", "fullreattest")

TOKEN_VERIFY_MS = 2.58
QUOTE_MS = 10.3
QUOTE_VERIFY_MS = 4.2
TLS_PQC = {CLEAN: 72.8, DISR: 789.5, HEAVY: 3871.7}
COMMIT_MAC_MS = 0.226

LINK = {
    CLEAN: dict(delay=10.0, jitter=0.0, loss=0.00, rto=30.0),
    DISR: dict(delay=100.0, jitter=20.0, loss=0.05, rto=300.0),
    HEAVY: dict(delay=200.0, jitter=50.0, loss=0.15, rto=600.0),
}

# Appendix A specifies two retries, i.e. at most three transmission attempts.
N_RETRY = 2

B_SIG = 3309
B_KEMCT = 1088
B_KEMPK = 1184
B_HMAC = 32
B_FULL_REATTEST = 9390

RHO_PATCH = 0.35
RHO_ATT_MIN = 0.40
LAG_POL = 1
LAG_KEY = 1
L_ATT = 2
BASE_CTR = 100
TIME_TTL_S = 300.0

CORE_FIELDS = ("sid", "mode", "reqClass", "secEpoch", "keyEpoch",
               "polEpoch", "policyHash", "manifestDigest")
FULL_FIELDS = CORE_FIELDS + ("attEpoch", "transCtr", "seqNo",
                             "chainDigest", "EARdigest")

_SIGMA_STRING_FIELDS = {
    "sid", "mode", "policyHash", "manifestDigest", "chainDigest",
    "EARdigest",
}
_SIGMA_INT_FIELDS = set(FULL_FIELDS) - _SIGMA_STRING_FIELDS
_VALID_MODES = {"PQC", "HYBRID", "LEGACY", "SUSPEND"}


def validate_sigma_schema(sigma: Any) -> Tuple[bool, str]:
    """Reject ambiguous or type-confused wire states before digesting them.

    The experiment generator always emits this exact schema.  Keeping the
    check here (rather than only in the verification harness) makes malformed
    wire inputs exercise the same parser boundary as protocol traffic.
    """
    if not isinstance(sigma, dict):
        return False, "sigma-type"
    if set(sigma) != set(FULL_FIELDS):
        return False, "sigma-fields"
    for key in _SIGMA_STRING_FIELDS:
        if not isinstance(sigma.get(key), str):
            return False, "sigma-type"
    for key in _SIGMA_INT_FIELDS:
        value = sigma.get(key)
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            return False, "sigma-type"
    if sigma["reqClass"] > 3 or sigma["mode"] not in _VALID_MODES:
        return False, "sigma-type"
    return True, "accept"


_MESSAGE_FIELDS = {
    "ReConnState": {"kind", "nonceJ", "sigmaJ", "sstJ"},
    "ReConnCommit": {"kind", "nonceI", "sigmaI", "sstI", "bundle",
                      "decision", "commitI", "ticketPrime"},
    "ReConnConfirm": {"kind", "decision", "commitJ"},
}


def validate_wire_message(message: Any, expected_kind: str) -> Tuple[bool, str]:
    """Strict schema check for the three authenticated resync messages."""
    if not isinstance(message, dict):
        return False, "message-type"
    expected = _MESSAGE_FIELDS.get(expected_kind)
    if expected is None or message.get("kind") != expected_kind:
        return False, "message-kind"
    if set(message) != expected:
        return False, "message-fields"
    nonce_key = "nonceJ" if expected_kind == "ReConnState" else "nonceI"
    if expected_kind != "ReConnConfirm" and not isinstance(
            message.get(nonce_key), str):
        return False, "message-type"
    if expected_kind == "ReConnState":
        ok, why = validate_sigma_schema(message.get("sigmaJ"))
        if not ok:
            return False, why
        if not isinstance(message.get("sstJ"), dict):
            return False, "message-type"
    elif expected_kind == "ReConnCommit":
        ok, why = validate_sigma_schema(message.get("sigmaI"))
        if not ok:
            return False, why
        if (not isinstance(message.get("sstI"), dict) or
                not isinstance(message.get("ticketPrime"), dict) or
                not isinstance(message.get("commitI"), str) or
                not isinstance(message.get("bundle"), dict) or
                message.get("decision") not in ("Resume", "DeltaPatch")):
            return False, "message-type"
    elif (not isinstance(message.get("commitJ"), str) or
          message.get("decision") not in ("Resume", "DeltaPatch")):
        return False, "message-type"
    return True, "accept"


# ---------------------------------------------------------------------------
# State and signed objects

def mk_sigma(sid: str, polEpoch: int, keyEpoch: int, attEpoch: int,
             transCtr: int, seqNo: int, chainDigest: str,
             manifestDigest: str, policyHash: str, mode: str = "HYBRID",
             reqClass: int = 1, secEpoch: int = 0,
             EARdigest: Optional[str] = None) -> Dict[str, Any]:
    return dict(sid=sid, mode=mode, reqClass=reqClass, secEpoch=secEpoch,
                keyEpoch=keyEpoch, polEpoch=polEpoch, attEpoch=attEpoch,
                transCtr=transCtr, seqNo=seqNo, chainDigest=chainDigest,
                manifestDigest=manifestDigest, policyHash=policyHash,
                EARdigest=EARdigest or H("ear", sid, attEpoch))


def core_digest(sigma: Dict[str, Any]) -> str:
    return H("core", {key: sigma[key] for key in CORE_FIELDS})


def state_digest(sigma: Dict[str, Any]) -> str:
    return H("state", {key: sigma[key] for key in FULL_FIELDS})


def _advance_seq(sigma: Dict[str, Any], amount: int, node_id: str) -> None:
    if amount <= 0:
        return
    previous = sigma["chainDigest"]
    sigma["seqNo"] += amount
    sigma["chainDigest"] = H("chain", node_id, previous, sigma["seqNo"])


def build_sst(sigma: Dict[str, Any], nonce_peer: str, nonce_self: str,
              role: str, signer: str, issued_at: float) -> Dict[str, Any]:
    body = {
        "kind": "sst", "stateDigest": state_digest(sigma),
        "transCtr": sigma["transCtr"], "attEpoch": sigma["attEpoch"],
        "seqNo": sigma["seqNo"], "chainDigest": sigma["chainDigest"],
        "noncePeer": nonce_peer, "nonceSelf": nonce_self,
        "sid": sigma["sid"], "role": role, "akId": signer,
        "issuedAt": int(round(issued_at)),
    }
    return sign_object(signer, body)


def build_waiver(issue_sigma: Dict[str, Any], to_ctr: int,
                 scope: Tuple[str, Tuple[str, ...]], waiver_id: str,
                 exp_event: int) -> Dict[str, Any]:
    body = {
        "kind": "waiver", "coreDigest": core_digest(issue_sigma),
        "fromStateDigest": state_digest(issue_sigma),
        "toTransCtr": int(to_ctr), "scope": [scope[0], list(scope[1])],
        "waiverID": waiver_id, "expEvent": int(exp_event),
        "nonceW": H("waiver-nonce", waiver_id)[:24],
    }
    return sign_object("PA", body)


def build_delta(issue_sigma: Dict[str, Any], target_sigma: Dict[str, Any],
                scope: Tuple[str, Tuple[str, ...]], delta_id: str,
                exp_event: int, relax_bits: int = 0) -> Dict[str, Any]:
    body = {
        "kind": "delta", "fromCoreDigest": core_digest(issue_sigma),
        "fromStateDigest": state_digest(issue_sigma),
        "fromPolEpoch": issue_sigma["polEpoch"],
        "toPolEpoch": target_sigma["polEpoch"],
        "fromPolicyHash": issue_sigma["policyHash"],
        "toPolicyHash": target_sigma["policyHash"],
        "fromReqClass": issue_sigma["reqClass"],
        "toReqClass": target_sigma["reqClass"],
        "scope": [scope[0], list(scope[1])], "deltaID": delta_id,
        "expEvent": int(exp_event), "relaxBits": int(relax_bits),
    }
    return sign_object("PA", body)


def build_key_update(issue_sigma: Dict[str, Any],
                     target_sigma: Dict[str, Any], update_id: str,
                     exp_event: int) -> Dict[str, Any]:
    body = {
        "kind": "keyupd", "fromCoreDigest": core_digest(issue_sigma),
        "fromStateDigest": state_digest(issue_sigma),
        "fromKeyEpoch": issue_sigma["keyEpoch"],
        "toKeyEpoch": target_sigma["keyEpoch"],
        "updateID": update_id, "expEvent": int(exp_event),
    }
    return sign_object("PA", body)


def compatible_scope(a: Any, b: Any) -> bool:
    if a is None or b is None:
        return True
    # A waiver authorizes a delta only when it covers every capability the
    # delta affects.  Mere overlap would allow a one-capability waiver to be
    # spliced onto a broader change.
    return a[0] == b[0] and set(b[1]).issubset(set(a[1]))


def issue_ticket(sigma: Dict[str, Any], event_idx: int,
                 ticket_id: str) -> Dict[str, Any]:
    body = {"kind": "ticket", "sid": sigma["sid"],
            "stateDigest": state_digest(sigma),
            "issuedEvent": int(event_idx), "expEvent": int(event_idx + 80),
            "ticketID": ticket_id}
    return sign_object("TA", body)


def ticket_digest(ticket: Dict[str, Any]) -> str:
    return H("ticket", ticket)


# ---------------------------------------------------------------------------
# Exogenous paired trace

@dataclass(frozen=True)
class Episode:
    idx: int
    scenario: str
    cond: str
    attack: Optional[str]
    delta_pol: int
    delta_key: int
    att_lag: int
    local_seq_i: int
    local_seq_j: int
    rho_min: float
    rho_att: float
    pa_reachable: bool
    verifier_reachable: bool
    cached_bundle: bool
    needs_waiver: bool
    window_s: float
    wall_time: float
    clock_skew_i: float
    nonce_i: str
    nonce_j: str
    net_draws: Dict[str, Tuple[Tuple[float, float], ...]]
    force_drop_stage: Optional[str] = None


@dataclass
class Trace:
    T: int
    scenario: str
    episodes: list[Episode]
    base_secret: bytes
    initial_sigma: Dict[str, Any]


def _network_draws(rng: np.random.Generator) \
        -> Dict[str, Tuple[Tuple[float, float], ...]]:
    labels = ("M1", "M2", "M3", "M4", "T1", "T2", "RA1", "RA2")
    return {
        label: tuple((float(rng.random()), float(rng.standard_normal()))
                     for _ in range(N_RETRY + 1))
        for label in labels
    }


def _pick_cond(rng: np.random.Generator, lossy: bool = False) -> str:
    p = [0.20, 0.30, 0.50] if lossy else [0.50, 0.30, 0.20]
    return str(rng.choice(CONDS, p=p))


def make_trace(scenario: str, T: int, seed: int) -> Trace:
    """Create an immutable paired exogenous trace.

    Endpoint state is deliberately absent from the trace.  Every policy starts
    from ``initial_sigma`` and carries its own committed state across the same
    sequence of exogenous increments and network uniforms.
    """
    rng = np.random.default_rng(seed)
    sid = f"sid-{seed}"
    base_secret = rng.integers(0, 256, size=32, dtype=np.uint8).tobytes()
    manifest = H("manifest", sid, "v1")
    initial = mk_sigma(
        sid=sid, polEpoch=3, keyEpoch=2, attEpoch=0,
        transCtr=BASE_CTR, seqNo=1000,
        chainDigest=H("chain", sid, 1000), manifestDigest=manifest,
        policyHash=H("policy", sid, 3), secEpoch=1,
    )
    episodes: list[Episode] = []

    for idx in range(T):
        attack: Optional[str] = None
        dp = dk = al = 0
        seq_i = seq_j = 0
        needs_waiver = False
        cached = False
        force_drop: Optional[str] = None
        cond = _pick_cond(rng)
        pa_reachable = bool(rng.random() < 0.35)
        verifier_reachable = bool(rng.random() < 0.60)

        if scenario == "RS1":
            pa_reachable = False
            if rng.random() >= 0.40:
                dp, dk = int(rng.integers(0, 2)), int(rng.integers(0, 2))
                al = int(rng.integers(0, L_ATT + 1))
                # Every scheduled patch carries at least one PA object.  This
                # keeps the full-digest ablation focused on its intended
                # issue-time-vs-apply-time binding failure.
                if dp == dk == 0:
                    dp = 1
                seq_i, seq_j = int(rng.integers(1, 4)), int(rng.integers(1, 5))
                cached = True
            # The verifier is often unavailable even though cached patches exist.
            verifier_reachable = bool(rng.random() < 0.55)
        elif scenario == "RS1L":
            dp, dk, al = (int(rng.integers(2, 5)),
                          int(rng.integers(0, 3)),
                          int(rng.integers(3, 6)))
            seq_i, seq_j = int(rng.integers(2, 6)), int(rng.integers(3, 8))
            cached = True
            pa_reachable = bool(rng.random() < 0.20)
            verifier_reachable = bool(rng.random() >= 0.15)
        elif scenario == "RS2":
            cond = CLEAN
            verifier_reachable = True
            if idx > 0:
                r = rng.random()
                attack = "stale" if r < 0.70 else None
        elif scenario == "RS3":
            cond = CLEAN
            cached = True
            verifier_reachable = True
            phase = idx % 4
            if phase == 0:
                needs_waiver = True
            elif phase == 1:
                attack = "waiv"
                needs_waiver = True
            elif phase == 2:
                attack = "wrongbase"
                dp = 1
                seq_i, seq_j = 1, 2
            else:
                dp, seq_i, seq_j = 1, 1, 2
        elif scenario == "RS4":
            cond = CLEAN
            cached = True
            verifier_reachable = True
            if idx == 0:
                dp, seq_i, seq_j = 1, 1, 2
            elif idx % 3 == 1:
                attack = "ticket"
            elif idx % 3 == 2:
                attack = "roll"
        elif scenario == "RS5":
            cond = _pick_cond(rng, lossy=True)
            cached = True
            verifier_reachable = True
            r = rng.random()
            if r < 0.30:
                dp, seq_i, seq_j = 1, 1, 2
            elif r < 0.55:
                attack, dp, needs_waiver = "splice", 1, True
                seq_i, seq_j = 1, 2
            elif r < 0.80:
                attack, dp = "cdrop", 1
                seq_i, seq_j = 1, 2
                force_drop = "M3" if rng.random() < 0.50 else "M4"
            else:
                attack, dp = "dsplice", 1
                seq_i, seq_j = 1, 2
        elif scenario == "RS6":
            cond = CLEAN
            verifier_reachable = True
            r = rng.random()
            if r >= 0.90:
                attack = "reflect"
            elif r >= 0.35:
                attack = "quar"
        elif scenario == "RS7":
            cond = _pick_cond(rng, lossy=True)
            cached = True
            verifier_reachable = True
            dk, seq_i, seq_j = 1, 1, 2
            if rng.random() >= 0.30:
                attack = "key_race"
                force_drop = "M4" if rng.random() < 0.35 else None
        elif scenario == "FRONTIER":
            cond = _pick_cond(rng)
            verifier_reachable = True
            dp = int(rng.integers(0, 6))
            cached = True
            seq_i, seq_j = (0, 0) if dp == 0 else (1, 2)
            if rng.random() >= 0.50:
                attack = "wrongbase"
                if dp == 0:
                    dp, seq_i, seq_j = 1, 1, 2
        elif scenario == "LOSS":
            cond = DISR
            verifier_reachable = True
            dp, seq_i, seq_j = 1, 1, 2
            cached = True
            # No forced verdict: actual M1--M4 network uniforms drive loss.
        elif scenario == "LATT":
            cond = CLEAN
            verifier_reachable = True
            al = int(rng.integers(0, 6))
            seq_i, seq_j = (0, 0) if al == 0 else (1, 2)
            cached = True
        else:
            raise ValueError(f"unknown resync scenario: {scenario}")

        if scenario in ("RS2", "RS3", "RS4", "RS5", "RS6", "RS7",
                        "FRONTIER", "LOSS"):
            rho_min = rho_att = 0.80
        else:
            rho_min = float(np.clip(0.55 + 0.10 * rng.standard_normal(),
                                    0.25, 0.95))
            rho_att = float(np.clip(0.55 + 0.10 * rng.standard_normal(),
                                    0.25, 0.95))
        episodes.append(Episode(
            idx=idx, scenario=scenario, cond=cond, attack=attack,
            delta_pol=dp, delta_key=dk, att_lag=al,
            local_seq_i=seq_i, local_seq_j=seq_j,
            rho_min=rho_min, rho_att=rho_att,
            pa_reachable=pa_reachable,
            verifier_reachable=verifier_reachable,
            cached_bundle=cached, needs_waiver=needs_waiver,
            window_s=float(rng.uniform(30.0, 180.0)),
            wall_time=float(idx * 60.0),
            clock_skew_i=float(rng.uniform(-90.0, 90.0)),
            nonce_i=H("nonce-i", seed, idx)[:32],
            nonce_j=H("nonce-j", seed, idx)[:32],
            net_draws=_network_draws(rng), force_drop_stage=force_drop,
        ))

    return Trace(T=T, scenario=scenario, episodes=episodes,
                 base_secret=base_secret, initial_sigma=initial)


# ---------------------------------------------------------------------------
# Policy and endpoint state

@dataclass
class PolCfg:
    name: str
    mode: str = "full"          # full | reauth | fullonly | ticket | oracle
    freshness_mode: str = "nonce"  # nonce | none | time
    binding_surface: str = "core"  # core | full | none
    check_bundle: bool = True
    consume_ctr: bool = True
    check_commit: bool = True
    bind_decision: bool = True
    check_chain: bool = True
    fresh_evidence_quar: bool = True
    lag_pol: int = LAG_POL
    lag_key: int = LAG_KEY
    L_att: int = L_ATT
    rho_patch: float = RHO_PATCH
    rho_att_min: float = RHO_ATT_MIN


@dataclass
class Endpoint:
    node_id: str
    sigma: Dict[str, Any]
    phase: str = "open"
    current_ticket: Optional[Dict[str, Any]] = None
    valid_tickets: set[str] = field(default_factory=set)
    invalidated_tickets: set[str] = field(default_factory=set)
    consumed_waivers: set[str] = field(default_factory=set)
    # Counter reservations are durable tombstones.  An aborted candidate may
    # not make its transition counter available to a later transcript.
    reserved_counters: set[int] = field(default_factory=set)
    peer_floor: Dict[str, Tuple[int, int]] = field(default_factory=dict)
    candidate_record: Optional[Dict[str, Any]] = None
    last_decision: Optional[str] = None


@dataclass
class DecisionResult:
    decision: str
    candidate: Optional[Dict[str, Any]]
    delta_sigma: Dict[str, Tuple[Any, Any]]
    reason: str
    waiver_id: Optional[str] = None


def _field_delta(sigma_i: Dict[str, Any], sigma_j: Dict[str, Any]) \
        -> Dict[str, Tuple[Any, Any]]:
    return {key: (sigma_i[key], sigma_j[key]) for key in FULL_FIELDS
            if sigma_i[key] != sigma_j[key]}


def _scope_body(obj: Optional[Dict[str, Any]]) -> Any:
    return None if obj is None else obj["body"].get("scope")


def _bundle_objects(bundle: Optional[Dict[str, Any]]) -> Iterable[Dict[str, Any]]:
    if not bundle:
        return ()
    return tuple(bundle[key] for key in ("waiver", "delta", "keyupd")
                 if bundle.get(key) is not None)


def _bundle_hashes(bundle: Optional[Dict[str, Any]]) -> Dict[str, str]:
    empty = H("empty")
    return {key: H(bundle[key]) if bundle and bundle.get(key) else empty
            for key in ("waiver", "delta", "keyupd")}


class ResyncPolicy:
    def __init__(self, cfg: PolCfg, secret: Optional[bytes] = None):
        self.cfg = copy.deepcopy(cfg)
        self.secret = secret or b"\x00" * 32
        self.i: Optional[Endpoint] = None
        self.j: Optional[Endpoint] = None
        self.captured_m2: Optional[Dict[str, Any]] = None
        self.captured_sst_i: Optional[Dict[str, Any]] = None
        self.captured_waiver: Optional[Dict[str, Any]] = None
        self.captured_ticket: Optional[Dict[str, Any]] = None
        self.rollback_snapshot: Optional[Dict[str, Any]] = None
        self.step_time_us: list[float] = []
        self.commit_step_time_us: list[float] = []
        self.commit_count = 0
        self._rng = np.random.default_rng(0)

    # ----- lifecycle -----------------------------------------------------
    def start(self, trace: Trace) -> None:
        sigma_i = copy.deepcopy(trace.initial_sigma)
        sigma_j = copy.deepcopy(trace.initial_sigma)
        self.i = Endpoint("node-i", sigma_i)
        self.j = Endpoint("node-j", sigma_j)
        initial_ticket = issue_ticket(sigma_i, -1, H("ticket-initial", sigma_i["sid"]))
        for endpoint in (self.i, self.j):
            endpoint.current_ticket = copy.deepcopy(initial_ticket)
            endpoint.valid_tickets.add(ticket_digest(initial_ticket))
        self.captured_ticket = copy.deepcopy(initial_ticket)
        self.rollback_snapshot = copy.deepcopy(sigma_j)
        self.captured_m2 = None
        self.captured_sst_i = None
        self.captured_waiver = None
        self.step_time_us.clear()
        self.commit_step_time_us.clear()
        self.commit_count = 0

    @property
    def endpoints(self) -> Tuple[Endpoint, Endpoint]:
        assert self.i is not None and self.j is not None
        return self.i, self.j

    # ----- paired link ---------------------------------------------------
    def _transmit(self, ep: Episode, label: str,
                  force_drop: bool = False) -> Tuple[bool, float]:
        link = LINK[ep.cond]
        elapsed = 0.0
        for uniform, jitter_z in ep.net_draws[label]:
            delay = max(1.0, link["delay"] + link["jitter"] * jitter_z)
            if force_drop or uniform < link["loss"]:
                elapsed += link["rto"]
                continue
            elapsed += delay
            return True, elapsed
        return False, elapsed

    # ----- durable state -------------------------------------------------
    def _persist_candidate(self, endpoint: Endpoint,
                           candidate: Dict[str, Any], ticket: Dict[str, Any],
                           decision: str, phase: str) -> None:
        old = endpoint.current_ticket
        if old is not None:
            digest = ticket_digest(old)
            endpoint.valid_tickets.discard(digest)
            endpoint.invalidated_tickets.add(digest)
            self.captured_ticket = copy.deepcopy(old)
        endpoint.candidate_record = {
            "sigma": copy.deepcopy(candidate), "ticket": copy.deepcopy(ticket),
            "decision": decision, "phase": phase,
        }
        endpoint.reserved_counters.add(candidate["transCtr"])
        endpoint.phase = phase

    def _commit_candidate(self, endpoint: Endpoint) -> None:
        record = endpoint.candidate_record
        assert record is not None
        endpoint.sigma = copy.deepcopy(record["sigma"])
        endpoint.current_ticket = copy.deepcopy(record["ticket"])
        endpoint.valid_tickets.add(ticket_digest(record["ticket"]))
        endpoint.phase = "open"
        endpoint.last_decision = record["decision"]
        endpoint.candidate_record = None

    def _abort_candidate(self, endpoint: Endpoint) -> None:
        # Deliberately retain reserved_counters as an anti-reuse tombstone.
        endpoint.candidate_record = None
        endpoint.phase = "closed"
        endpoint.last_decision = None

    def _next_counter(self, sigma_i: Dict[str, Any],
                      sigma_j: Dict[str, Any]) -> int:
        i, j = self.endpoints
        reserved = i.reserved_counters | j.reserved_counters
        active = {
            endpoint.candidate_record["sigma"]["transCtr"]
            for endpoint in (i, j) if endpoint.candidate_record is not None
        }
        reserved -= active
        candidate = max(sigma_i["transCtr"], sigma_j["transCtr"]) + 1
        while candidate in reserved:
            candidate += 1
        return candidate

    def _unsafe_adopt(self, endpoint: Endpoint, candidate: Dict[str, Any],
                      decision: str, event_idx: int) -> None:
        # No-commit deliberately leaves the old ticket valid.
        if endpoint.current_ticket is not None:
            self.captured_ticket = copy.deepcopy(endpoint.current_ticket)
        endpoint.sigma = copy.deepcopy(candidate)
        endpoint.current_ticket = issue_ticket(
            candidate, event_idx, H("unsafe-ticket", endpoint.node_id,
                                    event_idx, state_digest(candidate)))
        endpoint.valid_tickets.add(ticket_digest(endpoint.current_ticket))
        endpoint.phase = "open"
        endpoint.last_decision = decision

    def _update_peer_floors(self) -> None:
        i, j = self.endpoints
        i.peer_floor[j.node_id] = (j.sigma["transCtr"], j.sigma["seqNo"])
        j.peer_floor[i.node_id] = (i.sigma["transCtr"], i.sigma["seqNo"])

    # ----- partition and authority objects ------------------------------
    def _apply_partition(self, ep: Episode) \
            -> Tuple[Dict[str, Any], Dict[str, Any]]:
        i, j = self.endpoints
        # A reconnect starts from a closed transport.  Local partition-time
        # evolution may diverge, but those states must not both remain labelled
        # OPEN when M1/M2 delivery later fails.
        i.phase = j.phase = "closed"
        issue_i = copy.deepcopy(i.sigma)
        issue_j = copy.deepcopy(j.sigma)
        _advance_seq(i.sigma, ep.local_seq_i, i.node_id)
        _advance_seq(j.sigma, ep.local_seq_j, j.node_id)
        if ep.delta_pol:
            j.sigma["polEpoch"] += ep.delta_pol
            j.sigma["policyHash"] = H("policy", j.sigma["sid"],
                                            j.sigma["polEpoch"])
        if ep.delta_key:
            j.sigma["keyEpoch"] += ep.delta_key
        if ep.att_lag:
            j.sigma["attEpoch"] += ep.att_lag
            j.sigma["EARdigest"] = H("ear", j.sigma["sid"],
                                           j.sigma["attEpoch"])
        return issue_i, issue_j

    def _legitimate_bundle(self, ep: Episode,
                           issue_i: Dict[str, Any]) \
            -> Optional[Dict[str, Any]]:
        i, j = self.endpoints
        need_delta = i.sigma["polEpoch"] != j.sigma["polEpoch"]
        need_key = i.sigma["keyEpoch"] != j.sigma["keyEpoch"]
        need_objects = need_delta or need_key or ep.needs_waiver
        if need_objects and not (ep.cached_bundle or ep.pa_reachable):
            return None
        if not need_objects:
            return {}

        # Cached objects were issued against the pre-partition snapshot; fresh
        # online issuance binds the current live state.
        issue = issue_i if ep.cached_bundle else copy.deepcopy(i.sigma)
        normal_scope = ("dom0", ("authn", "session", "key-mgmt"))
        bundle: Dict[str, Any] = {}
        if need_delta:
            bundle["delta"] = build_delta(
                issue, j.sigma, normal_scope, f"delta-{ep.idx}", ep.idx + 20)
        if need_key:
            bundle["keyupd"] = build_key_update(
                issue, j.sigma, f"keyupd-{ep.idx}", ep.idx + 20)
        if ep.needs_waiver:
            target_ctr = self._next_counter(i.sigma, j.sigma)
            bundle["waiver"] = build_waiver(
                issue, target_ctr, normal_scope, f"waiver-{ep.idx}", ep.idx + 20)
        return bundle

    def _wrongbase_bundle(self, ep: Episode) -> Dict[str, Any]:
        i, j = self.endpoints
        wrong = copy.deepcopy(i.sigma)
        wrong["manifestDigest"] = H("wrong-manifest", ep.idx, i.sigma["sid"])
        wrong["policyHash"] = H("wrong-policy", ep.idx)
        target = copy.deepcopy(j.sigma)
        if target["polEpoch"] == i.sigma["polEpoch"]:
            target["polEpoch"] += 1
            target["policyHash"] = H("malicious-policy", ep.idx)
        scope = ("dom0", ("authn", "session"))
        return {"delta": build_delta(wrong, target, scope,
                                      f"wrong-{ep.idx}", ep.idx + 20)}

    def _splice_bundle(self, ep: Episode) -> Dict[str, Any]:
        i, j = self.endpoints
        issue = copy.deepcopy(i.sigma)
        target = copy.deepcopy(j.sigma)
        if target["polEpoch"] == issue["polEpoch"]:
            target["polEpoch"] += 1
            target["policyHash"] = H("splice-policy", ep.idx)
        target_ctr = self._next_counter(i.sigma, j.sigma)
        waiver = build_waiver(issue, target_ctr,
                               ("dom0", ("authn", "session")),
                               f"splice-waiver-{ep.idx}", ep.idx + 20)
        delta = build_delta(issue, target,
                            ("dom0", ("crypto-suite",)),
                            f"splice-delta-{ep.idx}", ep.idx + 20,
                            relax_bits=0b00001000)
        return {"waiver": waiver, "delta": delta}

    # ----- validators ----------------------------------------------------
    def _verify_sst(self, receiver: Endpoint, signed: Dict[str, Any],
                    wire_sigma: Dict[str, Any], expected_signer: str,
                    expected_role: str, expected_peer_nonce: str,
                    expected_self_nonce: str, ep: Episode) -> Tuple[bool, str]:
        ok, why = validate_sigma_schema(wire_sigma)
        if not ok:
            return False, why
        if not verify_object(signed, expected_signer):
            return False, "signature"
        body = signed["body"]
        expected_fields = {
            "kind", "stateDigest", "transCtr", "attEpoch", "seqNo",
            "chainDigest", "noncePeer", "nonceSelf", "sid", "role",
            "akId", "issuedAt",
        }
        if set(body) != expected_fields:
            return False, "sst-fields"
        if body.get("kind") != "sst" or body.get("sid") != wire_sigma.get("sid"):
            return False, "sid"
        if body.get("akId") != expected_signer or body.get("role") != expected_role:
            return False, "role"
        if body.get("stateDigest") != state_digest(wire_sigma):
            return False, "state-digest"
        for key in ("transCtr", "attEpoch", "seqNo", "chainDigest"):
            if body.get(key) != wire_sigma.get(key):
                return False, "state-field"
        issued_at = body.get("issuedAt")
        if not isinstance(issued_at, int) or isinstance(issued_at, bool):
            return False, "sst-type"
        if self.cfg.freshness_mode == "nonce":
            if (body.get("noncePeer") != expected_peer_nonce or
                    body.get("nonceSelf") != expected_self_nonce):
                return False, "fresh"
        elif self.cfg.freshness_mode == "time":
            local_now = ep.wall_time + ep.clock_skew_i
            age = local_now - float(body.get("issuedAt", -math.inf))
            if age < -TIME_TTL_S or age > TIME_TTL_S:
                return False, "time-ttl"
        floor = receiver.peer_floor.get(expected_signer)
        if self.cfg.check_chain and floor is not None:
            if (wire_sigma["transCtr"] < floor[0] or
                    wire_sigma["seqNo"] < floor[1]):
                return False, "chain"
        return True, "accept"

    def _validate_m2_message(self, receiver: Endpoint, m2: Any,
                             expected_signer: str,
                             expected_peer_nonce: str,
                             ep: Episode) -> Tuple[bool, str]:
        ok, why = validate_wire_message(m2, "ReConnState")
        if not ok:
            return False, why
        return self._verify_sst(
            receiver, m2["sstJ"], m2["sigmaJ"], expected_signer, "resp",
            expected_peer_nonce, m2["nonceJ"], ep)

    @staticmethod
    def _valid_scope(scope: Any) -> bool:
        return (isinstance(scope, list) and len(scope) == 2 and
                isinstance(scope[0], str) and isinstance(scope[1], list) and
                bool(scope[1]) and all(isinstance(item, str)
                                       for item in scope[1]))

    def _validate_authority_object(self, obj: Any) -> Tuple[bool, str]:
        if not verify_object(obj, "PA"):
            return False, "signature"
        if set(obj) != {"signer", "body", "sig"}:
            return False, "object-fields"
        body = obj["body"]
        kind = body.get("kind")
        fields = {
            "waiver": {"kind", "coreDigest", "fromStateDigest",
                       "toTransCtr", "scope", "waiverID", "expEvent",
                       "nonceW"},
            "delta": {"kind", "fromCoreDigest", "fromStateDigest",
                      "fromPolEpoch", "toPolEpoch", "fromPolicyHash",
                      "toPolicyHash", "fromReqClass", "toReqClass",
                      "scope", "deltaID", "expEvent", "relaxBits"},
            "keyupd": {"kind", "fromCoreDigest", "fromStateDigest",
                       "fromKeyEpoch", "toKeyEpoch", "updateID",
                       "expEvent"},
        }.get(kind)
        if fields is None or set(body) != fields:
            return False, "object-fields"
        integer_fields = {
            "waiver": ("toTransCtr", "expEvent"),
            "delta": ("fromPolEpoch", "toPolEpoch", "fromReqClass",
                      "toReqClass", "expEvent", "relaxBits"),
            "keyupd": ("fromKeyEpoch", "toKeyEpoch", "expEvent"),
        }[kind]
        if any(not isinstance(body.get(key), int) or
               isinstance(body.get(key), bool) or body.get(key) < 0
               for key in integer_fields):
            return False, "object-type"
        if kind == "delta" and (
                body["fromReqClass"] > 3 or body["toReqClass"] > 3 or
                body["relaxBits"] > 0xFF):
            return False, "object-type"
        string_fields = {
            "waiver": ("coreDigest", "fromStateDigest", "waiverID",
                       "nonceW"),
            "delta": ("fromCoreDigest", "fromStateDigest",
                      "fromPolicyHash", "toPolicyHash", "deltaID"),
            "keyupd": ("fromCoreDigest", "fromStateDigest", "updateID"),
        }[kind]
        if any(not isinstance(body.get(key), str) or not body.get(key)
               for key in string_fields):
            return False, "object-type"
        if kind in ("waiver", "delta") and not self._valid_scope(
                body.get("scope")):
            return False, "object-type"
        return True, "accept"

    @staticmethod
    def _validate_ticket(ticket: Any, candidate: Dict[str, Any],
                         ep: Episode) -> Tuple[bool, str]:
        if not verify_object(ticket, "TA"):
            return False, "ticket-signature"
        if set(ticket) != {"signer", "body", "sig"}:
            return False, "ticket-fields"
        body = ticket["body"]
        if set(body) != {"kind", "sid", "stateDigest", "issuedEvent",
                        "expEvent", "ticketID"}:
            return False, "ticket-fields"
        if (body.get("kind") != "ticket" or
                body.get("sid") != candidate.get("sid") or
                body.get("stateDigest") != state_digest(candidate)):
            return False, "ticket-bind"
        for key in ("issuedEvent", "expEvent"):
            if (not isinstance(body.get(key), int) or
                    isinstance(body.get(key), bool)):
                return False, "ticket-type"
        if body["issuedEvent"] > ep.idx or body["expEvent"] < ep.idx:
            return False, "ticket-expiry"
        return True, "accept"

    def _select_base(self, sigma_i: Dict[str, Any],
                     sigma_j: Dict[str, Any],
                     bundle: Optional[Dict[str, Any]]) \
            -> Tuple[Optional[Dict[str, Any]],
                     Optional[Dict[str, Any]], str]:
        """Select the role-labelled authority base from signed core digests.

        Equal cores and object-free non-core reconciliation choose initiator
        ``i``.  The NoBind ablation deliberately ignores object bindings and
        also chooses ``i`` so its intended wrong-base failure remains visible.
        """
        objects = tuple(_bundle_objects(bundle)) if isinstance(bundle, dict) \
            else ()
        core_i, core_j = core_digest(sigma_i), core_digest(sigma_j)
        if not objects:
            if core_i != core_j:
                return None, None, "core-mismatch"
            return sigma_i, sigma_j, "i"
        if self.cfg.binding_surface == "none":
            return sigma_i, sigma_j, "i"
        bound = {
            obj["body"].get("coreDigest",
                            obj["body"].get("fromCoreDigest"))
            for obj in objects
        }
        if len(bound) != 1:
            return None, None, "cross-core"
        selected = next(iter(bound))
        if selected == core_i:
            return sigma_i, sigma_j, "i"
        if selected == core_j:
            return sigma_j, sigma_i, "j"
        return None, None, "bind"

    def _validate_bundle(self, ep: Episode, sigma_i: Dict[str, Any],
                         sigma_j: Dict[str, Any],
                         bundle: Optional[Dict[str, Any]]) \
            -> Tuple[bool, str]:
        ok_i, why_i = validate_sigma_schema(sigma_i)
        ok_j, why_j = validate_sigma_schema(sigma_j)
        if not ok_i or not ok_j:
            return False, why_i if not ok_i else why_j
        if not isinstance(bundle, dict):
            return False, "missing-bundle"
        if not set(bundle).issubset({"waiver", "delta", "keyupd"}):
            return False, "bundle-fields"
        objects = tuple(_bundle_objects(bundle))
        for obj in objects:
            ok, why = self._validate_authority_object(obj)
            if not ok:
                return False, why
            if obj["body"].get("expEvent", ep.idx) < ep.idx:
                return False, "expiry"

        base, other, select_reason = self._select_base(
            sigma_i, sigma_j, bundle)
        if base is None or other is None:
            return False, select_reason
        expected_core = core_digest(base)
        expected_state = state_digest(base)
        cores = []
        for obj in objects:
            body = obj["body"]
            bound_core = body.get("coreDigest", body.get("fromCoreDigest"))
            cores.append(bound_core)
            if (self.cfg.binding_surface == "full" and
                    body.get("fromStateDigest") != expected_state):
                return False, "bind"

        delta = bundle.get("delta") if bundle else None
        keyupd = bundle.get("keyupd") if bundle else None
        waiver = bundle.get("waiver") if bundle else None
        if delta:
            body = delta["body"]
            if body.get("fromPolEpoch") != base["polEpoch"]:
                return False, "polepoch"
            if (self.cfg.binding_surface != "none" and
                    (body.get("fromPolicyHash") != base["policyHash"] or
                     body.get("fromReqClass") != base["reqClass"])):
                return False, "delta-base"
            if body.get("toPolEpoch") != body.get("fromPolEpoch") + 1:
                return False, "pol-adjacency"
            if body.get("toReqClass") < body.get("fromReqClass"):
                return False, "req-downgrade"
            if body.get("toPolEpoch") < max(base["polEpoch"],
                                             other["polEpoch"]):
                return False, "pol-target"
        if keyupd:
            body = keyupd["body"]
            if body.get("fromKeyEpoch") != base["keyEpoch"]:
                return False, "keyepoch"
            if body.get("toKeyEpoch") != body.get("fromKeyEpoch") + 1:
                return False, "key-adjacency"
            if body.get("toKeyEpoch") < max(base["keyEpoch"],
                                             other["keyEpoch"]):
                return False, "key-target"
        if waiver:
            body = waiver["body"]
            expected_ctr = self._next_counter(sigma_i, sigma_j)
            if body.get("toTransCtr") != expected_ctr:
                return False, "counter"
            waiver_id = body.get("waiverID")
            i, j = self.endpoints
            if (waiver_id in i.consumed_waivers or
                    waiver_id in j.consumed_waivers):
                return False, "counter"

        if self.cfg.check_bundle:
            if len(set(cores)) > 1:
                return False, "cross-core"
            if waiver and delta and not compatible_scope(
                    _scope_body(waiver), _scope_body(delta)):
                return False, "scope"
            if delta and delta["body"].get("relaxBits", 0) and not waiver:
                return False, "waiver-required"

        # Definition 6: with no authority object the two cores must be equal.
        # With objects, the peer core must be either the selected base or the
        # exact authorized target obtained by applying all signed targets.
        if objects:
            target = copy.deepcopy(base)
            if delta:
                body = delta["body"]
                target["polEpoch"] = body["toPolEpoch"]
                target["policyHash"] = body["toPolicyHash"]
                target["reqClass"] = body["toReqClass"]
            if keyupd:
                target["keyEpoch"] = keyupd["body"]["toKeyEpoch"]
            if core_digest(other) not in {expected_core,
                                           core_digest(target)}:
                return False, "target-core"
        return True, "accept"

    def _candidate(self, sigma_i: Dict[str, Any], sigma_j: Dict[str, Any],
                   bundle: Optional[Dict[str, Any]], decision: str,
                   ep: Episode) -> DecisionResult:
        delta_sigma = _field_delta(sigma_i, sigma_j)
        base, _, select_reason = self._select_base(sigma_i, sigma_j, bundle)
        if base is None:
            return DecisionResult("FullReAttest", None, delta_sigma,
                                  select_reason)
        if decision == "Resume":
            candidate = copy.deepcopy(base)
            candidate["transCtr"] = self._next_counter(sigma_i, sigma_j)
            candidate["seqNo"] = max(sigma_i["seqNo"], sigma_j["seqNo"]) + 1
            candidate["chainDigest"] = H(
                "merge-chain", sigma_i["chainDigest"],
                sigma_j["chainDigest"], candidate["seqNo"],
                core_digest(candidate))
            return DecisionResult(decision, candidate, delta_sigma, "exact")
        candidate = copy.deepcopy(base)
        delta = bundle.get("delta") if bundle else None
        keyupd = bundle.get("keyupd") if bundle else None
        waiver = bundle.get("waiver") if bundle else None
        if delta:
            body = delta["body"]
            candidate["polEpoch"] = body["toPolEpoch"]
            candidate["policyHash"] = body["toPolicyHash"]
            candidate["reqClass"] = body["toReqClass"]
        else:
            candidate["polEpoch"] = base["polEpoch"]
            candidate["policyHash"] = base["policyHash"]
            candidate["reqClass"] = base["reqClass"]
        if keyupd:
            candidate["keyEpoch"] = keyupd["body"]["toKeyEpoch"]
        else:
            candidate["keyEpoch"] = base["keyEpoch"]
        att_source = (sigma_i if sigma_i["attEpoch"] >= sigma_j["attEpoch"]
                      else sigma_j)
        candidate["attEpoch"] = att_source["attEpoch"]
        candidate["EARdigest"] = att_source["EARdigest"]
        candidate["seqNo"] = max(sigma_i["seqNo"], sigma_j["seqNo"]) + 1
        waiver_id = None
        if waiver:
            waiver_id = waiver["body"].get("waiverID")
            if self.cfg.consume_ctr:
                candidate["transCtr"] = waiver["body"]["toTransCtr"]
            else:
                candidate["transCtr"] = max(sigma_i["transCtr"],
                                              sigma_j["transCtr"])
        else:
            candidate["transCtr"] = self._next_counter(sigma_i, sigma_j)
        candidate["chainDigest"] = H(
            "merge-chain", sigma_i["chainDigest"], sigma_j["chainDigest"],
            candidate["seqNo"], core_digest(candidate))
        return DecisionResult(decision, candidate, delta_sigma, "patchable",
                              waiver_id=waiver_id)

    def _classify(self, ep: Episode, sigma_i: Dict[str, Any],
                  sigma_j: Dict[str, Any],
                  bundle: Optional[Dict[str, Any]]) -> DecisionResult:
        delta_sigma = _field_delta(sigma_i, sigma_j)
        if not delta_sigma and not bundle:
            return self._candidate(sigma_i, sigma_j, {}, "Resume", ep)
        if (sigma_i["sid"] != sigma_j["sid"] or
                sigma_i["secEpoch"] != sigma_j["secEpoch"] or
                sigma_i["manifestDigest"] != sigma_j["manifestDigest"]):
            return DecisionResult("FullReAttest", None, delta_sigma,
                                  "hard-state-mismatch")
        pol_gap = abs(sigma_j["polEpoch"] - sigma_i["polEpoch"])
        key_gap = abs(sigma_j["keyEpoch"] - sigma_i["keyEpoch"])
        att_gap = abs(sigma_j["attEpoch"] - sigma_i["attEpoch"])
        if (pol_gap > self.cfg.lag_pol or key_gap > self.cfg.lag_key or
                att_gap > self.cfg.L_att):
            return DecisionResult("FullReAttest", None, delta_sigma, "budget")
        if (sigma_i["attEpoch"] == sigma_j["attEpoch"] and
                sigma_i["EARdigest"] != sigma_j["EARdigest"]):
            return DecisionResult("FullReAttest", None, delta_sigma,
                                  "ear-conflict")
        if (ep.rho_min < self.cfg.rho_patch or
                ep.rho_att < self.cfg.rho_att_min):
            return DecisionResult("FullReAttest", None, delta_sigma, "confidence")
        policy_changed = any(
            sigma_i[key] != sigma_j[key]
            for key in ("polEpoch", "policyHash", "reqClass")
        )
        if policy_changed and (not bundle or not bundle.get("delta")):
            return DecisionResult("FullReAttest", None, delta_sigma,
                                  "missing-delta")
        if sigma_i["keyEpoch"] != sigma_j["keyEpoch"] and (
                not bundle or not bundle.get("keyupd")):
            return DecisionResult("FullReAttest", None, delta_sigma,
                                  "missing-keyupd")
        if sigma_i["mode"] != sigma_j["mode"]:
            return DecisionResult("FullReAttest", None, delta_sigma,
                                  "mode-mismatch")
        ok, reason = self._validate_bundle(ep, sigma_i, sigma_j, bundle)
        if not ok:
            return DecisionResult("FullReAttest", None, delta_sigma, reason)
        return self._candidate(sigma_i, sigma_j, bundle, "DeltaPatch", ep)

    # ----- transcript and commits ---------------------------------------
    def _ctx_digest(self, m2: Dict[str, Any], m3_fields: Dict[str, Any],
                    decision: str, result: DecisionResult) -> str:
        hashes = _bundle_hashes(m3_fields.get("bundle"))
        bound_decision = decision if self.cfg.bind_decision else "_"
        return H("ctx", {
            "peerI": "node-i", "peerJ": "node-j",
            "nonceI": m3_fields["nonceI"], "nonceJ": m2["nonceJ"],
            "hSstI": H(m3_fields["sstI"]), "hSstJ": H(m2["sstJ"]),
            "hEarI": H("empty"), "hEarJ": H("empty"),
            "hProofI": H("empty"), "hProofJ": H("empty"),
            "hWt": hashes["waiver"], "hDelta": hashes["delta"],
            "hKeyUpd": hashes["keyupd"], "decision": bound_decision,
            "deltaSigma": result.delta_sigma,
            "stateDigestPrime": state_digest(result.candidate),
        })

    def _resume_key(self, sigma_i: Dict[str, Any], sigma_j: Dict[str, Any],
                    sid: str, ctx_digest: str) -> bytes:
        base_epoch = min(sigma_i["keyEpoch"], sigma_j["keyEpoch"])
        epoch_secret = _hkdf(self.secret, _canon(("epoch", base_epoch)))
        return _hkdf(epoch_secret,
                     _canon(("resume", sid, ctx_digest)))

    @staticmethod
    def _commit_tag(key: bytes, role: str, candidate: Dict[str, Any],
                    ticket: Dict[str, Any], ctx: str) -> str:
        return _mac(key, (f"commit_{role}", state_digest(candidate),
                          ticket_digest(ticket), ctx))

    def _validate_m3_message(
            self, receiver: Endpoint, m2: Any, m3: Any, ep: Episode
    ) -> Tuple[bool, str, Optional[DecisionResult], Optional[str],
               Optional[bytes], Optional[str]]:
        """Validate a parsed M3 using the production SST/bundle/commit path.

        The final return item is the responder's effective decision.  Keeping
        this as one callable boundary lets the virtual verifier mutate a real
        wire message without reimplementing protocol acceptance logic.
        """
        ok, why = validate_wire_message(m2, "ReConnState")
        if not ok:
            return False, why, None, None, None, None
        ok, why = validate_wire_message(m3, "ReConnCommit")
        if not ok:
            return False, why, None, None, None, None
        if m3["nonceI"] != ep.nonce_i:
            return False, "fresh", None, None, None, None
        ok, why = self._verify_sst(
            receiver, m3["sstI"], m3["sigmaI"], "node-i", "init",
            m2["nonceJ"], ep.nonce_i, ep)
        if not ok:
            return False, why, None, None, None, None
        result = self._classify(ep, m3["sigmaI"], receiver.sigma,
                                m3.get("bundle"))
        if result.decision == "FullReAttest" or result.candidate is None:
            return False, result.reason, result, None, None, None
        if self.cfg.bind_decision and m3["decision"] != result.decision:
            return False, "decision", result, None, None, None
        decision = (result.decision if self.cfg.bind_decision
                    else m3["decision"])
        ok, why = self._validate_ticket(m3["ticketPrime"], result.candidate, ep)
        if not ok:
            return False, why, result, None, None, decision
        if ticket_digest(m3["ticketPrime"]) in receiver.invalidated_tickets:
            return False, "ticket-replay", result, None, None, decision
        ctx = self._ctx_digest(m2, m3, decision, result)
        key = self._resume_key(m3["sigmaI"], receiver.sigma,
                               receiver.sigma["sid"], ctx)
        expected = self._commit_tag(key, "i", result.candidate,
                                    m3["ticketPrime"], ctx)
        if not (isinstance(m3["commitI"], str) and
                hmac.compare_digest(expected, m3["commitI"])):
            return False, "commit-mac", result, ctx, key, decision
        return True, "accept", result, ctx, key, decision

    def _validate_m4_message(self, m4: Any, expected_decision: str,
                             key: bytes, candidate: Dict[str, Any],
                             ticket: Dict[str, Any], ctx: str,
                             receiver: Optional[Endpoint] = None) \
            -> Tuple[bool, str]:
        if receiver is not None:
            record = receiver.candidate_record
            if receiver.phase != "candidate" or record is None:
                return False, "phase"
            if (state_digest(record["sigma"]) != state_digest(candidate) or
                    ticket_digest(record["ticket"]) != ticket_digest(ticket)):
                return False, "candidate-bind"
        ok, why = validate_wire_message(m4, "ReConnConfirm")
        if not ok:
            return False, why
        if self.cfg.bind_decision and m4["decision"] != expected_decision:
            return False, "decision"
        expected = self._commit_tag(key, "j", candidate, ticket, ctx)
        if not hmac.compare_digest(expected, m4["commitJ"]):
            return False, "commit-mac"
        return True, "accept"

    # ----- common result/fallback ---------------------------------------
    def _full_target(self) -> Dict[str, Any]:
        i, j = self.endpoints
        # The reachable verifier/authority selects the monotone stronger state.
        target = copy.deepcopy(j.sigma)
        if i.sigma["polEpoch"] > target["polEpoch"]:
            target["polEpoch"] = i.sigma["polEpoch"]
            target["policyHash"] = i.sigma["policyHash"]
        target["keyEpoch"] = max(i.sigma["keyEpoch"], j.sigma["keyEpoch"])
        if i.sigma["attEpoch"] > target["attEpoch"]:
            target["attEpoch"] = i.sigma["attEpoch"]
            target["EARdigest"] = i.sigma["EARdigest"]
        target["reqClass"] = max(i.sigma["reqClass"], j.sigma["reqClass"])
        target["transCtr"] = self._next_counter(i.sigma, j.sigma)
        target["seqNo"] = max(i.sigma["seqNo"], j.sigma["seqNo"]) + 1
        target["chainDigest"] = H("reattest-chain", i.sigma["chainDigest"],
                                    j.sigma["chainDigest"], target["seqNo"])
        return target

    def _run_full_reattest(self, ep: Episode, latency_so_far: float,
                           bytes_so_far: int, reason: str,
                           patch_intended: bool, attack_tested: bool,
                           audit_kind: Optional[str]) -> Dict[str, Any]:
        i, j = self.endpoints
        latency = latency_so_far + TLS_PQC[ep.cond] + QUOTE_MS + QUOTE_VERIFY_MS
        success = ep.verifier_reachable
        if success:
            target = self._full_target()
            ticket = issue_ticket(target, ep.idx,
                                  H("reattest-ticket", ep.idx,
                                    state_digest(target), self.cfg.name))
            for endpoint in (i, j):
                if endpoint.current_ticket is not None:
                    digest = ticket_digest(endpoint.current_ticket)
                    endpoint.valid_tickets.discard(digest)
                    endpoint.invalidated_tickets.add(digest)
                    self.captured_ticket = copy.deepcopy(endpoint.current_ticket)
                endpoint.sigma = copy.deepcopy(target)
                endpoint.current_ticket = copy.deepcopy(ticket)
                endpoint.valid_tickets.add(ticket_digest(ticket))
                endpoint.phase = "open"
                endpoint.candidate_record = None
                endpoint.last_decision = "FullReAttest"
            self._update_peer_floors()
        else:
            for endpoint in (i, j):
                endpoint.phase = "closed"
                endpoint.candidate_record = None
        audit = []
        if audit_kind:
            audit.append((audit_kind, False, reason))
        if patch_intended:
            guard_admitted = reason.startswith("commit-")
            audit.append(("honest", guard_admitted,
                          "accepted" if guard_admitted else reason))
        else:
            guard_admitted = False
        return self._finish(
            ep, "fullreattest", latency, bytes_so_far + B_FULL_REATTEST,
            success=success, accepted=False, attack_tested=attack_tested,
            hquar=False, hquar_tested=(ep.attack == "quar" and attack_tested),
            divergent=False, patch_intended=patch_intended,
            patch_accepted=guard_admitted, audit=audit, commit_executed=False,
            decision_i="FullReAttest", decision_j="FullReAttest")

    def _finish(self, ep: Episode, path: str, latency_ms: float,
                byte_count: int, *, success: bool, accepted: bool,
                attack_tested: bool, hquar: bool, hquar_tested: bool,
                divergent: bool, patch_intended: bool,
                patch_accepted: bool, audit: list,
                commit_executed: bool, decision_i: Optional[str],
                decision_j: Optional[str]) -> Dict[str, Any]:
        i, j = self.endpoints
        operable_s = max(0.0, ep.window_s - latency_ms / 1000.0) if success else 0.0
        return {
            "idx": ep.idx, "path": path, "latency": float(latency_ms),
            "bytes": int(byte_count), "success": bool(success),
            "accepted": bool(accepted), "attack": ep.attack,
            "attack_tested": bool(attack_tested), "hquar": bool(hquar),
            "hquar_tested": bool(hquar_tested),
            "divergent": bool(divergent), "cond": ep.cond,
            "patch_intended": bool(patch_intended),
            "patch_accepted": bool(patch_accepted),
            "mission_s": float(ep.window_s), "operable_s": float(operable_s),
            "audit": audit, "commit_executed": bool(commit_executed),
            "decision_i": decision_i, "decision_j": decision_j,
            "state_i": state_digest(i.sigma), "state_j": state_digest(j.sigma),
            "phase_i": i.phase, "phase_j": j.phase,
        }

    # ----- full four-message wire protocol ------------------------------
    def _wire_protocol(self, ep: Episode, legitimate_bundle: Optional[Dict[str, Any]],
                       patch_intended: bool) -> Dict[str, Any]:
        i, j = self.endpoints
        latency = 0.0
        byte_count = 0

        m1 = {"kind": "ReConnHello", "sid": i.sigma["sid"],
              "nonceI": ep.nonce_i}
        ok, dt = self._transmit(ep, "M1")
        latency += dt
        byte_count += wire_bytes(m1)
        if not ok:
            return self._finish(ep, "abort", latency, byte_count,
                                success=False, accepted=False,
                                attack_tested=False, hquar=False,
                                hquar_tested=False, divergent=False,
                                patch_intended=patch_intended,
                                patch_accepted=False, audit=[],
                                commit_executed=False,
                                decision_i=None, decision_j=None)

        sigma_j_wire = copy.deepcopy(j.sigma)
        sst_j = build_sst(sigma_j_wire, ep.nonce_i, ep.nonce_j,
                          "resp", j.node_id, ep.wall_time)
        m2 = {"kind": "ReConnState", "nonceJ": ep.nonce_j,
              "sigmaJ": sigma_j_wire, "sstJ": sst_j}
        m2_attack_injected = False
        if ep.attack == "stale" and self.captured_m2 is not None:
            m2 = copy.deepcopy(self.captured_m2)
            m2_attack_injected = True
        elif ep.attack == "reflect" and self.captured_sst_i is not None:
            m2["sstJ"] = copy.deepcopy(self.captured_sst_i)
            m2["sigmaJ"] = copy.deepcopy(i.sigma)
            m2_attack_injected = True
        elif ep.attack == "roll" and self.rollback_snapshot is not None:
            rolled = copy.deepcopy(self.rollback_snapshot)
            m2["sigmaJ"] = rolled
            m2["sstJ"] = build_sst(rolled, ep.nonce_i, ep.nonce_j,
                                     "resp", j.node_id, ep.wall_time)
            m2_attack_injected = True
        elif ep.attack == "quar":
            m2["sstJ"] = copy.deepcopy(sst_j)
            m2["sstJ"]["sig"] = "00" * 32
            m2_attack_injected = True

        m2 = wire_roundtrip(m2)

        ok, dt = self._transmit(ep, "M2")
        latency += dt
        byte_count += wire_bytes(m2)
        malicious_m2 = m2_attack_injected
        attack_tested = bool(malicious_m2 and ok)
        if not ok:
            return self._finish(ep, "abort", latency, byte_count,
                                success=False, accepted=False,
                                attack_tested=False, hquar=False,
                                hquar_tested=False, divergent=False,
                                patch_intended=patch_intended,
                                patch_accepted=False, audit=[],
                                commit_executed=False,
                                decision_i=None, decision_j=None)

        valid, why = self._validate_m2_message(
            i, m2, j.node_id, ep.nonce_i, ep)
        latency += TOKEN_VERIFY_MS
        if not valid:
            # Unverifiable material is discarded; it never creates quarantine.
            audit_kind = "stale" if ep.attack in ("stale", "reflect") else \
                ("roll" if ep.attack == "roll" else
                 ("quar" if ep.attack == "quar" else None))
            if ep.attack == "quar":
                return self._finish(
                    ep, "abort", latency, byte_count, success=False,
                    accepted=False, attack_tested=attack_tested, hquar=False,
                    hquar_tested=True, divergent=False,
                    patch_intended=patch_intended, patch_accepted=False,
                    audit=[("quar", False, why)], commit_executed=False,
                    decision_i=None, decision_j=None)
            return self._run_full_reattest(
                ep, latency, byte_count, why, patch_intended,
                attack_tested, audit_kind)

        # Capture only an honestly generated M2, never the attacker's transform.
        if ep.attack not in ("stale", "reflect", "roll", "quar"):
            self.captured_m2 = copy.deepcopy(m2)

        bundle = copy.deepcopy(legitimate_bundle)
        malicious_bundle = False
        if ep.attack == "wrongbase":
            bundle, malicious_bundle = self._wrongbase_bundle(ep), True
        elif ep.attack == "waiv":
            bundle = ({"waiver": copy.deepcopy(self.captured_waiver)}
                      if self.captured_waiver is not None else None)
            malicious_bundle = True
        elif ep.attack == "splice":
            bundle, malicious_bundle = self._splice_bundle(ep), True

        result_i = self._classify(ep, i.sigma, m2["sigmaJ"], bundle)
        latency += len(tuple(_bundle_objects(bundle))) * TOKEN_VERIFY_MS
        if result_i.decision == "FullReAttest":
            audit_kind = ({"wrongbase": "wrongbase", "waiv": "waiv",
                           "splice": "splice"}.get(ep.attack))
            return self._run_full_reattest(
                ep, latency, byte_count, result_i.reason, patch_intended,
                attack_tested or malicious_bundle, audit_kind)

        assert result_i.candidate is not None
        sst_i = build_sst(i.sigma, m2["nonceJ"], ep.nonce_i,
                          "init", i.node_id, ep.wall_time)
        ticket_new = issue_ticket(
            result_i.candidate, ep.idx,
            H("ticket", self.cfg.name, ep.idx, state_digest(result_i.candidate)))
        m3_fields = {"nonceI": ep.nonce_i, "sigmaI": copy.deepcopy(i.sigma),
                     "sstI": sst_i, "bundle": bundle,
                     "decision": result_i.decision}
        ctx_i = self._ctx_digest(m2, m3_fields, result_i.decision, result_i)
        key_i = self._resume_key(i.sigma, m2["sigmaJ"], i.sigma["sid"], ctx_i)
        commit_i = self._commit_tag(key_i, "i", result_i.candidate,
                                    ticket_new, ctx_i)
        m3 = {"kind": "ReConnCommit", **m3_fields, "commitI": commit_i,
              "ticketPrime": ticket_new}
        if ep.attack == "dsplice":
            m3 = copy.deepcopy(m3)
            m3["decision"] = ("Resume" if result_i.decision == "DeltaPatch"
                              else "DeltaPatch")
        m3 = wire_roundtrip(m3)

        if not self.cfg.check_commit:
            # Unsafe baseline: initiator adopts before knowing whether M3 arrived.
            self._unsafe_adopt(i, result_i.candidate, result_i.decision, ep.idx)
            ok, dt = self._transmit(ep, "M3",
                                    force_drop=(ep.force_drop_stage == "M3"))
            latency += dt
            byte_count += wire_bytes(m3)
            attack_tested = attack_tested or bool(malicious_bundle and ok)
            if ok:
                valid_i, why_i = self._verify_sst(
                    j, m3["sstI"], m3["sigmaI"], i.node_id, "init",
                    m2["nonceJ"], ep.nonce_i, ep)
                latency += TOKEN_VERIFY_MS
                latency += len(tuple(_bundle_objects(m3.get("bundle")))) * \
                    TOKEN_VERIFY_MS
                result_j = self._classify(ep, m3["sigmaI"], j.sigma,
                                          m3.get("bundle")) if valid_i else \
                    DecisionResult("FullReAttest", None, {}, why_i)
                if result_j.candidate is not None:
                    self._unsafe_adopt(j, result_j.candidate,
                                       m3["decision"], ep.idx)
            divergent = (state_digest(i.sigma) != state_digest(j.sigma) or
                           i.last_decision != j.last_decision)
            attack_accepted = bool(malicious_bundle and ok and not divergent)
            if bundle and bundle.get("waiver"):
                self.captured_waiver = copy.deepcopy(bundle["waiver"])
            self.captured_sst_i = copy.deepcopy(sst_i)
            if not divergent:
                self._update_peer_floors()
            audit_kind = {"wrongbase": "wrongbase", "waiv": "waiv",
                          "splice": "splice"}.get(ep.attack)
            audit = []
            if audit_kind:
                audit.append((audit_kind, attack_accepted,
                              "accepted" if attack_accepted else "delivery"))
            if patch_intended:
                audit.append(("honest", result_i.decision == "DeltaPatch",
                              "accepted"))
            return self._finish(
                ep, result_i.decision.lower(), latency, byte_count,
                success=True, accepted=attack_accepted,
                attack_tested=attack_tested, hquar=False,
                hquar_tested=False, divergent=divergent,
                patch_intended=patch_intended,
                patch_accepted=(patch_intended and
                                result_i.decision == "DeltaPatch"),
                audit=audit, commit_executed=False,
                decision_i=result_i.decision,
                decision_j=j.last_decision)

        # Real two-sided commit: persist-before-send at both endpoints.
        self.commit_count += 1
        self._persist_candidate(i, result_i.candidate, ticket_new,
                                result_i.decision, "candidate")
        ok, dt = self._transmit(ep, "M3",
                                force_drop=(ep.force_drop_stage == "M3"))
        latency += dt
        byte_count += wire_bytes(m3)
        attack_tested = attack_tested or bool(malicious_bundle and ok)
        if not ok:
            self._abort_candidate(i)
            return self._run_full_reattest(
                ep, latency, byte_count, "commit-m3-loss", patch_intended,
                attack_tested, None)

        latency += TOKEN_VERIFY_MS
        latency += len(tuple(_bundle_objects(m3.get("bundle")))) * TOKEN_VERIFY_MS
        (valid_i, why_i, result_j, ctx_j, key_j,
         decision_j) = self._validate_m3_message(j, m2, m3, ep)
        latency += COMMIT_MAC_MS
        if not valid_i or result_j is None or result_j.candidate is None:
            self._abort_candidate(i)
            audit_kind = ({"wrongbase": "wrongbase", "waiv": "waiv",
                           "splice": "splice"}.get(ep.attack))
            return self._run_full_reattest(
                ep, latency, byte_count, why_i, patch_intended,
                attack_tested, audit_kind)

        assert ctx_j is not None and key_j is not None and decision_j is not None

        self._persist_candidate(j, result_j.candidate, m3["ticketPrime"],
                                decision_j, "half-open")
        commit_j = self._commit_tag(key_j, "j", result_j.candidate,
                                    m3["ticketPrime"], ctx_j)
        m4 = {"kind": "ReConnConfirm", "decision": decision_j,
              "commitJ": commit_j}
        m4 = wire_roundtrip(m4)
        ok, dt = self._transmit(ep, "M4",
                                force_drop=(ep.force_drop_stage == "M4"))
        latency += dt
        byte_count += wire_bytes(m4)
        if not ok:
            self._abort_candidate(i)
            self._abort_candidate(j)
            return self._run_full_reattest(
                ep, latency, byte_count, "commit-m4-loss", patch_intended,
                attack_tested, None)
        latency += COMMIT_MAC_MS
        valid_m4, why_m4 = self._validate_m4_message(
            m4, result_i.decision, key_i, result_i.candidate,
            ticket_new, ctx_i, receiver=i)
        if not valid_m4:
            self._abort_candidate(i)
            self._abort_candidate(j)
            return self._run_full_reattest(
                ep, latency, byte_count, why_m4, patch_intended,
                attack_tested, None)

        self._commit_candidate(i)
        self._commit_candidate(j)
        if result_i.waiver_id and self.cfg.consume_ctr:
            i.consumed_waivers.add(result_i.waiver_id)
            j.consumed_waivers.add(result_i.waiver_id)
        if bundle and bundle.get("waiver"):
            self.captured_waiver = copy.deepcopy(bundle["waiver"])
        self.captured_sst_i = copy.deepcopy(sst_i)
        self._update_peer_floors()
        divergent = (state_digest(i.sigma) != state_digest(j.sigma) or
                       result_i.decision != decision_j)
        accepted_m2_attack = (m2_attack_injected and
                              ep.attack in ("stale", "reflect", "roll"))
        attack_accepted = bool((malicious_bundle or accepted_m2_attack)
                               and not divergent)
        audit_kind = {"stale": "stale", "roll": "roll",
                      "wrongbase": "wrongbase", "waiv": "waiv",
                      "splice": "splice"}.get(ep.attack)
        audit = []
        if audit_kind:
            audit.append((audit_kind, attack_accepted,
                          "accepted" if attack_accepted else "rejected"))
        if patch_intended:
            audit.append(("honest", result_i.decision == "DeltaPatch" and
                          not divergent, "accepted"))
        return self._finish(
            ep, result_i.decision.lower(), latency, byte_count,
            success=True, accepted=attack_accepted,
            attack_tested=attack_tested,
            hquar=False, hquar_tested=False, divergent=divergent,
            patch_intended=patch_intended,
            patch_accepted=(patch_intended and result_i.decision == "DeltaPatch"
                            and not divergent), audit=audit,
            commit_executed=True, decision_i=result_i.decision,
            decision_j=decision_j)

    # ----- ticket replay and deployed comparators -----------------------
    def _ticket_replay(self, ep: Episode, patch_intended: bool,
                       strict_invalidation: bool) -> Dict[str, Any]:
        i, j = self.endpoints
        ticket = copy.deepcopy(self.captured_ticket or i.current_ticket)
        m1 = {"kind": "TicketResume", "ticket": ticket,
              "nonce": ep.nonce_i}
        m1 = wire_roundtrip(m1)
        ok, latency = self._transmit(ep, "T1")
        byte_count = wire_bytes(m1)
        if not ok or ticket is None:
            return self._finish(ep, "abort", latency, byte_count,
                                success=False, accepted=False,
                                attack_tested=False, hquar=False,
                                hquar_tested=False, divergent=False,
                                patch_intended=patch_intended,
                                patch_accepted=False, audit=[],
                                commit_executed=False,
                                decision_i=None, decision_j=None)
        tested = True
        digest = ticket_digest(ticket)
        valid = (verify_object(ticket, "TA") and
                 ticket["body"].get("sid") == j.sigma["sid"] and
                 ticket["body"].get("expEvent", -1) >= ep.idx)
        if strict_invalidation:
            valid = valid and digest not in j.invalidated_tickets
        if not valid:
            return self._run_full_reattest(
                ep, latency, byte_count, "ticket-invalidated", patch_intended,
                tested, "ticket")
        m2 = {"kind": "TicketAccept", "ticketDigest": digest}
        m2 = wire_roundtrip(m2)
        ok, dt = self._transmit(ep, "T2")
        latency += dt
        byte_count += wire_bytes(m2)
        if not ok:
            return self._finish(ep, "abort", latency, byte_count,
                                success=False, accepted=False,
                                attack_tested=tested, hquar=False,
                                hquar_tested=False, divergent=False,
                                patch_intended=patch_intended,
                                patch_accepted=False,
                                audit=[("ticket", False, "delivery")],
                                commit_executed=False,
                                decision_i=None, decision_j=None)
        i.phase = j.phase = "open"
        i.last_decision = j.last_decision = "Resume"
        divergent = state_digest(i.sigma) != state_digest(j.sigma)
        goal_accepted = ep.attack in ("ticket", "stale", "roll")
        return self._finish(
            ep, "resume", latency, byte_count, success=True,
            accepted=goal_accepted, attack_tested=tested, hquar=False,
            hquar_tested=False, divergent=divergent,
            patch_intended=patch_intended, patch_accepted=False,
            audit=[(ep.attack or "ticket", goal_accepted,
                    "accepted" if goal_accepted else "not-applicable")],
            commit_executed=False,
            decision_i="Resume", decision_j="Resume")

    def _reauth(self, ep: Episode, patch_intended: bool) -> Dict[str, Any]:
        i, j = self.endpoints
        ok, latency = self._transmit(ep, "RA1")
        byte_count = wire_bytes({"kind": "ReAuthHello", "nonce": ep.nonce_i})
        if not ok:
            return self._finish(ep, "abort", latency, byte_count,
                                success=False, accepted=False,
                                attack_tested=False, hquar=False,
                                hquar_tested=False, divergent=False,
                                patch_intended=patch_intended,
                                patch_accepted=False, audit=[],
                                commit_executed=False,
                                decision_i=None, decision_j=None)
        sigma_wire = copy.deepcopy(j.sigma)
        token = sign_object(j.node_id, {"kind": "identity", "sid": j.sigma["sid"]})
        if ep.attack == "stale":
            token = sign_object(j.node_id, {"kind": "identity", "sid": j.sigma["sid"]})
        elif ep.attack == "roll" and self.rollback_snapshot is not None:
            sigma_wire = copy.deepcopy(self.rollback_snapshot)
            token = sign_object(j.node_id, {"kind": "identity", "sid": sigma_wire["sid"]})
        elif ep.attack == "quar":
            token["sig"] = "00" * 32
        response = {"kind": "ReAuthResponse", "sigma": sigma_wire,
                    "identity": token}
        response = wire_roundtrip(response)
        ok, dt = self._transmit(ep, "RA2")
        latency += dt
        byte_count += wire_bytes(response)
        tested = bool(ep.attack is not None and ok)
        if not ok or not verify_object(token, j.node_id):
            return self._finish(
                ep, "abort", latency, byte_count, success=False,
                accepted=False, attack_tested=tested, hquar=False,
                hquar_tested=(ep.attack == "quar" and tested),
                divergent=False, patch_intended=patch_intended,
                patch_accepted=False, audit=[], commit_executed=False,
                decision_i=None, decision_j=None)
        i.phase = j.phase = "open"
        i.last_decision = j.last_decision = "Resume"
        divergent = state_digest(i.sigma) != state_digest(j.sigma)
        accepted = ep.attack in ("stale", "roll")
        return self._finish(
            ep, "resume", latency, byte_count, success=True,
            accepted=accepted, attack_tested=tested, hquar=False,
            hquar_tested=False, divergent=divergent,
            patch_intended=patch_intended, patch_accepted=False,
            audit=[(ep.attack, accepted, "identity-only")] if ep.attack else [],
            commit_executed=False, decision_i="Resume", decision_j="Resume")

    def _ticket_baseline(self, ep: Episode, patch_intended: bool) -> Dict[str, Any]:
        # TLS-like comparator: signed ticket + expiry, but no higher-layer state
        # reconciliation and no Q-ARTZ invalidation record.
        if ep.attack == "quar":
            ok, latency = self._transmit(ep, "T1")
            return self._finish(
                ep, "abort", latency, 64, success=False, accepted=False,
                attack_tested=ok, hquar=False, hquar_tested=ok,
                divergent=False, patch_intended=patch_intended,
                patch_accepted=False,
                audit=[("quar", False, "signature")] if ok else [],
                commit_executed=False, decision_i=None, decision_j=None)
        if ep.attack in ("stale", "roll", "ticket"):
            return self._ticket_replay(ep, patch_intended,
                                       strict_invalidation=False)
        i, j = self.endpoints
        ticket = i.current_ticket or self.captured_ticket
        self.captured_ticket = copy.deepcopy(ticket)
        return self._ticket_replay(ep, patch_intended,
                                   strict_invalidation=False)

    # ----- public episode ------------------------------------------------
    def run_episode(self, ep: Episode, rng: Optional[np.random.Generator] = None) \
            -> Dict[str, Any]:
        started = time.perf_counter()
        issue_i, _ = self._apply_partition(ep)
        legitimate_bundle = self._legitimate_bundle(ep, issue_i)

        # Patch opportunity is defined by the full core-bound mechanism before
        # adversarial substitution and independent of network delivery.
        reference_cfg = copy.deepcopy(self.cfg)
        reference_cfg.binding_surface = "core"
        reference_cfg.check_bundle = True
        reference_cfg.consume_ctr = True
        old_cfg = self.cfg
        self.cfg = reference_cfg
        reference = self._classify(ep, self.i.sigma, self.j.sigma,
                                   legitimate_bundle)
        self.cfg = old_cfg
        patch_intended = (ep.attack is None and
                          reference.decision == "DeltaPatch")

        if self.cfg.mode == "fullonly":
            out = self._run_full_reattest(
                ep, 0.0, 0, "full-only", patch_intended,
                attack_tested=bool(ep.attack), audit_kind=None)
        elif self.cfg.mode == "reauth":
            if ep.attack == "ticket":
                out = self._ticket_replay(ep, patch_intended,
                                          strict_invalidation=False)
            else:
                out = self._reauth(ep, patch_intended)
        elif self.cfg.mode == "ticket":
            out = self._ticket_baseline(ep, patch_intended)
        elif self.cfg.mode == "oracle":
            if ep.attack is not None:
                out = self._run_full_reattest(
                    ep, 0.0, 0, "oracle-reject", patch_intended,
                    attack_tested=True, audit_kind=None)
            else:
                saved = self.cfg
                self.cfg = copy.deepcopy(CFGS["R_QARTZ"])
                out = self._wire_protocol(ep, legitimate_bundle, patch_intended)
                self.cfg = saved
        elif ep.attack == "ticket":
            out = self._ticket_replay(ep, patch_intended,
                                      strict_invalidation=True)
        else:
            out = self._wire_protocol(ep, legitimate_bundle, patch_intended)

        elapsed_us = (time.perf_counter() - started) * 1e6
        self.step_time_us.append(elapsed_us)
        if out.get("commit_executed"):
            self.commit_step_time_us.append(elapsed_us)
        return out


# ---------------------------------------------------------------------------
# Runner and honest metric denominators

ATTACK_KEYS = {
    "stale": "acc_stale", "roll": "acc_roll",
    "wrongbase": "acc_wrong", "waiv": "acc_waiv",
    "splice": "acc_splice", "ticket": "acc_ticket",
}


def run_policy(policy: ResyncPolicy, trace: Trace) -> list[Dict[str, Any]]:
    policy.start(trace)
    return [policy.run_episode(ep, policy._rng) for ep in trace.episodes]


def metrics(trace: Trace, outcomes: list[Dict[str, Any]]) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    for attack, key in ATTACK_KEYS.items():
        tested = [out for out in outcomes
                  if out["attack"] == attack and out["attack_tested"]]
        numerator = sum(int(out["accepted"]) for out in tested)
        denominator = len(tested)
        result[f"{key}_num"] = numerator
        result[f"{key}_den"] = denominator
        result[key] = numerator / denominator if denominator else np.nan

    reflect = [out for out in outcomes
               if out["attack"] == "reflect" and out["attack_tested"]]
    result["acc_reflect_num"] = sum(int(out["accepted"]) for out in reflect)
    result["acc_reflect_den"] = len(reflect)
    result["acc_reflect"] = (result["acc_reflect_num"] / len(reflect)
                             if reflect else np.nan)

    quarantine_tests = [out for out in outcomes
                        if out["attack"] == "quar" and out["hquar_tested"]]
    result["hquar_num"] = sum(int(out["hquar"]) for out in quarantine_tests)
    result["hquar_den"] = len(quarantine_tests)
    result["hquar"] = (result["hquar_num"] / result["hquar_den"]
                       if result["hquar_den"] else np.nan)

    result["divergent_num"] = sum(int(out["divergent"]) for out in outcomes)
    result["divergent_den"] = len(outcomes)
    result["divergent"] = result["divergent_num"] / result["divergent_den"]

    result["availability_num"] = sum(out["operable_s"] for out in outcomes)
    result["availability_den"] = sum(out["mission_s"] for out in outcomes)
    result["availability"] = (result["availability_num"] /
                              result["availability_den"])
    result["success_num"] = sum(int(out["success"]) for out in outcomes)
    result["success_den"] = len(outcomes)
    result["success_rate"] = result["success_num"] / result["success_den"]

    patch_tests = [out for out in outcomes if out["patch_intended"]]
    result["honest_patch_acc_num"] = sum(
        int(out["patch_accepted"]) for out in patch_tests)
    result["honest_patch_acc_den"] = len(patch_tests)
    result["honest_patch_acc"] = (
        result["honest_patch_acc_num"] / result["honest_patch_acc_den"]
        if result["honest_patch_acc_den"] else np.nan)

    for path in PATHS:
        result[f"ratio_{path}_num"] = sum(out["path"] == path
                                           for out in outcomes)
        result[f"ratio_{path}_den"] = len(outcomes)
        result[f"ratio_{path}"] = (result[f"ratio_{path}_num"] /
                                   result[f"ratio_{path}_den"])

    for cond in CONDS:
        for path in PATHS:
            values = [out["latency"] for out in outcomes
                      if out["cond"] == cond and out["path"] == path
                      and out["success"] and not np.isnan(out["latency"])]
            result[f"lat_{cond}_{path}"] = (float(np.mean(values))
                                                    if values else np.nan)
        cond_values = [out["latency"] / 1000.0 for out in outcomes
                       if out["cond"] == cond and out["success"]]
        result[f"interrupt_{cond}"] = (float(np.mean(cond_values))
                                               if cond_values else np.nan)
    all_latency = [out["latency"] / 1000.0 for out in outcomes
                   if out["success"]]
    result["interruption_s"] = (float(np.mean(all_latency))
                                if all_latency else np.nan)
    for path in PATHS:
        values = [out["bytes"] for out in outcomes if out["path"] == path]
        result[f"bytes_{path}"] = float(np.mean(values)) if values else np.nan

    audit: Dict[str, Dict[str, Any]] = {}
    for out in outcomes:
        for kind, accepted, why in out["audit"]:
            item = audit.setdefault(kind, {"n": 0, "acc": 0, "reasons": {}})
            item["n"] += 1
            item["acc"] += int(accepted)
            if not accepted:
                item["reasons"][why] = item["reasons"].get(why, 0) + 1
    result["guard_audit"] = audit
    return result


def _factory(cfg: PolCfg):
    def create(rng: np.random.Generator, secret: Optional[bytes] = None):
        policy = ResyncPolicy(cfg, secret)
        policy._rng = rng
        return policy
    return create


CFGS = {
    "B1_ReAuth": PolCfg("B1_ReAuth", mode="reauth"),
    "B2_FullOnly": PolCfg("B2_FullOnly", mode="fullonly"),
    "B3_NoBind": PolCfg("B3_NoBind", binding_surface="none"),
    "B4_NoCommit": PolCfg("B4_NoCommit", check_commit=False),
    "B5_NoBundle": PolCfg("B5_NoBundle", check_bundle=False),
    "B6_Ticket": PolCfg("B6_Ticket", mode="ticket"),
    "R_QARTZ": PolCfg("R_QARTZ"),
    "R_Oracle": PolCfg("R_Oracle", mode="oracle"),
    "A_noFresh": PolCfg("A_noFresh", freshness_mode="none"),
    "A_fullDigestBind": PolCfg("A_fullDigestBind", binding_surface="full"),
    "A_noCtrConsume": PolCfg("A_noCtrConsume", consume_ctr=False),
    "A_noDecisionBind": PolCfg("A_noDecisionBind", bind_decision=False),
    "A_timeTTL": PolCfg("A_timeTTL", freshness_mode="time"),
}

POLICIES = {name: _factory(cfg) for name, cfg in CFGS.items()}
