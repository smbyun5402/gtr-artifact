# Q-ARTZ-Reauth (GT-R protocol) simulation core.
# Implements the four-flight gap-tolerant reconnect handshake GT-R (M1-M4), the
# independent sealed symmetric ratchet, the DR-KEM hybrid layer (oracle-bit
# validity + RoT-sealed epoch-indexed forward secrecy + modeled byte/time costs),
# the deterministic decision rule (R1 resume / R2 FullReAttest / Quarantine), the
# GT-RAKE network-control model (StateReveal + Rollback + ExtractRoT), baselines
# and ablations, over reconnect scenarios RA1..RA9.  See paper/QARTZ_Reauth_design.md.
#
# Fidelity scope:
#   * KEM / signature / DR-KEM decapsulation validity = ORACLE BIT (the IND-CCA /
#     EUF-CMA / selective-epoch-IND-CCA reductions cover forgery/decap);
#   * digests / MACs / KDF / chain fast-forward use hashlib, hmac, and
#     RFC-5869 HKDF-SHA256) over canonical, length-prefixed encodings;
#   * epochs / RoT monotonic counters / DR node windows use explicit integer and
#     state-transition computations;
#   * the adversary derives shared secrets only from material it
#     holds (captured transcripts, StateReveal'd chain state, Corrupt'd or
#     ExtractRoT'd long-term keys) -- so a session key is attacker-known iff the
#     key-schedule inputs are ALL reconstructible from held material;
#   * DR-KEM ct size / encaps / decaps / fast-forward costs = MODELED constants
#     (design.md sec.1.7, DR-cons parameters) emitted as *modeled*-labeled macros;
#   * guards return (ok, rejecting-conjunct) so per-attack audit macros aggregate.
#
# Each trace is a mission timeline of reconnect EPISODES.  During a gap both peers
# tick their key epochs independently (structural drift); at the reconnect event
# the policy executes GT-R against the scenario's adversary.  All policies consume
# the same pre-generated trace per seed so comparisons are paired.

import time
import hashlib
import hmac
import json
import numpy as np
from dataclasses import dataclass, field

# ---------------------------------------------------------------- crypto (real)
def _canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"),
                      default=str).encode()


def H(*parts):
    """SHA-256 over the length-prefixed concatenation of canonical parts."""
    h = hashlib.sha256()
    for p in parts:
        b = _canon(p)
        h.update(len(b).to_bytes(4, "big"))
        h.update(b)
    return h.hexdigest()


def _hkdf(secret, info, salt=b"qartz-reauth", length=32):
    """RFC-5869 HKDF-SHA256 (stdlib), one-shot."""
    if isinstance(secret, str):
        secret = secret.encode()
    prk = hmac.new(salt, secret, hashlib.sha256).digest()
    okm, t, i = b"", b"", 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        okm += t
        i += 1
    return okm[:length]


def _mac(key, msg):
    if isinstance(key, str):
        key = key.encode()
    return hmac.new(key, _canon(msg), hashlib.sha256).hexdigest()


def fast_forward(ck0, e_from, e_to):
    """Symmetric hash ratchet: ck[e+1] = KDF(ck[e], "gt-r-tick", e+1).
    Deterministic; the slower side iterates from e_from to e_to.  Returns
    (ck_at_e_to, n_iterations)."""
    ck = ck0
    n = 0
    for e in range(e_from + 1, e_to + 1):
        ck = _hkdf(ck, _canon(("gt-r-tick", e)))
        n += 1
    return ck, n


# ---------------------------------------------------------------- constants
CLEAN, DISR, HEAVY = "clean", "disrupted", "heavy"
CONDS = (CLEAN, DISR, HEAVY)

# Fixed latency anchors used only by the modeled link process.
TLS_PQC = {CLEAN: 72.8, DISR: 789.5, HEAVY: 3871.7}   # \Tls<Cond>Pqc
QUOTE_MS = 10.3
QUOTE_VERIFY_MS = 4.2
KEM_ENCAPS_MS = 0.09        # fixed ML-KEM-768 encapsulation-cost parameter
KEM_DECAPS_MS = 0.11        # ML-KEM-768 decaps
SIG_VERIFY_MS = 2.2         # ML-DSA-65 verify incl. process
MAC_MS = 0.02               # HKDF derive + HMAC compute/verify (sub-ms)

# The DR layer uses the modeled epoch-indexed interface. A separate OpenSSL
# harness instantiates that interface with independent per-epoch ML-KEM keys.
# The compact lattice study is exploratory and does not enter these metrics.
DR_CT_BYTES = 1088             # DR reconnect ct = one ML-KEM-768 ciphertext
DR_PK_BYTES = 1184             # one ML-KEM-768 public key (per epoch, at enrollment)
DR_ENCAPS_MS = 0.25         # modeled
DR_DECAPS_MS = 0.30         # modeled
DR_FF_PER_EPOCH_US = 45.0   # modeled DR secret-node fast-forward per epoch (O(log) tree step)

# per-message one-way delay (ms), jitter, loss, retransmit timeout
LINK = {
    CLEAN: dict(delay=10.0,  jitter=0.0,  loss=0.00, rto=30.0),
    DISR:  dict(delay=100.0, jitter=20.0, loss=0.05, rto=300.0),
    HEAVY: dict(delay=200.0, jitter=50.0, loss=0.15, rto=600.0),
}
N_RETRY = 4

# byte model: standardized primitive sizes plus fixed payload estimates
B_SIG = 3309                # ML-DSA-65 signature
B_KEMCT = 1088              # ML-KEM-768 ciphertext
B_KEMPK = 1184              # ML-KEM-768 public key
B_PAY = 250                 # generic payload (sid, nonce, epoch, framing)
B_MACTAG = 32               # HMAC-SHA256 tag

# protocol defaults
D_MAX = 8                   # max reconcilable epoch drift (bounded fast-forward)
G_MAX = 8                   # max gap (epochs) for a resume decision
SEAL_BATCH = 1              # reseal every SEAL_BATCH ticks (rollback window k-1)
N_RETRY_HS = 3              # bounded handshake retries then no-contact
T_EPOCH_S = 30.0            # local seconds per key epoch (doc; not simulated as wall)


# ---------------------------------------------------------------- policy config
@dataclass
class PolCfg:
    name: str
    # capability flags -- each maps to a protocol mechanism (design.md sec.3)
    ephemeral: bool = True       # K_e ephemeral ML-KEM  -> post-gap FS
    static_auth: bool = True     # static KEM (or sig) mutual entity auth
    drkem: bool = True           # DR-KEM hybrid layer   -> record-now-extract-later
    seal: bool = True            # RoT-sealed ratchet state -> anti-rollback
    transcript_bind: bool = True # transcript hash binds nonces/epochs/ids/roles
    lse_check: bool = True       # last-committed-epoch regression memory
    bounded_delta: bool = True   # enforce D_MAX before fast-forward
    drift_window: int = None     # None => D_MAX; B_DriftWin sets 1 (Assumption-2 window)
    sig_mode: bool = False       # ML-DSA signatures instead of implicit static KEM
    mac_ticket: bool = False     # auth = ck-MAC possession only (TLS-PSK analog)
    fullonly: bool = False       # always FullReAttest (safe/slow)
    sake_like: bool = False      # symmetric evolution + bounded resync, no fresh entropy
    seal_batch: int = SEAL_BATCH
    d_max: int = D_MAX
    g_max: int = G_MAX


# ---------------------------------------------------------------- traces
@dataclass
class Episode:
    idx: int
    cond: str
    attack: str            # None | replay | reflect | impersonate_passive
    #                        | impersonate_active | rollback | regression
    #                        | fastforward_dos | retro   (RA1..RA9)
    gap_epochs: int        # local no-contact gap g_x in endpoint epochs
    delta: int             # |e_i - e_j| asymmetric drift at reconnect
    verifier_reachable: bool
    captured_chain: bool   # adversary StateReveal'd the chain during the gap
    extracted_rot: bool    # adversary ExtractRoT'd statics AFTER this stage (RA9)
    cur_e: int             # local epoch at reconnect
    peer_e: int
    lse: int               # last committed epoch memory
    adv: dict = field(default_factory=dict)


@dataclass
class Trace:
    T: int
    scenario: str
    episodes: list
    base_secret: bytes


def _pick_cond(rng):
    return rng.choice(CONDS, p=[0.5, 0.3, 0.2])


def make_trace(scenario, T, seed):
    """One mission timeline of reconnect episodes for a scenario."""
    rng = np.random.default_rng(seed)
    base_secret = rng.integers(0, 256, size=32, dtype=np.uint8).tobytes()
    eps = []
    lse = 0
    e_i = 0
    # rolling capture library for the adversary (recorded transcripts)
    recorded = []

    for i in range(T):
        cond = _pick_cond(rng)
        attack = None
        captured_chain = False
        extracted_rot = False
        verifier = True
        gap = 1
        delta = 0

        if scenario == "RA1":                     # benign gaps, incl. multi-epoch
            gap = int(rng.integers(1, 7))
            delta = int(rng.integers(0, min(gap, 5) + 1))
        elif scenario == "RA2":                   # replay / reflection
            gap = int(rng.integers(1, 5))
            if i > 0 and rng.random() < 0.6:
                attack = "reflect" if rng.random() < 0.35 else "replay"
        elif scenario == "RA3":                   # capture-during-gap, PASSIVE after
            gap = int(rng.integers(1, 5))
            captured_chain = True
            if rng.random() < 0.6:
                attack = "impersonate_passive"    # read post-gap traffic
        elif scenario == "RA4":                   # capture-during-gap, ACTIVE at reconnect
            gap = int(rng.integers(1, 5))
            captured_chain = True
            if rng.random() < 0.6:
                attack = "impersonate_active"     # MitM at reconnect
        elif scenario == "RA5":                   # rollback of sealed state
            gap = int(rng.integers(1, 5))
            if rng.random() < 0.6:
                attack = "rollback"
        elif scenario == "RA6":                   # epoch regression vs honest peer
            gap = int(rng.integers(1, 5))
            # a regression is only meaningful once an epoch has been committed
            # (lse > 0); before that there is nothing to regress below.
            if lse > 0 and rng.random() < 0.6:
                attack = "regression"
        elif scenario == "RA7":                   # drift beyond budget / verifier absent
            gap = int(rng.integers(6, 14))
            delta = int(rng.integers(2, 10))
            if rng.random() < 0.4:
                verifier = False                  # honest R2 floor when unreachable
        elif scenario == "RA8":                   # fast-forward DoS
            gap = int(rng.integers(1, 5))
            if rng.random() < 0.6:
                attack = "fastforward_dos"
                delta = int(rng.integers(50, 500))  # adversarial huge epoch claim
        elif scenario == "RA9":                   # record-now-extract-later
            # Strengthened bilateral-extraction model: to make DR-KEM the
            # UNIQUE surviving forward-secret input, this test grants the adversary
            # both a gap-time StateReveal at the recorded epoch (chain ck revealed)
            # AND ephemeral compromise (bad-RNG / leak on constrained tactical HW),
            # then a later teardown ExtractRoT.  With ck and K_e both adversary-known,
            # only the RoT-sealed, deleted DR term preserves recorded-key secrecy.
            gap = int(rng.integers(1, 5))
            if rng.random() < 0.7:
                attack = "retro"
                captured_chain = True             # ck revealed at recorded epoch
                extracted_rot = True              # teardown extraction after the stage

        if delta == 0 and scenario in ("RA1", "RA7"):
            delta = int(rng.integers(0, min(gap, 4) + 1))

        peer_e = e_i + delta if rng.random() < 0.5 else max(0, e_i - delta)
        adv = {}
        if attack in ("replay", "reflect") and recorded:
            adv["transcript"] = dict(recorded[rng.integers(0, len(recorded))])
            adv["reflect"] = (attack == "reflect")
        if attack == "rollback":
            adv["old_e"] = max(0, e_i - int(rng.integers(1, 4)))
        if attack == "regression":
            # genuine regression: claim an epoch strictly below the committed lse
            adv["claim_e"] = int(rng.integers(0, lse))
        if attack == "fastforward_dos":
            adv["claim_e"] = e_i + delta

        ep = Episode(idx=i, cond=cond, attack=attack, gap_epochs=gap, delta=delta,
                     verifier_reachable=verifier, captured_chain=captured_chain,
                     extracted_rot=extracted_rot, cur_e=e_i, peer_e=peer_e, lse=lse,
                     adv=adv)
        eps.append(ep)

        # honest episodes advance epoch and record a transcript for later replay
        if attack is None:
            e_new = max(e_i, peer_e) + 1
            recorded.append({"e": e_new, "sid": f"sid-{seed}"})
            e_i = e_new
            lse = e_new

    return Trace(T, scenario, eps, base_secret)


# ---------------------------------------------------------------- policy
class ReauthPolicy:
    """One reconnect endpoint executing GT-R (or a baseline/ablation).  step per
    EPISODE: run_episode() executes the handshake for one reconnect and returns
    an outcome dict."""

    def __init__(self, cfg, secret=None):
        self.cfg = cfg
        self.secret = secret or b"\x00" * 32
        self.lse = 0
        self.rot_counter = 0          # RoT monotonic counter for the seal
        self.step_time_us = []

    # -- flight latency: four GT-R flights with bounded retransmit
    def _flight(self, n_msgs, cond, rng):
        L = LINK[cond]
        total, ok = 0.0, True
        for _ in range(n_msgs):
            tries = 0
            while True:
                d = max(1.0, L["delay"] + L["jitter"] * rng.standard_normal())
                if rng.random() >= L["loss"]:
                    total += d
                    break
                total += L["rto"]
                tries += 1
                if tries > N_RETRY:
                    ok = False
                    break
            if not ok:
                break
        return total, ok

    def _crypto_ms(self):
        cfg = self.cfg
        if cfg.mac_ticket:
            return 2 * MAC_MS
        ms = 0.0
        if cfg.static_auth:
            if cfg.sig_mode:
                ms += 2 * SIG_VERIFY_MS
            else:
                ms += 2 * (KEM_ENCAPS_MS + KEM_DECAPS_MS)
        if cfg.ephemeral:
            ms += KEM_ENCAPS_MS + KEM_DECAPS_MS
        if cfg.drkem:
            ms += 2 * (DR_ENCAPS_MS + DR_DECAPS_MS)
        ms += 3 * MAC_MS
        return ms

    def _bytes(self, path):
        cfg = self.cfg
        if path == "fullreattest":
            return B_KEMCT + B_KEMPK + 2 * B_SIG + 2 * B_PAY
        if cfg.mac_ticket:
            return 2 * B_PAY + 2 * B_MACTAG
        b = 3 * B_PAY + 3 * B_MACTAG            # M1--M3 payloads + 3 tags (M4 tag-only)
        if cfg.ephemeral:
            b += B_KEMPK + B_KEMCT              # epk_i + ct_e
        if cfg.static_auth:
            if cfg.sig_mode:
                b += 2 * B_SIG                  # two ML-DSA signatures
            else:
                b += 2 * B_KEMCT                # ct_sj + ct_si
        if cfg.drkem:
            b += 2 * DR_CT_BYTES               # dt_sj + dt_si (modeled)
        return b

    def _measure(self, path, ep, rng):
        cond = ep.cond
        if path in ("resume",):
            lat, ok = self._flight(4, cond, rng)
            if not ok:
                path = "fullreattest"
            else:
                lat += self._crypto_ms()
                if self.cfg.bounded_delta or self.cfg.drift_window is not None:
                    lat += ep.delta * (MAC_MS)          # chain fast-forward
                if self.cfg.drkem:
                    lat += ep.delta * DR_FF_PER_EPOCH_US / 1000.0
                return path, lat, True
        if path == "fullreattest":
            if not ep.verifier_reachable:
                return path, float("nan"), False
            return path, TLS_PQC[cond] + QUOTE_MS + QUOTE_VERIFY_MS, True
        if path == "quarantine":
            return path, float("nan"), False
        return path, float("nan"), False

    # -- effective drift window this policy will resume across
    def _window(self):
        cfg = self.cfg
        if cfg.drift_window is not None:
            return cfg.drift_window
        return cfg.d_max if cfg.bounded_delta else 10 ** 9

    # ==========================================================  run_episode
    def run_episode(self, ep, rng):
        t0 = time.perf_counter()
        out = self._dispatch(ep, rng)
        self.step_time_us.append((time.perf_counter() - t0) * 1e6)
        return out

    def _finish(self, ep, rng, path, accepted=False, imperson=False,
                pcs_leak=False, retro=False, hquar=False, divergent=False,
                r2_forced=False, audit=None):
        path, lat, succ = self._measure(path, ep, rng)
        return dict(path=path, accepted=accepted, imperson=imperson,
                    pcs_leak=pcs_leak, retro=retro, attack=ep.attack, hquar=hquar,
                    divergent=divergent, r2_forced=r2_forced, latency=lat,
                    success=succ, bytes=self._bytes(path), cond=ep.cond,
                    gap=ep.gap_epochs, delta=ep.delta, audit=audit or [])

    def _dispatch(self, ep, rng):
        cfg = self.cfg
        if cfg.fullonly:
            return self._finish(ep, rng, "fullreattest",
                                audit=[(ep.attack or "benign", False, "fullonly")])
        at = ep.attack

        # ---- honest reconnect: resume if within this policy's drift window and
        #      verifier-independence holds; else FullReAttest (R2).
        if at is None:
            win = self._window()
            # Drift and total communication-gap limits are independent protocol
            # guards.  Using max(win, g_max) here would silently disable a
            # configured G_MAX smaller than D_MAX.
            if ep.delta <= win and ep.gap_epochs <= cfg.g_max:
                if cfg.seal:
                    self.rot_counter += 1        # sealed tick on adoption
                self.lse = max(ep.cur_e, ep.peer_e) + 1
                return self._finish(ep, rng, "resume",
                                    audit=[("benign", True, "resume")])
            # drift beyond the window -> honest FullReAttest fallback
            return self._finish(ep, rng, "fullreattest",
                                r2_forced=(ep.delta > win),
                                audit=[("benign", True,
                                        "r2" if ep.verifier_reachable else "r2-noverify")])

        # ---- replay / reflection (RA2): transcript bound to fresh nonces/roles
        if at in ("replay", "reflect"):
            if cfg.transcript_bind:
                return self._finish(ep, rng, "fullreattest",
                                    audit=[(at, False, "freshness")])
            return self._finish(ep, rng, "resume", accepted=True,
                                audit=[(at, True, "accept")])

        # ---- capture-during-gap, PASSIVE (RA3): post-gap confidentiality.
        # Attacker holds the chain (StateReveal).  Post-gap key = KDF(ck', K_e,
        # KEM statics, DR...).  Confidential iff the key absorbs a secret the
        # ck-holder cannot compute: the ephemeral ML-KEM secret, or a STATIC ML-KEM
        # secret (fresh per handshake, requires the RoT decapsulation key). Signatures
        # authenticate but contribute NO secret to the key, so sig-only auth over a
        # captured chain leaks post-gap traffic (this is why B_SigOnly falls here).
        if at == "impersonate_passive":
            fresh_secret = cfg.ephemeral or (cfg.static_auth and not cfg.sig_mode)
            leak = not fresh_secret                         # ck-only key -> readable
            if cfg.mac_ticket:
                leak = True                                 # session key = f(ck)
            if leak:
                return self._finish(ep, rng, "resume", accepted=True,
                                    pcs_leak=True,
                                    audit=[(at, True, "pcs-leak")])
            return self._finish(ep, rng, "resume", accepted=False, pcs_leak=False,
                                audit=[(at, False, "healed")])

        # ---- capture-during-gap, ACTIVE (RA4): impersonation at reconnect.
        # Attacker holds ck but NOT RoT-held static keys -> cannot forge tau.
        if at == "impersonate_active":
            imp = not cfg.static_auth or cfg.mac_ticket     # no entity auth -> MitM
            if imp:
                return self._finish(ep, rng, "resume", accepted=True, imperson=True,
                                    audit=[(at, True, "impersonated")])
            return self._finish(ep, rng, "fullreattest",
                                audit=[(at, False, "auth-fail")])

        # ---- rollback of sealed state (RA5)
        if at == "rollback":
            in_batch = (self.cfg.seal_batch - 1) >= 1 and \
                (ep.cur_e - ep.adv.get("old_e", ep.cur_e)) <= (self.cfg.seal_batch - 1)
            if cfg.seal and not in_batch:
                return self._finish(ep, rng, "fullreattest",
                                    audit=[(at, False, "seal-counter")])
            return self._finish(ep, rng, "resume", accepted=True,
                                audit=[(at, True, "rolled-back")])

        # ---- epoch regression vs honest peer (RA6): lse memory
        if at == "regression":
            if cfg.lse_check and ep.adv.get("claim_e", 0) < ep.lse:
                # authenticated regression -> quarantine-eligible; unauth -> discard
                return self._finish(ep, rng, "fullreattest",
                                    audit=[(at, False, "lse")])
            return self._finish(ep, rng, "resume", accepted=True,
                                audit=[(at, True, "regressed")])

        # ---- fast-forward DoS (RA8): bounded-delta caps the work
        if at == "fastforward_dos":
            if cfg.bounded_delta and ep.adv.get("claim_e", 0) - ep.cur_e > cfg.d_max:
                return self._finish(ep, rng, "fullreattest",
                                    audit=[(at, False, "delta-bound")])
            # unbounded: the endpoint attempts a huge fast-forward (DoS realized)
            return self._finish(ep, rng, "resume", accepted=True,
                                audit=[(at, True, "ff-dos")])

        # ---- bilateral record-now-extract-later (RA9).
        # Later extraction of both endpoints makes K_si and K_sj recoverable; the
        # experiment additionally grants the recorded chain and ephemeral K_e.
        # The DR guard therefore represents the only hidden-input predicate.
        # (Under the WEAKER, ephemeral-fresh model of Thms 1-6 the ephemeral alone
        # already resists; DR is load-bearing only in the bilateral experiment.)
        if at == "retro":
            retro_ok = not cfg.drkem                         # only DR survives here
            if cfg.mac_ticket or (not cfg.static_auth and not cfg.drkem):
                retro_ok = True
            if retro_ok:
                return self._finish(ep, rng, "resume", accepted=True, retro=True,
                                    audit=[(at, True, "retro-decrypt")])
            return self._finish(ep, rng, "resume", accepted=False, retro=False,
                                audit=[(at, False, "dr-forward-secure")])

        return self._finish(ep, rng, "fullreattest",
                            audit=[(at, False, "default")])


# ---------------------------------------------------------------- run + metrics
def run_policy(policy, tr):
    return [policy.run_episode(ep, policy._rng) for ep in tr.episodes]


# attack class -> acceptance-metric key
ATTACK_KEYS = {
    "replay": "acc_replay", "reflect": "acc_replay",
    "impersonate_passive": "acc_pcs", "impersonate_active": "acc_imperson",
    "rollback": "acc_rollback", "regression": "acc_regression",
    "fastforward_dos": "acc_ffdos", "retro": "acc_retro",
}


def metrics(tr, outs):
    m = {}
    # per attack-class acceptance
    buckets = {}
    for o in outs:
        k = ATTACK_KEYS.get(o["attack"])
        if k:
            buckets.setdefault(k, []).append(float(o["accepted"]))
    for k, v in buckets.items():
        m[k] = float(np.mean(v)) if v else np.nan
    # specialized security metrics
    imp = [float(o["imperson"]) for o in outs if o["attack"] == "impersonate_active"]
    m["imperson_rate"] = float(np.mean(imp)) if imp else np.nan
    leak = [float(o["pcs_leak"]) for o in outs if o["attack"] == "impersonate_passive"]
    m["pcs_leak_rate"] = float(np.mean(leak)) if leak else np.nan
    retro = [float(o["retro"]) for o in outs if o["attack"] == "retro"]
    m["retro_rate"] = float(np.mean(retro)) if retro else np.nan
    # honest-side quarantine (should be ~0)
    m["hquar"] = float(np.mean([float(o["hquar"]) for o in outs]))
    # availability = fraction of reconnects that succeeded WITHOUT a verifier
    #   (the resume path counts; fullreattest requires a verifier and therefore does not).
    succ_noverify = [float(o["path"] == "resume" and o["success"]) for o in outs]
    m["availability"] = float(np.mean(succ_noverify))
    # overall reconnect success (either path)
    m["success_any"] = float(np.mean([float(o["success"]) for o in outs]))
    # R2-forced ratio (honest episodes routed to FullReAttest by drift)
    hon = [o for o in outs if o["attack"] is None]
    if hon:
        m["r2_forced_ratio"] = float(np.mean([float(o["r2_forced"]) for o in hon]))
        m["resume_ratio"] = float(np.mean([float(o["path"] == "resume") for o in hon]))
    else:
        m["r2_forced_ratio"] = np.nan
        m["resume_ratio"] = np.nan
    # latency by condition (successful resume only)
    for cond in CONDS:
        v = [o["latency"] for o in outs if o["cond"] == cond
             and o["path"] == "resume" and o["success"] and not np.isnan(o["latency"])]
        m[f"lat_{cond}_resume"] = float(np.mean(v)) if v else np.nan
        vf = [o["latency"] for o in outs if o["cond"] == cond
              and o["path"] == "fullreattest" and o["success"] and not np.isnan(o["latency"])]
        m[f"lat_{cond}_full"] = float(np.mean(vf)) if vf else np.nan
    # bytes by path
    for path in ("resume", "fullreattest"):
        v = [o["bytes"] for o in outs if o["path"] == path]
        m[f"bytes_{path}"] = float(np.mean(v)) if v else np.nan
    # guard audit
    audit = {}
    for o in outs:
        for kind, ok, why in o["audit"]:
            a = audit.setdefault(kind, {"n": 0, "acc": 0, "reasons": {}})
            a["n"] += 1
            if ok and o["accepted"]:
                a["acc"] += 1
            elif not ok:
                a["reasons"][why] = a["reasons"].get(why, 0) + 1
    m["guard_audit"] = audit
    return m


# ---------------------------------------------------------------- registry
def _mkpol(cfg):
    return lambda rng, secret=None: _bind_rng(ReauthPolicy(cfg, secret), rng)


def _bind_rng(pol, rng):
    pol._rng = rng
    return pol


CFGS = {
    # full protocol (implicit-KEM primary) + hybrid DR-KEM
    "P_Qartz":     PolCfg("P_Qartz"),
    # ML-DSA signature mode variant (auditable; 2x bytes)
    "P_QartzSig":  PolCfg("P_QartzSig", sig_mode=True),
    # ck-MAC possession only == TLS-PSK resumption analog (capture-impersonatable)
    "B_MacTicket": PolCfg("B_MacTicket", mac_ticket=True, ephemeral=False,
                          static_auth=False, drkem=False, seal=False),
    # always full re-attest (safe; unavailable without verifier)
    "B_FullOnly":  PolCfg("B_FullOnly", fullonly=True),
    # mutual ML-DSA, NO ephemeral KEM -> no post-gap FS/PCS-confidentiality
    "B_SigOnly":   PolCfg("B_SigOnly", sig_mode=True, ephemeral=False, drkem=False),
    # no RoT sealing -> restore-old-blob rollback succeeds
    "B_NoSeal":    PolCfg("B_NoSeal", seal=False),
    # Resync Assumption-2 baseline: resume only if delta <= 1, else R2
    "B_DriftWin":  PolCfg("B_DriftWin", drift_window=1),
    # SAKE-like symmetric evolution + bounded resync, no fresh entropy, no DR
    "B_SakeLike":  PolCfg("B_SakeLike", sake_like=True, ephemeral=False,
                          drkem=False, drift_window=2),
    # ablations
    "A_noEphemeral":     PolCfg("A_noEphemeral", ephemeral=False),
    "A_noStaticAuth":    PolCfg("A_noStaticAuth", static_auth=False),
    "A_unboundedDelta":  PolCfg("A_unboundedDelta", bounded_delta=False),
    "A_noTranscriptBind": PolCfg("A_noTranscriptBind", transcript_bind=False),
    "A_noLse":           PolCfg("A_noLse", lse_check=False),
    "A_noDrkem":         PolCfg("A_noDrkem", drkem=False),
}

POLICIES = {name: _mkpol(cfg) for name, cfg in CFGS.items()}
