# Experiment runner: Monte Carlo over scenarios, baselines + ablations,
# theta-frontier and threshold-sensitivity sweeps, figures (IEEE column
# width) and LaTeX result macros.

import os, csv, json, platform, time
from datetime import datetime, timezone
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from qartz_sim import (POLICIES, QARTZ, ScalarTrust, Params, make_trace,
                       run_policy, metrics, HYBRID, E3, E4, LEGACY_EXC)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results", "control")
FIG = os.path.join(HERE, "figures")
os.makedirs(OUT, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

_OUTPUT_FILES = set()


def _record_output(path):
    """Track only artifacts produced by this invocation for the manifest."""
    _OUTPUT_FILES.add(os.path.abspath(path))


def _artifact_path(*parts):
    return os.path.join(OUT, *parts)

T = 2000
T_LONG = 3000          # S1L: very long blackouts need more room
RUNS = 100
TRACE_SEED_BASE = 1000
POLICY_SEED_BASE = 7000

plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "figure.dpi": 200,
    "pdf.fonttype": 42,
})
W = 3.45  # IEEE column width (in)


def _savefig(fig, filename):
    path = os.path.join(FIG, filename)
    fig.savefig(path)
    _record_output(path)
    plt.close(fig)

SCEN_POLICIES = {
    "S1": ["B1_StaticHybrid", "B2_StaticPQC", "B3_TrustAuth", "B3lo_TrustAuth",
           "B4_ContextOnly", "L1_SLogic", "L2_BetaRep", "G1_Grace",
           "B5_QARTZ", "B6_Oracle", "A_noConf", "A_noSep"],
    "S1L": ["B3_TrustAuth", "B3lo_TrustAuth", "L1_SLogic", "L2_BetaRep",
            "G1_Grace", "B5_QARTZ", "B6_Oracle"],
    "S2": ["B3_TrustAuth", "B4_ContextOnly", "L1_SLogic", "L2_BetaRep",
           "G1_Grace", "B5_QARTZ", "B6_Oracle", "A_noGuard",
           "A_guardSigTtl", "A_guardSigCtr", "A_guardNoGates",
           "A_noC1C2"],
    "S2b": ["B2_StaticPQC", "B5_QARTZ", "B6_Oracle"],
    "S3": ["B1_StaticHybrid", "B3_TrustAuth", "B3lo_TrustAuth", "B4_ContextOnly",
           "L1_SLogic", "L2_BetaRep", "G1_Grace", "B5_QARTZ", "B6_Oracle",
           "A_noC1C2", "A_atomic"],
    "S4": ["B3_TrustAuth", "L1_SLogic", "L2_BetaRep", "G1_Grace", "B5_QARTZ",
           "B6_Oracle", "A_noSep", "A_noChi"],
    "S5": ["B4_ContextOnly", "L1_SLogic", "G1_Grace", "B5_QARTZ", "A_noGuard",
           "A_guardSigTtl", "A_guardSigCtr", "A_guardNoGates",
           "A_noC1C2"],
}

SCEN_T = {"S1L": T_LONG}


def aggregate():
    rows, raw = [], {}
    for scen, pols in SCEN_POLICIES.items():
        Ts = SCEN_T.get(scen, T)
        for run in range(RUNS):
            tr = make_trace(scen, Ts, seed=TRACE_SEED_BASE + run)
            for pol in pols:
                rng = np.random.default_rng(POLICY_SEED_BASE + run)
                policy = POLICIES[pol](rng)
                out = run_policy(policy, tr)
                m = metrics(tr, out)
                m.update(scenario=scen, policy=pol, run=run)
                rows.append(m)
                raw.setdefault((scen, pol), []).append(m)
        print(f"[done] {scen}", flush=True)
    path = _artifact_path("raw_metrics.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=sorted({k for r in rows for k in r}))
        w.writeheader()
        w.writerows(rows)
    _record_output(path)
    return raw


def mstat(raw, scen, pol, key):
    """Mean +/- normal 95% CI over finite scalar observations.

    MTTD/MTTC remain conditional on detection, matching the paper's existing
    convention.  Explicit coercion avoids silently retaining NumPy NaNs or
    non-scalar diagnostic fields.
    """
    vals = []
    for row in raw.get((scen, pol), []):
        try:
            value = float(row[key])
        except (KeyError, TypeError, ValueError):
            continue
        if np.isfinite(value):
            vals.append(value)
    if not vals:
        return np.nan, np.nan
    v = np.asarray(vals, float)
    ci = 1.96 * float(v.std(ddof=1)) / np.sqrt(v.size) if v.size > 1 else 0.0
    return float(v.mean()), float(ci)


# ------------------------------------------------------------------ figures
DISPLAY = {
    "B1_StaticHybrid": "B1\nStat-Hyb", "B2_StaticPQC": "B2\nStat-PQC",
    "B3_TrustAuth": "B3\n$\\theta$=.5", "B3lo_TrustAuth": "B3\n$\\theta$=.25",
    "B4_ContextOnly": "B4\nContext", "L1_SLogic": "L1/L2\nSL/Beta",
    "L2_BetaRep": "L2\nBetaRep", "G1_Grace": "G1\nGrace",
    "B5_QARTZ": "B5\nQ-ARTZ",
    "B6_Oracle": "B6\nOracle", "A_noConf": "$-\\rho_t$",
    "A_noSep": "$-a_t/\\eta_t$", "A_noChi": "$-\\chi_t$",
    "A_noGuard": "$-W_t$", "A_atomic": "rand-arb", "A_noC1C2": "$-$C1/C2",
    "A_guardSigTtl": "grd:\nsig", "A_guardSigCtr": "grd:\n+ctr",
    "A_guardNoGates": "grd:\n$-$gates",
}


def _contiguous(mask):
    idx = np.where(mask)[0]
    if not len(idx):
        return []
    segs, s = [], idx[0]
    for a, b in zip(idx[:-1], idx[1:]):
        if b != a + 1:
            segs.append((s, a)); s = b
    segs.append((s, idx[-1]))
    return segs


def fig_timeline():
    """Benign DDIL vs confused-DDIL attack: what the estimator sees."""
    fig, axes = plt.subplots(2, 1, figsize=(W, 2.8), sharex=True)
    for ax, scen, title in [(axes[0], "S1", "Benign DDIL (S1)"),
                            (axes[1], "S4", "Confused-DDIL attack (S4)")]:
        tr = make_trace(scen, T, seed=TRACE_SEED_BASE + 42)
        q = QARTZ(rng=np.random.default_rng(POLICY_SEED_BASE + 42))
        Ts, rhos, etas, profs, avs = [], [], [], [], []
        for t in range(T):
            d = q.step(tr, t)
            Ts.append(np.mean(list(d["T"].values())))
            rhos.append(min(d["rho"].values()))
            etas.append(d["eta"])
            profs.append(d["profile"])
            avs.append(tr.a_true[t])
        x = np.arange(T)
        ax.plot(x, Ts, lw=0.9, label=r"$\bar T_k$")
        ax.plot(x, rhos, lw=0.9, label=r"$\min_k \rho_k$")
        ax.plot(x, etas, lw=0.9, label=r"$\eta_t$")
        ax.plot(x, avs, lw=0.6, alpha=0.5, label=r"$a_t$")
        ax2 = ax.twinx()
        ax2.step(x, profs, lw=0.8, color="crimson", alpha=0.8)
        ax2.set_ylim(-0.2, 5.4)
        ax2.set_yticks(range(6))
        ax2.set_yticklabels([f"E{i}" for i in range(6)], fontsize=6, color="crimson")
        ax.set_ylim(-0.05, 1.05)
        ax.set_title(title, fontsize=8)
        for s, e in _contiguous(tr.outage):        # shade each blackout
            ax.axvspan(s, e, color="gray", alpha=0.15)
        if tr.attack_window:
            ax.axvline(tr.attack_window[0], color="k", ls="--", lw=0.7)
    axes[0].legend(ncol=4, loc="lower left", frameon=False)
    axes[1].set_xlabel("time step")
    fig.tight_layout(pad=0.4)
    _savefig(fig, "fig_timeline.pdf")


def _bar(ax, names, means, errs, ylabel):
    xs = np.arange(len(names))
    ax.bar(xs, means, yerr=errs, capsize=2, width=0.6,
           color=["#4477AA" if not n.startswith("A_") else "#EE9944" for n in names])
    for x, v in zip(xs, means):
        ax.text(x, v + 0.03, f"{100*v:.0f}", ha="center", fontsize=5.5,
                color="black")
    ax.set_ylim(0, 1.12)
    ax.set_xticks(xs)
    ax.set_xticklabels([DISPLAY.get(n, n) for n in names], fontsize=6)
    ax.set_ylabel(ylabel)


def fig_false_isolation(raw):
    fig, ax = plt.subplots(figsize=(W, 1.7))
    # L2 duplicates L1's decision surface (SL projected prob = beta mean)
    pols = [p for p in SCEN_POLICIES["S1"] if p != "L2_BetaRep"]
    ms, es = zip(*[mstat(raw, "S1", p, "false_isolation") for p in pols])
    _bar(ax, pols, ms, es, "false-isolation rate")
    fig.tight_layout(pad=0.4)
    _savefig(fig, "fig_false_isolation.pdf")


def fig_downgrade(raw):
    fig, ax = plt.subplots(figsize=(W, 1.7))
    pols = [p for p in SCEN_POLICIES["S2"] if p != "L2_BetaRep"]
    ms, es = zip(*[mstat(raw, "S2", p, "downgrade_success") for p in pols])
    _bar(ax, pols, ms, es, "downgrade success rate")
    fig.tight_layout(pad=0.4)
    _savefig(fig, "fig_downgrade.pdf")


def fig_mttd_cdf(raw):
    """CDF normalized by total runs: censored mass shows as a plateau."""
    fig, ax = plt.subplots(figsize=(W, 1.8))
    cdf_names = {"B5_QARTZ": "Q-ARTZ-Control",
                 "B3_TrustAuth": r"B3 ($\theta$=0.5)",
                 "B3lo_TrustAuth": r"B3 ($\theta$=0.25)",
                 "L1_SLogic": "L1/L2 SL$\\equiv$BetaRep",
                 "B6_Oracle": "Oracle"}
    for pol, style in [("B5_QARTZ", "-"), ("B3_TrustAuth", "--"),
                       ("B3lo_TrustAuth", ":"), ("L1_SLogic", (0, (3, 1, 1, 1))),
                       ("B6_Oracle", "-.")]:
        rs = raw[("S3", pol)]
        vals = np.sort([r["mttd"] for r in rs if not np.isnan(r.get("mttd", np.nan))])
        y = (np.arange(len(vals)) + 1) / len(rs)
        ax.plot(vals, y, ls=style, lw=1.1, label=cdf_names[pol])
    ax.set_xlabel("detection delay (steps)")
    ax.set_ylabel("CDF (of all runs)")
    ax.set_ylim(0, 1.05)
    ax.legend(frameon=False)
    fig.tight_layout(pad=0.4)
    _savefig(fig, "fig_mttd_cdf.pdf")


# ------------------------------------------------------------------ frontier
THETAS = np.round(np.arange(0.20, 0.5751, 0.025), 3)
FRONTIER_RUNS = 60


def theta_frontier():
    """FI (S1 medium / S1L long blackouts) and detection (S3) vs theta."""
    res = {"theta": THETAS, "fi_med": [], "fi_long": [], "det": [], "mttd": []}
    for th in THETAS:
        fi_m, fi_l, det, mttd = [], [], [], []
        for run in range(FRONTIER_RUNS):
            for scen, acc in (("S1", fi_m), ("S1L", fi_l)):
                tr = make_trace(scen, SCEN_T.get(scen, T),
                                seed=TRACE_SEED_BASE + run)
                out = run_policy(ScalarTrust(HYBRID, theta=th), tr)
                acc.append(metrics(tr, out)["false_isolation"])
            tr = make_trace("S3", T, seed=TRACE_SEED_BASE + run)
            m = metrics(tr, run_policy(ScalarTrust(HYBRID, theta=th), tr))
            det.append(m["detected"])
            if not np.isnan(m["mttd"]):
                mttd.append(m["mttd"])
        res["fi_med"].append(np.mean(fi_m))
        res["fi_long"].append(np.mean(fi_l))
        res["det"].append(np.mean(det))
        res["mttd"].append(np.mean(mttd) if mttd else np.nan)
        print(f"[frontier] theta={th}: fiM={res['fi_med'][-1]:.2f} "
              f"fiL={res['fi_long'][-1]:.2f} det={res['det'][-1]:.2f} "
              f"mttd={res['mttd'][-1]:.0f}", flush=True)
    path = _artifact_path("frontier.npy")
    np.save(path, res, allow_pickle=True)
    _record_output(path)
    return res


def fig_frontier(fr, raw):
    fig, axes = plt.subplots(1, 2, figsize=(W, 1.9))
    th = fr["theta"]
    ax = axes[0]
    ax.plot(th, fr["fi_med"], "-o", ms=2.5, lw=1,
            label="blackouts 250-600")
    ax.plot(th, fr["fi_long"], "-s", ms=2.5, lw=1,
            label="blackouts 900-1300")
    ax.axhline(0, color="#2ca02c", lw=1, ls="--")
    ax.annotate("Q-ARTZ (any $\\theta$-free)", (th[0], 0.035), fontsize=5.5,
                color="#2ca02c")
    ax.set_xlabel(r"scalar threshold $\theta$")
    ax.set_ylabel("false isolation (S1)")
    ax.legend(frameon=False, fontsize=5.5)
    ax = axes[1]
    ax.plot(th, fr["det"], "-o", ms=2.5, lw=1, color="#4477AA")
    ax.set_xlabel(r"scalar threshold $\theta$")
    ax.set_ylabel("detection rate (S3)", color="#4477AA")
    ax.set_ylim(0, 1.05)
    ax2 = ax.twinx()
    ax2.plot(th, fr["mttd"], "-^", ms=2.5, lw=1, color="#EE9944")
    m_q, _ = mstat(raw, "S3", "B5_QARTZ", "mttd")
    ax2.axhline(m_q, color="#2ca02c", lw=1, ls="--")
    ax2.set_ylabel("MTTD, detected runs", color="#EE9944", fontsize=7)
    fig.tight_layout(pad=0.4)
    _savefig(fig, "fig_theta_frontier.pdf")


# ------------------------------------------------------------------ robustness
ROB_PARAMS = [
    ("LamU", "lam_u", [0.20, 0.25, 0.30, 0.35, 0.40]),
    ("LamEta", "lam_eta", [0.40, 0.50, 0.60, 0.70, 0.80]),
    ("LamChi", "lam_chi", [0.30, 0.40, 0.50, 0.60, 0.70]),
    ("RhoPatch", "rho_patch", [0.25, 0.30, 0.35, 0.40, 0.45]),
    ("RhoExc", "rho_exc", [0.30, 0.40, 0.50, 0.60, 0.70]),
    ("TtlExc", "ttl_exc", [100, 200, 300, 400, 500]),
    ("TauFresh", "tau_fresh", [150, 200, 250, 325, 400]),
    ("EtaLo", "eta_lo", [0.15, 0.20, 0.25, 0.30]),
]
ROB_RUNS = 20


def param_robustness():
    """1-D sweeps summarized at the parameter-point level.

    Each point is first averaged over matched runs.  The reported worst values
    are then extrema across those point estimates, rather than extrema across
    individual stochastic episodes.
    """
    rows, csv_rows = {}, []
    for tag, key, vals in ROB_PARAMS:
        points = []
        for v in vals:
            fi, unn, det, mttd, dg = [], [], [], [], []
            for run in range(ROB_RUNS):
                p = Params(**{key: v})
                tr = make_trace("S1L", T_LONG,
                                seed=TRACE_SEED_BASE + run)
                m = metrics(tr, run_policy(
                    QARTZ(p=p, rng=np.random.default_rng(
                        POLICY_SEED_BASE + run)), tr))
                fi.append(m["false_isolation"]); unn.append(m["unnecessary_esc"])
                tr = make_trace("S3", T, seed=TRACE_SEED_BASE + run)
                m = metrics(tr, run_policy(
                    QARTZ(p=p, rng=np.random.default_rng(
                        POLICY_SEED_BASE + run)), tr))
                det.append(m["detected"])
                if not np.isnan(m["mttd"]):
                    mttd.append(m["mttd"])
                tr = make_trace("S2", T, seed=TRACE_SEED_BASE + run)
                m = metrics(tr, run_policy(
                    QARTZ(p=p, rng=np.random.default_rng(
                        POLICY_SEED_BASE + run)), tr))
                if not np.isnan(m["downgrade_success"]):
                    dg.append(m["downgrade_success"])
            point = dict(
                value=v,
                fi=100 * float(np.mean(fi)),
                unn=100 * float(np.mean(unn)),
                det=100 * float(np.mean(det)),
                dg=100 * float(np.mean(dg)) if dg else np.nan,
                mttd=float(np.mean(mttd)) if mttd else np.nan,
                mttd_n=len(mttd),
                dg_n=len(dg),
            )
            points.append(point)
            csv_rows.append(dict(
                tag=tag, parameter=key, value=v, runs=ROB_RUNS,
                false_isolation_pct=point["fi"],
                unnecessary_escalation_pct=point["unn"],
                detection_pct=point["det"],
                downgrade_success_pct=point["dg"],
                mttd_mean_detected=point["mttd"],
                mttd_detected_runs=point["mttd_n"],
                downgrade_observed_runs=point["dg_n"],
            ))

        def extreme(metric, choose):
            finite = [p for p in points if np.isfinite(p[metric])]
            if not finite:
                return np.nan, "--"
            point = choose(finite, key=lambda p: p[metric])
            return point[metric], str(point["value"])

        fi_worst, fi_at = extreme("fi", max)
        unn_worst, unn_at = extreme("unn", max)
        det_worst, det_at = extreme("det", min)
        dg_worst, dg_at = extreme("dg", max)
        mlo, mlo_at = extreme("mttd", min)
        mhi, mhi_at = extreme("mttd", max)
        rows[tag] = dict(
            rng=f"{vals[0]}--{vals[-1]}", points=points,
            fi=fi_worst, fi_at=fi_at,
            unn=unn_worst, unn_at=unn_at,
            det=det_worst, det_at=det_at,
            dg=dg_worst, dg_at=dg_at,
            mlo=mlo, mlo_at=mlo_at, mhi=mhi, mhi_at=mhi_at,
        )
        print(f"[rob] {tag}: FI<={rows[tag]['fi']:.0f} DG<={rows[tag]['dg']:.0f} "
              f"Det>={rows[tag]['det']:.0f} MTTD {rows[tag]['mlo']:.0f}-"
              f"{rows[tag]['mhi']:.0f}", flush=True)

    path = _artifact_path("robustness_1d.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        fieldnames = list(csv_rows[0]) if csv_rows else []
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if fieldnames:
            writer.writeheader()
            writer.writerows(csv_rows)
    _record_output(path)
    return rows


# ------------------------------------------------------------------ joint sweep
JOINT_CFGS = 120        # LHS configs inside the 1-D envelope
PROBE_CFGS = 24         # beyond-envelope risk-weight probe
JOINT_RUNS_FI = 10      # S1L runs per config
JOINT_RUNS_DG = 8       # S2 runs per config
JOINT_RUNS_DET = 10     # S3 runs per config
JOINT_SEED = 2026
CHI_MIN_DEFAULT = 0.60
PSI_HI_RC_ONE = 0.65    # tighter of the two classes covered by Prop. 1


def _lhs(n, k, rng):
    """Stratified (Latin-hypercube-style) unit sample: n points, k dims."""
    return np.stack([(rng.permutation(n) + rng.random(n)) / n
                     for _ in range(k)], axis=1)


def joint_robustness():
    """All-eight-parameters-at-once robustness (reviewer request): an LHS
    sample inside the 1-D sweep envelope, plus a deliberate beyond-envelope
    probe of the risk weights that violates the governance inequality
    (Eq. 12) so the failure boundary is exhibited rather than asserted."""
    rngm = np.random.default_rng(JOINT_SEED)
    keys = [k for _, k, _ in ROB_PARAMS]
    los = np.array([v[0] for _, _, v in ROB_PARAMS], float)
    his = np.array([v[-1] for _, _, v in ROB_PARAMS], float)

    tr_fi = [make_trace("S1L", T_LONG, seed=TRACE_SEED_BASE + r)
             for r in range(JOINT_RUNS_FI)]
    tr_dg = [make_trace("S2", T, seed=TRACE_SEED_BASE + r)
             for r in range(JOINT_RUNS_DG)]
    tr_det = [make_trace("S3", T, seed=TRACE_SEED_BASE + r)
              for r in range(JOINT_RUNS_DET)]

    def one_cfg(x, fi_only=False):
        cfg = dict(zip(keys, [float(v) for v in x]))
        cfg["ttl_exc"] = int(round(cfg["ttl_exc"]))
        p = Params(**cfg)
        fi = []
        for r, tr in enumerate(tr_fi):
            m = metrics(tr, run_policy(
                QARTZ(p=p, rng=np.random.default_rng(
                    POLICY_SEED_BASE + r)), tr))
            fi.append(m["false_isolation"])
        out = dict(fi=100 * float(np.mean(fi)),
                   lhs=cfg["lam_u"] + cfg["lam_eta"] * cfg["eta_lo"]
                       + cfg["lam_chi"] * (1 - CHI_MIN_DEFAULT))
        if fi_only:
            return out
        dg = []
        for r, tr in enumerate(tr_dg):
            m = metrics(tr, run_policy(
                QARTZ(p=p, rng=np.random.default_rng(
                    POLICY_SEED_BASE + r)), tr))
            if not np.isnan(m["downgrade_success"]):
                dg.append(m["downgrade_success"])
        det, mttd = [], []
        for r, tr in enumerate(tr_det):
            m = metrics(tr, run_policy(
                QARTZ(p=p, rng=np.random.default_rng(
                    POLICY_SEED_BASE + r)), tr))
            det.append(m["detected"])
            if not np.isnan(m["mttd"]):
                mttd.append(m["mttd"])
        out.update(dg=100 * float(np.mean(dg)) if dg else np.nan,
                   det=100 * float(np.mean(det)),
                   mttd=float(np.mean(mttd)) if mttd else np.nan)
        return out

    X = los + _lhs(JOINT_CFGS, len(keys), rngm) * (his - los)
    env = []
    for i, x in enumerate(X):
        env.append(one_cfg(x))
        if (i + 1) % 20 == 0:
            print(f"[joint] {i+1}/{JOINT_CFGS}", flush=True)

    # probe: push the three risk weights beyond the 1-D envelope so that the
    # governance inequality is violated and, for large weights, the benign
    # blackout floor itself crosses psi_hi -> Rule C2 -> false isolation
    Xp = los + _lhs(PROBE_CFGS, len(keys), rngm) * (his - los)
    U = rngm.random((PROBE_CFGS, 3))
    Xp[:, keys.index("lam_u")] = 0.45 + 0.45 * U[:, 0]     # 0.45--0.90
    Xp[:, keys.index("lam_eta")] = 0.60 + 0.80 * U[:, 1]   # 0.60--1.40
    Xp[:, keys.index("lam_chi")] = 0.50 + 0.70 * U[:, 2]   # 0.50--1.20
    probe = [one_cfg(x, fi_only=True) for x in Xp]
    print(f"[joint] probe done ({PROBE_CFGS} cfgs)", flush=True)

    env_viol = [c for c in env if c["lhs"] >= PSI_HI_RC_ONE]
    all_ok = [c for c in env + probe if c["lhs"] < PSI_HI_RC_ONE]
    probe_fi_pos = [c for c in probe if c["fi"] > 0]
    res = dict(
        ncfg=JOINT_CFGS,
        fi_worst=max(c["fi"] for c in env),
        fi_med=float(np.median([c["fi"] for c in env])),
        dg_worst=max(c["dg"] for c in env),
        det_worst=min(c["det"] for c in env),
        det_med=float(np.median([c["det"] for c in env])),
        mttd_lo=min(c["mttd"] for c in env),
        mttd_hi=max(c["mttd"] for c in env),
        env_nviol=len(env_viol),
        env_viol_fi_max=max((c["fi"] for c in env_viol), default=0.0),
        probe_n=PROBE_CFGS,
        probe_nfipos=len(probe_fi_pos),
        probe_fi_max=max((c["fi"] for c in probe), default=0.0),
        probe_lhs_fi_min=min((c["lhs"] for c in probe_fi_pos), default=np.nan),
        ok_fi_max=max((c["fi"] for c in all_ok), default=0.0),
        n_ok=len(all_ok),
    )
    print(f"[joint] env: FI worst {res['fi_worst']:.1f} med {res['fi_med']:.1f} "
          f"DG worst {res['dg_worst']:.1f} Det worst {res['det_worst']:.1f} "
          f"MTTD {res['mttd_lo']:.0f}-{res['mttd_hi']:.0f} "
          f"(viol {res['env_nviol']}, their FI max {res['env_viol_fi_max']:.1f})",
          flush=True)
    print(f"[joint] probe: {res['probe_nfipos']}/{PROBE_CFGS} cfgs FI>0, "
          f"FI max {res['probe_fi_max']:.1f}; "
          f"FI>0 only above lhs {res['probe_lhs_fi_min']:.2f}; "
          f"ok-cfg FI max {res['ok_fi_max']:.1f} over {res['n_ok']}",
          flush=True)
    path = _artifact_path("joint.npy")
    np.save(path, dict(env=env, probe=probe), allow_pickle=True)
    _record_output(path)
    return res


# ------------------------------------------------------------------ sensitivity
SENS_RUNS = 30


def fig_sensitivity():
    """Sweep eta_hi x psi_hi(RC3): MTTD (S3) vs false isolation (S1)."""
    etas = [0.35, 0.40, 0.45, 0.50, 0.55, 0.60]
    psis = [0.25, 0.30, 0.35, 0.40, 0.45]
    mttd = np.zeros((len(etas), len(psis)))
    fiso = np.zeros_like(mttd)
    import qartz_sim as QS
    for i, eh in enumerate(etas):
        for j, ph in enumerate(psis):
            m_acc, f_acc = [], []
            for run in range(SENS_RUNS):
                p = Params(eta_hi=eh, eta_hi_exit=eh - 0.1)
                QS.RC_PSI_HI = dict(QS.RC_PSI_HI); QS.RC_PSI_HI[3] = ph
                tr3 = make_trace("S3", T, seed=TRACE_SEED_BASE + run)
                q = QARTZ(p=p, rng=np.random.default_rng(
                    POLICY_SEED_BASE + run))
                m = metrics(tr3, run_policy(q, tr3))
                if not np.isnan(m.get("mttd", np.nan)):
                    m_acc.append(m["mttd"])
                tr1 = make_trace("S1", T, seed=TRACE_SEED_BASE + run)
                q = QARTZ(p=p, rng=np.random.default_rng(
                    POLICY_SEED_BASE + run))
                f_acc.append(metrics(tr1, run_policy(q, tr1))["false_isolation"])
            mttd[i, j] = np.mean(m_acc) if m_acc else np.nan
            fiso[i, j] = np.mean(f_acc)
        print(f"[sens] eta_hi={eh}", flush=True)
    QS.RC_PSI_HI[3] = 0.35   # restore default

    fig, axes = plt.subplots(1, 2, figsize=(W, 1.85))
    for ax, M, title, vmin, vmax in [
            (axes[0], mttd, "MTTD (steps)", None, None),
            (axes[1], fiso, "false-isolation rate", 0.0, 1.0)]:
        im = ax.imshow(M, aspect="auto", origin="lower", cmap="viridis",
                       vmin=vmin, vmax=vmax)
        ax.set_xticks(range(len(psis)))
        ax.set_xticklabels(psis, fontsize=6)
        ax.set_yticks(range(len(etas)))
        ax.set_yticklabels(etas, fontsize=6)
        ax.set_xlabel(r"$\psi_{\mathrm{hi}}(\mathrm{RC}_3)$")
        ax.set_ylabel(r"$\eta_{\mathrm{hi}}$")
        ax.set_title(title, fontsize=7)
        fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout(pad=0.4)
    _savefig(fig, "fig_sensitivity.pdf")
    mttd_path = _artifact_path("sens_mttd.npy")
    fiso_path = _artifact_path("sens_fiso.npy")
    np.save(mttd_path, mttd)
    np.save(fiso_path, fiso)
    _record_output(mttd_path)
    _record_output(fiso_path)
    return mttd, fiso


# ------------------------------------------------------------------ macros
# LaTeX control sequences cannot contain digits -> letters-only policy names
POLNAME = {
    "B1_StaticHybrid": "StaticHyb", "B2_StaticPQC": "StaticPqc",
    "B3_TrustAuth": "TrustAuth", "B3lo_TrustAuth": "TrustAuthLo",
    "B4_ContextOnly": "CtxOnly", "L1_SLogic": "Slog", "L2_BetaRep": "Beta",
    "G1_Grace": "Grace", "B5_QARTZ": "Qartz", "B6_Oracle": "Oracle",
    "A_noConf": "AblNoConf", "A_noSep": "AblNoSep", "A_noChi": "AblNoChi",
    "A_noGuard": "AblNoGuard", "A_atomic": "AblAtomic", "A_noC1C2": "AblNoRules",
    "A_guardSigTtl": "GvSigTtl", "A_guardSigCtr": "GvSigCtr",
    "A_guardNoGates": "GvNoGates",
}


REASON_LABEL = {"sig": "signature", "fresh": "expiry/nonce", "ctr": "counter",
                "digest": "state digest", "estimator": "$\\chi/\\eta$ gate",
                "confidence": "$\\rho$ gate", "prop": "\\texttt{Prop}",
                "ruleCone": "Rule C1", "accept": "accepted"}


def macros(raw, fr, sens_mttd, rob, joint):
    def pct(x):
        return "--" if x is None or np.isnan(x) else f"{100*x:.1f}"

    def num(x, d=0):
        return "--" if x is None or np.isnan(x) else f"{x:.{d}f}"

    q = QARTZ()
    tr = make_trace("S3", T, seed=1)
    run_policy(q, tr)
    step_us = float(np.mean(q.step_time_us))

    lines = []
    def M(name, val):
        lines.append(f"\\newcommand{{\\{name}}}{{{val}}}")

    table = [("S1", "false_isolation", "Fiso"),
             ("S1", "unnecessary_esc", "Unn"),
             ("S1", "avail_outage", "AvOut"),
             ("S1L", "false_isolation", "FisoLong"),
             ("S2", "downgrade_success", "Dg"),
             ("S2", "time_legacy", "TlegS"),
             ("S5", "downgrade_success", "DgU"),
             ("S5", "time_legacy", "TlegU"),
             ("S3", "detected", "Det"),
             ("S3", "mttd", "Mttd"), ("S3", "mttc", "Mttc"),
             ("S4", "detected", "DetConf"),
             ("S4", "mttd", "MttdConf"), ("S4", "mttc", "MttcConf")]
    for scen, key, tag in table:
        for pol in SCEN_POLICIES[scen]:
            m, e = mstat(raw, scen, pol, key)
            short = POLNAME[pol]
            if key in ("mttd", "mttc"):
                M(f"{tag}{short}", num(m))
                M(f"{tag}{short}Err", num(e))
            else:
                M(f"{tag}{short}", pct(m))
                M(f"{tag}{short}Err", pct(e))
    m, _ = mstat(raw, "S2b", "B5_QARTZ", "time_legacy")
    M("LegitExcQartz", pct(m))
    m, _ = mstat(raw, "S2b", "B5_QARTZ", "time_suspend")
    M("LegitSuspQartz", pct(m))
    m, _ = mstat(raw, "S2b", "B2_StaticPQC", "time_legacy")
    M("LegitExcStaticPqc", pct(m))
    m, _ = mstat(raw, "S1", "B5_QARTZ", "mode_switches_ph")
    M("SwitchQartz", num(m, 1))
    m, _ = mstat(raw, "S3", "A_atomic", "weak_action_rate")
    M("WeakActAtomic", pct(m))
    M("StepMicros", num(step_us, 1))
    M("NumRuns", str(RUNS))
    M("SimT", str(T))
    M("FrontierRuns", str(FRONTIER_RUNS))
    M("RobRuns", str(ROB_RUNS))
    M("SensRuns", str(SENS_RUNS))

    # theta-frontier windows: theta with FI==0 and det>=0.95
    th = np.asarray(fr["theta"])
    det = np.asarray(fr["det"])
    for name, fi in (("Med", np.asarray(fr["fi_med"])),
                     ("Long", np.asarray(fr["fi_long"]))):
        ok = (fi == 0) & (det >= 0.95)
        if ok.any():
            M(f"ThetaWin{name}Lo", f"{th[ok].min():.3g}")
            M(f"ThetaWin{name}Hi", f"{th[ok].max():.3g}")
            M(f"ThetaWin{name}N", str(int(ok.sum())))
        else:
            M(f"ThetaWin{name}Lo", "--"); M(f"ThetaWin{name}Hi", "--")
            M(f"ThetaWin{name}N", "0")
    ok_med = (np.asarray(fr["fi_med"]) == 0) & (det >= 0.95)
    mt = np.asarray(fr["mttd"])
    M("MttdScalarBest", num(np.nanmin(mt[ok_med])) if ok_med.any() else "--")
    M("SensMttdLo", num(np.nanmin(sens_mttd)))
    M("SensMttdHi", num(np.nanmax(sens_mttd)))

    # guard decision audit (S2, Q-ARTZ): per token kind over all runs
    agg = {}
    for r in raw[("S2", "B5_QARTZ")]:
        for kind, a in r.get("guard_audit", {}).items():
            g = agg.setdefault(kind, {"n": 0, "acc": 0, "reasons": {}})
            g["n"] += a["n"]; g["acc"] += a["acc"]
            for why, c in a["reasons"].items():
                g["reasons"][why] = g["reasons"].get(why, 0) + c
    for kind in ("valid", "replay", "forged", "rollback", "expired", "rebased"):
        g = agg.get(kind, {"n": 0, "acc": 0, "reasons": {}})
        K = kind.capitalize()
        M(f"GuardN{K}", str(g["n"]))
        M(f"GuardAccPct{K}", pct(g["acc"] / g["n"]) if g["n"] else "--")
        if g["reasons"]:
            tot = sum(g["reasons"].values())
            top = sorted(g["reasons"].items(), key=lambda kv: -kv[1])
            lbl = REASON_LABEL.get(top[0][0], top[0][0])
            share = f"{100*top[0][1]/tot:.0f}"
            if len(top) > 1 and top[1][1] / tot >= 0.2:
                lbl += f" / {REASON_LABEL.get(top[1][0], top[1][0])}"
                share += f"/{100*top[1][1]/tot:.0f}"
            M(f"GuardWhy{K}", lbl)
            M(f"GuardWhyPct{K}", share)
        else:
            M(f"GuardWhy{K}", "--"); M(f"GuardWhyPct{K}", "--")

    # guard-conjunct reductions: per-kind acceptance + thin-evidence entries
    for pol, short in (("A_guardSigTtl", "GvSigTtl"),
                       ("A_guardSigCtr", "GvSigCtr"),
                       ("A_guardNoGates", "GvNoGates")):
        agv = {}
        for r in raw[("S2", pol)]:
            for kind, a in r.get("guard_audit", {}).items():
                g = agv.setdefault(kind, {"n": 0, "acc": 0, "thin": 0})
                g["n"] += a["n"]; g["acc"] += a["acc"]
                g["thin"] += a.get("thin", 0)
        for kind in ("valid", "replay", "forged", "rollback", "expired",
                     "rebased"):
            g = agv.get(kind, {"n": 0, "acc": 0, "thin": 0})
            M(f"{short}Acc{kind.capitalize()}",
              pct(g["acc"] / g["n"]) if g["n"] else "--")
        gv = agv.get("valid", {"acc": 0, "thin": 0})
        M(f"{short}ThinPct",
          pct(gv["thin"] / gv["acc"]) if gv["acc"] else "--")

    # joint (LHS) robustness + governance-boundary probe
    M("JointNCfg", str(joint["ncfg"]))
    M("JointRunsFi", str(JOINT_RUNS_FI))
    M("JointRunsDg", str(JOINT_RUNS_DG))
    M("JointRunsDet", str(JOINT_RUNS_DET))
    M("JointFiWorst", f"{joint['fi_worst']:.1f}")
    M("JointFiMed", f"{joint['fi_med']:.1f}")
    M("JointDgWorst", f"{joint['dg_worst']:.1f}")
    M("JointDetWorst", f"{joint['det_worst']:.1f}")
    M("JointDetMed", f"{joint['det_med']:.1f}")
    M("JointMttdLo", f"{joint['mttd_lo']:.0f}")
    M("JointMttdHi", f"{joint['mttd_hi']:.0f}")
    M("JointEnvNViol", str(joint["env_nviol"]))
    M("JointEnvViolFiMax", f"{joint['env_viol_fi_max']:.1f}")
    M("ProbeNCfg", str(joint["probe_n"]))
    M("ProbeNFiPos", str(joint["probe_nfipos"]))
    M("ProbeFiMax", f"{joint['probe_fi_max']:.1f}")
    M("ProbeLhsFiMin", num(joint["probe_lhs_fi_min"], 2))
    M("JointOkFiMax", f"{joint['ok_fi_max']:.1f}")
    M("JointNOk", str(joint["n_ok"]))

    # parameter robustness sweeps
    for tag, row in rob.items():
        M(f"Rob{tag}Rng", row["rng"])
        M(f"Rob{tag}Fi", f"{row['fi']:.1f}")
        M(f"Rob{tag}FiAt", row["fi_at"])
        M(f"Rob{tag}Dg", f"{row['dg']:.1f}")
        M(f"Rob{tag}DgAt", row["dg_at"])
        M(f"Rob{tag}Det", f"{row['det']:.1f}")
        M(f"Rob{tag}DetAt", row["det_at"])
        M(f"Rob{tag}Mttd", f"{row['mlo']:.0f}--{row['mhi']:.0f}")
        M(f"Rob{tag}MttdLoAt", row["mlo_at"])
        M(f"Rob{tag}MttdHiAt", row["mhi_at"])
    M("RobFiMax", f"{max(r['fi'] for r in rob.values()):.1f}")
    M("RobDgMax", f"{max(r['dg'] for r in rob.values()):.1f}")
    M("RobDetMin", f"{min(r['det'] for r in rob.values()):.1f}")
    M("RobMttdLo", f"{min(r['mlo'] for r in rob.values()):.0f}")
    M("RobMttdHi", f"{max(r['mhi'] for r in rob.values()):.0f}")
    M("RobUnnMax", f"{max(r['unn'] for r in rob.values()):.1f}")

    path = _artifact_path("results_macros.tex")
    with open(path, "w", encoding="utf-8") as f:
        f.write("% auto-generated by run_experiments.py\n")
        f.write("\n".join(lines) + "\n")
    _record_output(path)
    print(f"[macros] {len(lines)} written")


def write_manifest(elapsed_seconds):
    """Write provenance for a complete Control experiment invocation."""
    path = _artifact_path("manifest.json")
    _record_output(path)

    def rel(p):
        return os.path.relpath(p, HERE).replace(os.sep, "/")

    manifest = {
        "schema_version": 1,
        "experiment": "QARTZ-Control",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": round(float(elapsed_seconds), 3),
        "script": os.path.basename(__file__),
        "software": {
            "python": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "numpy": np.__version__,
            "matplotlib": matplotlib.__version__,
        },
        "paths": {
            "results": rel(OUT),
            "figures": rel(FIG),
        },
        "seeds": {
            "trace_seed": f"{TRACE_SEED_BASE} + run_index",
            "policy_seed": f"{POLICY_SEED_BASE} + run_index",
            "joint_lhs_seed": JOINT_SEED,
            "timeline_run_index": 42,
        },
        "run_counts": {
            "aggregate_runs_per_scenario_policy": RUNS,
            "aggregate_metric_rows": RUNS * sum(
                len(policies) for policies in SCEN_POLICIES.values()),
            "frontier_runs_per_theta": FRONTIER_RUNS,
            "robustness_1d_runs_per_parameter_point": ROB_RUNS,
            "sensitivity_runs_per_grid_cell": SENS_RUNS,
            "joint_configs": JOINT_CFGS,
            "joint_probe_configs": PROBE_CFGS,
            "joint_runs_false_isolation_per_config": JOINT_RUNS_FI,
            "joint_runs_downgrade_per_config": JOINT_RUNS_DG,
            "joint_runs_detection_per_config": JOINT_RUNS_DET,
        },
        "simulation": {
            "default_steps": T,
            "long_blackout_steps": T_LONG,
            "scenario_steps": {s: SCEN_T.get(s, T) for s in SCEN_POLICIES},
            "scenario_policies": SCEN_POLICIES,
        },
        "sweeps": {
            "theta": THETAS.tolist(),
            "robustness_1d": [
                {"tag": tag, "parameter": key, "values": vals}
                for tag, key, vals in ROB_PARAMS
            ],
            "joint_seed": JOINT_SEED,
        },
        "statistics": {
            "aggregate_summary": "mean and normal-approximation 95% CI",
            "mttd_mttc": "conditional on detected/contained runs",
            "robustness_1d": (
                "per-parameter-point means, followed by extrema across points"
            ),
        },
        "output_files": sorted(rel(p) for p in _OUTPUT_FILES),
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True, ensure_ascii=False)
        f.write("\n")
    print(f"[manifest] {len(manifest['output_files'])} artifacts recorded")


if __name__ == "__main__":
    t0 = time.time()
    raw = aggregate()
    fig_timeline()
    fig_false_isolation(raw)
    fig_downgrade(raw)
    fig_mttd_cdf(raw)
    fr = theta_frontier()
    fig_frontier(fr, raw)
    sens_mttd, _ = fig_sensitivity()
    rob = param_robustness()
    joint = joint_robustness()
    macros(raw, fr, sens_mttd, rob, joint)
    elapsed = time.time() - t0
    write_manifest(elapsed)
    print(f"total {elapsed:.1f}s")
